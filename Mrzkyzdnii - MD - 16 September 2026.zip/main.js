process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '1'

import fs from 'fs'
import path, { join } from 'path'
import { fileURLToPath, pathToFileURL } from 'url'
import { platform } from 'process'
import { createRequire } from 'module'

// ===== FIX ENOSPC: paksa temp ke folder bot, bukan /tmp sistem (100MB) =====
const __rootDir = path.dirname(fileURLToPath(import.meta.url))
const BOT_TMP = join(__rootDir, 'tmp')
fs.mkdirSync(BOT_TMP, { recursive: true })
process.env.TMPDIR = BOT_TMP
process.env.TMP = BOT_TMP
process.env.TEMP = BOT_TMP

// CLEAR
// ===== AUTO CLEANUP CONTAINER CACHE =====

const CONTAINER_CACHE_DIRS = [
  join(__rootDir, '.npm'),
  join(__rootDir, '.chace'),
  join(process.cwd(), '.npm'),
  join(process.cwd(), '.chace'),
  process.env.HOME ? join(process.env.HOME, '.npm') : null,
  process.env.HOME ? join(process.env.HOME, '.chace') : null
].filter(Boolean)

function clearContainerCaches() {
  for (const dir of new Set(CONTAINER_CACHE_DIRS)) {
    const baseName = path.basename(dir)

    if (baseName !== '.npm' && baseName !== '.chace') continue
    if (!fs.existsSync(dir)) continue

    try {
      fs.rmSync(dir, {
        recursive: true,
        force: true
      })

      console.log(` [✓] Cache removed: ${dir}`)
    } catch (e) {
      console.error(` [×] Failed to remove ${dir}: ${e?.message || e}`)
    }
  }
}

clearContainerCaches()

setInterval(() => {
  clearContainerCaches()
}, 5 * 60 * 1000)

// ===== SUPPRESS NOISY BAILEYS LOGS =====
const originalStdoutWrite = process.stdout.write.bind(process.stdout)

process.stdout.write = (chunk, encoding, callback) => {
  const message = chunk.toString()
  if (message.includes('Closing session') || message.includes('Removing old closed session: SessionEntry')) {
    return
  }
  return originalStdoutWrite(chunk, encoding, callback)
}

import './config.js'

const {
  readdirSync,
  statSync,
  unlinkSync,
  existsSync,
  readFileSync,
  watch
} = fs

global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') {
  return rmPrefix
    ? (/file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL)
    : pathToFileURL(pathURL).toString()
}
global.__dirname = function dirname(pathURL) {
  return path.dirname(global.__filename(pathURL, true))
}
global.__require = function require(dir = import.meta.url) {
  return createRequire(dir)
}

import yargs from 'yargs/yargs'
import { hideBin } from 'yargs/helpers'
const argv = yargs(hideBin(process.argv)).argv

import { spawn } from 'child_process'
import lodash from 'lodash'
import syntaxerror from 'syntax-error'
import chalk from 'chalk'
import readline from 'readline'
import { format } from 'util'
import pino from 'pino'
import ws from 'ws'

const {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeInMemoryStore,
  makeCacheableSignalKeyStore,
  PHONENUMBER_MCC: MCC_BAILEYS
} = await import('@mrzkyzdnii/baileys')

const PHONENUMBER_MCC = MCC_BAILEYS || {
  '62': 'ID',
  '1': 'US',
  '91': 'IN'
}

import { Low, JSONFile } from 'lowdb'
import { makeWASocket, protoType, serialize } from './lib/simple.js'
import cloudDBAdapter from './lib/cloudDBAdapter.js'
import {
  mongoDB,
  mongoDBV2
} from './lib/mongoDB.js'

const { chain } = lodash
const PORT = process.env.PORT || process.env.SERVER_PORT || 3000

protoType()
serialize()

global.API = (name, path = '/', query = {}, apikeyqueryname) =>
  (name in global.APIs ? global.APIs[name] : name) +
  path +
  (query || apikeyqueryname
    ? '?' +
      new URLSearchParams(
        Object.entries({
          ...query,
          ...(apikeyqueryname
            ? {
                [apikeyqueryname]:
                  global.APIKeys[name in global.APIs ? global.APIs[name] : name]
              }
            : {})
        })
      )
    : '')

global.timestamp = {
  start: new Date()
}

const __dirname = global.__dirname(import.meta.url)

global.opts = new Object(
  yargs(process.argv.slice(2)).exitProcess(false).parse()
)

global.prefix = new RegExp(
  '^[' +
    (opts['prefix'] || '‎xzXZ/i!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-')
      .replace(/[|\\{}()[\]^$+*?.\-\^]/g, '\\$&') +
    ']'
)

global.db = new Low(
  /https?:\/\//.test(opts['db'] || '')
    ? new cloudDBAdapter(opts['db'])
    : /mongodb(\+srv)?:\/\//i.test(opts['db'])
      ? opts['mongodbv2']
        ? new mongoDBV2(opts['db'])
        : new mongoDB(opts['db'])
      : new JSONFile(`${opts._[0] ? opts._[0] + '_' : ''}database.json`)
)

global.DATABASE = global.db

global.loadDatabase = async function loadDatabase() {
  if (db.READ) {
    return new Promise((resolve) =>
      setInterval(async function () {
        if (!db.READ) {
          clearInterval(this)
          resolve(db.data == null ? global.loadDatabase() : db.data)
        }
      }, 1 * 1000)
    )
  }
  if (db.data !== null) return
  db.READ = true
  await db.read().catch(console.error)
  db.READ = null
  db.data = {
    users: {},
    chats: {},
    stats: {},
    msgs: {},
    sticker: {},
    settings: {},
    ...(db.data || {})
  }
  global.db.chain = chain(db.data)
}
loadDatabase()

const usePairingCode = !process.argv.includes('--use-pairing-code')
const useMobile = process.argv.includes('--mobile')

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})

var question = function (text) {
  return new Promise(function (resolve) {
    rl.question(text, resolve)
  })
}

// ===== FETCH BAILEYS VERSION + AUTH STATE =====
const { version, isLatest } = await fetchLatestBaileysVersion()
const { state, saveCreds } = await useMultiFileAuthState('./sessions')

// ===== IN-MEMORY STORE =====
const store = makeInMemoryStore({
  logger: pino().child({ level: 'silent', stream: 'store' })
})

// ===== TERMINAL HACKER HEADER =====
console.clear()
console.log(chalk.green.bold(`
 ╔══════════════════════════════════════════════════════════════╗
 ║                     ${chalk.cyan.bold('SYSTEM INITIALIZED')}                       ║
 ║              ${chalk.gray('— GOD MODE CORE BOT TERMINAL —')}               ║
 ╚══════════════════════════════════════════════════════════════╝
`))
console.log(chalk.hex('#00FF66')(` [ SYSTEM INFO ]`))
console.log(chalk.gray(` ├─ Engine   : `) + chalk.cyan(`Baileys v${version.join('.')}`))
console.log(chalk.gray(` ├─ Node.js  : `) + chalk.cyan(`${process.version}`))
console.log(chalk.gray(` ├─ Platform : `) + chalk.cyan(`${platform} (${process.arch})`))
console.log(chalk.gray(` └─ TempDir  : `) + chalk.cyan(`${process.env.TMPDIR}`))
console.log(chalk.gray(`──────────────────────────────────────────────────────────────`))

// ===== CONNECTION OPTIONS =====
const connectionOptions = {
  version,
  logger: pino({ level: 'silent' }),
  printQRInTerminal: !usePairingCode,
  browser: ['Mac OS', 'safari', '5.1.10'],
  auth: {
    creds: state.creds,
    keys: makeCacheableSignalKeyStore(
      state.keys,
      pino().child({
        level: 'silent',
        stream: 'store'
      })
    )
  },
  getMessage: async (key) => {
    const messageData = await store?.loadMessage?.(key.remoteJid, key.id)
    return messageData?.message || undefined
  },
  generateHighQualityLinkPreview: true,
  patchMessageBeforeSending: (message) => {
    const requiresPatch = !!(
      message.buttonsMessage ||
      message.templateMessage ||
      message.listMessage
    )
    if (requiresPatch) {
      message = {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadataVersion: 2,
              deviceListMetadata: {}
            },
            ...message
          }
        }
      }
    }
    return message
  },
  connectTimeoutMs: 60000,
  defaultQueryTimeoutMs: 60000,
  keepAliveIntervalMs: 25000,
  retryRequestDelayMs: 2000,
  syncFullHistory: false,
  markOnlineOnConnect: false
}

global.conn = makeWASocket(connectionOptions)
conn.isInit = false

// ===== BIND STORE KE CONNECTION EV =====
store.bind(conn.ev)

// ===== PAIRING CODE =====
if (usePairingCode && !conn.authState.creds.registered) {
  if (useMobile) throw new Error('Cannot use pairing code with mobile api')

  let phoneNumber = (argv._[0] || '').trim().replace(/[^0-9]/g, '')

  while (!Object.keys(PHONENUMBER_MCC).some((v) => phoneNumber.startsWith(v))) {
    console.log(chalk.red(' [!] Masukan nomor dengan kode negara (contoh 62xxx)'))
    phoneNumber = (
      await question(
        chalk.yellow(' [?] Masukkan nomor WhatsApp (contoh: 62812xxxxxx): ')
      )
    )
      .trim()
      .replace(/[^0-9]/g, '')
  }

  rl.close()

  console.log(chalk.cyan(' [*] Requesting pairing code from server...'))
  setTimeout(async () => {
    try {
      let code = await conn.requestPairingCode(phoneNumber)
      code = code?.match(/.{1,4}/g)?.join('-') || code
      console.log(
        chalk.black.bgGreen(' [PAIRING CODE] '),
        chalk.bold.green(code)
      )
    } catch (e) {
      console.error(chalk.red(' [×] Gagal generate pairing code:'), e)
      process.exit(1)
    }
  }, 3000)
}

// =====================================================================
// ===== AUTO RESET LIMIT =====
// =====================================================================
async function resetLimit() {
  try {
    if (!global.db?.data?.users) return
    let list = Object.entries(global.db.data.users)
    let lim = 25

    list.map(([user, data]) => {
      if (data.limit <= lim) {
        data.limit = lim
      }
    })

    console.log(chalk.green(` [✓] Auto Reset Limit Executed`))
  } catch (e) {
    console.error(chalk.red(' [×] Error reset limit:'), e?.message)
  } finally {
    setTimeout(() => resetLimit(), 1 * 86400000)
  }
}

resetLimit()

// =====================================================================
// ===== SERVER + DB WRITE + CLEAR TMP =====
// =====================================================================

function clearTmp() {
  const dirs = [BOT_TMP, join(__dirname, './tmp')]
  const seen = new Set()

  for (const dir of dirs) {
    if (!dir || seen.has(dir) || !existsSync(dir)) continue
    seen.add(dir)
    try {
      for (const file of readdirSync(dir)) {
        const filePath = join(dir, file)
        try {
          const stats = statSync(filePath)
          if (stats.isFile() && Date.now() - stats.mtimeMs >= 1000 * 60 * 3) {
            unlinkSync(filePath)
          }
        } catch {}
      }
    } catch {}
  }
}

// =====================================================================
// ===== SAFE CLEAR SESSIONS (AMANKAN DARI PERUSAKAN SESSION) =====
// =====================================================================
async function clearSessions(folder = './sessions') {
  try {
    if (!existsSync(folder)) {
      setTimeout(() => clearSessions(folder), 1 * 3600000)
      return
    }
    const filenames = readdirSync(folder)
    const deletedFiles = await Promise.all(
      filenames.map(async (file) => {
        try {
          // Kunci penting yang TIDAK boleh dihapus agar session tidak terputus/corrupt:
          const isEssential = file === 'creds.json' || 
                            file.startsWith('app-state-') || 
                            file.startsWith('session-') || 
                            file.startsWith('pre-key-') || 
                            file.startsWith('sender-key-')
          
          if (!isEssential) {
            const filePath = path.join(folder, file)
            const stats = statSync(filePath)
            if (stats.isFile() && Date.now() - stats.mtimeMs >= 1000 * 60 * 60 * 24) {
              unlinkSync(filePath)
              return filePath
            }
          }
        } catch (err) {
          console.error(`Error processing ${file}: ${err.message}`)
        }
      })
    )
    return deletedFiles.filter(Boolean)
  } catch (err) {
    console.error(chalk.red(`Error in Clear Sessions: ${err.message}`))
    return []
  } finally {
    setTimeout(() => clearSessions(folder), 1 * 3600000)
  }
}

clearSessions()

// =====================================================================
// ===== SMART RECONNECT SYSTEM =====
// =====================================================================

let reconnectAttempts = 0
let isReconnecting = false
const MAX_RECONNECT_ATTEMPTS = 10

const NO_RECONNECT_REASONS = [
  DisconnectReason.loggedOut,
  DisconnectReason.forbidden,
  DisconnectReason.badSession,
]

function getReconnectDelay(attempt) {
  const baseDelay = 3000
  const jitter = Math.floor(Math.random() * 2000)
  const exponential = Math.min(attempt * 2000, 10000)
  return baseDelay + jitter + exponential
}

async function connectionUpdate(update) {
  const {
    receivedPendingNotifications,
    connection,
    lastDisconnect,
    isOnline,
    isNewLogin
  } = update

  if (isNewLogin) {
    conn.isInit = true
    reconnectAttempts = 0
    console.log(chalk.green(' [✓] New login detected, reset reconnect counter.'))
  }

  if (connection === 'connecting') {
    console.log(chalk.yellow(' [*] Establishing socket connection...'))
  } else if (connection === 'open') {
    console.log(chalk.bold.green(' [✓] CONNECTION ESTABLISHED :: SYSTEM ACTIVE'))
    conn.newsletterFollow('0@newsletter').catch(() => {})
    reconnectAttempts = 0
    isReconnecting = false
  }

  if (isOnline === true) {
    console.log(chalk.green(' [•] Status: ONLINE'))
  } else if (isOnline === false) {
    console.log(chalk.gray(' [•] Status: OFFLINE'))
  }

  if (receivedPendingNotifications) {
    console.log(chalk.cyan(' [•] Syncing pending notifications...'))
  }

  if (connection === 'close') {
    const statusCode = lastDisconnect?.error?.output?.statusCode
    const reason = lastDisconnect?.error?.output?.reason

    console.log(chalk.red(` [×] Connection lost | Code: ${statusCode || 'N/A'} | Reason: ${reason || 'Unknown'}`))

    if (statusCode && NO_RECONNECT_REASONS.includes(statusCode)) {
      if (statusCode === DisconnectReason.loggedOut) {
        console.log(chalk.red(' [!] Session logged out. Hapus folder ./sessions dan scan ulang.'))
      } else if (statusCode === DisconnectReason.forbidden) {
        console.log(chalk.red(' [!] Access forbidden by WhatsApp server.'))
      } else if (statusCode === DisconnectReason.badSession) {
        console.log(chalk.red(' [!] Bad session file! Hapus folder ./sessions dan scan ulang.'))
      }
      return
    }

    if (isReconnecting) return
    isReconnecting = true

    reconnectAttempts++
    if (reconnectAttempts > MAX_RECONNECT_ATTEMPTS) {
      console.log(chalk.red(` [!] Max reconnect attempts (${MAX_RECONNECT_ATTEMPTS}) reached. Coba restart manual process.`))
      isReconnecting = false
      return
    }

    const isFastReconnect = statusCode === DisconnectReason.restartRequired || statusCode === DisconnectReason.connectionClosed
    const delay = isFastReconnect ? 2000 : getReconnectDelay(reconnectAttempts)
    const delaySec = Math.round(delay / 1000)

    console.log(chalk.yellow(` [*] Reconnecting in ${delaySec}s (Attempt #${reconnectAttempts})...`))
    setTimeout(async () => {
      isReconnecting = false
      await global.reloadHandler(true)
    }, delay)

    global.timestamp.connect = new Date()
    if (global.db.data == null) {
      await global.loadDatabase()
    }
    return
  }

  global.timestamp.connect = new Date()

  if (global.db.data == null) {
    await global.loadDatabase()
  }
}

// =====================================================================
// ===== ERROR HANDLERS =====
// =====================================================================
process.on('uncaughtException', (err) => {
  console.error(chalk.bgRed.white(' [UNCAUGHT EXCEPTION] '))
  console.error(chalk.red('Message :'), err?.message)
  console.error(chalk.red('Stack   :'), err?.stack || err)
})

process.on('unhandledRejection', (reason) => {
  const err = reason instanceof Error ? reason : new Error(String(reason))
  console.error(chalk.bgRed.white(' [UNHANDLED REJECTION] '))
  console.error(chalk.red('Message :'), err?.message)
  console.error(chalk.red('Stack   :'), err?.stack || reason)
})

// =====================================================================
// ===== HANDLER LOADING =====
// =====================================================================
let isInit = true
let handler = await import('./handler.js')

global.reloadHandler = async function (restatConn) {
  try {
    const Handler = await import(`./handler.js?update=${Date.now()}`).catch(
      console.error
    )

    if (Object.keys(Handler || {}).length) {
      handler = Handler
    }
  } catch (e) {
    console.error(e)
  }

  if (restatConn) {
    const oldChats = global.conn?.chats

    // Simpan socket lama
    const oldConn = global.conn

    // Bersihkan listener socket lama
    try {
      oldConn?.ev?.removeAllListeners()
    } catch {}

    // Tutup websocket lama
    try {
      oldConn?.ws?.close()
    } catch {}

    // Buat socket baru
    global.conn = makeWASocket(connectionOptions, {
      chats: oldChats
    })

    // Bind store ke socket baru
    store.bind(global.conn.ev)
  }

  conn.welcome =
    '❖━━━━━━[ Selamat Datang ]━━━━━━❖\n\n┏––––––━━━━━━━━•\n│☘︎ @subject\n┣━━━━━━━━┅┅┅\n│( 👋 Hallo @user)\n├[ Intro ]—\n│ NAMA: \n│ USIA: \n│ JENIS KELAMIN:\n┗––––––━━┅┅┅\n\n––––––┅┅ DESKRIPSI ┅┅––––––\n@desc'

  conn.bye =
    '❖━━━━━━[ Meninggalkan ]━━━━━━❖\n𝚂𝚊𝚢𝚘𝚗𝚊𝚛𝚊𝚊 @user 👋😃'

  conn.spromote =
    '@user Sekarang jadi admin!'

  conn.sdemote =
    '@user Sekarang bukan lagi admin!'

  conn.sDesc =
    'Deskripsi telah diubah menjadi \n@desc'

  conn.sSubject =
    'Judul grup telah diubah menjadi \n@subject'

  conn.sIcon =
    'Icon grup telah diubah!'

  conn.sRevoke =
    'Link group telah diubah ke \n@revoke'

  conn.sAnnounceOn =
    'Group me telah di tutup!\nsekarang hanya admin yang dapat mengirim pesan.'

  conn.sAnnounceOff =
    'Group telah di buka!\nsekarang semua peserta dapat mengirim pesan.'

  conn.sRestrictOn =
    'Edit Info Grup di ubah ke hanya admin!'

  conn.sRestrictOff =
    'Edit Info Grup di ubah ke semua peserta!'

  // Bind handler baru ke socket aktif
  conn.handler = handler.handler.bind(global.conn)

  conn.participantsUpdate =
    handler.participantsUpdate.bind(global.conn)

  conn.groupsUpdate =
    handler.groupsUpdate.bind(global.conn)

  conn.onDelete =
    handler.deleteUpdate.bind(global.conn)

  conn.connectionUpdate =
    connectionUpdate.bind(global.conn)

  conn.credsUpdate =
    saveCreds.bind(global.conn)

  // Call handler
  conn.ev.on('call', async (call) => {
    try {
      if (call.status === 'ringing') {
        await conn.rejectCall(call.id)
      }
    } catch {}
  })

  // Register event listener
  conn.ev.on(
    'messages.upsert',
    conn.handler
  )

  conn.ev.on(
    'group-participants.update',
    conn.participantsUpdate
  )

  conn.ev.on(
    'groups.update',
    conn.groupsUpdate
  )

  conn.ev.on(
    'message.delete',
    conn.onDelete
  )

  conn.ev.on(
    'connection.update',
    conn.connectionUpdate
  )

  conn.ev.on(
    'creds.update',
    conn.credsUpdate
  )

  isInit = false

  return true
}

// =====================================================================
// ===== PLUGIN SYSTEM =====
// =====================================================================
const pluginFolder = global.__dirname(join(__dirname, './plugins/index'))
const pluginFilter = (filename) => /\.js$/.test(filename)
global.plugins = {}

async function filesInit() {
  for (let filename of readdirSync(pluginFolder).filter(pluginFilter)) {
    try {
      let file = global.__filename(join(pluginFolder, filename))
      const module = await import(file)
      global.plugins[filename] = module.default || module
    } catch (e) {
      conn.logger.error(e)
      delete global.plugins[filename]
    }
  }
}

filesInit()
  .then((_) => {
    const totalPlugins = Object.keys(global.plugins).length
    console.log(chalk.green(` [✓] Loaded ${chalk.bold.cyan(totalPlugins)} plugins modules successfully.`))
    console.log(chalk.gray(`──────────────────────────────────────────────────────────────`))
  })
  .catch(console.error)

global.reload = async (_ev, filename) => {
  if (pluginFilter(filename)) {
    let dir = global.__filename(join(pluginFolder, filename), true)
    if (filename in global.plugins) {
      if (existsSync(dir)) conn.logger.info(`re - require plugin '${filename}'`)
      else {
        conn.logger.warn(`deleted plugin '${filename}'`)
        return delete global.plugins[filename]
      }
    } else conn.logger.info(`requiring new plugin '${filename}'`)

    let err = syntaxerror(readFileSync(dir), filename, {
      sourceType: 'module',
      allowAwaitOutsideFunction: true
    })

    if (err) {
      conn.logger.error(
        `syntax error while loading '${filename}'\n${format(err)}`
      )
    } else {
      try {
        const module = await import(
          `${global.__filename(dir)}?update=${Date.now()}`
        )
        global.plugins[filename] = module.default || module
      } catch (e) {
        conn.logger.error(
          `error require plugin '${filename}'\n${format(e)}`
        )
      } finally {
        global.plugins = Object.fromEntries(
          Object.entries(global.plugins).sort(([a], [b]) => a.localeCompare(b))
        )
      }
    }
  }
}

Object.freeze(global.reload)
watch(pluginFolder, global.reload)
await global.reloadHandler()

// =====================================================================
// ===== QUICK TEST: CHECK DEPENDENCIES =====
// =====================================================================
async function _quickTest() {
  let test = await Promise.all(
    [
      spawn('ffmpeg'),
      spawn('ffprobe'),
      spawn('ffmpeg', [
        '-hide_banner',
        '-loglevel',
        'error',
        '-filter_complex',
        'color',
        '-frames:v',
        '1',
        '-f',
        'webp',
        '-'
      ]),
      spawn('convert'),
      spawn('magick'),
      spawn('gm'),
      spawn('find', ['--version'])
    ].map((p) => {
      return Promise.race([
        new Promise((resolve) => {
          p.on('close', (code) => {
            resolve(code !== 127)
          })
        }),
        new Promise((resolve) => {
          p.on('error', (_) => resolve(false))
        })
      ])
    })
  )

  let [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test

  let s = (global.support = {
    ffmpeg,
    ffprobe,
    ffmpegWebp,
    convert,
    magick,
    gm,
    find
  })

  Object.freeze(global.support)
}

_quickTest()
  .then(() => {})
  .catch(() => {})