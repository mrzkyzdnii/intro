import WebSocket from 'ws'

const WS_URL = 'wss://wss-1-et4s.onrender.com/ws'
const connections = new Map()

function createId() {
    return 'ninja-' + Math.random().toString(36).slice(2, 10)
}

function connect(room, name = 'NinjaBot') {
    const old = connections.get(room)
    if (old?.ws && old.ws.readyState === WebSocket.OPEN) {
        return old
    }

    const id = createId()
    const ws = new WebSocket(WS_URL)
    const client = {
        ws,
        room,
        id,
        name,
        x: 180,
        y: 515,
        dir: 1,
        score: 0,
        best: 0,
        gameOver: false,
        dashCooldown: 0,
        rocks: []
    }

    connections.set(room, client)

    ws.on('open', () => {
        console.log(`[NINJA] Connected → ${WS_URL}`)
        ws.send(JSON.stringify({
            type: 'join',
            room,
            id,
            name,
            color: '#ff3b3b',
            x: client.x,
            y: client.y,
            dir: client.dir
        }))
    })

    ws.on('message', raw => {
        try {
            const data = JSON.parse(raw.toString())
            if (data.type === 'ninja_event') {
                handleNinjaEvent(data, room)
            }
        } catch (e) {
            console.log('[NINJA] Error:', e.message)
        }
    })

    ws.on('error', err => {
        console.log('[NINJA ERROR]', err.message)
    })

    ws.on('close', () => {
        console.log(`[NINJA] Disconnected room=${room}`)
        if (connections.get(room)?.id === id) {
            connections.delete(room)
        }
    })

    return client
}

function send(room, data) {
    const client = connections.get(room)
    if (!client) throw new Error(`Belum connect ke room ${room}`)
    if (client.ws.readyState !== WebSocket.OPEN) throw new Error(`WebSocket ${room} belum OPEN`)
    client.ws.send(JSON.stringify({ room, id: client.id, name: client.name, ...data }))
}

function handleNinjaEvent(data, room) {
    const client = connections.get(room)
    if (!client) return
    
    switch(data.action) {
        case 'move':
            client.x = data.x
            client.y = data.y
            break
        case 'dash':
            console.log(`⚡ ${data.player} melakukan dash!`)
            break
        case 'score':
            if (data.score > client.best) client.best = data.score
            client.score = data.score
            break
        case 'gameover':
            client.gameOver = true
            break
    }
}

// MAIN HANDLER
let handler = async (m, { conn, text, usedPrefix, command }) => {
    await m.react('🥷')

    if (!text) {
        return conn.reply(m.chat,
            `╭─「 🥷 NINJA DODGE 」\n` +
            `│\n` +
            `│ ${usedPrefix + command} join ROOM\n` +
            `│ ${usedPrefix + command} play ROOM\n` +
            `│ ${usedPrefix + command} move ROOM LEFT|RIGHT\n` +
            `│ ${usedPrefix + command} dash ROOM\n` +
            `│ ${usedPrefix + command} score ROOM SCORE\n` +
            `│ ${usedPrefix + command} close ROOM\n` +
            `│ ${usedPrefix + command} list\n` +
            `│\n` +
            `╰──────────────`, m
        )
    }

    const args = text.trim().split(/\s+/)
    const action = args.shift()?.toLowerCase()

    try {
        if (action === 'join') {
            const room = args.shift()?.toUpperCase().replace(/[^A-Z0-9_-]/g, '')
            if (!room) {
                return conn.reply(m.chat, `Contoh: ${usedPrefix + command} join ARENA`, m)
            }

            if (connections.get(room)?.ws?.readyState === WebSocket.OPEN) {
                return conn.reply(m.chat, `⚠️ Sudah terhubung ke *${room}*.`, m)
            }

            connect(room, 'NinjaBot')
            
            // Kirim rich message game
            await conn.relayMessage(m.chat, {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "ninja-" + Date.now(),
                        verificationMetadata: {
                            proofs: [{
                                version: 1,
                                useCase: 1,
                                signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                certificateChain: ["TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfo8Nw1qxFwg5OU2cq1y1bWNBELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vVJSKkrMz6lTxZM8IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2kLmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg"]
                            }]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{
                                messageType: 2,
                                messageText: "🥷 Ninja Dodge"
                            }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "ninja-" + Date.now(),
                                    "sections": [{
                                        "view_model": {
                                            "primitive": {
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive",
                                                "payload": generateGameHTML(room),
                                                "trusted_sources": ["adam.dev"]
                                            },
                                            "__typename": "GenAISingleLayoutViewModel"
                                        }
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            }, {})

            return conn.reply(m.chat,
                `✅ *Ninja Dodge Ready!*\n\n` +
                `Room: *${room}*\n` +
                `Gunakan: ${usedPrefix + command} move ${room} LEFT/RIGHT\n` +
                `Dash: ${usedPrefix + command} dash ${room}\n` +
                `Update Score: ${usedPrefix + command} score ${room} SKOR`, m
            )
        }

        if (action === 'move') {
            const room = args.shift()?.toUpperCase()
            const direction = args.shift()?.toLowerCase()
            
            if (!room || !['left', 'right'].includes(direction)) {
                return conn.reply(m.chat, `Contoh: ${usedPrefix + command} move ARENA LEFT`, m)
            }

            const client = connections.get(room)
            if (!client) {
                return conn.reply(m.chat, `❌ Belum connect ke ${room}.\nGunakan: ${usedPrefix + command} join ${room}`, m)
            }

            const dir = direction === 'left' ? -1 : 1
            client.x += dir * 48
            client.x = Math.max(8, Math.min(352, client.x))

            send(room, {
                type: 'ninja_event',
                action: 'move',
                x: client.x,
                y: client.y
            })

            // Update game dengan posisi baru
            await updateGame(conn, m.chat, room, client)

            return conn.reply(m.chat,
                `🥷 *Ninja ${direction.toUpperCase()}*\n` +
                `📍 Posisi: ${client.x}, ${client.y}\n` +
                `🏆 Score: ${client.score || 0}`, m
            )
        }

        if (action === 'dash') {
            const room = args.shift()?.toUpperCase()
            if (!room) {
                return conn.reply(m.chat, `Contoh: ${usedPrefix + command} dash ARENA`, m)
            }

            const client = connections.get(room)
            if (!client) {
                return conn.reply(m.chat, `❌ Belum connect ke ${room}`, m)
            }

            send(room, {
                type: 'ninja_event',
                action: 'dash',
                player: 'NinjaBot'
            })

            // Efek dash di game
            await conn.relayMessage(m.chat, {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "dash-" + Date.now(),
                        verificationMetadata: {
                            proofs: [{
                                version: 1,
                                useCase: 1,
                                signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                certificateChain: ["TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfo8Nw1qxFwg5OU2cq1y1bWNBELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vVJSKkrMz6lTxZM8IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2kLmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg"]
                            }]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{
                                messageType: 2,
                                messageText: "⚡ DASH!"
                            }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "dash-" + Date.now(),
                                    "sections": [{
                                        "view_model": {
                                            "primitive": {
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive",
                                                "payload": generateDashEffect(room),
                                                "trusted_sources": ["adam.dev"]
                                            },
                                            "__typename": "GenAISingleLayoutViewModel"
                                        }
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            }, {})

            return conn.reply(m.chat, `⚡ *DASH!* Ninja menghindar dengan cepat!`, m)
        }

        if (action === 'score') {
            const room = args.shift()?.toUpperCase()
            const score = parseInt(args.shift())
            
            if (!room || isNaN(score)) {
                return conn.reply(m.chat, `Contoh: ${usedPrefix + command} score ARENA 100`, m)
            }

            const client = connections.get(room)
            if (client) {
                client.score = score
                if (score > client.best) client.best = score
                
                send(room, {
                    type: 'ninja_event',
                    action: 'score',
                    score: score
                })
            }

            return conn.reply(m.chat,
                `📊 *Score Updated*\n` +
                `🏆 Score: *${score}*\n` +
                `👑 Best: *${client?.best || 0}*`, m
            )
        }

        if (action === 'close') {
            const room = args.shift()?.toUpperCase()
            if (!room) {
                return conn.reply(m.chat, `Contoh: ${usedPrefix + command} close ARENA`, m)
            }

            const client = connections.get(room)
            if (!client) {
                return conn.reply(m.chat, `❌ Tidak ada koneksi *${room}*.`, m)
            }

            client.ws.close()
            connections.delete(room)

            return conn.reply(m.chat, `🔌 Koneksi *${room}* ditutup.`, m)
        }

        if (action === 'list') {
            if (!connections.size) {
                return conn.reply(m.chat, `📭 Tidak ada koneksi aktif.`, m)
            }

            const list = []
            for (const [room, client] of connections) {
                const status = client.ws.readyState === WebSocket.OPEN ? '🟢' : '🔴'
                list.push(
                    `• ${status} *${room}*\n` +
                    `  📍 ${client.x}, ${client.y}\n` +
                    `  🏆 ${client.score || 0} | Best: ${client.best || 0}`
                )
            }

            return conn.reply(m.chat,
                `╭─「 🥷 NINJA CONNECTIONS 」\n│\n${list.join('\n│\n')}\n│\n╰──────────────`, m
            )
        }

        return conn.reply(m.chat,
            `❌ Action tidak dikenal: *${action}*\n\nGunakan: ${usedPrefix + command}`, m
        )

    } catch (e) {
        console.error('[NINJA ERROR]', e)
        return conn.reply(m.chat, `❌ *Error*\n\n${e.message}`, m)
    }
}

// Fungsi generate HTML game
function generateGameHTML(room) {
    return `{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#08080d;display:flex;justify-content:center;align-items:center;min-height:100vh;font-family:Arial,sans-serif;touch-action:none}
.game-container{background:#0d0d1a;border-radius:20px;padding:15px;box-shadow:0 0 40px rgba(255,50,50,0.15),inset 0 0 40px rgba(255,50,50,0.05);max-width:420px;width:100%}
.game-header{display:flex;justify-content:space-between;align-items:center;padding:0 5px 10px 5px;color:#fff}
.game-header .title{font-size:18px;font-weight:bold;background:linear-gradient(45deg,#ff3b3b,#ff6b3b);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.game-header .scores{display:flex;gap:20px;font-size:14px}
.game-header .scores span{color:#888}
.game-header .scores .score{color:#ff6b3b;font-weight:bold}
.game-header .scores .best{color:#ffd700;font-weight:bold}
canvas{display:block;width:100%;height:auto;border-radius:12px;background:#08080d;touch-action:none;cursor:pointer}
.controls{display:flex;justify-content:space-between;align-items:center;padding:12px 5px 5px 5px;gap:10px}
.controls button{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.08);color:#fff;padding:12px 20px;border-radius:12px;font-size:16px;font-weight:bold;cursor:pointer;flex:1;transition:all 0.15s;min-height:55px;touch-action:none;backdrop-filter:blur(4px)}
.controls button:active{transform:scale(0.92);background:rgba(255,255,255,0.12)}
.controls .dash-btn{background:rgba(180,92,255,0.15);border-color:rgba(180,92,255,0.25);color:#b45cff;font-size:14px}
.controls .dash-btn:active{background:rgba(180,92,255,0.3)}
.controls .arrow-btn{font-size:22px;padding:12px 16px;flex:0.8}
.controls .arrow-btn:active{background:rgba(255,255,255,0.12)}
.hint{text-align:center;color:#444;font-size:11px;padding:8px 0 2px 0;letter-spacing:0.5px}
.hint span{color:#666}
</style>
<div class="game-container">
<div class="game-header">
<div class="title">🥷 NINJA DODGE</div>
<div class="scores">
<span>🏆 <span class="score" id="scoreDisplay">0</span></span>
<span>👑 <span class="best" id="bestDisplay">0</span></span>
</div>
</div>
<canvas id="gameCanvas" width="400" height="600"></canvas>
<div class="controls">
<button class="arrow-btn" id="leftBtn">◀</button>
<button class="dash-btn" id="dashBtn">⚡ DASH</button>
<button class="arrow-btn" id="rightBtn">▶</button>
</div>
<div class="hint">◀ ▶ Gerak • <span>⚡ Dash menghindar</span></div>
</div>
<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreEl = document.getElementById('scoreDisplay');
const bestEl = document.getElementById('bestDisplay');

// Game state
let player, rocks, score, best = 0, gameOver, frame, speed, dashTime, dashCooldown, stars;

// Load best score
try {
    let v = localStorage.getItem('ninja_best');
    if (v) best = parseInt(v) || 0;
} catch(e) {}
bestEl.textContent = best;

function reset() {
    player = { x: 180, y: 515, w: 40, h: 55 };
    rocks = [];
    stars = [];
    score = 0;
    gameOver = false;
    frame = 0;
    speed = 3;
    dashTime = 0;
    dashCooldown = 0;
    scoreEl.textContent = '0';
    for (let i = 0; i < 45; i++) {
        stars.push({ x: Math.random() * 400, y: Math.random() * 600, s: Math.random() * 2 + 1 });
    }
}

function addRock() {
    let size = 22 + Math.random() * 18;
    rocks.push({
        x: 10 + Math.random() * (400 - size - 20),
        y: -size,
        size: size,
        vy: speed + Math.random() * 2,
        rot: Math.random() * 6.28
    });
}

function hit(a, b) {
    return a.x + 6 < b.x + b.size - 5 && a.x + a.w - 6 > b.x + 5 &&
           a.y + 7 < b.y + b.size - 5 && a.y + a.h - 7 > b.y + 5;
}

function move(dir) {
    if (gameOver) { reset(); return; }
    player.x += dir * 48;
    if (player.x < 8) player.x = 8;
    if (player.x > 352) player.x = 352;
}

function dash() {
    if (gameOver) { reset(); return; }
    if (dashCooldown <= 0) {
        dashTime = 25;
        dashCooldown = 100;
    }
}

function update() {
    if (gameOver) return;
    frame++;
    if (frame % 35 === 0) addRock();
    if (dashCooldown > 0) dashCooldown--;
    if (dashTime > 0) dashTime--;
    speed = 3 + score / 180;
    for (let r of rocks) {
        r.y += r.vy + (dashTime > 0 ? 1 : 0);
        r.rot += 0.08;
    }
    rocks = rocks.filter(r => r.y < 650);
    if (dashTime <= 0) {
        for (let r of rocks) {
            if (hit(player, r)) {
                gameOver = true;
                if (score > best) {
                    best = score;
                    bestEl.textContent = best;
                    try { localStorage.setItem('ninja_best', String(best)); } catch(e) {}
                }
            }
        }
    }
    for (let s of stars) {
        s.y += speed * 0.25;
        if (s.y > 600) { s.y = 0; s.x = Math.random() * 400; }
    }
    if (frame % 5 === 0) {
        score++;
        scoreEl.textContent = score;
        if (score > best) {
            best = score;
            bestEl.textContent = best;
            try { localStorage.setItem('ninja_best', String(best)); } catch(e) {}
        }
    }
}

function drawPlayer() {
    ctx.save();
    ctx.translate(player.x + 20, player.y + 27);
    if (dashTime > 0) {
        ctx.shadowColor = '#b45cff';
        ctx.shadowBlur = 30;
    }
    // Body
    ctx.fillStyle = '#16161f';
    ctx.beginPath();
    ctx.arc(0, 0, 21, 0, Math.PI * 2);
    ctx.fill();
    // Head
    ctx.fillStyle = '#ddd';
    ctx.beginPath();
    ctx.arc(0, -3, 15, 0, Math.PI * 2);
    ctx.fill();
    // Eyes
    ctx.fillStyle = '#111';
    ctx.fillRect(-14, -5, 28, 8);
    ctx.fillStyle = '#ff3030';
    ctx.fillRect(-11, -3, 7, 3);
    ctx.fillRect(4, -3, 7, 3);
    // Body
    ctx.fillStyle = '#242432';
    ctx.fillRect(-17, 17, 12, 18);
    ctx.fillRect(5, 17, 12, 18);
    // Arms
    ctx.fillStyle = '#aaa';
    ctx.fillRect(-21, 11, 8, 5);
    ctx.fillRect(13, 11, 8, 5);
    ctx.restore();
}

function drawRock(r) {
    ctx.save();
    ctx.translate(r.x + r.size/2, r.y + r.size/2);
    ctx.rotate(r.rot);
    ctx.shadowColor = 'rgba(255,50,50,0.8)';
    ctx.shadowBlur = 14;
    ctx.fillStyle = '#ff3b3b';
    ctx.beginPath();
    ctx.moveTo(-r.size/2, 0);
    ctx.lineTo(-r.size*0.25, -r.size/2);
    ctx.lineTo(r.size*0.25, -r.size*0.42);
    ctx.lineTo(r.size/2, 0);
    ctx.lineTo(r.size*0.22, r.size/2);
    ctx.lineTo(-r.size*0.3, r.size*0.35);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#ff9b3b';
    ctx.beginPath();
    ctx.arc(-4, -3, 3, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

function draw() {
    ctx.clearRect(0, 0, 400, 600);
    ctx.fillStyle = '#08080d';
    ctx.fillRect(0, 0, 400, 600);
    // Stars
    for (let s of stars) {
        ctx.fillStyle = 'rgba(255,255,255,0.45)';
        ctx.fillRect(s.x, s.y, s.s, s.s);
    }
    // Glow
    ctx.fillStyle = 'rgba(120,60,180,0.08)';
    ctx.beginPath();
    ctx.arc(200, 300, 220, 0, Math.PI * 2);
    ctx.fill();
    // Rocks
    for (let r of rocks) drawRock(r);
    // Player
    drawPlayer();
    // Dash effect
    if (dashTime > 0) {
        ctx.strokeStyle = 'rgba(190,90,255,0.8)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(player.x + 20, player.y + 27, 32 + Math.random() * 4, 0, Math.PI * 2);
        ctx.stroke();
    }
    // Game over
    if (gameOver) {
        ctx.fillStyle = 'rgba(0,0,0,0.72)';
        ctx.fillRect(0, 0, 400, 600);
        ctx.fillStyle = '#fff';
        ctx.textAlign = 'center';
        ctx.font = 'bold 30px Arial';
        ctx.fillText('YOU DIED', 200, 260);
        ctx.font = '18px Arial';
        ctx.fillText('Score: ' + score, 200, 300);
        ctx.font = '14px Arial';
        ctx.fillStyle = 'rgba(255,255,255,0.7)';
        ctx.fillText('Tap untuk main lagi', 200, 340);
        ctx.textAlign = 'left';
    }
}

function loop() {
    update();
    draw();
    requestAnimationFrame(loop);
}

// Controls
document.getElementById('leftBtn').addEventListener('pointerdown', e => { e.preventDefault(); move(-1); });
document.getElementById('rightBtn').addEventListener('pointerdown', e => { e.preventDefault(); move(1); });
document.getElementById('dashBtn').addEventListener('pointerdown', e => { e.preventDefault(); dash(); });

// Keyboard
document.addEventListener('keydown', e => {
    if (e.key === 'ArrowLeft' || e.key === 'a') move(-1);
    if (e.key === 'ArrowRight' || e.key === 'd') move(1);
    if (e.code === 'Space') dash();
});

// Click canvas to restart
document.addEventListener('pointerdown', e => {
    if (e.target === canvas && gameOver) reset();
});

reset();
loop();
</script>`;
}

// Fungsi generate efek dash
function generateDashEffect(room) {
    return `{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{background:#08080d;display:flex;justify-content:center;align-items:center;min-height:100vh;font-family:Arial,sans-serif}
.dash-container{background:linear-gradient(135deg,#0d0d1a,#1a0d2a);border-radius:20px;padding:40px;text-align:center;max-width:400px;width:100%;border:1px solid rgba(180,92,255,0.2)}
.dash-icon{font-size:80px;display:block;animation:pulse 0.5s ease-in-out infinite alternate}
@keyframes pulse{from{transform:scale(1);opacity:0.7}to{transform:scale(1.2);opacity:1}}
.dash-text{color:#b45cff;font-size:28px;font-weight:bold;margin:15px 0;text-shadow:0 0 30px rgba(180,92,255,0.3)}
.dash-sub{color:#888;font-size:14px}
.dash-room{color:#555;font-size:12px;margin-top:10px}
</style>
<div class="dash-container">
<span class="dash-icon">⚡</span>
<div class="dash-text">DASH!</div>
<div class="dash-sub">Ninja menghindar dengan cepat</div>
<div class="dash-room">Room: ${room}</div>
</div>`;
}

// Fungsi update game
async function updateGame(conn, chatId, room, client) {
    // Kirim update posisi via rich message jika diperlukan
    // Ini bisa digunakan untuk update UI game
}

handler.help = ['ninja']
handler.tags = ['game']
handler.command = /^ninja$/i
handler.limit = 10

export default handler