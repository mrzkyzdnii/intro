import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import axios from 'axios'

const W = 1080
const H = 681

// Register font kalau tersedia di server
try {
    GlobalFonts.registerFromPath(
        './src/font/DejaVuSans.ttf',
        'UI Sans'
    )

    GlobalFonts.registerFromPath(
        './src/font/DejaVuSans-Bold.ttf',
        'UI Sans'
    )
} catch {}

const makeFakeTikTok = async ({
    name = 'Mrzkyzdnii',
    username = 'mrizkyzadani',
    following = '390',
    followers = '39',
    likes = '50',
    bio = 'git commit -m "another day"',
    avatarInput = null
}) => {
    const canvas = createCanvas(W, H)
    const ctx = canvas.getContext('2d')

    ctx.fillStyle = '#000000'
    ctx.fillRect(0, 0, W, H)

    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'

    // =========================
    // HELPER
    // =========================

    const text = (
        value,
        x,
        y,
        size,
        color = '#f5f5f5',
        weight = '400',
        align = 'left'
    ) => {
        ctx.font = `${weight} ${size}px "UI Sans", sans-serif`
        ctx.fillStyle = color
        ctx.textAlign = align
        ctx.textBaseline = 'alphabetic'
        ctx.fillText(String(value ?? ''), x, y)
    }

    const stroke = (color, width = 4) => {
        ctx.strokeStyle = color
        ctx.lineWidth = width
        ctx.fillStyle = 'transparent'
    }

    const roundRect = (
        x,
        y,
        w,
        h,
        r,
        fill,
        line,
        lineWidth = 1
    ) => {
        ctx.beginPath()
        ctx.roundRect(x, y, w, h, r)

        if (fill) {
            ctx.fillStyle = fill
            ctx.fill()
        }

        if (line) {
            ctx.strokeStyle = line
            ctx.lineWidth = lineWidth
            ctx.stroke()
        }
    }

    // =========================
    // EDIT ICON
    // =========================

    const drawEdit = () => {
        stroke('#eeeeee', 5)

        ctx.beginPath()
        ctx.moveTo(48, 80)
        ctx.lineTo(78, 50)
        ctx.lineTo(88, 60)
        ctx.lineTo(58, 90)
        ctx.lineTo(45, 94)
        ctx.closePath()
        ctx.stroke()

        ctx.beginPath()
        ctx.moveTo(70, 58)
        ctx.lineTo(80, 68)
        ctx.stroke()
    }

    // =========================
    // MENU
    // =========================

    const drawMenu = () => {
        stroke('#eeeeee', 5)

        for (const y of [49, 65, 81]) {
            ctx.beginPath()
            ctx.moveTo(991, y)
            ctx.lineTo(1031, y)
            ctx.stroke()
        }
    }

    // =========================
    // ADD PERSON
    // =========================

    const drawAddPerson = () => {
        stroke('#eeeeee', 4)

        ctx.beginPath()
        ctx.arc(908, 49, 10, 0, Math.PI * 2)
        ctx.stroke()

        ctx.beginPath()
        ctx.arc(
            908,
            78,
            17,
            Math.PI * 1.12,
            Math.PI * 1.88
        )
        ctx.stroke()

        ctx.beginPath()
        ctx.moveTo(935, 71)
        ctx.lineTo(935, 90)
        ctx.moveTo(926, 80)
        ctx.lineTo(944, 80)
        ctx.stroke()
    }

    // =========================
    // BOTTOM TABS
    // =========================

    const drawTabs = () => {
        const c = '#8d8d8d'

        stroke('#f1f1f1', 5)

        for (const x of [117, 133, 149]) {
            ctx.beginPath()
            ctx.moveTo(x, 625)
            ctx.lineTo(x, 662)
            ctx.stroke()
        }

        ctx.fillStyle = '#f1f1f1'

        ctx.beginPath()
        ctx.moveTo(164, 640)
        ctx.lineTo(178, 640)
        ctx.lineTo(171, 649)
        ctx.closePath()
        ctx.fill()

        stroke(c, 5)

        // Shop
        ctx.beginPath()
        ctx.moveTo(332, 641)
        ctx.lineTo(332, 659)
        ctx.quadraticCurveTo(332, 664, 338, 664)
        ctx.lineTo(355, 664)
        ctx.quadraticCurveTo(361, 664, 361, 659)
        ctx.lineTo(361, 641)
        ctx.stroke()

        ctx.beginPath()
        ctx.arc(347, 635, 11, Math.PI, 0)
        ctx.stroke()

        // Repost
        ctx.beginPath()
        ctx.moveTo(525, 632)
        ctx.lineTo(535, 626)
        ctx.lineTo(540, 638)

        ctx.moveTo(535, 626)
        ctx.lineTo(535, 653)

        ctx.quadraticCurveTo(
            535,
            660,
            542,
            660
        )

        ctx.lineTo(550, 660)

        ctx.moveTo(550, 660)
        ctx.lineTo(558, 653)

        ctx.moveTo(558, 653)
        ctx.lineTo(555, 666)

        ctx.lineTo(545, 661)

        ctx.stroke()

        // Bookmark
        ctx.beginPath()
        ctx.moveTo(725, 626)
        ctx.lineTo(739, 626)
        ctx.lineTo(754, 626)
        ctx.lineTo(754, 654)
        ctx.lineTo(740, 647)
        ctx.lineTo(725, 658)
        ctx.closePath()
        ctx.stroke()

        // Likes
        ctx.beginPath()
        ctx.moveTo(919, 635)

        ctx.bezierCurveTo(
            919,
            621,
            939,
            619,
            940,
            634
        )

        ctx.bezierCurveTo(
            942,
            619,
            962,
            622,
            960,
            637
        )

        ctx.bezierCurveTo(
            958,
            651,
            940,
            663,
            940,
            663
        )

        ctx.bezierCurveTo(
            940,
            663,
            921,
            650,
            919,
            635
        )

        ctx.stroke()
    }

    // =========================
    // AVATAR
    // =========================

    const drawAvatar = async () => {
        let avatarImg = null

        if (avatarInput) {
            try {
                if (Buffer.isBuffer(avatarInput)) {
                    avatarImg = await loadImage(avatarInput)
                } else if (
                    typeof avatarInput === 'string' &&
                    avatarInput.trim().startsWith('http')
                ) {
                    const res = await axios.get(
                        avatarInput.trim(),
                        {
                            responseType: 'arraybuffer',
                            timeout: 15000
                        }
                    )

                    avatarImg = await loadImage(
                        Buffer.from(res.data)
                    )
                }
            } catch (e) {
                console.log(
                    'Avatar gagal dimuat:',
                    e.message
                )
            }
        }

        // Lingkaran avatar
        ctx.save()

        ctx.beginPath()
        ctx.arc(
            930,
            286,
            96,
            0,
            Math.PI * 2
        )
        ctx.clip()

        if (avatarImg) {
            // Cover image
            const targetSize = 192

            const aspect =
                avatarImg.width / avatarImg.height

            let drawW = targetSize
            let drawH = targetSize

            if (aspect > 1) {
                drawH = targetSize
                drawW = targetSize * aspect
            } else {
                drawW = targetSize
                drawH = targetSize / aspect
            }

            const drawX =
                930 - drawW / 2

            const drawY =
                286 - drawH / 2

            ctx.drawImage(
                avatarImg,
                drawX,
                drawY,
                drawW,
                drawH
            )
        } else {
            // Fallback avatar
            ctx.fillStyle = '#252525'
            ctx.fillRect(
                834,
                190,
                192,
                192
            )

            const initial =
                String(name || 'U')
                    .trim()
                    .charAt(0)
                    .toUpperCase()

            text(
                initial,
                930,
                315,
                95,
                '#ffffff',
                '700',
                'center'
            )
        }

        ctx.restore()

        // Border avatar
        ctx.lineWidth = 2
        ctx.strokeStyle = '#151515'

        ctx.beginPath()
        ctx.arc(
            930,
            286,
            96,
            0,
            Math.PI * 2
        )
        ctx.stroke()

        // Add button
        ctx.fillStyle = '#08bde6'

        ctx.beginPath()
        ctx.arc(
            1013,
            357,
            29,
            0,
            Math.PI * 2
        )
        ctx.fill()

        text(
            '+',
            1013,
            369,
            42,
            '#ffffff',
            '700',
            'center'
        )
    }

    // =========================
    // BUTTONS
    // =========================

    const drawOrderButtons = () => {
        roundRect(
            38,
            506,
            276,
            67,
            34,
            null,
            '#454545',
            1
        )

        roundRect(
            334,
            506,
            279,
            67,
            34,
            null,
            '#454545',
            1
        )

        text(
            '♟',
            58,
            551,
            27,
            '#f51b65',
            '700'
        )

        text(
            'TikTok Studio',
            96,
            551,
            29,
            '#f5f5f5',
            '700'
        )

        text(
            '♙',
            356,
            550,
            28,
            '#f51b65',
            '700'
        )

        text(
            'Your orders',
            392,
            551,
            29,
            '#f5f5f5',
            '700'
        )

        ctx.fillStyle = '#f51b65'

        ctx.beginPath()
        ctx.arc(
            581,
            529,
            10,
            0,
            Math.PI * 2
        )
        ctx.fill()
    }

    // =========================
    // RENDER
    // =========================

    drawEdit()
    drawAddPerson()
    drawMenu()

    // =========================
    // NAME
    // =========================

    const displayName =
        String(name || 'Mrzkyzdnii')
            .slice(0, 22)

    text(
        displayName,
        38,
        210,
        64,
        '#f5f5f5',
        '700'
    )

    // Notification badge
    roundRect(
        423,
        161,
        67,
        47,
        24,
        '#f21b59',
        null
    )

    text(
        '9+',
        456,
        194,
        28,
        '#ffffff',
        '400',
        'center'
    )

    // =========================
    // USERNAME
    // =========================

    const cleanUsername =
        String(username || 'mrizkyzadani')
            .replace(/^@/, '')

    text(
        `@${cleanUsername}`,
        39,
        262,
        29,
        '#8f8f8f',
        '700'
    )

    // =========================
    // STATS
    // =========================

    text(
        following,
        39,
        345,
        36,
        '#f2f2f2',
        '700'
    )

    text(
        'Following',
        39,
        382,
        28,
        '#999999',
        '400'
    )

    text(
        followers,
        221,
        345,
        36,
        '#f2f2f2',
        '700'
    )

    text(
        'Followers',
        221,
        382,
        28,
        '#999999',
        '400'
    )

    text(
        likes,
        400,
        345,
        36,
        '#f2f2f2',
        '700'
    )

    text(
        'Likes',
        400,
        382,
        28,
        '#999999',
        '400'
    )

    // =========================
    // AVATAR
    // =========================

    await drawAvatar()

    // =========================
    // MESSAGE BUTTON
    // =========================

    roundRect(
        830,
        131,
        202,
        70,
        28,
        '#4a4a4a',
        null
    )

    text(
        "What's good?",
        847,
        175,
        27,
        '#bdbdbd',
        '700'
    )

    // =========================
    // BIO
    // =========================

    const bioText =
        String(bio || '')
            .slice(0, 45)

    text(
        bioText,
        39,
        471,
        30,
        '#eeeeee',
        '400'
    )

    // =========================
    // BUTTONS
    // =========================

    drawOrderButtons()

    // =========================
    // TABS
    // =========================

    drawTabs()

    return canvas.toBuffer('image/png')
}

// ======================================================
// HANDLER
// ======================================================

const handler = async (
    m,
    {
        conn,
        text,
        usedPrefix,
        command
    }
) => {
    try {
        const q = m.quoted
            ? m.quoted
            : m

        const mime =
            (q.msg || q).mimetype || ''

        if (!text) {
            return m.reply(
`*Example:*

➜ ${usedPrefix + command} Mrzkyzdnii | mrizkyzadani | 390 | 39 | 50

➜ Dengan bio:
${usedPrefix + command} Mrzkyzdnii | mrizkyzadani | 390 | 39 | 50 | git commit -m "another day"

➜ Dengan URL avatar:
${usedPrefix + command} Mrzkyzdnii | mrizkyzadani | 390 | 39 | 50 | git commit -m "another day" | https://example.com/image.jpg

➜ Atau reply gambar:
Reply gambar lalu:
${usedPrefix + command} Mrzkyzdnii | mrizkyzadani | 390 | 39 | 50

*Format:*
name | username | following | followers | likes | bio (opsional) | url (opsional)`
            )
        }

        await conn.sendMessage(
            m.chat,
            {
                react: {
                    text: '⏳',
                    key: m.key
                }
            }
        )

        // ==========================================
        // PARSE INPUT
        // ==========================================

        const args = text.includes('|')
            ? text
                .split('|')
                .map(v => v.trim())
            : text
                .split(/\s+/)
                .map(v => v.trim())

        const [
            name,
            username,
            following,
            followers,
            likes,
            bio,
            url
        ] = args

        if (
            !name ||
            !username ||
            !following ||
            !followers ||
            !likes
        ) {
            throw `🍂 *Format tidak valid!*

Gunakan:

${usedPrefix + command} name | username | following | followers | likes

*Contoh:*
${usedPrefix + command} Mrzkyzdnii | mrizkyzadani | 390 | 39 | 50`
        }

        // ==========================================
        // AVATAR
        // ==========================================

        let avatarInput = null

        // Kalau URL diberikan
        if (
            url &&
            /^https?:\/\//i.test(url)
        ) {
            avatarInput = url
        }

        // Kalau tidak ada URL, cek reply gambar
        if (
            !avatarInput &&
            mime.startsWith('image/')
        ) {
            avatarInput = await q.download()
        }

        // ==========================================
        // CREATE IMAGE
        // ==========================================

        const imageBuffer =
            await makeFakeTikTok({
                name,
                username,
                following,
                followers,
                likes,
                bio: bio || 'git commit -m "another day"',
                avatarInput
            })

        // ==========================================
        // SEND
        // ==========================================

        await conn.sendMessage(
            m.chat,
            {
                image: imageBuffer,
                caption:
`*TikTok Profile Created* ✨

• *Name:* ${name}
• *Username:* @${username.replace(/^@/, '')}
• *Following:* ${following}
• *Followers:* ${followers}
• *Likes:* ${likes}`
            },
            {
                quoted: m
            }
        )

    } catch (e) {
        console.error(
            'FAKETIKTOK ERROR:',
            e
        )

        await m.reply(
            typeof e === 'string'
                ? e
                : '🍂 *Terjadi kesalahan saat membuat fake TikTok profile.*'
        )

    } finally {
        try {
            await conn.sendMessage(
                m.chat,
                {
                    react: {
                        text: '',
                        key: m.key
                    }
                }
            )
        } catch {}
    }
}

handler.help = ['faketiktok']
handler.tags = ['maker']
handler.command = /^(faketiktok|fakett)$/i
handler.limit = 10
handler.register = false

export default handler