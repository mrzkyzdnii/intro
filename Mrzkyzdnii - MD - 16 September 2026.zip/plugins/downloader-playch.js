import yts from 'yt-search'
import fs from 'fs'
import os from 'os'
import path from 'path'
import { execFile } from 'child_process'
import { promisify } from 'util'

const execFileAsync = promisify(execFile)

const YTDLP = './yt-dlp'
const DENO = '/home/container/.deno/bin/deno'
const COOKIES = './proxy.txt'

const getNewsletterJid = id => {
    id = String(id || '').trim()

    if (!id) return null

    if (id.endsWith('@newsletter')) {
        return id
    }

    if (/^\d+$/.test(id)) {
        return `${id}@newsletter`
    }

    return null
}

const isYoutubeUrl = url => {
    return /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//i.test(url)
}

const searchYoutube = async query => {
    if (isYoutubeUrl(query)) {
        const id =
            query.match(/[?&]v=([^&]+)/)?.[1] ||
            query.match(/youtu\.be\/([^?&]+)/)?.[1]

        if (!id) return null

        return await yts({
            videoId: id
        })
    }

    const result = await yts(query)

    return result?.videos?.[0] || null
}

const downloadAudio = async (url, dir) => {
    const output = path.join(dir, 'audio.%(ext)s')

    const args = [
        '--js-runtimes',
        `deno:${DENO}`,
        '--remote-components',
        'ejs:github',
        '--cookies',
        COOKIES,
        '--no-playlist',
        '--no-update',
        '--no-warnings',
        '-f',
        'bestaudio',
        '-o',
        output,
        url
    ]

    const { stdout, stderr } = await execFileAsync(YTDLP, args, {
        env: {
            ...process.env,
            PATH: `/home/container/.deno/bin:${process.env.PATH || ''}`
        },
        maxBuffer: 100 * 1024 * 1024
    })

    const files = fs.readdirSync(dir)
        .filter(file => file.startsWith('audio.'))
        .map(file => path.join(dir, file))

    if (!files.length) {
        throw new Error(
            stderr ||
            stdout ||
            'Audio tidak ditemukan.'
        )
    }

    return files[0]
}

const convertAudio = async (input, output) => {
    const args = [
        '-i',
        input,
        '-vn',
        '-map_metadata',
        '-1',
        '-c:a',
        'libopus',
        '-b:a',
        '96k',
        '-ar',
        '48000',
        '-ac',
        '2',
        '-y',
        output
    ]

    const { stderr } = await execFileAsync('ffmpeg', args, {
        maxBuffer: 100 * 1024 * 1024
    })

    if (!fs.existsSync(output)) {
        throw new Error(
            stderr ||
            'Gagal mengubah audio.'
        )
    }

    return output
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text?.trim()) {
        return m.reply(
            `Contoh:\n${usedPrefix + command} 120363403952337689 | swim chase atlantic`
        )
    }

    const parts = text.split('|')

    if (parts.length < 2) {
        return m.reply(
            `Format salah.\n\nContoh:\n${usedPrefix + command} 120363403952337689 | swim chase atlantic`
        )
    }

    const channelId = getNewsletterJid(parts.shift())
    const query = parts.join('|').trim()

    if (!channelId) {
        return m.reply('ID channel tidak valid.')
    }

    if (!query) {
        return m.reply('Judul lagu tidak boleh kosong.')
    }

    let tempDir

    try {
        await m.react('⏳').catch(() => {})

        tempDir = fs.mkdtempSync(
            path.join(os.tmpdir(), 'playch-')
        )

        const video = await searchYoutube(query)

        if (!video?.url) {
            throw new Error('Lagu tidak ditemukan.')
        }

        const input = await downloadAudio(
            video.url,
            tempDir
        )

        const output = path.join(
            tempDir,
            'audio.opus'
        )

        await convertAudio(
            input,
            output
        )

        const buffer = fs.readFileSync(output)

        if (!buffer.length) {
            throw new Error('Buffer audio kosong.')
        }

        console.log('[PLAYCH]')
        console.log('Channel:', channelId)
        console.log('Title:', video.title)
        console.log('Size:', buffer.length)

        const result = await conn.sendMessage(
            channelId,
            {
                audio: buffer,
                mimetype: 'audio/ogg; codecs=opus',
                fileName: `${video.title || 'audio'}.opus`,
                ptt: false
            }
        )

        console.log('[PLAYCH SENT]', result?.key?.id)

        await m.react('✅').catch(() => {})
    } catch (e) {
        console.error('[PLAYCH ERROR]', e)

        await m.react('❌').catch(() => {})

        await m.reply(
            `Gagal kirim audio\n\n${e?.message || e}`
        )
    } finally {
        if (tempDir) {
            fs.rmSync(tempDir, {
                recursive: true,
                force: true
            })
        }
    }
}

handler.help = ['playch']
handler.tags = ['owner']
handler.command = /^playch$/i
handler.owner = true
handler.limit = 10

export default handler