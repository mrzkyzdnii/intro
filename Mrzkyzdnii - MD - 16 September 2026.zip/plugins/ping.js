import os from 'os'

const FAKE_TOTAL_RAM = 62.32 * 1024 ** 3

const formatUptime = (sec) => {
  const d = Math.floor(sec / 86400)
  const h = Math.floor((sec % 86400) / 3600)
  const m = Math.floor((sec % 3600) / 60)
  const s = Math.floor(sec % 60)

  if (d) return `${d}d ${h}h ${m}m`
  if (h) return `${h}h ${m}m`
  if (m) return `${m}m ${s}s`
  return `${s}s`
}

const formatBytes = (bytes) => {
  if (bytes >= 1024 ** 3)
    return `${(bytes / 1024 ** 3).toFixed(2)} GB`

  if (bytes >= 1024 ** 2)
    return `${(bytes / 1024 ** 2).toFixed(2)} MB`

  if (bytes >= 1024)
    return `${(bytes / 1024).toFixed(2)} KB`

  return `${bytes} B`
}

const getCpuModel = () => {
  const cpu = os.cpus()

  return (
    cpu[0]?.model
      ?.replace(/\(R\)|\(TM\)|\(C\)/gi, '')
      .replace(/CPU|Processor/gi, '')
      .replace(/@.*$/g, '')
      .replace(/\s+/g, ' ')
      .trim()
  ) || 'Unknown CPU'
}

const getBar = (percent, length = 14) => {
  const filled = Math.round(
    Math.max(0, Math.min(100, percent)) / 100 * length
  )

  return '▰'.repeat(filled) +
    '▱'.repeat(length - filled)
}

const getStatus = (ping) => {
  if (ping < 100) return '🟢 Excellent'
  if (ping < 300) return '🟡 Stable'
  return '🔴 Slow'
}

const handler = async (m, { conn }) => {
  const start = process.hrtime.bigint()

  const cpu = os.cpus() || []

  // =========================
  // MEMORY
  // =========================

  // RAM asli server
  const realTotalRam = os.totalmem()
  const freeRam = os.freemem()

  // RAM yang benar-benar sedang digunakan
  const usedRam = Math.max(
    0,
    realTotalRam - freeRam
  )

  // Total RAM yang ditampilkan
  const totalRam = FAKE_TOTAL_RAM

  // Persentase berdasarkan total RAM fake
  const ramPercent = Math.round(
    (usedRam / totalRam) * 100
  )

  const memory = process.memoryUsage()

  // =========================
  // UPTIME
  // =========================

  const botUptime = formatUptime(
    process.uptime()
  )

  const serverUptime = formatUptime(
    os.uptime()
  )

  // =========================
  // SERVER
  // =========================

  const load = os
    .loadavg()
    .map(x => x.toFixed(2))
    .join('  •  ')

  // =========================
  // CPU
  // =========================

  const cpuModel = getCpuModel()

  const cpuCores = cpu.length

  const cpuSpeed = cpu[0]?.speed
    ? `${cpu[0].speed} MHz`
    : 'N/A'

  // =========================
  // SYSTEM
  // =========================

  const platform = os.platform()
  const arch = os.arch()
  const hostname = os.hostname()

  const nodeVersion = process.version

  const v8Version =
    process.versions?.v8 || 'N/A'

  // =========================
  // PING
  // =========================

  const end = process.hrtime.bigint()

  const ping =
    Number(end - start) / 1e6

  const pingSpeed =
    ping.toFixed(2)

  // =========================
  // MESSAGE
  // =========================

  const message = `
╭━━━〔 ⚡ 𝐀𝐏𝐄𝐗 𝐂𝐎𝐑𝐄 〕━━━╮
┃
┃  ⚡ 𝐏𝐈𝐍𝐆
┃  ├─ Response  : ${pingSpeed} ms
┃  └─ Status    : ${getStatus(ping)}
┃
┃  🤖 𝐁𝐎𝐓
┃  ├─ Uptime    : ${botUptime}
┃  └─ Runtime   : ${nodeVersion}
┃
┃  🖥️ 𝐒𝐄𝐑𝐕𝐄𝐑
┃  ├─ Uptime    : ${serverUptime}
┃  ├─ Host      : ${hostname}
┃  └─ Load      : ${load}
┃
┃  💻 𝐏𝐑𝐎𝐂𝐄𝐒𝐒𝐎𝐑
┃  ├─ Model     : ${cpuModel}
┃  ├─ Cores     : ${cpuCores}
┃  └─ Speed     : ${cpuSpeed}
┃
┃  💾 𝐌𝐄𝐌𝐎𝐑𝐘
┃  ├─ Usage     : ${ramPercent}%
┃  ├─ ${getBar(ramPercent)}
┃  └─ ${formatBytes(usedRam)} / ${formatBytes(totalRam)}
┃
┃  🧠 𝐏𝐑𝐎𝐂𝐄𝐒𝐒
┃  ├─ Heap      : ${formatBytes(memory.heapUsed)}
┃  └─ RSS       : ${formatBytes(memory.rss)}
┃
┃  ⚙️ 𝐒𝐘𝐒𝐓𝐄𝐌
┃  ├─ Platform  : ${platform}
┃  ├─ Arch      : ${arch}
┃  └─ V8        : ${v8Version}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯
`.trim()

  await conn.reply(
    m.chat,
    message,
    m
  )
}

handler.help = ['ping']
handler.tags = ['info']
handler.command = /^ping$/i
handler.limit = 10

export default handler