const handler = async (m, { conn }) => {
    const target = '57540515774618@lid'

    await conn.sendMessage(m.chat, {
        text: `@${target.split('@')[0]} iya`,
        mentions: [target]
    }, { quoted: m })
}

handler.help = ['halo']
handler.tags = ['main']
handler.command = /^halo$/i

export default handler