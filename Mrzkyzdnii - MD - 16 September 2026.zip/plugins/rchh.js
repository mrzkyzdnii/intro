import axios from 'axios'

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        throw `Contoh:\n${usedPrefix + command} https://whatsapp.com/channel/xxxxx/xxxxx | 🔥❤️🤍🫰`
    }

    const [url, react] = text.split('|').map(v => v.trim())

    if (!url) {
        throw `URL WhatsApp wajib diisi.\n\nContoh:\n${usedPrefix + command} https://whatsapp.com/channel/xxxxx/xxxxx | 🔥❤️🤍🫰`
    }

    if (!react) {
        throw `Reaction wajib diisi.\n\nContoh:\n${usedPrefix + command} ${url} | 🔥❤️🤍🫰`
    }

    if (!/^https?:\/\/(?:www\.)?whatsapp\.com\//i.test(url)) {
        throw 'URL harus berupa link WhatsApp.'
    }

    try {
        await conn.reply(m.chat, '⏳ Memproses reaction...', m)

        const apiUrl = `https://api-faa.my.id/faa/react-channel?url=${encodeURIComponent(url)}&react=${encodeURIComponent(react)}&apikey=faa-ganteng-sekali`

        const { data } = await axios.get(apiUrl, {
            timeout: 30000
        })

        let result

        if (typeof data === 'string') {
            result = data
        } else {
            result = data?.message ||
                data?.msg ||
                data?.result ||
                data?.data ||
                JSON.stringify(data, null, 2)
        }

        await conn.reply(
            m.chat,
            `✅ *Reaction Channel Berhasil*\n\n` +
            `🔗 *URL:* ${url}\n` +
            `💖 *Reaction:* ${react}\n\n` +
            `${typeof result === 'string' ? result : JSON.stringify(result, null, 2)}`,
            m
        )
    } catch (e) {
        const error = e.response?.data

        let message = 'Gagal melakukan reaction.'

        if (typeof error === 'string') {
            message = error
        } else if (error?.message) {
            message = error.message
        } else if (error?.msg) {
            message = error.msg
        }

        throw `❌ ${message}`
    }
}

handler.help = ['reactch']
handler.tags = ['tools']
handler.command = /^reactch$/i

export default handler