/**
 * WhatsApp Arcade RelayMessage Baileys Plugin
 * 1 FILE UTUH (SELF-CONTAINED) - LANGSUNG SIAP DIPASANG KE BOT
 *
 * Game:
 * 1. 🏹 Panah Master (Archery King - Wind Physics & Bullseye)
 * 2. 🚇 Subway Surfers 3D (3-Lane Runner, Jump, Slide, Coins & Trains)
 * 3. 🐦 Angry Birds Slingshot (Trajectory Parabola & Block Castle Destruction)
 */

function genUuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

// ==================== GAME 1: PANAH MASTER (ARCHERY KING) ====================
const gamePanahHtml = `<style>
*{box-sizing:border-box;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent}
#gameWrap1{position:relative;width:100%;max-width:500px;min-height:480px;height:480px;margin:0 auto;background:radial-gradient(circle at center,#143823 0%,#06130b 100%);overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,sans-serif;color:#fff;touch-action:none}
#gameWrap1 canvas{position:absolute;top:0;left:0;width:100%;height:100%;display:block}
#gameWrap1 .hud{position:absolute;top:10px;left:12px;right:12px;display:flex;justify-content:space-between;pointer-events:none;z-index:10}
#gameWrap1 .score{font-size:22px;font-weight:900;color:#facc15;text-shadow:0 0 10px rgba(250,204,21,0.6);line-height:1}
#gameWrap1 .info{font-size:11px;color:#86efac;margin-top:4px}
#gameWrap1 .arrows{font-size:16px;color:#38bdf8;text-align:right;font-weight:800}
#gameWrap1 .wind{font-size:11px;color:#fdba74;text-align:right}
#gameWrap1 .hit-banner{position:absolute;top:38%;left:50%;transform:translate(-50%,-50%);font-size:28px;font-weight:900;color:#facc15;text-shadow:0 0 20px #eab308;pointer-events:none;opacity:0;transition:opacity .2s,transform .2s;z-index:15}
#gameWrap1 .hit-banner.show{opacity:1;transform:translate(-50%,-65%) scale(1.15)}
#gameWrap1 .guide{position:absolute;bottom:10px;left:0;right:0;text-align:center;font-size:11px;color:#93c5fd;pointer-events:none;z-index:10;background:rgba(0,0,0,0.5);padding:4px 0}
#gameWrap1 .over{position:absolute;inset:0;background:rgba(4,18,10,0.95);display:none;flex-direction:column;align-items:center;justify-content:center;z-index:30}
#gameWrap1 .over.show{display:flex}
#gameWrap1 .btn{background:#22c55e;color:#052e16;font-size:13px;font-weight:900;border-radius:10px;padding:10px 24px;border:none;cursor:pointer;box-shadow:0 0 20px rgba(34,197,94,0.4)}
#gameWrap1 .btn:active{transform:scale(0.96)}
</style>
<div id="gameWrap1">
  <canvas id="c1" width="360" height="480"></canvas>
  <div class="hud">
    <div>
      <div class="score" id="score1">0 PTS</div>
      <div class="info">TARGET: 50 METER</div>
    </div>
    <div>
      <div class="arrows" id="arrows1">🏹 🏹 🏹 🏹 🏹</div>
      <div class="wind" id="wind1">ANGIN: 0.0 M/S</div>
    </div>
  </div>
  <div class="hit-banner" id="banner1">🎯 BULLSEYE 10!</div>
  <div class="guide">TARIK BUSUR KE BELAKANG LALU LEPAS UNTUK MEMANAH</div>
  <div class="over" id="gover1">
    <h2 style="color:#facc15;margin:0 0 6px;font-size:22px">RONDE SELESAI!</h2>
    <p id="finalScore1" style="color:#86efac;font-size:16px;margin:0 0 16px">Total Skor: 0 PTS</p>
    <button class="btn" id="restartBtn1">MAIN LAGI 🏹</button>
  </div>
</div>
<script>
(function(){
  const wrap = document.getElementById('gameWrap1') || document.body;
  const c = document.getElementById('c1');
  if(!c) return;
  const ctx = c.getContext('2d');

  let W = 360, H = 480;
  function resize(){
    const r = wrap.getBoundingClientRect();
    const w = Math.floor(r.width || window.innerWidth || 360);
    const h = Math.floor(r.height || 480);
    if(w > 50 && h > 50){ W = c.width = w; H = c.height = h; }
  }
  resize();
  window.addEventListener('resize', resize);
  setTimeout(resize, 100);

  let actx;
  function sndShoot(){
    try{
      if(!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(); o.type = 'triangle';
      o.frequency.setValueAtTime(320, actx.currentTime);
      o.frequency.exponentialRampToValueAtTime(100, actx.currentTime + 0.18);
      const g = actx.createGain(); g.gain.setValueAtTime(0.3, actx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.01, actx.currentTime + 0.2);
      o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.2);
    }catch(e){}
  }
  function sndHit(v){
    try{
      if(!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(); o.type = 'sine';
      const f = v === 10 ? 880 : (v >= 8 ? 660 : 440);
      o.frequency.setValueAtTime(f, actx.currentTime);
      const g = actx.createGain(); g.gain.setValueAtTime(0.25, actx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.01, actx.currentTime + 0.3);
      o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.3);
    }catch(e){}
  }

  let score = 0, arrowsLeft = 5, wind = 1.2, targetY = 0.45;
  let dragging = false, dragStartX = 0, dragStartY = 0, dragCurrX = 0, dragCurrY = 0;
  let flyingArrow = null;
  const stuckArrows = [];

  function updateWind(){
    wind = (Math.random() * 6 - 3);
    const dir = wind > 0 ? '▶' : '◀';
    const el = document.getElementById('wind1');
    if(el) el.innerText = 'ANGIN: ' + Math.abs(wind).toFixed(1) + ' M/S ' + dir;
  }
  updateWind();

  function showBanner(text, col){
    const b = document.getElementById('banner1');
    if(!b) return;
    b.innerText = text;
    b.style.color = col || '#facc15';
    b.classList.add('show');
    setTimeout(() => b.classList.remove('show'), 900);
  }

  function getPos(e){
    const r = c.getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: cx - r.left, y: cy - r.top };
  }

  function onDown(e){
    if(arrowsLeft <= 0 || flyingArrow) return;
    const p = getPos(e);
    const bowY = H * 0.82;
    if(Math.hypot(p.x - W/2, p.y - bowY) < 130){
      dragging = true;
      dragStartX = W / 2; dragStartY = bowY;
      dragCurrX = p.x; dragCurrY = p.y;
    }
  }
  function onMove(e){
    if(!dragging) return;
    const p = getPos(e);
    dragCurrX = p.x; dragCurrY = p.y;
  }
  function onUp(){
    if(!dragging) return;
    dragging = false;
    const bowY = H * 0.82;
    const dx = (W / 2) - dragCurrX;
    const dy = bowY - dragCurrY;
    const power = Math.min(Math.hypot(dx, dy), 90);
    if(power > 18){
      sndShoot();
      arrowsLeft--;
      document.getElementById('arrows1').innerText = '🏹 '.repeat(arrowsLeft) || 'KOSONG';
      const angle = Math.atan2(dy, dx);
      flyingArrow = {
        x: W / 2, y: bowY,
        vx: Math.cos(angle) * (power * 0.28),
        vy: -Math.sin(angle) * (power * 0.28),
        scale: 1,
        t: 0
      };
    }
  }

  c.addEventListener('touchstart', onDown, { passive: true });
  c.addEventListener('touchmove', onMove, { passive: true });
  c.addEventListener('touchend', onUp);
  c.addEventListener('mousedown', onDown);
  c.addEventListener('mousemove', onMove);
  c.addEventListener('mouseup', onUp);

  document.getElementById('restartBtn1').addEventListener('click', () => {
    score = 0; arrowsLeft = 5; flyingArrow = null; stuckArrows.length = 0;
    document.getElementById('score1').innerText = '0 PTS';
    document.getElementById('arrows1').innerText = '🏹 🏹 🏹 🏹 🏹';
    document.getElementById('gover1').classList.remove('show');
    updateWind();
  });

  let t = 0;
  function loop(){
    t += 0.02;
    ctx.clearRect(0, 0, W, H);

    // Rumput & Lapangan
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#062010'); grad.addColorStop(0.55, '#14532d'); grad.addColorStop(1, '#052e16');
    ctx.fillStyle = grad; ctx.fillRect(0, 0, W, H);

    // Garis jarak
    ctx.strokeStyle = 'rgba(255,255,255,0.08)'; ctx.lineWidth = 1.5;
    for(let i = 1; i <= 4; i++){
      ctx.beginPath(); ctx.moveTo(0, H * 0.45 + i * 40); ctx.lineTo(W, H * 0.45 + i * 40); ctx.stroke();
    }

    // Target Papan Panah (Bergerak perlahan)
    const targetX = W / 2 + Math.sin(t * 0.8) * (W * 0.22);
    const ty = H * 0.32;
    const tr = 46;

    ctx.fillStyle = 'rgba(0,0,0,0.3)'; ctx.beginPath(); ctx.ellipse(targetX, ty + 120, tr * 0.7, 12, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#78350f'; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(targetX, ty + 10); ctx.lineTo(targetX - 25, ty + 120); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(targetX, ty + 10); ctx.lineTo(targetX + 25, ty + 120); ctx.stroke();

    const rings = [
      { r: tr, c: '#ffffff', pts: 2 },
      { r: tr * 0.78, c: '#0284c7', pts: 4 },
      { r: tr * 0.55, c: '#dc2626', pts: 6 },
      { r: tr * 0.32, c: '#facc15', pts: 8 },
      { r: tr * 0.15, c: '#eab308', pts: 10 },
    ];
    rings.forEach(rg => {
      ctx.fillStyle = rg.c; ctx.beginPath(); ctx.arc(targetX, ty, rg.r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = 'rgba(0,0,0,0.2)'; ctx.lineWidth = 1; ctx.stroke();
    });

    // Anak panah tertancap
    stuckArrows.forEach(st => {
      ctx.save();
      const ax = targetX + st.ox, ay = ty + st.oy;
      ctx.fillStyle = '#facc15'; ctx.beginPath(); ctx.arc(ax, ay, 4, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#e2e8f0'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(ax - 10, ay + 18); ctx.stroke();
      ctx.restore();
    });

    // Arrow flying logic
    if(flyingArrow){
      flyingArrow.t += 0.05;
      flyingArrow.x += flyingArrow.vx + wind * 0.4;
      flyingArrow.y += flyingArrow.vy;
      flyingArrow.vy += 0.28; // gravitasi
      flyingArrow.scale = Math.max(0.35, 1 - flyingArrow.t * 0.5);

      ctx.save();
      ctx.translate(flyingArrow.x, flyingArrow.y);
      const angle = Math.atan2(flyingArrow.vy, flyingArrow.vx);
      ctx.rotate(angle);
      ctx.scale(flyingArrow.scale, flyingArrow.scale);
      ctx.strokeStyle = '#facc15'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-35, 0); ctx.lineTo(10, 0); ctx.stroke();
      ctx.fillStyle = '#ffffff';
      ctx.beginPath(); ctx.moveTo(15, 0); ctx.lineTo(6, -5); ctx.lineTo(6, 5); ctx.closePath(); ctx.fill();
      ctx.restore();

      // Hit detection target
      if(flyingArrow.y <= ty + 10 && flyingArrow.vy < 0 || flyingArrow.scale <= 0.42){
        const dist = Math.hypot(flyingArrow.x - targetX, flyingArrow.y - ty);
        let pts = 0;
        for(let i = rings.length - 1; i >= 0; i--){
          if(dist <= rings[i].r){ pts = rings[i].pts; break; }
        }
        if(pts > 0){
          score += pts;
          sndHit(pts);
          stuckArrows.push({ ox: flyingArrow.x - targetX, oy: flyingArrow.y - ty });
          showBanner(pts === 10 ? '🎯 BULLSEYE 10!' : 'HEBAT! +' + pts + ' PTS', pts >= 8 ? '#facc15' : '#38bdf8');
        } else {
          showBanner('MELESET! ❌', '#ef4444');
        }
        document.getElementById('score1').innerText = score + ' PTS';
        flyingArrow = null;
        updateWind();

        if(arrowsLeft <= 0){
          setTimeout(() => {
            document.getElementById('gover1').classList.add('show');
            document.getElementById('finalScore1').innerText = 'Total Skor: ' + score + ' PTS';
          }, 700);
        }
      }
    }

    // Busur panah di bawah
    const bowBaseX = W / 2, bowBaseY = H * 0.82;
    let pullX = dragging ? dragCurrX : bowBaseX;
    let pullY = dragging ? dragCurrY : bowBaseY;
    const pDist = Math.hypot(pullX - bowBaseX, pullY - bowBaseY);
    if(pDist > 90){
      const ang = Math.atan2(pullY - bowBaseY, pullX - bowBaseX);
      pullX = bowBaseX + Math.cos(ang) * 90;
      pullY = bowBaseY + Math.sin(ang) * 90;
    }

    if(dragging){
      ctx.strokeStyle = 'rgba(250,204,21,0.4)'; ctx.lineWidth = 2; ctx.setLineDash([4, 6]);
      ctx.beginPath(); ctx.moveTo(bowBaseX, bowBaseY);
      const aimX = bowBaseX - (pullX - bowBaseX) * 2.2;
      const aimY = bowBaseY - (pullY - bowBaseY) * 2.2;
      ctx.lineTo(aimX, aimY); ctx.stroke(); ctx.setLineDash([]);
    }

    // Tali Busur
    ctx.strokeStyle = '#f8fafc'; ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(bowBaseX - 50, bowBaseY - 20);
    ctx.lineTo(pullX, pullY);
    ctx.lineTo(bowBaseX + 50, bowBaseY - 20);
    ctx.stroke();

    // Gagang Busur Kayu
    ctx.strokeStyle = '#92400e'; ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.arc(bowBaseX, bowBaseY + 10, 54, Math.PI * 1.15, Math.PI * 1.85);
    ctx.stroke();

    if(arrowsLeft > 0 && !flyingArrow){
      const arrowAngle = Math.atan2(bowBaseY - pullY, bowBaseX - pullX);
      ctx.save();
      ctx.translate(pullX, pullY);
      ctx.rotate(arrowAngle - Math.PI / 2);
      ctx.strokeStyle = '#facc15'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -60); ctx.stroke();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.moveTo(0, -66); ctx.lineTo(-4, -56); ctx.lineTo(4, -56); ctx.closePath(); ctx.fill();
      ctx.restore();
    }

    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
<\/script>`;

// ==================== GAME 2: SUBWAY SURFERS 3D ====================
const gameSubwaySurfersHtml = `<style>
*{box-sizing:border-box;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent}
#gameWrap2{position:relative;width:100%;max-width:500px;min-height:480px;height:480px;margin:0 auto;background:#0284c7;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,sans-serif;color:#fff;touch-action:none}
#gameWrap2 canvas{position:absolute;top:0;left:0;width:100%;height:100%;display:block}
#gameWrap2 .hud{position:absolute;top:10px;left:12px;right:12px;display:flex;justify-content:space-between;pointer-events:none;z-index:10;font-weight:900}
#gameWrap2 .coins{font-size:20px;color:#facc15;text-shadow:0 0 10px rgba(250,204,21,0.6)}
#gameWrap2 .score{font-size:18px;color:#fff;text-align:right}
#gameWrap2 .mult{font-size:11px;color:#38bdf8}
#gameWrap2 .ctrls{position:absolute;bottom:8px;left:8px;right:8px;display:flex;justify-content:space-between;align-items:center;z-index:20}
#gameWrap2 .dpad{display:grid;grid-template-columns:48px 74px 48px;grid-gap:6px}
#gameWrap2 .btn{background:rgba(15,23,42,0.85);border:1.5px solid #38bdf8;color:#fff;font-size:13px;font-weight:bold;border-radius:10px;height:44px;display:flex;align-items:center;justify-content:center;cursor:pointer}
#gameWrap2 .btn:active{background:#38bdf8;color:#000}
#gameWrap2 .btn-jump{width:62px;height:62px;border-radius:50%;background:#f59e0b;border:2px solid #fef08a;font-size:11px;color:#000;font-weight:900;display:flex;flex-direction:column;gap:2px}
#gameWrap2 .over{position:absolute;inset:0;background:rgba(15,23,42,0.95);display:none;flex-direction:column;align-items:center;justify-content:center;z-index:30}
#gameWrap2 .over.show{display:flex}
</style>
<div id="gameWrap2">
  <canvas id="c2" width="360" height="480"></canvas>
  <div class="hud">
    <div>
      <div class="coins" id="coins2">🪙 0</div>
      <div class="mult" id="speed2">KECEPATAN: 40 KM/H</div>
    </div>
    <div>
      <div class="score" id="score2">0 M</div>
      <div class="mult">2X SCORE MULTIPLIER</div>
    </div>
  </div>
  <div class="ctrls">
    <div class="dpad">
      <div class="btn" id="btnLeft2">◀</div>
      <div class="btn" id="btnSlide2">⬇️ SLIDE</div>
      <div class="btn" id="btnRight2">▶</div>
    </div>
    <div class="btn btn-jump" id="btnJump2">
      <span style="font-size:18px">⬆️</span>
      <span>LOMPAT</span>
    </div>
  </div>
  <div class="over" id="gover2">
    <h2 style="color:#ef4444;margin:0 0 4px;font-size:22px">TERTABRAK KERETA!</h2>
    <p id="finalStat2" style="color:#94a3b8;font-size:15px;margin:4px 0 16px">Jarak: 0m | Koin: 0</p>
    <div class="btn" id="restartBtn2" style="padding:10px 24px;background:#facc15;color:#000;font-weight:900;width:auto">LARI LAGI 🏃💨</div>
  </div>
</div>
<script>
(function(){
  const wrap = document.getElementById('gameWrap2') || document.body;
  const c = document.getElementById('c2');
  if(!c) return;
  const ctx = c.getContext('2d');

  let W = 360, H = 480;
  function resize(){
    const r = wrap.getBoundingClientRect();
    const w = Math.floor(r.width || window.innerWidth || 360);
    const h = Math.floor(r.height || 480);
    if(w > 50 && h > 50){ W = c.width = w; H = c.height = h; }
  }
  resize();
  window.addEventListener('resize', resize);
  setTimeout(resize, 100);

  let actx;
  function sndCoin(){
    try{
      if(!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(); o.type = 'sine';
      o.frequency.setValueAtTime(987, actx.currentTime);
      o.frequency.setValueAtTime(1318, actx.currentTime + 0.08);
      const g = actx.createGain(); g.gain.setValueAtTime(0.2, actx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.01, actx.currentTime + 0.2);
      o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.2);
    }catch(e){}
  }
  function sndCrash(){
    try{
      if(!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(); o.type = 'sawtooth';
      o.frequency.setValueAtTime(150, actx.currentTime);
      o.frequency.exponentialRampToValueAtTime(30, actx.currentTime + 0.3);
      const g = actx.createGain(); g.gain.setValueAtTime(0.4, actx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.01, actx.currentTime + 0.3);
      o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.3);
    }catch(e){}
  }

  let lane = 1; // 0: kiri, 1: tengah, 2: kanan
  let targetLaneX = 1;
  let playerLaneX = 1;
  let playerY = 0, vy = 0, isJumping = false, isSliding = false, slideTimer = 0;
  let score = 0, coins = 0, speed = 0.016, isOver = false;

  const items = [];
  function spawnItem(){
    if(isOver) return;
    const l = Math.floor(Math.random() * 3);
    const typeRnd = Math.random();
    if(typeRnd < 0.45){
      items.push({ type: 'coin', lane: l, z: 1.0 });
    } else if(typeRnd < 0.78){
      items.push({ type: 'barrier', lane: l, z: 1.0 });
    } else {
      items.push({ type: 'train', lane: l, z: 1.0, length: 0.35 });
    }
  }

  let spawnTicker = 0;
  function reset(){
    lane = 1; targetLaneX = 1; playerLaneX = 1;
    playerY = 0; vy = 0; isJumping = false; isSliding = false; slideTimer = 0;
    score = 0; coins = 0; speed = 0.016; isOver = false;
    items.length = 0;
    document.getElementById('gover2').classList.remove('show');
    document.getElementById('coins2').innerText = '🪙 0';
    document.getElementById('score2').innerText = '0 M';
  }

  function moveLeft(){ if(lane > 0){ lane--; targetLaneX = lane; } }
  function moveRight(){ if(lane < 2){ lane++; targetLaneX = lane; } }
  function jump(){
    if(!isJumping && !isSliding){
      isJumping = true; vy = 11;
    }
  }
  function slide(){
    if(!isSliding){
      isSliding = true; slideTimer = 35;
      if(isJumping){ vy = -12; } // slam down
    }
  }

  document.getElementById('btnLeft2').addEventListener('click', moveLeft);
  document.getElementById('btnRight2').addEventListener('click', moveRight);
  document.getElementById('btnJump2').addEventListener('click', jump);
  document.getElementById('btnSlide2').addEventListener('click', slide);
  document.getElementById('restartBtn2').addEventListener('click', reset);

  // Swipe Gestures
  let touchStartX = 0, touchStartY = 0;
  c.addEventListener('touchstart', e => {
    touchStartX = e.touches[0].clientX;
    touchStartY = e.touches[0].clientY;
  }, { passive: true });
  c.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - touchStartX;
    const dy = e.changedTouches[0].clientY - touchStartY;
    if(Math.abs(dx) > Math.abs(dy)){
      if(dx > 30) moveRight();
      else if(dx < -30) moveLeft();
    } else {
      if(dy < -30) jump();
      else if(dy > 30) slide();
    }
  });

  window.addEventListener('keydown', e => {
    if(e.key === 'ArrowLeft' || e.key === 'a') moveLeft();
    if(e.key === 'ArrowRight' || e.key === 'd') moveRight();
    if(e.key === 'ArrowUp' || e.key === 'w' || e.key === ' ') jump();
    if(e.key === 'ArrowDown' || e.key === 's') slide();
  });

  function getLaneX(l, z){
    const horizonX = W / 2;
    const bottomLaneSpacing = W * 0.28;
    const topLaneSpacing = W * 0.08;
    const spacing = topLaneSpacing + (bottomLaneSpacing - topLaneSpacing) * (1 - z);
    return horizonX + (l - 1) * spacing;
  }
  function getTrackY(z){
    const horizonY = H * 0.38;
    return horizonY + (H - horizonY) * (1 - z);
  }

  let bgOffset = 0;
  function loop(){
    if(!isOver){
      score += Math.floor(speed * 300);
      speed = Math.min(0.032, speed + 0.000005);
      document.getElementById('score2').innerText = score + ' M';
      document.getElementById('speed2').innerText = 'KECEPATAN: ' + Math.floor(speed * 2500) + ' KM/H';

      playerLaneX += (targetLaneX - playerLaneX) * 0.25;

      if(isJumping){
        playerY += vy;
        vy -= 0.7;
        if(playerY <= 0){ playerY = 0; isJumping = false; vy = 0; }
      }
      if(isSliding){
        slideTimer--;
        if(slideTimer <= 0) isSliding = false;
      }

      spawnTicker++;
      if(spawnTicker > 42){ spawnTicker = 0; spawnItem(); }
    }

    ctx.clearRect(0, 0, W, H);

    // Langit & Gedung Kota
    ctx.fillStyle = '#0284c7'; ctx.fillRect(0, 0, W, H * 0.38);
    ctx.fillStyle = '#0369a1';
    for(let i = 0; i < 7; i++){
      const bx = i * (W / 6) - 10;
      ctx.fillRect(bx, H * 0.18 + (i % 3) * 14, W / 7, H * 0.2);
    }

    // Tanah Rel Kereta Bawah Tanah
    ctx.fillStyle = '#1e293b'; ctx.fillRect(0, H * 0.38, W, H * 0.62);

    // Rel 3D
    ctx.strokeStyle = '#f59e0b'; ctx.lineWidth = 2;
    for(let l = 0; l <= 3; l++){
      const xTop = W/2 + (l - 1.5) * (W * 0.12);
      const xBot = W/2 + (l - 1.5) * (W * 0.34);
      ctx.beginPath(); ctx.moveTo(xTop, H * 0.38); ctx.lineTo(xBot, H); ctx.stroke();
    }

    // Bantalan kayu rel
    bgOffset = (bgOffset + speed * 15) % 30;
    ctx.strokeStyle = 'rgba(255,255,255,0.12)'; ctx.lineWidth = 3;
    for(let y = H * 0.38; y < H; y += 22){
      const py = y + bgOffset;
      if(py <= H){ ctx.beginPath(); ctx.moveTo(0, py); ctx.lineTo(W, py); ctx.stroke(); }
    }

    // Update & Render Rintangan
    for(let i = items.length - 1; i >= 0; i--){
      const it = items[i];
      if(!isOver) it.z -= speed;

      const screenX = getLaneX(it.lane, it.z);
      const screenY = getTrackY(it.z);
      const scale = (1 - it.z);

      if(it.type === 'coin'){
        const r = 8 + scale * 14;
        ctx.fillStyle = '#facc15'; ctx.beginPath(); ctx.arc(screenX, screenY - r - 8, r, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = '#ca8a04'; ctx.lineWidth = 2; ctx.stroke();
        ctx.fillStyle = '#713f12'; ctx.font = 'bold ' + (r * 0.9) + 'px sans-serif'; ctx.textAlign = 'center';
        ctx.fillText('$', screenX, screenY - r * 0.6);

        // Kena Koin
        if(it.z < 0.18 && it.z > 0.02 && Math.abs(playerLaneX - it.lane) < 0.45 && playerY < 50){
          coins++;
          sndCoin();
          document.getElementById('coins2').innerText = '🪙 ' + coins;
          items.splice(i, 1);
          continue;
        }
      } else if(it.type === 'barrier'){
        const bw = 24 + scale * 50;
        const bh = 14 + scale * 30;
        ctx.fillStyle = '#ef4444'; ctx.fillRect(screenX - bw / 2, screenY - bh, bw, bh);
        ctx.fillStyle = '#ffffff'; ctx.fillRect(screenX - bw / 2 + 4, screenY - bh + 4, bw - 8, 4);

        // Tabrak Barikade (bisa dilewati dengan LOMPAT)
        if(it.z < 0.16 && it.z > 0.04 && Math.abs(playerLaneX - it.lane) < 0.42 && playerY < 24){
          isOver = true; sndCrash();
          document.getElementById('gover2').classList.add('show');
          document.getElementById('finalStat2').innerText = 'Jarak: ' + score + 'm | Koin: ' + coins;
        }
      } else if(it.type === 'train'){
        const tw = 28 + scale * 60;
        const th = 32 + scale * 70;
        ctx.fillStyle = '#334155'; ctx.fillRect(screenX - tw / 2, screenY - th, tw, th);
        ctx.fillStyle = '#38bdf8'; ctx.fillRect(screenX - tw / 2 + 6, screenY - th + 8, tw - 12, th * 0.35);
        ctx.fillStyle = '#facc15'; ctx.beginPath(); ctx.arc(screenX, screenY - 10, 6, 0, Math.PI * 2); ctx.fill();

        // Tabrak Kereta (TIDAK bisa dilewati lompat biasa)
        if(it.z < 0.18 && it.z > 0.02 && Math.abs(playerLaneX - it.lane) < 0.45){
          isOver = true; sndCrash();
          document.getElementById('gover2').classList.add('show');
          document.getElementById('finalStat2').innerText = 'Jarak: ' + score + 'm | Koin: ' + coins;
        }
      }

      if(it.z <= -0.1) items.splice(i, 1);
    }

    // Karakter Surfer
    const pScreenX = getLaneX(playerLaneX, 0.08);
    const pScreenY = getTrackY(0.08) - playerY;

    // Bayangan
    ctx.fillStyle = 'rgba(0,0,0,0.4)';
    ctx.beginPath(); ctx.ellipse(pScreenX, getTrackY(0.08) + 2, 20, 7, 0, 0, Math.PI * 2); ctx.fill();

    ctx.save();
    ctx.translate(pScreenX, pScreenY);
    if(isSliding){
      ctx.fillStyle = '#f59e0b'; ctx.fillRect(-18, -16, 36, 16);
      ctx.fillStyle = '#0f172a'; ctx.beginPath(); ctx.arc(14, -8, 8, 0, Math.PI * 2); ctx.fill();
    } else {
      ctx.fillStyle = '#0284c7'; ctx.fillRect(-12, -20, 10, 20); ctx.fillRect(2, -20, 10, 20);
      ctx.fillStyle = '#0f172a'; ctx.fillRect(-16, -46, 32, 26);
      ctx.fillStyle = '#ef4444'; ctx.fillRect(-14, -60, 28, 14);
      ctx.fillRect(-18, -52, 36, 4);
      ctx.fillStyle = '#fde047'; ctx.beginPath(); ctx.arc(0, -48, 10, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();

    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
<\/script>`;

// ==================== GAME 3: ANGRY BIRDS SLINGSHOT ====================
const gameAngryBirdsHtml = `<style>
*{box-sizing:border-box;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent}
#gameWrap3{position:relative;width:100%;max-width:500px;min-height:480px;height:480px;margin:0 auto;background:#38bdf8;overflow:hidden;font-family:-apple-system,BlinkMacSystemFont,sans-serif;color:#fff;touch-action:none}
#gameWrap3 canvas{position:absolute;top:0;left:0;width:100%;height:100%;display:block}
#gameWrap3 .hud{position:absolute;top:10px;left:12px;right:12px;display:flex;justify-content:space-between;pointer-events:none;z-index:10;font-weight:900}
#gameWrap3 .score{font-size:20px;color:#facc15;text-shadow:0 0 10px rgba(0,0,0,0.5)}
#gameWrap3 .birds{font-size:15px;color:#fff;text-align:right}
#gameWrap3 .guide{position:absolute;bottom:10px;left:0;right:0;text-align:center;font-size:11px;color:#fff;pointer-events:none;z-index:10;background:rgba(0,0,0,0.5);padding:4px 0}
#gameWrap3 .over{position:absolute;inset:0;background:rgba(15,23,42,0.94);display:none;flex-direction:column;align-items:center;justify-content:center;z-index:30}
#gameWrap3 .over.show{display:flex}
#gameWrap3 .btn{background:#22c55e;color:#000;font-size:13px;font-weight:900;border-radius:10px;padding:10px 24px;border:none;cursor:pointer;box-shadow:0 0 20px rgba(34,197,94,0.4)}
#gameWrap3 .btn:active{transform:scale(0.96)}
</style>
<div id="gameWrap3">
  <canvas id="c3" width="360" height="480"></canvas>
  <div class="hud">
    <div>
      <div class="score" id="score3">SKOR: 0</div>
      <div style="font-size:11px;color:#e0f2fe" id="pigsCount3">BABI TERSISA: 3</div>
    </div>
    <div>
      <div class="birds" id="birdsLeft3">BURUNG: 🔴 🔴 🔴</div>
      <div style="font-size:11px;color:#facc15">TARIK KETAPEL!</div>
    </div>
  </div>
  <div class="guide">TARIK KARET KETAPEL KE KIRI BAWAH LALU LEPAS!</div>
  <div class="over" id="gover3">
    <h2 id="govTitle3" style="color:#facc15;margin:0 0 6px;font-size:22px">SEMUA BABI HANCUR!</h2>
    <p id="finalScore3" style="color:#86efac;font-size:15px;margin:0 0 16px">Skor: 0</p>
    <button class="btn" id="restartBtn3">MAIN LAGI 🐦</button>
  </div>
</div>
<script>
(function(){
  const wrap = document.getElementById('gameWrap3') || document.body;
  const c = document.getElementById('c3');
  if(!c) return;
  const ctx = c.getContext('2d');

  let W = 360, H = 480;
  function resize(){
    const r = wrap.getBoundingClientRect();
    const w = Math.floor(r.width || window.innerWidth || 360);
    const h = Math.floor(r.height || 480);
    if(w > 50 && h > 50){ W = c.width = w; H = c.height = h; }
  }
  resize();
  window.addEventListener('resize', resize);
  setTimeout(resize, 100);

  let actx;
  function playSnd(type){
    try{
      if(!actx) actx = new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(), g = actx.createGain();
      if(type === 'launch'){
        o.type = 'sine'; o.frequency.setValueAtTime(300, actx.currentTime);
        o.frequency.exponentialRampToValueAtTime(700, actx.currentTime + 0.2);
        g.gain.setValueAtTime(0.2, actx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.01, actx.currentTime + 0.2);
      }else if(type === 'pop'){
        o.type = 'triangle'; o.frequency.setValueAtTime(800, actx.currentTime);
        o.frequency.exponentialRampToValueAtTime(150, actx.currentTime + 0.15);
        g.gain.setValueAtTime(0.3, actx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.01, actx.currentTime + 0.15);
      }else{
        o.type = 'sawtooth'; o.frequency.setValueAtTime(140, actx.currentTime);
        o.frequency.exponentialRampToValueAtTime(40, actx.currentTime + 0.15);
        g.gain.setValueAtTime(0.2, actx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.01, actx.currentTime + 0.15);
      }
      o.connect(g); g.connect(actx.destination); o.start(); o.stop(actx.currentTime + 0.25);
    }catch(e){}
  }

  let slingX = 0, slingY = 0;
  const bird = { x: 0, y: 0, vx: 0, vy: 0, active: false, launched: false, r: 14 };
  let birdsCount = 3;
  let score = 0;
  let dragging = false;

  let blocks = [];
  let pigs = [];
  const particles = [];

  function buildCastle(){
    blocks = []; pigs = [];
    const baseX = W * 0.75, baseY = H * 0.75;
    blocks.push({ x: baseX - 36, y: baseY - 30, w: 14, h: 60, hp: 2, col: '#b45309' });
    blocks.push({ x: baseX + 36, y: baseY - 30, w: 14, h: 60, hp: 2, col: '#b45309' });
    blocks.push({ x: baseX, y: baseY - 66, w: 96, h: 12, hp: 2, col: '#d97706' });
    blocks.push({ x: baseX - 20, y: baseY - 96, w: 12, h: 48, hp: 2, col: '#78716c' });
    blocks.push({ x: baseX + 20, y: baseY - 96, w: 12, h: 48, hp: 2, col: '#78716c' });
    blocks.push({ x: baseX, y: baseY - 126, w: 60, h: 12, hp: 2, col: '#a8a29e' });

    pigs.push({ x: baseX, y: baseY - 18, r: 15, alive: true });
    pigs.push({ x: baseX, y: baseY - 84, r: 13, alive: true });
    pigs.push({ x: baseX + 54, y: baseY - 15, r: 12, alive: true });
    updatePigsUI();
  }

  function updatePigsUI(){
    const left = pigs.filter(p => p.alive).length;
    document.getElementById('pigsCount3').innerText = 'BABI TERSISA: ' + left;
  }

  function resetBird(){
    slingX = W * 0.22; slingY = H * 0.68;
    bird.x = slingX; bird.y = slingY;
    bird.vx = 0; bird.vy = 0;
    bird.active = true; bird.launched = false;
  }

  function restartGame(){
    score = 0; birdsCount = 3;
    document.getElementById('score3').innerText = 'SKOR: 0';
    document.getElementById('birdsLeft3').innerText = 'BURUNG: 🔴 🔴 🔴';
    document.getElementById('gover3').classList.remove('show');
    buildCastle();
    resetBird();
  }
  document.getElementById('restartBtn3').addEventListener('click', restartGame);

  function getPos(e){
    const r = c.getBoundingClientRect();
    const cx = e.touches ? e.touches[0].clientX : e.clientX;
    const cy = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: cx - r.left, y: cy - r.top };
  }

  function onDown(e){
    if(!bird.active || bird.launched || birdsCount <= 0) return;
    const p = getPos(e);
    if(Math.hypot(p.x - bird.x, p.y - bird.y) < 40){
      dragging = true;
    }
  }
  function onMove(e){
    if(!dragging) return;
    const p = getPos(e);
    const dist = Math.hypot(p.x - slingX, p.y - slingY);
    const maxPull = 60;
    if(dist > maxPull){
      const ang = Math.atan2(p.y - slingY, p.x - slingX);
      bird.x = slingX + Math.cos(ang) * maxPull;
      bird.y = slingY + Math.sin(ang) * maxPull;
    }else{
      bird.x = p.x; bird.y = p.y;
    }
  }
  function onUp(){
    if(!dragging) return;
    dragging = false;
    const dx = slingX - bird.x;
    const dy = slingY - bird.y;
    if(Math.hypot(dx, dy) > 15){
      bird.launched = true;
      bird.vx = dx * 0.28;
      bird.vy = dy * 0.28;
      birdsCount--;
      document.getElementById('birdsLeft3').innerText = 'BURUNG: ' + '🔴 '.repeat(birdsCount) || 'HABIS';
      playSnd('launch');
    }else{
      bird.x = slingX; bird.y = slingY;
    }
  }

  c.addEventListener('touchstart', onDown, { passive: true });
  c.addEventListener('touchmove', onMove, { passive: true });
  c.addEventListener('touchend', onUp);
  c.addEventListener('mousedown', onDown);
  c.addEventListener('mousemove', onMove);
  c.addEventListener('mouseup', onUp);

  buildCastle();
  resetBird();

  function loop(){
    ctx.clearRect(0, 0, W, H);

    // Langit Gradien & Awan
    const sky = ctx.createLinearGradient(0, 0, 0, H * 0.75);
    sky.addColorStop(0, '#38bdf8'); sky.addColorStop(1, '#bae6fd');
    ctx.fillStyle = sky; ctx.fillRect(0, 0, W, H * 0.75);

    // Tanah Rumput
    ctx.fillStyle = '#65a30d'; ctx.fillRect(0, H * 0.75, W, H * 0.25);
    ctx.fillStyle = '#4d7c0f'; ctx.fillRect(0, H * 0.75 + 14, W, H * 0.25);

    // Gambar Ketapel
    ctx.strokeStyle = '#78350f'; ctx.lineWidth = 8;
    ctx.beginPath(); ctx.moveTo(slingX, H * 0.75); ctx.lineTo(slingX, slingY + 18);
    ctx.lineTo(slingX - 16, slingY - 14); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(slingX, slingY + 18); ctx.lineTo(slingX + 16, slingY - 14); ctx.stroke();

    // Karet Ketapel (Saat Ditarik)
    if(dragging){
      ctx.strokeStyle = '#451a03'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.moveTo(slingX - 14, slingY - 10); ctx.lineTo(bird.x, bird.y); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(slingX + 14, slingY - 10); ctx.lineTo(bird.x, bird.y); ctx.stroke();

      // Titik Prediksi Lintasan Parabola
      ctx.fillStyle = 'rgba(255,255,255,0.7)';
      let simX = bird.x, simY = bird.y;
      let simVx = (slingX - bird.x) * 0.28, simVy = (slingY - bird.y) * 0.28;
      for(let i = 0; i < 18; i++){
        simX += simVx; simY += simVy; simVy += 0.45;
        ctx.beginPath(); ctx.arc(simX, simY, 2.5, 0, Math.PI * 2); ctx.fill();
      }
    }

    // Update Burung Terbang
    if(bird.launched){
      bird.x += bird.vx;
      bird.y += bird.vy;
      bird.vy += 0.45; // gravitasi

      // Tabrak tanah
      if(bird.y >= H * 0.75 - bird.r){
        bird.y = H * 0.75 - bird.r;
        bird.vy = -bird.vy * 0.35;
        bird.vx *= 0.65;
        if(Math.abs(bird.vx) < 0.4 && Math.abs(bird.vy) < 0.5){
          bird.launched = false;
          setTimeout(() => {
            const pigsLeft = pigs.filter(p => p.alive).length;
            if(pigsLeft === 0){
              document.getElementById('gover3').classList.add('show');
              document.getElementById('govTitle3').innerText = '🏆 MENANG! SEMUA BABI HANCUR!';
              document.getElementById('finalScore3').innerText = 'Total Skor: ' + score;
            } else if(birdsCount <= 0){
              document.getElementById('gover3').classList.add('show');
              document.getElementById('govTitle3').innerText = '💀 BURUNG HABIS!';
              document.getElementById('finalScore3').innerText = 'Skor: ' + score + ' (Babi tersisa: ' + pigsLeft + ')';
            } else {
              resetBird();
            }
          }, 600);
        }
      }

      // Tabrak Balok
      blocks.forEach(b => {
        if(b.hp > 0 && Math.abs(bird.x - b.x) < b.w/2 + bird.r && Math.abs(bird.y - b.y) < b.h/2 + bird.r){
          b.hp--;
          bird.vx *= 0.6;
          score += 50;
          document.getElementById('score3').innerText = 'SKOR: ' + score;
          playSnd('hit');
          for(let i = 0; i < 6; i++){
            particles.push({ x: bird.x, y: bird.y, vx: (Math.random()-0.5)*5, vy: (Math.random()-0.5)*5, c: b.col, life: 1 });
          }
        }
      });

      // Tabrak Babi
      pigs.forEach(p => {
        if(p.alive && Math.hypot(bird.x - p.x, bird.y - p.y) < p.r + bird.r){
          p.alive = false;
          score += 200;
          document.getElementById('score3').innerText = 'SKOR: ' + score;
          playSnd('pop');
          updatePigsUI();
          for(let i = 0; i < 12; i++){
            particles.push({ x: p.x, y: p.y, vx: (Math.random()-0.5)*7, vy: (Math.random()-0.5)*7, c: '#22c55e', life: 1 });
          }
        }
      });
    }

    // Render Balok Kayu/Batu
    blocks.forEach(b => {
      if(b.hp > 0){
        ctx.fillStyle = b.col;
        ctx.fillRect(b.x - b.w/2, b.y - b.h/2, b.w, b.h);
        ctx.strokeStyle = 'rgba(0,0,0,0.3)'; ctx.lineWidth = 1.5;
        ctx.strokeRect(b.x - b.w/2, b.y - b.h/2, b.w, b.h);
      }
    });

    // Render Babi Hijau
    pigs.forEach(p => {
      if(p.alive){
        ctx.fillStyle = '#22c55e'; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#16a34a'; ctx.beginPath(); ctx.ellipse(p.x, p.y + 2, p.r * 0.5, p.r * 0.35, 0, 0, Math.PI * 2); ctx.fill();
        // Hidung
        ctx.fillStyle = '#14532d'; ctx.beginPath(); ctx.arc(p.x - 3, p.y + 2, 2, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(p.x + 3, p.y + 2, 2, 0, Math.PI * 2); ctx.fill();
        // Mata
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(p.x - 6, p.y - 4, 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(p.x + 6, p.y - 4, 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(p.x - 6, p.y - 4, 1.5, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(p.x + 6, p.y - 4, 1.5, 0, Math.PI * 2); ctx.fill();
      }
    });

    // Render Burung Merah
    if(bird.active){
      ctx.fillStyle = '#ef4444'; ctx.beginPath(); ctx.arc(bird.x, bird.y, bird.r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#f87171'; ctx.beginPath(); ctx.arc(bird.x - 4, bird.y - 4, bird.r * 0.4, 0, Math.PI * 2); ctx.fill();
      // Paruh Kuning
      ctx.fillStyle = '#facc15'; ctx.beginPath();
      ctx.moveTo(bird.x + bird.r - 2, bird.y - 2); ctx.lineTo(bird.x + bird.r + 9, bird.y); ctx.lineTo(bird.x + bird.r - 2, bird.y + 4);
      ctx.closePath(); ctx.fill();
      // Mata & Alis Garang
      ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.arc(bird.x + 3, bird.y - 3, 4, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(bird.x + 4, bird.y - 3, 2, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#000'; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.moveTo(bird.x - 3, bird.y - 8); ctx.lineTo(bird.x + 8, bird.y - 4); ctx.stroke();
    }

    // Render Partikel Efek
    for(let i = particles.length - 1; i >= 0; i--){
      const pt = particles[i];
      pt.x += pt.vx; pt.y += pt.vy; pt.vy += 0.2; pt.life -= 0.04;
      if(pt.life <= 0){ particles.splice(i, 1); continue; }
      ctx.fillStyle = pt.c; ctx.globalAlpha = pt.life;
      ctx.fillRect(pt.x, pt.y, 4, 4);
      ctx.globalAlpha = 1.0;
    }

    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();
<\/script>`;

// ==================== BOT HANDLER ====================
const handler = async (m, { conn }) => {
  const responseId = genUuid();
  const botResponseId = genUuid();

  const payloadData = {
    response_id: responseId,
    sections: [
      {
        view_model: {
          primitive: {
            text: '> 🎮 *ARCADE MINI GAMES (PREMIUM)*\\n> Buka tab di bawah untuk mulai bermain game seru:\\n> 1. 🏹 *Panah Master* (Archery King & Bullseye)\\n> 2. 🚇 *Subway Surfers 3D* (Lari di 3 Rel Kereta)\\n> 3. 🐦 *Angry Birds* (Ketapel Burung & Ledakkan Babi)',
            __typename: 'GenAIMarkdownTextUXPrimitive',
          },
          __typename: 'GenAISingleLayoutViewModel',
        },
      },
    ],
    embedded_screens: [
      {
        title: 'Arcade Mini Games',
        content: [
          {
            __typename: 'FOAIDNixelButtonSheets',
            tabs: [
              {
                id: 'tab_0',
                tab_header: '🏹 Panah Master',
                sections: [
                  {
                    __typename: 'GenAIUnifiedResponseSection',
                    view_model: {
                      __typename: 'GenAISingleLayoutViewModel',
                      primitive: {
                        __typename: 'GenAIaeacdsnwHtmlPrimitive',
                        payload: gamePanahHtml,
                        trusted_sources: [
                          'store.ubet.my.id',
                          'youtube.com',
                          'keyrafara.com',
                          'lrclib.net',
                          'spotify.com'
                        ],
                      },
                    },
                  },
                ],
                step_entries: [],
              },
              {
                id: 'tab_1',
                tab_header: '🚇 Subway Surfers',
                sections: [
                  {
                    __typename: 'GenAIUnifiedResponseSection',
                    view_model: {
                      __typename: 'GenAISingleLayoutViewModel',
                      primitive: {
                        __typename: 'GenAIaeacdsnwHtmlPrimitive',
                        payload: gameSubwaySurfersHtml,
                        trusted_sources: [
                          'store.ubet.my.id',
                          'youtube.com',
                          'keyrafara.com',
                          'lrclib.net',
                          'spotify.com'
                        ],
                      },
                    },
                  },
                ],
                step_entries: [],
              },
              {
                id: 'tab_2',
                tab_header: '🐦 Angry Birds',
                sections: [
                  {
                    __typename: 'GenAIUnifiedResponseSection',
                    view_model: {
                      __typename: 'GenAISingleLayoutViewModel',
                      primitive: {
                        __typename: 'GenAIaeacdsnwHtmlPrimitive',
                        payload: gameAngryBirdsHtml,
                        trusted_sources: [
                          'store.ubet.my.id',
                          'youtube.com',
                          'keyrafara.com',
                          'lrclib.net',
                          'spotify.com'
                        ],
                      },
                    },
                  },
                ],
                step_entries: [],
              },
            ],
          },
        ],
      },
    ],
  };

  await conn.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {
          messageDisclaimerText: '',
          botResponseId: botResponseId,
          verificationMetadata: {
            proofs: [
              {
                version: 1,
                useCase: 1,
                signature: 'TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YY28GDo8OXSlgg==',
                certificateChain: [
                  'TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGE663ESCbLizCieg4wPebEFhVgH2dAgtZ8ajRuM4EY9p4BB4ay1X8InJh4KPu2GGhxlhPifhj3TFWzDND9OoPAx9ngvHgJ7qW+qq4UWIO3BxUoSc1UlkrSRYrDad3Oddz6dbHJqguhpE4JQ9nTyVT3lFWnuMg2oBEXG2mkdFR1fOnKG03454VeAGFLQfQMoAlq7AfmTFVXn45X8kMduwwCFuSE3sIF8uAMhP5Ng1Rn+mMmGZfne5RsyCa4wuHhv9p5KVKgnP8NXF6Sv6kAx5Dcer/qxZRaofRXTp7kSenmU+HU1w9KQfsEpHdbsfoRXKsscYm2KYl45U+FaFWbdaM1SXso3kE7SmMbNNCoJyX1ra8qoCXn940lJ3NjAb/7V6FjV7kHXXQycABxEtM7f3XaWzBMAnHMv43vTYv0g14snH90OpBPAJoOqA9Fhd+7636dOAT1pEQfCaghq/oSE2+/c0pbXK20WxtrzJnGRO6Kiy3R9KWMiPlbQu5Npoiu25PMFqujhoZiteQY3EoQnxLCHWZuV7ozseUrnfCbSGuzIvvd2iwx3z7k2Vlh5+vuiM9/j6/tstk5KG0AhP/G4aOAnbQfnowH1jpCC51Onnoz9eXDBwYOmA/QCiLgIL9PcJUoMPERaX0bp3Oy5q77VNVzFhIWFWVukfWn7uNmZgKFqfPzLAiy5nBEwfSrf23tmXxjbF0131XO1KbraDB0TVktoWMF45Y2U81rB4yD7WR+MFxMRaA3EF+jC6i/+giHnUHRhb3F4BF3derq03u1EmegX6dnt43U5dnSZmJb9pmQslhBaFlWJqRK82gqfdRtT5r4Q/wamUUgrIGjS',
                  'TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGFOvdeboN7QHpWcPzdiI0ToTcoQmXrfuUIXi8v7akW/tOniN+d81uRd3SAcEEBKYyU3FCvolzcQCSd/P1+7jc8AwUqwp7OE0QpcJmqTO7EBLHQHx5B2gEZN0+ELrpuGdG3pQRVs7UB0bhTChnGR3asNYE6akIIrcMBKLaH0A+RjpJ0cOMh4Im9ZysfMWlFkng2Q0rmbBjxmxt/uY2hMDC6FAT6Agty8fSMQZAqU1KgbDpe/0kHA1p0U04N2t7xgi/zCsrPIHrq3YSKn1pYAmUeT+F/CK5Wz2SsEN7DicSMzHsK5XMJ0sWFp4ICrmSp+n5dhzrW/rt2ZB6sEyX4ll1z0dRuApMLNV4+j96Ir+0FzQ1QwNzMDHdQMSYXJulErBjjuK7j6BPG3lGd6yaGIZbfkZmL4ohq/thIIFP99JsUppkox0ENCmXkcwYfvTw8Ob+fv5VeTycFXUIufKV/Sc16Yf4bi5Hlr1U/zQRb/T86KHxUBBYuDW4F0PbrOZUGKaWKoWlHG2ZLTxLYomYbS/K7EyF6zjeLLioB/kQOtqD1K8R5u4tl7WnauJLV6jANHFWRflWdoBTETbgVE2Jew46vvQlk6VQKlava48yGAjZWvjkGCsZWUSu5azahZh9FbNbc/Z/cbY7++g2xxpTFywh698xyGsO4WSEIT9zWv3+esKut+/1BTu/hVZReQnU9NaJSeMpysUZmWmVM0FNQPPNrfYrj6p25MtyfjVT/AtCgEhNrin5q8unHgfDRUpi7WffTH3NFVVHcfOrc99/wHfAHUtAEFTdzjHSwJ+AODaXf/zbAnGXHqKgtcnesf+UhbPBK6HYX0T95EgGOUzwNPujmKUrcKNDFeCksP2QXSZiT1J03T/sGgIBABuuu6UoA1l8Id7qOtDl9umuZVsxFoXfVEzOR702oL3fwCCWJr8U9UJ6aUHa4o/lXP/zFoC4rV9DFvntb5HfPDL2taOmYocN1iI3l9rl4S+Pvoo8iFjRrwJAikIgZ+pbX137sfKdETrgw0QuW+khRtsj6Q90s3vmI/bxRNASxBKws92R/JCSZUenpRtSUrRoY9mvFlq7qsbAWkGA09lzFCVB/sK/kXJLBGgx+298TvhBYyOw==',
                ],
              },
            ],
          },
        },
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 2,
                messageText: '> 🎮 *ARCADE MINI GAMES*\\n> 1. 🏹 Panah Master (Tarik Busur & Skor Target)\\n> 2. 🚇 Subway Surfers (Lari di Rel Kereta & Hindari Rintangan)\\n> 3. 🐦 Angry Birds (Ketapel Burung & Hancurkan Babi)',
              },
            ],
            unifiedResponse: {
              data: Buffer.from(JSON.stringify(payloadData)).toString('base64'),
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedAiBotMessageInfo: {
                botJid: '867051314767696@bot',
              },
              forwardOrigin: 4,
            },
          },
        },
      },
    },
    {
      additionalNodes: [
        {
          tag: 'biz',
          attrs: {},
          content: [
            {
              tag: 'interactive',
              attrs: { type: 'native_flow', v: '1' },
              content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }],
            },
          ],
        },
      ],
    }
  );
};

handler.help = ['game', 'arcade', 'panah', 'subway', 'angrybird'];
handler.tags = ['games'];
handler.command = /^(game|arcade|panah|subway|subwaysurfer|subwaysurfers|angrybird|angrybirds)$/i;

export default handler;