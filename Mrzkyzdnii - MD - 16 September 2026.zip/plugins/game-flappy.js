let handler = async (m, { conn, text, usedPrefix, command }) => {
  await m.react('✨')

  conn.relayMessage(
m.chat,
{
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
botMetadata: {
messageDisclaimerText: "",
botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860",
verificationMetadata: {
proofs: [
{
version: 1,
useCase: 1,
signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
certificateChain: [
"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
]
}
]
}
}
},
botForwardedMessage: {
message: {
richResponseMessage: {
messageType: 1,
submessages: [
{
messageType: 2,
messageText: "Flappy Bird"
}
],
unifiedResponse: {
data: Buffer.from(JSON.stringify({
"response_id": "flappy-1b2c3d4e-5f6g-7h8i-9j0k",
"sections": [
{
"view_model": {
"primitive": {
"__typename": "GenAIaeacdsnwHtmlPrimitive",
"payload": "<style>{-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}</style>\n<body style='margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee;touch-action:manipulation;cursor:pointer'>\n<div style='width:100%;max-width:620px;margin:auto;padding:16px;box-sizing:border-box'>\n<div style='background:rgba(255,255,255,.06);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.15);border-radius:16px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.35)'>\n<div style='padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.12);display:flex;justify-content:space-between;align-items:center'>\n<div><div style='font-size:11px;letter-spacing:1.5px;color:rgba(255,255,255,.45)'>FLAPPY</div><div style='font-size:21px;font-weight:bold;color:#fff'>Flappy Bird</div></div>\n<div style='text-align:right'><div id='score' style='font-size:18px;font-weight:bold;color:#fff;text-shadow:0 0 10px rgba(108,92,231,.85)'>0</div><div id='best' style='font-size:10px;color:rgba(255,255,255,.4);margin-top:2px'>BEST 0</div></div>\n</div>\n<div style='padding:18px'>\n<canvas id='game' width='400' height='600' style='width:100%;height:auto;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.12);border-radius:12px;display:block'></canvas>\n<div id='status' style='text-align:center;margin-top:10px;font-size:12px;color:rgba(255,255,255,.55)'>Tap atau spasi untuk terbang</div>\n</div></div></div>\n<script>\nconst c=document.getElementById('game'),ctx=c.getContext('2d');\nconst scoreEl=document.getElementById('score'),bestEl=document.getElementById('best');\nconst GRAVITY=0.4, JUMP=-7, PIPE_W=52, PIPE_GAP=150, PIPE_SPEED=2.5;\nlet bird, pipes, score, best=0, gameOver, frame;\nfunction loadBest(){try{let v=localStorage.getItem('flappy_best');if(v)best=parseInt(v)||0}catch(e){}return best}\nfunction saveBest(v){try{localStorage.setItem('flappy_best',String(v))}catch(e){}}\nbest=loadBest();bestEl.textContent='BEST '+best;\nfunction reset(){\nbird={x:60,y:280,w:30,h:24,vy:0,rot:0};\npipes=[];score=0;gameOver=false;frame=0;\nscoreEl.textContent='0';\n}\nfunction addPipe(){\nlet minH=60,maxH=c.height-PIPE_GAP-60;\nlet h=minH+Math.random()*(maxH-minH);\npipes.push({x:c.width,y:h,w:PIPE_W,h:h,scored:false});\npipes.push({x:c.width,y:h+PIPE_GAP,w:PIPE_W,h:c.height-h-PIPE_GAP});\n}\nfunction hitTest(){\nif(bird.y<0||bird.y+bird.h>c.height)return true;\nfor(let p of pipes){\nif(bird.x+10<p.x+p.w && bird.x+bird.w-10>p.x && bird.y+10<p.y+p.h && bird.y+bird.h-10>p.y)return true;\n}\nreturn false;\n}\nfunction jump(){if(gameOver){reset();return}bird.vy=JUMP;bird.rot=-0.4}\nfunction update(){\nif(gameOver)return;\nframe++;\nbird.vy+=GRAVITY;\nbird.y+=bird.vy;\nbird.rot=Math.min(0.8,bird.rot+0.03);\nif(bird.vy<0)bird.rot=-0.35;\nfor(let p of pipes) p.x-=PIPE_SPEED;\npipes=pipes.filter(p=>p.x>-80);\nif(frame%90===0)addPipe();\nfor(let p of pipes){\nif(!p.scored && p.x+p.w<bird.x){\np.scored=true;score++;scoreEl.textContent=score;\nif(score>best){best=score;saveBest(best);bestEl.textContent='BEST '+best}\n}\n}\nif(hitTest()){gameOver=true;saveBest(best)}\n}\nfunction drawBird(){\nctx.save();\nctx.translate(bird.x+bird.w/2,bird.y+bird.h/2);\nctx.rotate(bird.rot);\nctx.fillStyle='#ffcc00';\nctx.shadowColor='rgba(255,200,0,.5)';ctx.shadowBlur=16;\nctx.beginPath();ctx.ellipse(0,0,bird.w/2,bird.h/2,0,0,Math.PI*2);ctx.fill();\nctx.shadowBlur=0;\nctx.fillStyle='#fff';\nctx.beginPath();ctx.arc(6,-4,6,0,Math.PI*2);ctx.fill();\nctx.fillStyle='#222';\nctx.beginPath();ctx.arc(8,-5,3,0,Math.PI*2);ctx.fill();\nctx.fillStyle='#ff6600';\nctx.beginPath();ctx.moveTo(12,0);ctx.lineTo(20,-4);ctx.lineTo(20,4);ctx.closePath();ctx.fill();\nctx.restore();\n}\nfunction drawPipe(p){\nctx.fillStyle='#4caf50';\nctx.shadowColor='rgba(76,175,80,.3)';ctx.shadowBlur=8;\nctx.fillRect(p.x,p.y,p.w,p.h);\nctx.shadowBlur=0;\nctx.fillStyle='#388e3c';\nctx.fillRect(p.x-6,p.y+8,6,20);\nctx.fillRect(p.x+p.w,p.y+8,6,20);\nif(p.y===0){\nctx.fillRect(p.x-6,p.y+p.h-28,6,20);\nctx.fillRect(p.x+p.w,p.y+p.h-28,6,20);\n}\n}\nfunction draw(){\nctx.clearRect(0,0,c.width,c.height);\nctx.fillStyle='rgba(255,255,255,.08)';\nfor(let i=0;i<20;i++){ctx.fillRect(i*30+frame%60,0,2,c.height)}\nfor(let p of pipes) drawPipe(p);\ndrawBird();\nif(gameOver){\nctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(0,0,c.width,c.height);\nctx.fillStyle='#fff';ctx.textAlign='center';ctx.font='bold 28px Arial';\nctx.fillText('GAME OVER',c.width/2,280);\nctx.font='16px Arial';ctx.fillText('Tap untuk main lagi',c.width/2,330);\nctx.textAlign='left';\n}\n}\nfunction loop(){\nupdate();draw();requestAnimationFrame(loop);\n}\ndocument.addEventListener('pointerdown',e=>{e.preventDefault();jump()});\ndocument.addEventListener('keydown',e=>{if(e.code==='Space'){e.preventDefault();jump()}});\nreset();addPipe();addPipe();loop();\n</script></body>",
"trusted_sources": ["adam.dev"]
},
"__typename": "GenAISingleLayoutViewModel"
}
}
]
})).toString('base64')
},
contextInfo: {
forwardingScore: 1,
isForwarded: true,
forwardedAiBotMessageInfo: {
botJid: "867051314767696@bot"
},
forwardOrigin: 4
}
}
}
}
},
{}
)
}

handler.help = ['flappy']
handler.tags = ['game']
handler.command = /^flappy$/i
handler.limit = 10

export default handler