import axios from 'axios'
import * as cheerio from 'cheerio'
import FormData from 'form-data'
import querystring from 'querystring'
import fs from 'fs'
import path from 'path'

// Database file lokal agar style yang di-add tersimpan permanen
const DB_PATH = path.resolve('./textpro_styles.json')

// Database default style TextPro.me (Single-Text Input)
const defaultStyles = [
{ title: "Cute 3D Candy", url: "https://textpro.me/online-cute-3d-candy-text-effect-generator-1192.html" },
{ title: "3D Sand Text Effect", url: "https://textpro.me/realistic-3d-sand-text-effect-online-580.html" },
{ title: "3D Wooden Text Effect", url: "https://textpro.me/3d-wooden-text-effects-online-104.html" },
{ title: "3D Gradient Text Effect", url: "https://textpro.me/create-3d-gradient-text-effect-online-600.html" },
{ title: "3D Luxury Gold Text", url: "https://textpro.me/create-a-luxury-gold-text-effect-online-594.html" },
{ title: "3D Comic Text Style", url: "https://textpro.me/create-online-3d-comic-style-text-effects-817.html" },
{ title: "Dragon Ball Text Style", url: "https://textpro.me/create-dragon-ball-style-text-effects-online-809.html" },
{ title: "Glossy Silver 3D Text", url: "https://textpro.me/create-glossy-silver-3d-text-effect-online-802.html" },
{ title: "Pixel Glitch Effect", url: "https://textpro.me/create-pixel-glitch-text-effect-online-769.html" },
{ title: "Neon Light Text Effect", url: "https://textpro.me/making-neon-light-text-effect-with-galaxy-style-521.html" },
{ title: "1917 Movie Text Effect", url: "https://textpro.me/1917-style-text-effect-523.html" },
{ title: "Broken Glass Text Effect", url: "https://textpro.me/create-broken-glass-text-effect-online-698.html" }
]

// Fungsi ambil daftar style
const getStyles = () => {
try {
if (!fs.existsSync(DB_PATH)) {
fs.writeFileSync(DB_PATH, JSON.stringify(defaultStyles, null, 2))
return defaultStyles
}
return JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'))
} catch {
return defaultStyles
}
}

// Fungsi simpan daftar style
const saveStyles = (styles) => {
try {
fs.writeFileSync(DB_PATH, JSON.stringify(styles, null, 2))
} catch (err) {
console.error('Gagal menyimpan styles TextPro:', err)
}
}

// Scraper Engine TextPro.me (Bypass Signature, Payload Rebuilding & Fetch Image Buffer)
const scraper = async (pageUrl, text) => {
const headers = {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
'Accept-Language': 'en-US,en;q=0.9',
'Origin': 'https://textpro.me',
'Referer': pageUrl
}

// 1. Ambil session cookies, form token, & build_server
const getRes = await axios.get(pageUrl, { headers })
const rawCookies = getRes.headers['set-cookie'] || []
let cookies = rawCookies.map(c => c.split(';')[0]).join('; ')

const $ = cheerio.load(getRes.data)
const token = $('input[name="token"]').val()
const buildServer = $('input[name="build_server"]').val()
const buildServerId = $('input[name="build_server_id"]').val()

if (!token || !buildServer) {
throw new Error('Gagal mengambil parameter token atau server TextPro.')
}

// 2. Submit data teks ke endpoint form
const form = new FormData()
form.append('text[]', text)
form.append('submit', 'Go')
form.append('token', token)
form.append('build_server', buildServer)
form.append('build_server_id', buildServerId)

const postRes = await axios.post(pageUrl, form, {
headers: {
...form.getHeaders(),
'Cookie': cookies,
'User-Agent': headers['User-Agent'],
'Referer': pageUrl,
'Origin': 'https://textpro.me'
}
})

if (postRes.headers['set-cookie']) {
const postCookies = postRes.headers['set-cookie'].map(c => c.split(';')[0]).join('; ')
cookies = `${cookies}; ${postCookies}`
}

// 3. Ekstrak payload rahasia & Signature ('sign') dari #form_value
const $post = cheerio.load(postRes.data)
const formValueRaw = $post('#form_value').first().text() || $post('input[name="form_value_input"]').val()

if (!formValueRaw) {
throw new Error('Gagal memproses form (form_value tidak ditemukan).')
}

const jsonMatch = formValueRaw.match(/{"id":[\s\S]*?}/)
if (!jsonMatch) {
throw new Error('Gagal parsing payload signature dari TextPro.')
}

const formDataObj = JSON.parse(jsonMatch[0])

// 4. Request image render final dengan menyertakan cryptographic signature ('sign')
const postData = querystring.stringify({
id: formDataObj.id,
'text[]': formDataObj.text,
token: formDataObj.token,
build_server: formDataObj.build_server,
build_server_id: formDataObj.build_server_id,
sign: formDataObj.sign
})

const createRes = await axios.post('https://textpro.me/effect/create-image', postData, {
headers: {
'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
'Cookie': cookies,
'User-Agent': headers['User-Agent'],
'Referer': pageUrl,
'Origin': 'https://textpro.me',
'X-Requested-With': 'XMLHttpRequest'
}
})

if (!createRes.data || !createRes.data.success) {
throw new Error(createRes.data?.info || 'Gagal generate gambar dari server TextPro.')
}

const fullImageUrl = formDataObj.build_server + createRes.data.image

// 5. Download langsung gambar sebagai Buffer agar aman dari blokir hotlink / CORS
const imageRes = await axios.get(fullImageUrl, {
responseType: 'arraybuffer',
headers: {
'User-Agent': headers['User-Agent'],
'Referer': 'https://textpro.me/'
}
})

return {
buffer: Buffer.from(imageRes.data),
url: fullImageUrl
}
}

// Bot Handler
const handler = async (m, { conn, text, usedPrefix, command }) => {
const styles = getStyles()

if (!text) {
throw `乂 T E X T P R O M E M A K E R

📌 Menu Perintah:
• ${usedPrefix + command} list ➔ Melihat semua style yang tersedia
• ${usedPrefix + command} add ➔ Menambahkan style TextPro otomatis
• ${usedPrefix + command} delete ➔ Menghapus style TextPro
• ${usedPrefix + command} <nomor/nama> | <teks> ➔ Membuat efek teks

💡 Contoh:
• ${usedPrefix + command} 1 | Sweet Candy
• ${usedPrefix + command} candy | Abid Ganteng
• ${usedPrefix + command} add https://textpro.me/online-cute-3d-candy-text-effect-generator-1192.html
• ${usedPrefix + command} delete 5
• ${usedPrefix + command} delete "Candy"`
}

const trimmedText = text.trim()

// 1. LIHAT DAFTAR STYLE
if (trimmedText.toLowerCase() === 'list') {
let caption = `乂 T E X T P R O S T Y L E S (Total: ${styles.length})\n\n`
styles.forEach((style, index) => {
caption += `${index + 1}. ${style.title}\n`
})
caption += `\n_Cara pakai: *${usedPrefix + command} <nomor> | <teks>*_\n_Tambah style: *${usedPrefix + command} add <url>*_\n_Hapus style: *${usedPrefix + command} delete <nomor/judul>*_`
return await conn.reply(m.chat, caption.trim(), m)
}

// 2. TAMBAH STYLE OTOMATIS
if (trimmedText.toLowerCase().startsWith('add')) {
const targetUrl = trimmedText.slice(3).trim()

if (!targetUrl || !/^https?:\/\/textpro\.me\/.+\.html/i.test(targetUrl)) {
throw `Link tidak valid! Pastikan link dari website textpro.me dan berakhiran .html\nContoh:\n*${usedPrefix + command} add https://textpro.me/online-cute-3d-candy-text-effect-generator-1192.html*`
}

const isExist = styles.find(s => s.url.toLowerCase() === targetUrl.toLowerCase())
if (isExist) {
return await conn.reply(m.chat, `⚠️ Style sudah ada:\n*${isExist.title}* (Nomor ${styles.indexOf(isExist) + 1})`, m)
}

await conn.reply(m.chat, '🔍 Memeriksa link dan mengambil judul style TextPro...', m)

try {
const res = await axios.get(targetUrl, {
headers: {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
}
})

const $ = cheerio.load(res.data)
const form = $('form#main-form, form.ajax-submit')
const textInputs = form.find('input[name="text[]"]')
const fileInputs = form.find('input[type="file"], input[name="myfile"]')

if (textInputs.length !== 1 || fileInputs.length > 0) {
throw new Error('Style ini memerlukan lebih dari 1 input atau memerlukan upload file gambar.')
}

let autoTitle = $('h1, #effect_title').first().text().trim()
if (!autoTitle) {
autoTitle = $('title').text().replace(/\s*-\s*Textpro\.me/gi, '').replace(/\s*online\s*/gi, ' ').trim()
}

const newStyle = { title: autoTitle, url: targetUrl }
styles.push(newStyle)
saveStyles(styles)

return await conn.reply(
m.chat,
`✅ *Berhasil Ditambahkan!*\n\n• *Nomor:* ${styles.length}\n• *Title:* ${autoTitle}\n• *URL:* ${targetUrl}\n\nLangsung gunakan dengan cara:\n*${usedPrefix + command} ${styles.length} | teks kamu*`,
m
)
} catch (err) {
return await conn.reply(m.chat, `❌ Gagal menambahkan style: ${err.message}`, m)
}
}

// 3. DELETE STYLE
if (trimmedText.toLowerCase().startsWith('delete')) {
const deleteQuery = trimmedText.slice(6).trim()

if (!deleteQuery) {
throw `Cara hapus style:\n*${usedPrefix + command} delete <nomor>*\n*${usedPrefix + command} delete "<judul>"*\n\nContoh:\n*${usedPrefix + command} delete 5*\n*${usedPrefix + command} delete "Candy"*`
}

// Cek berdasarkan nomor
const deleteIndex = parseInt(deleteQuery) - 1
let deletedStyle = null
let deletedIndex = -1

if (!isNaN(deleteIndex) && deleteIndex >= 0 && deleteIndex < styles.length) {
deletedStyle = styles[deleteIndex]
deletedIndex = deleteIndex
} else {
// Cek berdasarkan judul (case insensitive, partial match)
const matchIndex = styles.findIndex(s => 
s.title.toLowerCase().includes(deleteQuery.toLowerCase())
)
if (matchIndex !== -1) {
deletedStyle = styles[matchIndex]
deletedIndex = matchIndex
}
}

if (!deletedStyle) {
throw `Style dengan nomor/judul *"${deleteQuery}"* tidak ditemukan!\nKetik *${usedPrefix + command} list* untuk melihat daftar style.`
}

// Cek apakah ini default style (tidak boleh dihapus)
const isDefault = defaultStyles.some(s => s.url === deletedStyle.url)
if (isDefault && styles.length <= defaultStyles.length) {
throw `❌ Tidak bisa menghapus style default TextPro!\n\nStyle *"${deletedStyle.title}"* adalah bawaan TextPro dan tidak dapat dihapus.`
}

// Hapus style
styles.splice(deletedIndex, 1)
saveStyles(styles)

return await conn.reply(
m.chat,
`🗑️ *Style Berhasil Dihapus!*\n\n• *Nama:* ${deletedStyle.title}\n• *URL:* ${deletedStyle.url}\n• *Sisa style:* ${styles.length}\n\nKetik *${usedPrefix + command} list* untuk melihat daftar terbaru.`,
m
)
}

// 4. GENERATE GAMBAR TEKS EFEK
const [styleInput, ...textInputArr] = text.split('|')
const styleQuery = styleInput?.trim().toLowerCase()
const customText = textInputArr.join('|').trim()

if (!styleQuery || !customText) {
throw `Format salah! Gunakan:\n*${usedPrefix + command} <nomor/nama/link> | <teks>*\n\nContoh:\n*${usedPrefix + command} 1 | My Candy*\n*${usedPrefix + command} list*`
}

let targetUrl = ''
const styleIndex = parseInt(styleQuery) - 1

if (!isNaN(styleIndex) && styles[styleIndex]) {
targetUrl = styles[styleIndex].url
} else if (styleQuery.startsWith('http://') || styleQuery.startsWith('https://')) {
targetUrl = styleInput.trim()
} else {
const matched = styles.find(s => s.title.toLowerCase().includes(styleQuery))
if (matched) {
targetUrl = matched.url
} else {
throw `Style *"${styleInput.trim()}"* tidak ditemukan!\nKetik *${usedPrefix + command} list* untuk melihat daftar nomor style.`
}
}

await conn.reply(m.chat, '⏳ Sedang merender teks efek TextPro, mohon tunggu...', m)

try {
const { buffer, url } = await scraper(targetUrl, customText)

await conn.sendFile(
m.chat,
buffer,
'textpro.jpg',
`*TextPro 3D Text Effect*\n• *Text:* ${customText}\n• *URL:* ${url}`,
m
)
} catch (err) {
await conn.reply(m.chat, `❌ Error: ${err.message}`, m)
}
}

handler.help = ['textpro']
handler.tags = ['maker']
handler.command = /^textpro$/i
handler.limit = 50

export default handler