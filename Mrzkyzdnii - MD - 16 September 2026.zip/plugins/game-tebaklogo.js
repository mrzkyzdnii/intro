import fs from 'fs'

let timeout = 60000 // 60 detik
let poin = 0 // opsional untuk skor

let handler = async (m, { conn, command, isAdmin, isOwner }) => {
  global.tebaklogo = global.tebaklogo || {}
  const chat = m.chat
  const room = global.tebaklogo[chat] || {}

  if (command === "tebaklogo" || command === "tlogo") {
    if (room.answer) 
      return conn.reply(chat, "❌ Masih ada soal belum terjawab di chat ini.", m)

    // Ambil data dari JSON
    let src = JSON.parse(fs.readFileSync('./json/tebaklogo.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]

    // Kirim gambar dengan deskripsi
    await conn.sendMessage(
      chat,
      {
        image: { url: json.img },
        caption: `🖼️ *TEBAK LOGO*\n\n📝 *Deskripsi:* ${json.deskripsi}\n⏳ Waktu: *60 detik*\n💡 Ketik jawaban langsung.\n🔑 Ketik *.whologo* untuk klu (Admin saja).`,
      },
      { quoted: m }
    )

    global.tebaklogo[chat] = {
      answer: json.jawaban.toLowerCase(),
      player: m.sender,
      timer: setTimeout(() => {
        conn.reply(chat, `❌ Waktu habis!\nJawaban: *${json.jawaban}*`)
        delete global.tebaklogo[chat]
      }, timeout),
    }
  }

  // Fitur clue (hanya admin/owner)
  if (command === "whologo") {
    if (!room.answer) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    if (!isAdmin && !isOwner)
      return conn.reply(chat, "❌ Klu hanya untuk admin/owner.", m)

    const ans = room.answer
    const hint = ans[0] + "_".repeat(Math.max(ans.length - 2, 1)) + ans.slice(-1)
    return conn.reply(chat, `🧩 *KLU:* ${hint}`, m)
  }

  // Fitur cek player
  if (command === "whoplayerlogo") {
    if (!room.player) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    return conn.reply(
      chat,
      `👤 Player: @${room.player.split("@")[0]}`,
      m,
      { mentions: [room.player] }
    )
  }
}

handler.all = async function (m) {
  const room = global.tebaklogo?.[m.chat]
  if (!room?.answer) return

  const text = (m.text || "").trim().toLowerCase()
  if (!text) return

  if (text === room.answer) {
    clearTimeout(room.timer)
    this.reply(m.chat, `✅ *Benar!* 🎉\nJawaban: *${room.answer}*`, m)
    delete global.tebaklogo[m.chat]
  }
}

handler.help = ["tebaklogo"]
handler.tags = ["game"]
handler.command = /^(tebaklogo|tlogo|whologo|whoplayerlogo)$/i
handler.limit = 10

export default handler