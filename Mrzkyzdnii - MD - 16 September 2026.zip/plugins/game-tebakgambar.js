import fs from 'fs'

let timeout = 60000 // 60 detik

let handler = async (m, { conn, command, isAdmin, isOwner }) => {
  global.tebakgambar = global.tebakgambar || {}

  const chat = m.chat
  const room = global.tebakgambar[chat] || {}

  // =========================
  // MULAI GAME
  // =========================
  if (command === 'tebakgambar' || command === 'tgambar') {
    if (room.answer) {
      return conn.reply(
        chat,
        '❌ Masih ada soal yang belum terjawab di chat ini.',
        m
      )
    }

    let src

    try {
      src = JSON.parse(
        fs.readFileSync('./json/tebakgambar.json', 'utf-8')
      )
    } catch (e) {
      return conn.reply(
        chat,
        '❌ Gagal membaca database tebak gambar.',
        m
      )
    }

    if (!Array.isArray(src) || !src.length) {
      return conn.reply(
        chat,
        '❌ Database tebak gambar kosong.',
        m
      )
    }

    const json = src[Math.floor(Math.random() * src.length)]

    if (!json.img || !json.jawaban) {
      return conn.reply(
        chat,
        '❌ Data soal tidak valid.',
        m
      )
    }

    await conn.sendMessage(
      chat,
      {
        image: { url: json.img },
        caption:
          `🧩 *TEBAK GAMBAR*\n\n` +
          `🖼️ Tebak kata/kalimat dari gambar di atas!\n` +
          `⏳ Waktu: *60 detik*\n` +
          `💰 Hadiah: *Rp5.000 - Rp10.000*\n` +
          `💡 Ketik jawaban langsung.\n` +
          `🔑 Ketik *.whogambar* untuk melihat deskripsi (Admin saja).`
      },
      { quoted: m }
    )

    global.tebakgambar[chat] = {
      answer: String(json.jawaban).trim().toLowerCase(),
      description: json.deskripsi || 'Tidak ada deskripsi.',
      player: m.sender,
      timer: setTimeout(() => {
        conn.reply(
          chat,
          `⏰ *WAKTU HABIS!*\n\n` +
          `❌ Jawaban yang benar:\n` +
          `*${json.jawaban}*`
        )

        delete global.tebakgambar[chat]
      }, timeout)
    }

    return
  }

  // =========================
  // CLUE / DESKRIPSI
  // ADMIN & OWNER
  // =========================
  if (command === 'whogambar') {
    if (!room.answer) {
      return conn.reply(
        chat,
        '❌ Tidak ada tebak gambar yang sedang aktif.',
        m
      )
    }

    if (!isAdmin && !isOwner) {
      return conn.reply(
        chat,
        '❌ Clue hanya bisa digunakan oleh admin/owner.',
        m
      )
    }

    return conn.reply(
      chat,
      `🧩 *CLUE TEBAK GAMBAR*\n\n` +
      `${room.description}`,
      m
    )
  }

  // =========================
  // CEK PLAYER
  // =========================
  if (command === 'whoplayergambar') {
    if (!room.player) {
      return conn.reply(
        chat,
        '❌ Tidak ada game aktif.',
        m
      )
    }

    return conn.reply(
      chat,
      `👤 *Player:* @${room.player.split('@')[0]}`,
      m,
      {
        mentions: [room.player]
      }
    )
  }

  // =========================
  // HINT
  // =========================
  if (command === 'hintgambar') {
    if (!room.answer) {
      return conn.reply(
        chat,
        '❌ Tidak ada tebak gambar yang sedang aktif.',
        m
      )
    }

    const answer = room.answer

    const hint = answer
      .split(' ')
      .map(word => {
        if (word.length <= 2) return word

        return (
          word[0] +
          '_'.repeat(word.length - 2) +
          word[word.length - 1]
        )
      })
      .join(' ')

    return conn.reply(
      chat,
      `🧩 *HINT:*\n\n${hint}`,
      m
    )
  }
}

// =========================
// CEK JAWABAN OTOMATIS
// =========================
handler.all = async function (m) {
  const room = global.tebakgambar?.[m.chat]

  if (!room?.answer) return

  const text = String(m.text || '')
    .trim()
    .toLowerCase()

  if (!text) return

  // Jawaban benar
  if (text === room.answer) {
    clearTimeout(room.timer)

    // Reward acak 5.000 - 10.000
    const reward =
      Math.floor(Math.random() * 5001) + 5000

    // Pastikan struktur user tersedia
    global.db.data.users[m.sender] =
      global.db.data.users[m.sender] || {}

    const user = global.db.data.users[m.sender]

    // Tambahkan money
    user.money = (user.money || 0) + reward

    await this.reply(
      m.chat,
      `╭━━〔 🎉 *BENAR!* 〕━━╮\n` +
      `┃\n` +
      `┃ 👤 Player › @${m.sender.split('@')[0]}\n` +
      `┃ 🎯 Jawaban › *${room.answer.toUpperCase()}*\n` +
      `┃\n` +
      `┃ 💰 Hadiah › *+Rp${reward.toLocaleString('id-ID')}*\n` +
      `┃ 💵 Money › *Rp${user.money.toLocaleString('id-ID')}*\n` +
      `┃\n` +
      `╰━━━━━━━━━━━━━━━━━━╯`,
      m,
      {
        mentions: [m.sender]
      }
    )

    delete global.tebakgambar[m.chat]
  }
}

handler.help = [
  'tebakgambar',
  'whogambar',
  'whoplayergambar',
  'hintgambar'
]

handler.tags = ['game']

handler.command =
  /^(tebakgambar|tgambar|whogambar|whoplayergambar|hintgambar)$/i

handler.limit = 10

export default handler