import axios from 'axios'

const downloadYt = async (url, format = '360') => {
  const initRes = await axios.get(
    `https://loader.to/ajax/download.php?format=${format}&url=${encodeURIComponent(url)}`,
    {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
      }
    }
  )

  const initData = initRes.data
  if (!initData.success) throw initData.message || 'Gagal memulai unduhan video'

  const progressUrl = initData.progress_url || `https://loader.to/ajax/progress.php?id=${initData.id}`
  let downloadUrl = null

  for (let i = 0; i < 25; i++) {
    await new Promise(r => setTimeout(r, 1500))
    const pRes = await axios.get(progressUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36'
      }
    })
    const pData = pRes.data
    if (pData.download_url) {
      downloadUrl = pData.download_url
      break
    }
  }

  if (!downloadUrl) throw 'Gagal memproses file media (Request Timeout)'

  return {
    title: initData.title || 'YouTube Media',
    format: initData.full_format || format,
    downloadUrl
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh Penggunaan:\n${usedPrefix + command} https://youtube.com/watch?v=j9MYFnxWrvU [resolusi]\n\nResolusi tersedia: 360, 480, 720, 1080\nContoh audio: ${usedPrefix}yta https://youtube.com/watch?v=j9MYFnxWrvU`

  const args = text.trim().split(/\s+/)
  const url = args[0]
  const isAudio = /^(yta|ytmp3)$/i.test(command)

  let quality = isAudio ? 'mp3' : '360'
  if (!isAudio && args[1] && ['360', '480', '720', '1080'].includes(args[1])) {
    quality = args[1]
  }

  await conn.reply(m.chat, `Sedang mengunduh ${isAudio ? 'audio MP3' : 'video ' + quality + 'p'}, tunggu sebentar...`, m)

  try {
    const data = await downloadYt(url, quality)

    if (isAudio) {
      await conn.sendFile(
        m.chat,
        data.downloadUrl,
        `${data.title}.mp3`,
        '',
        m,
        null,
        { mimetype: 'audio/mp4', ptt: false }
      )
    } else {
      const caption = `🎬 *${data.title}*\n📺 *Format:* ${data.format}`
      await conn.sendFile(
        m.chat,
        data.downloadUrl,
        `${data.title}.mp4`,
        caption,
        m,
        false,
        { mimetype: 'video/mp4' }
      )
    }
  } catch (e) {
    throw String(e.message || e)
  }
}

handler.help = ['ytv [url] [resolusi]', 'yta [url]']
handler.tags = ['downloader']
handler.command = /^(ytv|ytmp4|yta|ytmp3)$/i
handler.limit = 1

export default handler