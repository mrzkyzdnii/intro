import axios from 'axios'

const CF_ACCOUNT_ID = 'b48f4b3d5ab819451421fab4c5e0f321'
const CF_API_TOKEN = 'cfut_IApW4yTuOhYOUlbkCQvov3mWxWMWIrX9qLngwgDU8aad973e'

// Daftar model resmi Cloudflare Workers AI yang sudah verified 100% Work
const MODELS = {
  flux: {
    id: '@cf/black-forest-labs/flux-1-schnell',
    name: 'FLUX.1 Schnell (Photorealistic)',
    enhance: 'photorealistic, raw 35mm photograph, 8k uhd, realistic skin texture, cinematic lighting'
  },
  fast: {
    id: '@cf/bytedance/stable-diffusion-xl-lightning',
    name: 'SDXL Lightning (Super Fast 2s)',
    enhance: 'high quality, sharp focus, masterpiece, 8k'
  },
  anime: {
    id: '@cf/lykon/dreamshaper-8-lcm',
    name: 'DreamShaper 8 (Anime & 3D Art)',
    enhance: 'anime artwork, vibrant colors, detailed anime style, masterpiece'
  },
  sdxl: {
    id: '@cf/stabilityai/stable-diffusion-xl-base-1.0',
    name: 'Stable Diffusion XL Base',
    enhance: 'masterpiece, high quality, 8k resolution, detailed wallpaper'
  }
}

/**
 * Universal Client Cloudflare Workers AI
 */
const generateAIImage = async (prompt, style = 'flux') => {
  const selected = MODELS[style] || MODELS.flux
  const finalPrompt = `${prompt}, ${selected.enhance}`
  const endpoint = `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT_ID}/ai/run/${selected.id}`

  const response = await axios.post(
    endpoint,
    { prompt: finalPrompt },
    {
      headers: {
        Authorization: `Bearer ${CF_API_TOKEN}`,
        'Content-Type': 'application/json'
      },
      responseType: 'arraybuffer'
    }
  )

  const contentType = response.headers['content-type'] || ''
  let imageBuffer

  // Handle jika response berupa JSON (seperti model FLUX)
  if (contentType.includes('application/json')) {
    const json = JSON.parse(Buffer.from(response.data).toString())
    if (!json.success || !json.result?.image) {
      const errMsg = json.errors?.[0]?.message || 'Gagal generate gambar dari Cloudflare.'
      throw new Error(errMsg)
    }
    imageBuffer = Buffer.from(json.result.image, 'base64')
  } else {
    // Handle jika response berupa Raw Binary Image (seperti SDXL & DreamShaper)
    imageBuffer = Buffer.from(response.data)
  }

  return {
    buffer: imageBuffer,
    modelName: selected.name
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    throw `*Contoh Penggunaan:*\n` +
      `• *Default (Realistic FLUX):*\n  ${usedPrefix + command} a handsome boy in coffee shop\n` +
      `• *Mode Anime:*\n  ${usedPrefix + command} cute girl with katana --anime\n` +
      `• *Mode Super Fast (2 detik):*\n  ${usedPrefix + command} cyberpunk sport car --fast\n` +
      `• *Mode SDXL:*\n  ${usedPrefix + command} ancient fantasy dragon --sdxl`
  }

  let style = 'flux'
  let cleanPrompt = text

  // Filter flag pilihan model
  if (text.includes('--anime')) {
    style = 'anime'
    cleanPrompt = text.replace('--anime', '').trim()
  } else if (text.includes('--fast')) {
    style = 'fast'
    cleanPrompt = text.replace('--fast', '').trim()
  } else if (text.includes('--sdxl')) {
    style = 'sdxl'
    cleanPrompt = text.replace('--sdxl', '').trim()
  }

  await conn.reply(m.chat, `🎨 Sedang generate dengan *${MODELS[style].name}*...`, m)

  try {
    const { buffer, modelName } = await generateAIImage(cleanPrompt, style)

    await conn.sendFile(
      m.chat,
      buffer,
      'ai-generated.png',
      `*AI Image Generator*\n*Prompt:* ${cleanPrompt}\n*Model:* ${modelName}`,
      m
    )
  } catch (e) {
    throw `❌ Gagal: ${e.message}`
  }
}

handler.help = ['text2img']
handler.tags = ['ai']
handler.command = /^(text2img)$/i

export default handler