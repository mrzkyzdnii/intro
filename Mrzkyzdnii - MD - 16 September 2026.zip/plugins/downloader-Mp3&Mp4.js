import { execFile } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'
import os from 'os'
import path from 'path'

const execFileAsync = promisify(execFile)

const YTDLP = './yt-dlp'
const DENO = '/home/container/.deno/bin/deno'
const COOKIES = './proxy.txt'

const isYouTubeUrl = (url) =>
  /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\//i.test(url)

const safeFileName = (name) =>
  String(name || 'youtube')
    .replace(/[\\/:*?"<>|\u0000-\u001F]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80) || 'youtube'

const downloadMedia = async (url, type, dir) => {
  const output = path.join(dir, 'media.%(ext)s')

  const commonArgs = [
    '--js-runtimes',
    `deno:${DENO}`,
    '--remote-components',
    'ejs:github',
    '--cookies',
    COOKIES,
    '--no-playlist',
    '--no-update',
    '--no-warnings',
    '-o',
    output
  ]

  const args = type === 'audio'
    ? [
        ...commonArgs,
        '-f',
        '140/251/250/249/bestaudio',
        url
      ]
    : [
        ...commonArgs,
        '-f',
        'bv*[height<=360][ext=mp4]+ba[ext=m4a]/b[height<=360][ext=mp4]/b[height<=360]',
        '--merge-output-format',
        'mp4',
        url
      ]

  const { stdout, stderr } = await execFileAsync(YTDLP, args, {
    env: {
      ...process.env,
      PATH: `/home/container/.deno/bin:${process.env.PATH || ''}`
    },
    maxBuffer: 100 * 1024 * 1024
  })

  const files = fs.readdirSync(dir)
    .filter((file) => file.startsWith('media.'))
    .map((file) => path.join(dir, file))

  if (!files.length) {
    throw new Error(stderr || stdout || 'File hasil download tidak ditemukan.')
  }

  const preferredExt = type === 'audio'
    ? ['m4a', 'webm', 'mp3', 'opus']
    : ['mp4', 'webm', 'mkv']

  const file = files.sort((a, b) => {
    const aIndex = preferredExt.indexOf(path.extname(a).slice(1))
    const bIndex = preferredExt.indexOf(path.extname(b).slice(1))
    return (aIndex < 0 ? 999 : aIndex) - (bIndex < 0 ? 999 : bIndex)
  })[0]

  return file
}

const handler = async (m, { conn, text, command, usedPrefix }) => {
  if (!text?.trim()) {
    throw `Contoh:\n${usedPrefix + command} https://youtu.be/xxxxxx`
  }

  const url = text.trim()

  if (!isYouTubeUrl(url)) {
    throw 'Masukkan link YouTube yang valid.'
  }

  await m.react('⏳').catch(() => {})

  const type = command.toLowerCase() === 'ytmp4' ? 'video' : 'audio'
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ytmp-'))

  try {
    const file = await downloadMedia(url, type, tempDir)
    const ext = path.extname(file).toLowerCase()
    const title = safeFileName(path.basename(file, ext))
    const buffer = fs.readFileSync(file)

    if (type === 'audio') {
      const mimetype = ext === '.m4a'
        ? 'audio/mp4'
        : ext === '.mp3'
          ? 'audio/mpeg'
          : 'audio/webm'

      await conn.sendMessage(
        m.chat,
        {
          audio: buffer,
          mimetype,
          fileName: `${title}${ext}`,
          ptt: false
        },
        { quoted: m }
      )
    } else {
      await conn.sendMessage(
        m.chat,
        {
          video: buffer,
          mimetype: ext === '.mp4' ? 'video/mp4' : 'video/webm',
          fileName: `${title}${ext}`,
          caption: 'Berhasil mengunduh video 360p.'
        },
        { quoted: m }
      )
    }

    await m.react('💯').catch(() => {})
  } catch (error) {
    console.error('[YTMP ERROR]', error)
    await m.reply(`❌ Gagal mengunduh ${type === 'audio' ? 'audio' : 'video'}.\n\n${error?.stderr || error?.message || error}`)
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true })
  }
}

handler.help = ['ytmp3', 'ytmp4']
handler.tags = ['downloader']
handler.command = /^(ytmp3|ytmp4)$/i
handler.limit = 10

export default handler