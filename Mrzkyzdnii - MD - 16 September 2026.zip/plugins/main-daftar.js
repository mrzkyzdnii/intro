import { createCanvas, loadImage } from '@napi-rs/canvas'
import { createHash } from 'crypto'
import moment from 'moment-timezone'

const Reg = /^([\w\s]+)\s*,\s*(\d{1,3})$/i

const roundedRect = (ctx, x, y, w, h, r = 18) => {
  const radius = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.arcTo(x + w, y, x + w, y + h, radius)
  ctx.arcTo(x + w, y + h, x, y + h, radius)
  ctx.arcTo(x, y + h, x, y, radius)
  ctx.arcTo(x, y, x + w, y, radius)
  ctx.closePath()
}

const write = (
  ctx,
  value,
  x,
  y,
  size,
  color = '#2e3b45',
  weight = '600',
  align = 'left'
) => {
  ctx.font = `${weight} ${size}px Sans`
  ctx.fillStyle = color
  ctx.textAlign = align
  ctx.fillText(String(value), x, y)
  ctx.textAlign = 'left'
}

const line = (
  ctx,
  x1,
  y1,
  x2,
  y2,
  color = '#d7d1c7',
  width = 1
) => {
  ctx.beginPath()
  ctx.moveTo(x1, y1)
  ctx.lineTo(x2, y2)
  ctx.strokeStyle = color
  ctx.lineWidth = width
  ctx.stroke()
}

const drawRegistrationCard = ({
  name,
  age,
  sn,
  week,
  date,
  time,
  avatar
}) => {
  const width = 1200
  const height = 720

  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  ctx.fillStyle = '#ebe7df'
  ctx.fillRect(0, 0, width, height)

  ctx.strokeStyle = 'rgba(93, 106, 108, 0.08)'
  ctx.lineWidth = 1

  for (let x = 0; x < width; x += 36) {
    line(
      ctx,
      x,
      0,
      x,
      height,
      'rgba(93,106,108,0.06)'
    )
  }

  for (let y = 0; y < height; y += 36) {
    line(
      ctx,
      0,
      y,
      width,
      y,
      'rgba(93,106,108,0.06)'
    )
  }

  ctx.save()
  ctx.shadowColor = 'rgba(53, 64, 68, 0.22)'
  ctx.shadowBlur = 22
  ctx.shadowOffsetY = 12

  roundedRect(ctx, 70, 55, 1060, 610, 26)

  ctx.fillStyle = '#fffdf8'
  ctx.fill()

  ctx.restore()

  roundedRect(ctx, 70, 55, 18, 610, 9)

  ctx.fillStyle = '#bd7168'
  ctx.fill()

  write(
    ctx,
    'FORM / 001',
    130,
    112,
    15,
    '#bd7168',
    '800'
  )

  write(
    ctx,
    'PENDAFTARAN ANGGOTA',
    130,
    157,
    34,
    '#283b45',
    '800'
  )

  write(
    ctx,
    'Data kamu telah dicatat ke dalam sistem.',
    130,
    188,
    17,
    '#7c898b',
    '500'
  )

  write(
    ctx,
    '(｡•̀ᴗ-)✧',
    1005,
    150,
    30,
    '#bd7168',
    '700',
    'center'
  )

  line(
    ctx,
    130,
    220,
    1070,
    220,
    '#ddd8cf',
    2
  )

  ctx.save()

  ctx.translate(950, 315)
  ctx.rotate(-0.12)

  ctx.strokeStyle = '#bd7168'
  ctx.lineWidth = 4
  ctx.setLineDash([7, 5])

  ctx.beginPath()
  ctx.arc(0, 0, 74, 0, Math.PI * 2)
  ctx.stroke()

  ctx.setLineDash([])

  write(
    ctx,
    'REGISTERED',
    0,
    -5,
    14,
    '#bd7168',
    '800',
    'center'
  )

  write(
    ctx,
    '✓',
    0,
    29,
    28,
    '#bd7168',
    '800',
    'center'
  )

  ctx.restore()

  write(
    ctx,
    '01',
    130,
    278,
    13,
    '#bd7168',
    '800'
  )

  write(
    ctx,
    'IDENTITAS PEMILIK',
    170,
    278,
    13,
    '#829093',
    '800'
  )

  line(
    ctx,
    130,
    294,
    745,
    294,
    '#e2ded6'
  )

  write(
    ctx,
    'NAMA LENGKAP',
    130,
    342,
    12,
    '#829093',
    '800'
  )

  write(
    ctx,
    name.length > 25
      ? `${name.slice(0, 24)}…`
      : name,
    130,
    376,
    28,
    '#283b45',
    '800'
  )

  line(
    ctx,
    130,
    394,
    745,
    394,
    '#c9c3b9',
    2
  )

  write(
    ctx,
    'USIA',
    130,
    435,
    12,
    '#829093',
    '800'
  )

  write(
    ctx,
    `${age} tahun`,
    130,
    470,
    23,
    '#283b45',
    '700'
  )

  line(
    ctx,
    130,
    488,
    355,
    488,
    '#c9c3b9',
    2
  )

  write(
    ctx,
    'NOMOR IDENTITAS',
    400,
    435,
    12,
    '#829093',
    '800'
  )

  write(
    ctx,
    sn.slice(0, 16).toUpperCase(),
    400,
    470,
    18,
    '#283b45',
    '700'
  )

  line(
    ctx,
    400,
    488,
    745,
    488,
    '#c9c3b9',
    2
  )

  write(
    ctx,
    '02',
    130,
    542,
    13,
    '#bd7168',
    '800'
  )

  write(
    ctx,
    'WAKTU PENDAFTARAN',
    170,
    542,
    13,
    '#829093',
    '800'
  )

  line(
    ctx,
    130,
    558,
    745,
    558,
    '#e2ded6'
  )

  write(
    ctx,
    `${week}, ${date}`,
    130,
    598,
    16,
    '#283b45',
    '700'
  )

  write(
    ctx,
    `PUKUL ${time} WIB`,
    450,
    598,
    15,
    '#7c898b',
    '600'
  )

  roundedRect(
    ctx,
    810,
    275,
    240,
    250,
    18
  )

  ctx.save()

  ctx.clip()

  ctx.fillStyle = '#f2eee6'
  ctx.fill()

  if (avatar) {
    ctx.globalAlpha = 0.16

    ctx.beginPath()
    ctx.arc(
      930,
      398,
      88,
      0,
      Math.PI * 2
    )

    ctx.clip()

    ctx.drawImage(
      avatar,
      842,
      310,
      176,
      176
    )
  }

  ctx.restore()

  roundedRect(
    ctx,
    810,
    275,
    240,
    250,
    18
  )

  ctx.strokeStyle = '#ded7cc'
  ctx.lineWidth = 1.5
  ctx.stroke()

  write(
    ctx,
    'VERIFICATION',
    840,
    315,
    12,
    '#829093',
    '800'
  )

  write(
    ctx,
    '✓',
    930,
    395,
    58,
    '#bd7168',
    '800',
    'center'
  )

  write(
    ctx,
    'DATA VALID',
    930,
    440,
    16,
    '#283b45',
    '800',
    'center'
  )

  write(
    ctx,
    'Tersimpan dengan aman',
    930,
    470,
    12,
    '#829093',
    '500',
    'center'
  )

  write(
    ctx,
    '⌁ (´｡• ᵕ •｡`)',
    930,
    505,
    15,
    '#bd7168',
    '700',
    'center'
  )

  line(
    ctx,
    130,
    625,
    1070,
    625,
    '#ddd8cf'
  )

  write(
    ctx,
    '✦ AVOSKY-F REGISTRATION DESK',
    130,
    650,
    11,
    '#829093',
    '800'
  )

  write(
    ctx,
    'STATUS : ACTIVE',
    1070,
    650,
    11,
    '#bd7168',
    '800',
    'right'
  )

  return canvas.toBuffer('image/png')
}

const registrationGuide = (prefix, command) => {
  return `╭─〔 ✦ CARA PENDAFTARAN 〕
│
│ Untuk mendaftar, kirim perintah
│ dengan format:
│
│ ${prefix + command} nama,umur
│
├─〔 📝 CONTOH BENAR 〕
│
│ ${prefix + command} avosky,18
│ ${prefix + command} rizky,22
│ ${prefix + command} budi,20
│
├─〔 🔍 PENJELASAN 〕
│
│ • Bagian sebelum koma = NAMA
│ • Bagian setelah koma = UMUR
│ • Wajib menggunakan tanda koma (,)
│ • Nama dan umur harus berada dalam
│   satu pesan/perintah.
│
├─〔 ❌ CONTOH SALAH 〕
│
│ ${prefix + command} avosky 18
│ ${prefix + command} avosky-18
│ ${prefix + command} avosky.18
│ ${prefix + command} avosky, umur 18
│
├─〔 💡 PALING MUDAH 〕
│
│ Cukup copy format ini:
│
│ ${prefix + command} avosky,18
│
│ Lalu ganti "avosky" dengan nama kamu
│ dan "18" dengan umur kamu.
│
╰───────────────`
}

const alreadyRegistered = (prefix, sn) => {
  return `╭─〔 ≡ SUDAH TERDAFTAR 〕
│
│ Kamu sudah terdaftar di database.
│
│ Untuk melihat SN:
│ ${prefix}ceksn
│
│ Untuk membatalkan pendaftaran:
│ ${prefix}unreg ${sn}
│
╰───────────────`
}

let handler = async (
  m,
  {
    text,
    usedPrefix,
    command,
    conn
  }
) => {
  const user = global.db.data.users[m.sender]
  const sn = createHash('md5')
    .update(m.sender)
    .digest('hex')

  const input = (text || '').trim()

  let pp

  try {
    pp = await conn.profilePictureUrl(
      m.sender,
      'image'
    )
  } catch {
    pp = './src/avatar_contact.png'
  }

  let avatar

  try {
    avatar = await loadImage(pp)
  } catch {
    avatar = await loadImage(
      './src/avatar_contact.png'
    )
  }

  if (user.registered) {
    return m.reply(
      alreadyRegistered(
        usedPrefix,
        sn
      )
    )
  }

  if (!input) {
    return m.reply(
      registrationGuide(
        usedPrefix,
        command
      )
    )
  }

  if (!Reg.test(input)) {
    return m.reply(`╭─〔 ❌ FORMAT SALAH 〕
│
│ Format yang kamu kirim belum benar.
│ Jangan khawatir, gampang kok. 😄
│
│ Format yang BENAR:
│
│ ${usedPrefix + command} nama,umur
│
│ Contoh:
│ ${usedPrefix + command} avosky,18
│
├─〔 INGAT 〕
│
│ 1. Tulis nama
│ 2. Tambahkan koma (,)
│ 3. Tulis umur
│ 4. Kirim dalam satu pesan
│
│ Contoh:
│ ${usedPrefix + command} avosky,18
│                  ↑      ↑
│                nama    umur
│
│ ❌ Jangan:
│ ${usedPrefix + command} avosky 18
│
│ ❌ Jangan:
│ ${usedPrefix + command} avosky-18
│
│ ❌ Jangan:
│ ${usedPrefix + command} avosky.18
│
│ Kalau masih bingung, ketik:
│ ${usedPrefix + command}
│
│ untuk melihat tutorial lengkap.
╰───────────────`)
  }

  let [, name, ageStr] = input.match(Reg)

  name = name.trim()

  const age = parseInt(ageStr)

  if (!name || !age) {
    return m.reply(`╭─〔 ❌ DATA TIDAK VALID 〕
│
│ Nama atau umur yang kamu masukkan
│ tidak valid.
│
│ Contoh yang benar:
│ ${usedPrefix + command} avosky,18
│
╰───────────────`)
  }

  if (name.length > 100) {
    return m.reply(`╭─〔 ❌ NAMA TERLALU PANJANG 〕
│
│ Nama maksimal 100 karakter.
│
│ Silakan pendekkan nama kamu lalu
│ lakukan pendaftaran kembali.
│
╰───────────────`)
  }

  if (age < 5 || age > 100) {
    return m.reply(`╭─〔 ❌ UMUR TIDAK VALID 〕
│
│ Umur harus berada di antara
│ 5 sampai 100 tahun.
│
│ Contoh:
│ ${usedPrefix + command} avosky,18
│
╰───────────────`)
  }

  const d = new Date()

  const week = d.toLocaleDateString(
    'id',
    {
      weekday: 'long'
    }
  )

  const date = d.toLocaleDateString(
    'id',
    {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }
  )

  const time = moment
    .tz('Asia/Jakarta')
    .format('HH:mm:ss')

  user.name = name
  user.age = age
  user.regTime = +new Date()
  user.registered = true

  const thumbnail = drawRegistrationCard({
    name,
    age,
    sn,
    week,
    date,
    time,
    avatar
  })

  const caption = `╭─〔 ✦ PENDAFTARAN BERHASIL 〕
│
│ ✅ Data kamu berhasil disimpan!
│
├─〔 👤 DATA AKUN 〕
│
│ Nama : ${name}
│ Umur : ${age} tahun
│ SN   : ${sn}
│
├─〔 🗓️ WAKTU 〕
│
│ ${week}, ${date}
│ ${time} WIB
│
├─〔 🔐 NOMOR IDENTITAS 〕
│
│ SN kamu adalah kode identitas unik.
│ Simpan SN tersebut jika sewaktu-waktu
│ diperlukan untuk proses unreg.
│
╰─〔 ✦ AVOSKY-F 〕

Terima kasih sudah melakukan pendaftaran! (｡•̀ᴗ-)✧`

  await conn.sendMessage(
    m.chat,
    {
      image: thumbnail,
      caption,
      footer: 'avosky-F 〔 REGISTRATION DESK 〕',
      optionText: 'Pilih Menu',
      optionTitle: 'Daftar',
      nativeFlow: [
        {
          text: 'Menu',
          sections: [
            {
              title: 'Main',
              rows: [
                {
                  title: 'Menu Utama',
                  id: '.menu'
                }
              ]
            }
          ]
        },
        {
          text: 'Copy SN',
          copy: sn
        }
      ]
    },
    {
      quoted: m
    }
  )
}

handler.help = ['daftar']
handler.tags = ['main']
handler.command = /^(daftar|verify|reg(ister)?)$/i

handler.limit = 10

export default handler