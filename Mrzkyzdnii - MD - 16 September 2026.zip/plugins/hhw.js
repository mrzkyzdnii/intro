import axios from 'axios'

const BASE_URL = 'https://reaction-whatsapp.edgeone.dev'
const API_KEY = 'C3CENFUP'

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Example:\n${usedPrefix + command} link emoji`

    const args = text.trim().split(/\s+/)
    const emoji = args.pop()
    const link = args.join(' ')

    if (!link || !emoji) {
        throw `Example:\n${usedPrefix + command} link emoji`
    }

    await m.react('⏳')

    try {
        const res = await axios.post(`${BASE_URL}/react`, {
            link,
            emoji
        }, {
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${API_KEY}`,
                'Origin': BASE_URL,
                'Referer': `${BASE_URL}/`
            },
            validateStatus: () => true
        })

        if (res.status === 200) {
            await m.react('✅')
            return conn.reply(m.chat, JSON.stringify(res.data, null, 2), m)
        }

        await m.react('❌')

        return conn.reply(
            m.chat,
            JSON.stringify({
                status: false,
                httpStatus: res.status,
                data: res.data
            }, null, 2),
            m
        )
    } catch (error) {
        await m.react('❌')

        throw error.message
    }
}

handler.help = ['reactwa']
handler.tags = ['tools']
handler.command = /^reactwa$/i

export default handler