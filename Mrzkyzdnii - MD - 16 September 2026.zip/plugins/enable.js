let handler = async (m, { conn, usedPrefix, command, args, isOwner, isAdmin, isROwner }) => {
  const isEnable = /^(enable|on)$/i.test(command)

  global.db.data.chats = global.db.data.chats || {}

  let chat = global.db.data.chats[m.chat]
  if (!chat) {
    chat = global.db.data.chats[m.chat] = {}
  }

  // Default settings
  if (!('welcome' in chat)) chat.welcome = true
  if (!('delete' in chat)) chat.delete = true
  if (!('antiDelete' in chat)) chat.antiDelete = false
  if (!('antiLink' in chat)) chat.antiLink = false
  if (!('antiMedia' in chat)) chat.antiMedia = false
  if (!('antiBadword' in chat)) chat.antiBadword = false
  if (!('autogpt' in chat)) chat.autogpt = false
  if (!('autosimi' in chat)) chat.autosimi = false
  if (!('autodl' in chat)) chat.autodl = false
  if (!('antiPromosi' in chat)) chat.antiPromosi = false
  if (!('detect' in chat)) chat.detect = true
  if (!('rpgs' in chat)) chat.rpgs = true
  if (!('autolevelup' in chat)) chat.autolevelup = false

  // Anti SW GC
  if (!chat.antiswgc || typeof chat.antiswgc !== 'object') {
    chat.antiswgc = {
      status: false,
      delete: false,
      kick: false
    }
  }

  if (global.autocorrect === undefined) {
    global.autocorrect = true
  }

  const type = (args[0] || '').toLowerCase()
  let isAll = false

  switch (type) {

    case 'welcome':
      if (m.isGroup && !isAdmin) {
        return global.dfail('admin', m, conn)
      }

      chat.welcome = isEnable
      break

    case 'delete':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.delete = isEnable
      break

    case 'antidelete':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.antiDelete = isEnable
      break

    case 'antilink':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.antiLink = isEnable
      break

    case 'antibadword':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.antiBadword = isEnable
      break

    case 'antipromosi':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.antiPromosi = isEnable
      break

    case 'antimedia':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.antiMedia = isEnable
      break

    case 'autogpt':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.autogpt = isEnable
      break

    case 'autosimi':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.autosimi = isEnable
      break

    case 'autodl':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.autodl = isEnable
      break

    case 'detect':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.detect = isEnable
      break

    case 'rpg':
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      chat.rpgs = isEnable
      break

    // ==================================================
    // ANTI SW GC
    // ==================================================

    case 'antiswgc': {
      if (m.isGroup && !(isAdmin || isOwner)) {
        return global.dfail('admin', m, conn)
      }

      // Disable Anti SW GC
      if (!isEnable) {
        chat.antiswgc = {
          status: false,
          delete: false,
          kick: false
        }

        break
      }

      const option = (args[1] || 'delete').toLowerCase()

      if (!['delete', 'kick', 'both'].includes(option)) {
        return m.reply(
`╭━━〔 ⚠️ ᴀɴᴛɪ sᴡ ɢᴄ 〕━━╮
│
│ ᴏᴘᴛɪᴏɴ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ
│
│ Pilihan:
│ ├─ delete
│ ├─ kick
│ ╰─ both
│
│ Contoh:
│ ${usedPrefix}${command} antiswgc delete
│
╰━━━━━━━━━━━━━━━━━━╯`
        )
      }

      chat.antiswgc = {
        status: true,
        delete: option === 'delete' || option === 'both',
        kick: option === 'kick' || option === 'both'
      }

      break
    }

    case 'autolevelup':
      isAll = true

      if (!isROwner) {
        return global.dfail('rowner', m, conn)
      }

      chat.autolevelup = isEnable
      break

    case 'autocorrect':
      isAll = true

      if (!isROwner) {
        return global.dfail('rowner', m, conn)
      }

      global.autocorrect = isEnable
      break

    case 'public':
      isAll = true

      if (!isROwner) {
        return global.dfail('rowner', m, conn)
      }

      global.opts.self = !isEnable
      break

    case 'autoread':
      isAll = true

      if (!isROwner) {
        return global.dfail('rowner', m, conn)
      }

      global.opts.autoread = isEnable
      break

    case 'pconly':
      isAll = true

      if (!isROwner) {
        return global.dfail('rowner', m, conn)
      }

      global.opts.pconly = isEnable
      break

    case 'gconly':
      isAll = true

      if (!isROwner) {
        return global.dfail('rowner', m, conn)
      }

      global.opts.gconly = isEnable
      break

    case 'self':
      isAll = true

      if (!isROwner) {
        return global.dfail('rowner', m, conn)
      }

      global.opts.self = isEnable
      break

    default: {

      const status = value => value ? '◉ ON' : '○ OFF'

      let swgcStatus = '○ OFF'

      if (chat.antiswgc && chat.antiswgc.status) {
        if (chat.antiswgc.delete && chat.antiswgc.kick) {
          swgcStatus = '◉ BOTH'
        } else if (chat.antiswgc.delete) {
          swgcStatus = '◉ DELETE'
        } else if (chat.antiswgc.kick) {
          swgcStatus = '◉ KICK'
        } else {
          swgcStatus = '◉ ON'
        }
      }

      const groupSettings = [
        ['Welcome', chat.welcome],
        ['Delete', chat.delete],
        ['Anti Delete', chat.antiDelete],
        ['Anti Link', chat.antiLink],
        ['Anti Badword', chat.antiBadword],
        ['Anti Promosi', chat.antiPromosi],
        ['Anti Media', chat.antiMedia],
        ['Anti SW GC', swgcStatus],
        ['Detect', chat.detect],
        ['Auto GPT', chat.autogpt],
        ['Auto Simi', chat.autosimi],
        ['Auto DL', chat.autodl],
        ['RPG', chat.rpgs]
      ]

      const ownerSettings = [
        ['Public', !global.opts.self],
        ['Self', global.opts.self],
        ['Auto Read', global.opts.autoread],
        ['PC Only', global.opts.pconly],
        ['GC Only', global.opts.gconly],
        ['Auto LevelUp', chat.autolevelup],
        ['Auto Correct', global.autocorrect]
      ]

      const formatList = list => {
        return list.map((item, index) => {
          const name = item[0]
          const value = item[1]

          const isLast = index === list.length - 1
          const branch = isLast ? '╰' : '├'

          const state =
            typeof value === 'string'
              ? value
              : status(value)

          return `│ ${branch}─ ${name.padEnd(14)} ${state}`
        }).join('\n')
      }

      const totalOn = [
        chat.welcome,
        chat.delete,
        chat.antiDelete,
        chat.antiLink,
        chat.antiBadword,
        chat.antiPromosi,
        chat.antiMedia,
        chat.antiswgc.status,
        chat.detect,
        chat.autogpt,
        chat.autosimi,
        chat.autodl,
        chat.rpgs,
        !global.opts.self,
        global.opts.self,
        global.opts.autoread,
        global.opts.pconly,
        global.opts.gconly,
        chat.autolevelup,
        global.autocorrect
      ].filter(Boolean).length

      return m.reply(
`╭━━━〔 ⚙️ ᴘʟᴜɢɪɴ sᴇᴛᴛɪɴɢs 〕━━━╮
│
│ ╭─〔 👥 ɢʀᴏᴜᴘ 〕
${formatList(groupSettings)}
│
│ ╭─〔 👑 ᴏᴡɴᴇʀ 〕
${formatList(ownerSettings)}
│
├───〔 📊 sᴛᴀᴛᴜs 〕
│
│ ᴛᴏᴛᴀʟ ᴀᴋᴛɪғ  › ${totalOn} fitur
│
├───〔 💡 ᴜsᴀɢᴇ 〕
│
│ ${usedPrefix}enable <fitur>
│ ${usedPrefix}disable <fitur>
│
│ ᴀɴᴛɪ sᴡ ɢᴄ:
│ ${usedPrefix}enable antiswgc delete
│ ${usedPrefix}enable antiswgc kick
│ ${usedPrefix}enable antiswgc both
│ ${usedPrefix}disable antiswgc
│
╰━━━━━━━━━━━━━━━━━━━━━━━━━━╯`.trim()
      )
    }
  }

  const target = isAll
    ? 'untuk bot ini'
    : m.isGroup
      ? 'untuk grup ini'
      : 'untuk chat ini'

  await global.db.write?.().catch(() => null)

  let extra = ''

  if (type === 'antiswgc' && isEnable) {
    let option = 'ON'

    if (chat.antiswgc.delete && chat.antiswgc.kick) {
      option = 'DELETE + KICK'
    } else if (chat.antiswgc.delete) {
      option = 'DELETE'
    } else if (chat.antiswgc.kick) {
      option = 'KICK'
    }

    extra = `\n│ Sanksi › *${option}*`
  }

  return m.reply(
`╭━━〔 ✅ ᴜᴘᴅᴀᴛᴇᴅ 〕━━╮
│
│ Fitur  › *${type}*
│ Status › *${isEnable ? 'ON' : 'OFF'}*
│ Target › ${target}${extra}
│
╰━━━━━━━━━━━━━━━━━━╯`
  )
}

handler.help = ['enable', 'disable']
handler.tags = ['group', 'owner']
handler.command = /^(enable|disable|on|off)$/i

handler.limit = 10

export default handler