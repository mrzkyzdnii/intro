import yts from 'yt-search'
import { exec } from 'child_process'
import fs from 'fs'
import { createCanvas, loadImage } from '@napi-rs/canvas'

const YTDLP = './yt-dlp'
const DENO = '/home/container/.deno/bin/deno'
const COOKIES = './proxy.txt'
const OUTPUT = 'play_audio.%(ext)s'

/* ================= STATE ================= */

const playLists = new Map()

/* ================= HELPERS ================= */

const getMessageId = message => (
  message?.key?.id ||
  message?.id ||
  message?.stanzaId ||
  null
)

const getQuotedId = quoted => (
  quoted?.key?.id ||
  quoted?.id ||
  quoted?.stanzaId ||
  null
)

const formatViews = views => {
  const num = Number(views || 0)

  if (!Number.isFinite(num) || num <= 0)
    return 'N/A'

  if (num >= 1_000_000_000)
    return `${(num / 1_000_000_000).toFixed(1)}B`

  if (num >= 1_000_000)
    return `${(num / 1_000_000).toFixed(1)}M`

  if (num >= 1_000)
    return `${(num / 1_000).toFixed(1)}K`

  return num.toLocaleString('id-ID')
}

const cleanTitle = title => {
  return String(title || '')
    .replace(/\s+/g, ' ')
    .trim()
}

const cleanupAudio = () => {
  for (const file of [
    'play_audio.m4a',
    'play_audio.webm',
    'play_audio.mp3'
  ]) {
    try {
      if (fs.existsSync(file))
        fs.unlinkSync(file)
    } catch {}
  }
}

/* ================= CANVAS HELPERS ================= */

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

function drawCover(ctx, img, x, y, w, h) {
  const ir = img.width / img.height
  const tr = w / h

  let sx, sy, sw, sh

  if (ir > tr) {
    sh = img.height
    sw = sh * tr
    sx = (img.width - sw) / 2
    sy = 0
  } else {
    sw = img.width
    sh = sw / tr
    sx = 0
    sy = (img.height - sh) / 2
  }

  ctx.drawImage(
    img,
    sx,
    sy,
    sw,
    sh,
    x,
    y,
    w,
    h
  )
}

function wrapText(ctx, text, maxWidth, maxLines) {
  const words = String(text || '').split(' ')
  const lines = []
  let current = ''

  for (const word of words) {
    const test = current
      ? `${current} ${word}`
      : word

    if (
      ctx.measureText(test).width > maxWidth &&
      current
    ) {
      lines.push(current)
      current = word

      if (lines.length === maxLines - 1)
        break
    } else {
      current = test
    }
  }

  if (current)
    lines.push(current)

  if (lines.length === maxLines) {
    let last = lines[maxLines - 1]

    while (
      ctx.measureText(last + '…').width > maxWidth &&
      last.length > 1
    ) {
      last = last.slice(0, -1)
    }

    lines[maxLines - 1] =
      last.trimEnd() + '…'
  }

  return lines
}

function drawIconCircle(ctx, cx, cy, r, color) {
  ctx.save()

  ctx.shadowColor = color
  ctx.shadowBlur = 25

  ctx.beginPath()
  ctx.arc(cx, cy, r, 0, Math.PI * 2)
  ctx.fillStyle = color
  ctx.fill()

  ctx.restore()
}

function drawPlayIcon(ctx, cx, cy) {
  ctx.save()

  ctx.fillStyle = '#0a0a14'

  ctx.beginPath()
  ctx.moveTo(cx - 10, cy - 15)
  ctx.lineTo(cx - 10, cy + 15)
  ctx.lineTo(cx + 16, cy)
  ctx.closePath()
  ctx.fill()

  ctx.restore()
}

function drawPrevNextIcon(ctx, cx, cy, dir) {
  ctx.save()

  ctx.fillStyle =
    'rgba(255,255,255,0.85)'

  const s = dir

  ctx.beginPath()

  ctx.moveTo(
    cx - 10 * s,
    cy - 14
  )

  ctx.lineTo(
    cx - 10 * s,
    cy + 14
  )

  ctx.lineTo(
    cx + 12 * s,
    cy
  )

  ctx.closePath()
  ctx.fill()

  ctx.fillRect(
    cx + 12 * s - (s > 0 ? 4 : 0),
    cy - 14,
    4,
    28
  )

  ctx.restore()
}

function drawEqualizer(ctx, x, y, bars) {
  const heights = [
    22,
    40,
    16,
    34,
    26,
    44,
    18,
    30
  ]

  const barW = 6
  const gap = 6

  for (let i = 0; i < bars; i++) {
    const h =
      heights[i % heights.length]

    ctx.fillStyle =
      i % 2 === 0
        ? '#1DB954'
        : 'rgba(29,185,84,0.5)'

    roundRect(
      ctx,
      x + i * (barW + gap),
      y - h,
      barW,
      h,
      3
    )

    ctx.fill()
  }
}

/* ================= CREATE MUSIC CARD ================= */

async function createMusicCard(
  { title, views, duration },
  thumbBuffer
) {
  const W = 1280
  const H = 640

  const canvas =
    createCanvas(W, H)

  const ctx =
    canvas.getContext('2d')

  let bg = null

  try {
    if (thumbBuffer)
      bg = await loadImage(thumbBuffer)
  } catch (e) {
    console.error(
      '[THUMBNAIL ERROR]',
      e
    )
  }

  ctx.fillStyle = '#0a0a14'

  ctx.fillRect(
    0,
    0,
    W,
    H
  )

  if (bg) {
    try {
      ctx.save()

      ctx.filter =
        'blur(45px) brightness(0.45) saturate(1.3)'

      drawCover(
        ctx,
        bg,
        -80,
        -80,
        W + 160,
        H + 160
      )

      ctx.restore()
    } catch (e) {
      console.error(
        '[BACKGROUND ERROR]',
        e
      )
    }
  }

  const grad =
    ctx.createLinearGradient(
      0,
      0,
      W,
      H
    )

  grad.addColorStop(
    0,
    'rgba(6,6,16,0.55)'
  )

  grad.addColorStop(
    1,
    'rgba(4,4,10,0.9)'
  )

  ctx.fillStyle = grad

  ctx.fillRect(
    0,
    0,
    W,
    H
  )

  /* ================= ART ================= */

  const artSize = 380
  const artX = 90
  const artY =
    (H - artSize) / 2

  ctx.save()

  ctx.shadowColor =
    'rgba(0,0,0,0.7)'

  ctx.shadowBlur = 50
  ctx.shadowOffsetY = 25

  roundRect(
    ctx,
    artX,
    artY,
    artSize,
    artSize,
    28
  )

  ctx.fillStyle = '#111'

  ctx.fill()

  ctx.restore()

  if (bg) {
    ctx.save()

    roundRect(
      ctx,
      artX,
      artY,
      artSize,
      artSize,
      28
    )

    ctx.clip()

    drawCover(
      ctx,
      bg,
      artX,
      artY,
      artSize,
      artSize
    )

    ctx.restore()
  }

  ctx.save()

  roundRect(
    ctx,
    artX,
    artY,
    artSize,
    artSize,
    28
  )

  ctx.lineWidth = 3

  ctx.strokeStyle =
    'rgba(255,255,255,0.25)'

  ctx.stroke()

  ctx.restore()

  /* ================= RIGHT PANEL ================= */

  const panelX =
    artX + artSize + 60

  const panelW =
    W - panelX - 80

  /* ================= BADGE ================= */

  ctx.save()

  roundRect(
    ctx,
    panelX,
    artY - 6,
    200,
    44,
    22
  )

  ctx.fillStyle =
    '#1DB954'

  ctx.fill()

  ctx.fillStyle =
    '#0a0a14'

  ctx.font =
    'bold 20px sans-serif'

  ctx.textBaseline =
    'middle'

  ctx.fillText(
    '▶  NOW PLAYING',
    panelX + 20,
    artY - 6 + 22
  )

  ctx.restore()

  /* ================= TITLE ================= */

  ctx.fillStyle =
    '#ffffff'

  ctx.font =
    'bold 48px sans-serif'

  ctx.textBaseline =
    'alphabetic'

  const titleLines =
    wrapText(
      ctx,
      title,
      panelW,
      2
    )

  let ty =
    artY + 100

  titleLines.forEach(
    (line, i) => {

      ctx.fillText(
        line,
        panelX,
        ty + i * 58
      )

    }
  )

  ty +=
    (titleLines.length - 1) * 58

  /* ================= VIEWS ================= */

  ctx.fillStyle =
    'rgba(255,255,255,0.65)'

  ctx.font =
    '26px sans-serif'

  ctx.fillText(
    `👁  ${formatViews(views)} views`,
    panelX,
    ty + 60
  )

  /* ================= PROGRESS ================= */

  const barY =
    artY + artSize - 95

  const barW =
    panelW

  roundRect(
    ctx,
    panelX,
    barY,
    barW,
    8,
    4
  )

  ctx.fillStyle =
    'rgba(255,255,255,0.15)'

  ctx.fill()

  ctx.beginPath()

  ctx.arc(
    panelX + 8,
    barY + 4,
    9,
    0,
    Math.PI * 2
  )

  ctx.fillStyle =
    '#1DB954'

  ctx.fill()

  /* ================= DURATION ================= */

  ctx.fillStyle =
    'rgba(255,255,255,0.6)'

  ctx.font =
    '22px sans-serif'

  ctx.fillText(
    '0:00',
    panelX,
    barY + 36
  )

  const durText =
    duration || '--:--'

  const durW =
    ctx.measureText(
      durText
    ).width

  ctx.fillText(
    durText,
    panelX + barW - durW,
    barY + 36
  )

  /* ================= CONTROLS ================= */

  const ctrlY =
    barY + 85

  const cx =
    panelX + barW / 2

  drawIconCircle(
    ctx,
    cx,
    ctrlY,
    36,
    '#1DB954'
  )

  drawPlayIcon(
    ctx,
    cx,
    ctrlY
  )

  drawPrevNextIcon(
    ctx,
    cx - 100,
    ctrlY,
    -1
  )

  drawPrevNextIcon(
    ctx,
    cx + 100,
    ctrlY,
    1
  )

  /* ================= EQUALIZER ================= */

  drawEqualizer(
    ctx,
    W - 220,
    H - 50,
    10
  )

  /* ================= FOOTER ================= */

  ctx.fillStyle =
    'rgba(255,255,255,0.35)'

  ctx.font =
    '18px sans-serif'

  ctx.fillText(
    'YT MUSIC • DOWNLOADER',
    panelX,
    H - 40
  )

  return canvas.encode('png')
}

/* ================= DOWNLOAD AUDIO ================= */

async function downloadAudio(url) {

  cleanupAudio()

  return new Promise(
    (resolve, reject) => {

      const cmd = [
        YTDLP,
        '--js-runtimes',
        `"deno:${DENO}"`,
        '--remote-components',
        '"ejs:github"',
        '--cookies',
        `"${COOKIES}"`,
        '--no-playlist',
        '-f',
        '"140/251/250/249/bestaudio"',
        '-o',
        `"${OUTPUT}"`,
        '--no-update',
        `"${url}"`
      ].join(' ')

      console.log(
        '[PLAY]',
        url
      )

      exec(
        cmd,
        {
          env: {
            ...process.env,
            PATH:
              `/home/container/.deno/bin:${process.env.PATH || ''}`
          },

          maxBuffer:
            100 * 1024 * 1024
        },

        (err, stdout, stderr) => {

          if (err) {

            console.error(
              '[YTDLP ERROR]',
              stderr ||
              stdout ||
              err
            )

            return reject(
              new Error(
                stderr ||
                stdout ||
                err.message
              )
            )
          }

          const audio =
            fs.existsSync(
              'play_audio.m4a'
            )
              ? 'play_audio.m4a'
              : fs.existsSync(
                  'play_audio.webm'
                )
                ? 'play_audio.webm'
                : fs.existsSync(
                    'play_audio.mp3'
                  )
                  ? 'play_audio.mp3'
                  : null

          if (!audio) {

            return reject(
              new Error(
                'Audio tidak ditemukan setelah download.'
              )
            )
          }

          resolve(audio)
        }
      )
    }
  )
}

/* ================= NORMALIZE VIDEO ================= */

function normalizeVideo(v) {

  return {
    title:
      cleanTitle(v.title),

    url:
      v.url,

    thumbnail:
      v.thumbnail || '',

    views:
      v.views || 0,

    duration:
      v.timestamp || ''
  }
}

/* ================= THUMBNAIL ================= */

async function getThumbnail(video) {

  if (video.thumbnail) {

    try {

      const res =
        await fetch(
          video.thumbnail
        )

      if (res.ok) {

        return Buffer.from(
          await res.arrayBuffer()
        )

      }

    } catch {}
  }

  const id =
    video.url.match(
      /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/))([^?&/]+)/
    )?.[1]

  if (!id)
    return null

  try {

    const res =
      await fetch(
        `https://i.ytimg.com/vi/${id}/hqdefault.jpg`
      )

    if (!res.ok)
      return null

    return Buffer.from(
      await res.arrayBuffer()
    )

  } catch {

    return null

  }
}

/* ================= SEND AUDIO ================= */

async function sendAudio(
  conn,
  m,
  video
) {

  let audio = null

  try {

    /* ================= CARD ================= */

    const thumbBuffer =
      await getThumbnail(video)

    const caption =
      `🎧 *${video.title}*\n` +
      `🔗 ${video.url}\n\n` +
      `⏳ Sedang mengunduh audio...`

    try {

      const cardBuffer =
        await createMusicCard(
          video,
          thumbBuffer
        )

      if (
        !cardBuffer ||
        !Buffer.isBuffer(cardBuffer) ||
        cardBuffer.length === 0
      ) {
        throw new Error(
          'Canvas menghasilkan buffer kosong.'
        )
      }

      await conn.sendMessage(
        m.chat,
        {
          image:
            cardBuffer,

          mimetype:
            'image/png',

          caption
        },
        {
          quoted: m
        }
      )

    } catch (e) {

      console.error(
        '[CANVAS ERROR]',
        e
      )

      await conn.reply(
        m.chat,
        caption,
        m
      )
    }

    /* ================= DOWNLOAD ================= */

    audio =
      await downloadAudio(
        video.url
      )

    /* ================= SEND AUDIO ================= */

    const buffer =
      fs.readFileSync(audio)

    const mimetype =
      audio.endsWith('.m4a')
        ? 'audio/mp4'
        : audio.endsWith('.mp3')
          ? 'audio/mpeg'
          : 'audio/webm'

    await conn.sendMessage(
      m.chat,
      {
        audio:
          buffer,

        mimetype,

        fileName:
          `${video.title}.${audio.split('.').pop()}`,

        ptt: false
      },
      {
        quoted: m
      }
    )

  } finally {

    if (audio) {

      try {
        fs.unlinkSync(audio)
      } catch {}

    }

    cleanupAudio()
  }
}

/* ================= HANDLER ================= */

const handler = async (
  m,
  {
    conn,
    text,
    usedPrefix,
    command
  }
) => {

  if (!text) {

    throw (
      `Contoh:\n` +
      `${usedPrefix + command} beautiful in white\n\n` +
      `List:\n` +
      `${usedPrefix + command} beautiful in white --list 5`
    )

  }

  conn.playLists =
    conn.playLists || new Map()

  let input =
    text.trim()

  /* =================================================
   * MODE --LIST <JUMLAH>
   * ================================================= */

  const listMatch =
    input.match(
      /\s+--list(?:\s+(\d+))?\s*$/i
    )

  if (listMatch) {

    const count =
      Number(
        listMatch[1] || 5
      )

    const query =
      input
        .replace(
          /\s+--list(?:\s+\d+)?\s*$/i,
          ''
        )
        .trim()

    if (!query) {

      throw (
        `Masukkan judul lagu.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} beautiful in white --list 5`
      )

    }

    /*
     * Hanya izinkan 1-20
     */

    if (
      !Number.isInteger(count) ||
      count < 1 ||
      count > 20
    ) {

      throw (
        `Jumlah list harus antara 1–20.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} beautiful in white --list 5`
      )

    }

    await conn.reply(
      m.chat,
      `🔎 Mencari ${count} hasil YouTube...`,
      m
    )

    let results

    try {

      const search =
        await yts(query)

      results =
        search.videos
          .slice(0, count)
          .map(normalizeVideo)

    } catch (e) {

      console.error(
        '[YTS ERROR]',
        e
      )

      throw (
        '❌ Gagal mencari video YouTube.'
      )

    }

    if (!results.length)
      throw '❌ Video tidak ditemukan.'

    /*
     * ================= LIST =================
     */

    let listText =
      `╭─〔 🎧 YOUTUBE SEARCH 〕\n` +
      `│ 🔎 Query : ${query}\n` +
      `│ 📋 Total : ${results.length} hasil\n` +
      `│\n`

    results.forEach(
      (video, index) => {

        listText +=
          `│ *${index + 1}.* ${video.title}\n` +
          `│    ├ ⏱️ ${video.duration || '-'}\n` +
          `│    └ 👁️ ${formatViews(video.views)} views\n` +
          `│\n`

      }
    )

    listText +=
      `│ Reply pesan ini dengan angka *1–${results.length}*\n` +
      `│ untuk memilih lagu.\n` +
      `│\n` +
      `│ ⏳ Berlaku selama 60 detik.\n` +
      `╰────────────`

    const sent =
      await conn.sendMessage(
        m.chat,
        {
          text: listText
        },
        {
          quoted: m
        }
      )

    const messageId =
      getMessageId(sent)

    /*
     * ================= HAPUS STATE LAMA =================
     */

    const old =
      conn.playLists.get(
        m.sender
      )

    if (old?.timer)
      clearTimeout(
        old.timer
      )

    /*
     * ================= SIMPAN STATE =================
     */

    const pending = {
      sender:
        m.sender,

      chat:
        m.chat,

      messageId,

      results,

      createdAt:
        Date.now(),

      timer:
        null
    }

    conn.playLists.set(
      m.sender,
      pending
    )

    /*
     * ================= EXPIRE =================
     */

    pending.timer =
      setTimeout(
        () => {

          const current =
            conn.playLists.get(
              m.sender
            )

          if (current === pending) {

            conn.playLists.delete(
              m.sender
            )

            console.log(
              `[PLAY LIST] Expired: ${m.sender}`
            )

          }

        },
        60000
      )

    return
  }

  /* =================================================
   * MODE NORMAL
   * ================================================= */

  const query =
    input

  /*
   * Kalau cuma angka, biarkan before
   * yang menangani pemilihan list.
   */

  if (/^\d+$/.test(query))
    return

  let video

  try {

    /*
     * ================= URL =================
     */

    if (
      /youtu\.be|youtube\.com/i.test(
        query
      )
    ) {

      video = {
        title:
          'YouTube Audio',

        url:
          query,

        thumbnail:
          '',

        views:
          0,

        duration:
          ''
      }

      /*
       * Ambil metadata bila tersedia.
       */

      try {

        const search =
          await yts(query)

        if (
          search.videos?.length
        ) {

          video =
            normalizeVideo(
              search.videos[0]
            )

        }

      } catch {}

    } else {

      /*
       * ================= SEARCH =================
       */

      const search =
        await yts(query)

      if (
        !search.videos?.length
      ) {

        throw new Error(
          'Video tidak ditemukan.'
        )

      }

      video =
        normalizeVideo(
          search.videos[0]
        )
    }

    /*
     * ================= DOWNLOAD =================
     */

    await sendAudio(
      conn,
      m,
      video
    )

  } catch (e) {

    console.error(
      '[PLAY ERROR]',
      e
    )

    await conn.reply(
      m.chat,
      `❌ ${
        e?.message ||
        e ||
        'Terjadi kesalahan.'
      }`,
      m
    )
  }
}

/* =================================================
 * LIST SELECTOR
 * ================================================= */

handler.before = async (
  m,
  {
    conn
  }
) => {

  conn.playLists =
    conn.playLists || new Map()

  const answer =
    String(
      m.text || ''
    ).trim()

  /*
   * Angka 1-20 saja.
   */

  if (
    !/^(?:[1-9]|1\d|20)$/.test(
      answer
    )
  ) {
    return
  }

  /*
   * Cari state berdasarkan sender.
   */

  const pending =
    conn.playLists.get(
      m.sender
    )

  if (!pending)
    return

  /*
   * Wajib reply list.
   */

  if (!m.quoted)
    return

  const quotedId =
    getQuotedId(
      m.quoted
    )

  if (
    !quotedId ||
    quotedId !== pending.messageId
  ) {
    return
  }

  /*
   * Pastikan chat sama.
   */

  if (
    pending.chat !== m.chat
  ) {
    return
  }

  /*
   * Hapus state sebelum download
   * supaya tidak double process.
   */

  conn.playLists.delete(
    m.sender
  )

  if (pending.timer)
    clearTimeout(
      pending.timer
    )

  const index =
    Number(answer) - 1

  const video =
    pending.results[index]

  if (!video) {

    return conn.reply(
      m.chat,
      `❌ Pilihan hanya tersedia 1–${pending.results.length}.`,
      m
    )

  }

  /*
   * ================= SELECTED =================
   */

  await conn.reply(
    m.chat,
    `🎵 *Pilihan #${index + 1}*\n` +
    `🎧 ${video.title}\n` +
    `⏱️ ${video.duration || '-'}\n` +
    `👁️ ${formatViews(video.views)} views\n\n` +
    `⏳ Sedang memproses audio...`,
    m
  )

  try {

    await sendAudio(
      conn,
      m,
      video
    )

  } catch (e) {

    console.error(
      '[PLAY LIST ERROR]',
      e
    )

    await conn.reply(
      m.chat,
      `❌ Gagal mengunduh audio.\n\n${
        e?.message ||
        e ||
        'Unknown error'
      }`,
      m
    )
  }
}

/* ================= CONFIG ================= */

handler.help = [
  'play'
]

handler.tags = [
  'downloader'
]

handler.command =
  /^(play)$/i

handler.limit = 10
handler.register = true

export default handler