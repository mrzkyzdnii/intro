import axios from 'axios'
import * as cheerio from 'cheerio'

const scraper = async (query) => {
    try {
        const { data } = await axios.get(`https://www.myinstants.com/en/search/?name=${encodeURIComponent(query)}`, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        })
        const $ = cheerio.load(data)
        const results = []

        $('.instant').each((_, el) => {
            const title = $(el).find('a.instant-link').text().trim()
            const onclick = $(el).find('button.small-button').attr('onclick') || ''
            const soundMatch = onclick.match(/play\('([^']+)'/)
            
            if (title && soundMatch) {
                results.push({
                    title,
                    music: 'https://www.myinstants.com' + soundMatch[1]
                })
            }
        })

        return results
    } catch (e) {
        throw new Error('Gagal mengambil data dari MyInstants.')
    }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Contoh penggunaan:\n${usedPrefix + command} haha`

    // Jika user mengklik tombol pilihan sound dari button row
    if (text.startsWith('get|')) {
        const audioUrl = text.split('get|')[1]
        const res = { music: audioUrl }

        await conn.sendMessage(
          m.chat,
          {
            audio: { url: res.music },
            mimetype: 'audio/mpeg'
          },
          { quoted: m }
        )
        return
    }

    // Melakukan pencarian sound di MyInstants
    const results = await scraper(text)

    if (!results || results.length === 0) {
        return conn.reply(m.chat, `Sound dengan kata kunci "${text}" tidak ditemukan.`, m)
    }

    // Ambil maksimal 10 hasil teratas untuk button row
    const topResults = results.slice(0, 10)

    const rows = topResults.map((item) => ({
        header: '',
        title: item.title.slice(0, 24),
        description: `Kirim audio: ${item.title}`,
        id: `${usedPrefix + command} get|${item.music}`
    }))

    await conn.sendMessage(m.chat, {
        text: `*MYINSTANTS SOUND SEARCH*\n\nHasil pencarian untuk: *${text}*\nJumlah ditemukan: ${results.length} sound.\nPilih sound pada tombol di bawah:`,
        footer: 'MyInstants Soundboard',
        optionText: 'Pilih Sound',
        optionTitle: 'Daftar Sound',
        nativeFlow: [
            {
                text: '🎵 Pilih Sound',
                sections: [
                    {
                        title: `Hasil Sound (${topResults.length})`,
                        rows: rows
                    }
                ]
            }
        ]
    }, { quoted: m })
}

handler.help = ['soundmeme']
handler.tags = ['internet']
handler.command = /^(soundmeme)$/i

handler.limit = 10
export default handler