import axios from 'axios'

const API = 'https://webcommerce-gw.alfagift.id/v2/products/searches'

const searchAlfagift = async (keyword, start = 0, limit = 60) => {
    const trxid = String(Date.now()).slice(-10)

    const { data } = await axios.get(API, {
        params: {
            keyword,
            start,
            limit
        },
        headers: {
            accept: 'application/json',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/152.0.0.0 Mobile Safari/537.36',
            origin: 'https://alfagift.id',
            referer: 'https://alfagift.id/',
            fingerprint: 'vwcNMuFrrYxG2xkEmDdDX6NCi+vUyFbCXNtE6xcx+bZpq0aZQLcgxlAR1C59wWim',
            devicetype: 'Web',
            devicemodel: 'chrome',
            trxid
        },
        timeout: 20000
    })

    return data
}

const formatRupiah = number => {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        maximumFractionDigits: 0
    }).format(number)
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text?.trim()) {
        throw `Contoh:\n${usedPrefix + command} kahf`
    }

    const keyword = text.trim()

    try {
        const data = await searchAlfagift(keyword)

        if (!data?.products?.length) {
            return conn.reply(
                m.chat,
                `❌ Produk tidak ditemukan untuk: *${keyword}*`,
                m
            )
        }

        const products = data.products

        let result = `🛒 *ALFAGIFT SEARCH*\n`
        result += `Keyword: *${keyword}*\n`
        result += `Ditemukan: *${data.totalData || products.length} produk*\n\n`

        for (let i = 0; i < products.length; i++) {
            const p = products[i]

            const price = p.finalPrice ?? p.basePrice ?? 0
            const stock = p.stock ?? 0
            const discount = p.discountPercent || 0

            result += `*${i + 1}. ${p.productName}*\n`
            result += `💰 ${formatRupiah(price)}`

            if (discount > 0) {
                result += ` ─ ${discount.toFixed(0)}% OFF`
            }

            result += `\n`
            result += `📦 Stock: ${stock}\n`
            result += `🏷️ SKU: ${p.sku || '-'}\n`
            result += `🔖 PLU: ${p.plu || '-'}\n`
            result += `🚚 ${p.deliveryInfo || '-'}\n`
            result += `📍 ${p.categoryNameLvl1 || p.categoryNameLvl0 || '-'}\n`
            result += `\n`
        }

        result += `> Alfagift • ${data.currentPage + 1 || 1}/${data.totalPage || 1}`

        const firstImage = products[0]?.image

        if (firstImage) {
            await conn.sendFile(
                m.chat,
                firstImage,
                'alfagift.jpg',
                result,
                m
            )
        } else {
            await conn.reply(m.chat, result, m)
        }
    } catch (e) {
        console.error(e)
        throw `❌ Gagal mengambil data Alfagift.\n\n${e?.response?.data?.message || e.message}`
    }
}

handler.help = ['alf <keyword>']
handler.tags = ['tools']
handler.command = /^alf$/i

export default handler