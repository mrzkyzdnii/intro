const handler = async (m, { conn, command }) => {
conn.relayMessage(
m.chat,
{
messageContextInfo:{
deviceListMetadata:{},
deviceListMetadataVersion:2,
botMetadata:{
messageDisclaimerText:"",
botResponseId:"b2e40280-433c-45d8-9c1a-270bec558860",
verificationMetadata:{
proofs:[
{
version:1,
useCase:1,
signature:"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
certificateChain:[
"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq7/1/5OU2cq",
"TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2T8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT0IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUd5tUo9ri/hS3W/SM+1F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
]
}
]
}
}
},
botForwardedMessage:{
message:{
richResponseMessage:{
messageType:1,
submessages:[
{
messageType:2,
messageText:"MEMORY MATCH"
}
],
unifiedResponse:{
data:Buffer.from(JSON.stringify({
"response_id":"7c9d11a4-6a2d-4c8d-9b2e-9f4f2a7c31b2",
"sections":[
{
"view_model":{
"primitive":{
"__typename":"GenAIaeacdsnwHtmlPrimitive",
"payload":`<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
body{margin:0;background:transparent;font-family:Arial,sans-serif;color:#fff;touch-action:manipulation}
.wrap{width:100%;max-width:620px;margin:auto;padding:14px}
.card{background:linear-gradient(145deg,rgba(255,255,255,.09),rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.14);border-radius:22px;overflow:hidden;box-shadow:0 14px 45px rgba(0,0,0,.5);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}
.head{padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.1);display:flex;justify-content:space-between;align-items:center}
.logo{font-size:10px;letter-spacing:2px;color:#888;text-transform:uppercase}
.title{font-size:23px;font-weight:800;margin-top:3px}
.level{font-size:14px;color:#a29bfe;font-weight:bold}
.boardWrap{padding:18px}
#game{width:100%;height:auto;display:block;border-radius:16px;border:1px solid rgba(255,255,255,.1);box-shadow:0 8px 30px rgba(0,0,0,.35)}
.stats{display:flex;gap:8px;padding:0 18px 14px}
.stat{flex:1;text-align:center;padding:10px 5px;border-radius:12px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.07)}
.stat b{display:block;font-size:15px}
.stat span{display:block;color:#777;font-size:9px;margin-top:3px;letter-spacing:1px}
.controls{display:flex;gap:9px;padding:0 18px 18px}
.btn{flex:1;border:0;border-radius:12px;padding:13px;color:#fff;background:rgba(255,255,255,.07);font-weight:bold;border:1px solid rgba(255,255,255,.1)}
.reset{background:linear-gradient(135deg,#6c5ce7,#4834d4)}
.info{text-align:center;color:#777;font-size:10px;padding:0 18px 18px}
</style>

<body>
<div class="wrap">
<div class="card">

<div class="head">
<div>
<div class="logo">HITORI GAME</div>
<div class="title">🧠 Memory Match</div>
</div>
<div id="level" class="level">LEVEL 1</div>
</div>

<div class="boardWrap">
<canvas id="game" width="640" height="640"></canvas>
</div>

<div class="stats">
<div class="stat"><b id="score">0</b><span>SCORE</span></div>
<div class="stat"><b id="moves">0</b><span>MOVES</span></div>
<div class="stat"><b id="timer">30</b><span>TIME</span></div>
<div class="stat"><b id="lives">❤️❤️❤️</b><span>LIVES</span></div>
</div>

<div class="controls">
<button class="btn reset" id="reset">↻ RESET</button>
</div>

<div class="info">
Cocokkan semua kartu • 30 LEVEL • Sound ON
</div>

</div>
</div>

<script>

const c=document.getElementById('game'),x=c.getContext('2d');
const levelEl=document.getElementById('level'),scoreEl=document.getElementById('score'),movesEl=document.getElementById('moves'),timerEl=document.getElementById('timer'),livesEl=document.getElementById('lives'),reset=document.getElementById('reset');

const icons=['🌙','⭐','🔥','💎','🍀','🎮','👑','🚀','⚡','🎯','🦊','🐉','🍕','🍔','🎲','🎵','💰','💜','🖤','🤍','☀️','🌈','🍎','🍇','🥶','👾','🧿','🪐','🏆','💠'];

let cards=[];
let first=null;
let second=null;
let lock=false;
let level=1;
let score=0;
let moves=0;
let lives=3;
let time=30;
let timer=null;
let finished=false;
let cols=4;
let rows=2;
let gameToken=0;

let audio=null;

function sound(type){

try{

if(!audio)audio=new(window.AudioContext||window.webkitAudioContext)();

if(audio.state==='suspended')audio.resume();

let o=audio.createOscillator();
let g=audio.createGain();

o.connect(g);
g.connect(audio.destination);

let now=audio.currentTime;

if(type==='flip'){

o.type='sine';
o.frequency.setValueAtTime(500,now);
o.frequency.exponentialRampToValueAtTime(800,now+.08);

g.gain.setValueAtTime(.0001,now);
g.gain.exponentialRampToValueAtTime(.08,now+.01);
g.gain.exponentialRampToValueAtTime(.0001,now+.09);

o.start(now);
o.stop(now+.1);

}

if(type==='match'){

o.type='sine';
o.frequency.setValueAtTime(520,now);
o.frequency.setValueAtTime(720,now+.08);
o.frequency.setValueAtTime(980,now+.16);

g.gain.setValueAtTime(.0001,now);
g.gain.exponentialRampToValueAtTime(.1,now+.02);
g.gain.exponentialRampToValueAtTime(.0001,now+.28);

o.start(now);
o.stop(now+.3);

}

if(type==='wrong'){

o.type='sawtooth';
o.frequency.setValueAtTime(250,now);
o.frequency.exponentialRampToValueAtTime(100,now+.18);

g.gain.setValueAtTime(.0001,now);
g.gain.exponentialRampToValueAtTime(.08,now+.02);
g.gain.exponentialRampToValueAtTime(.0001,now+.2);

o.start(now);
o.stop(now+.21);

}

if(type==='level'){

o.type='triangle';
o.frequency.setValueAtTime(500,now);
o.frequency.setValueAtTime(700,now+.1);
o.frequency.setValueAtTime(900,now+.2);
o.frequency.setValueAtTime(1200,now+.3);

g.gain.setValueAtTime(.0001,now);
g.gain.exponentialRampToValueAtTime(.1,now+.03);
g.gain.exponentialRampToValueAtTime(.0001,now+.42);

o.start(now);
o.stop(now+.45);

}

if(type==='win'){

o.type='triangle';
o.frequency.setValueAtTime(500,now);
o.frequency.setValueAtTime(650,now+.12);
o.frequency.setValueAtTime(800,now+.24);
o.frequency.setValueAtTime(1000,now+.36);
o.frequency.setValueAtTime(1300,now+.48);

g.gain.setValueAtTime(.0001,now);
g.gain.exponentialRampToValueAtTime(.12,now+.03);
g.gain.exponentialRampToValueAtTime(.0001,now+.7);

o.start(now);
o.stop(now+.72);

}

if(type==='gameover'){

o.type='sawtooth';
o.frequency.setValueAtTime(400,now);
o.frequency.exponentialRampToValueAtTime(90,now+.5);

g.gain.setValueAtTime(.0001,now);
g.gain.exponentialRampToValueAtTime(.1,now+.03);
g.gain.exponentialRampToValueAtTime(.0001,now+.55);

o.start(now);
o.stop(now+.58);

}

}catch(e){}

}

function getPairs(){

let p=4+Math.floor((level-1)/2);

if(p>12)p=12;

return p;

}

function setup(){

clearInterval(timer);

gameToken++;

first=null;
second=null;
lock=false;
finished=false;
moves=0;
lives=3;

time=Math.max(18,35-Math.floor(level*.5));

let pairs=getPairs();

if(pairs<=4){
cols=4;
rows=2;
}else if(pairs<=6){
cols=4;
rows=3;
}else if(pairs<=8){
cols=4;
rows=4;
}else if(pairs<=10){
cols=5;
rows=4;
}else{
cols=6;
rows=4;
}

let arr=[];

for(let i=0;i<pairs;i++){

arr.push({
v:icons[i],
open:false,
done:false,
x:0,
y:0
});

arr.push({
v:icons[i],
open:false,
done:false,
x:0,
y:0
});

}

cards=arr.sort(()=>Math.random()-.5);

levelEl.textContent='LEVEL '+level;
movesEl.textContent='0';
timerEl.textContent=time;
livesEl.textContent='❤️❤️❤️';

draw();
startTimer();

}

function startTimer(){

timer=setInterval(()=>{

if(finished)return;

time--;

timerEl.textContent=time;

if(time<=0){

clearInterval(timer);

lives--;

if(lives<=0){

gameOver('TIME OUT');

}else{

time=Math.max(12,25-Math.floor(level*.3));

timerEl.textContent=time;

livesEl.textContent='❤️'.repeat(lives)+'🖤'.repeat(3-lives);

sound('wrong');

}

}

},1000);

}

function draw(){

let W=c.width;
let H=c.height;

x.clearRect(0,0,W,H);

let bg=x.createRadialGradient(W/2,H/2,50,W/2,H/2,W);

bg.addColorStop(0,'#17142b');
bg.addColorStop(1,'#07070e');

x.fillStyle=bg;
x.fillRect(0,0,W,H);

let gap=12;
let pad=25;

let cw=(W-pad*2-gap*(cols-1))/cols;
let ch=(H-pad*2-gap*(rows-1))/rows;

cards.forEach((card,i)=>{

let r=Math.floor(i/cols);
let col=i%cols;

card.x=pad+col*(cw+gap);
card.y=pad+r*(ch+gap);

if(card.open||card.done){

let gg=x.createLinearGradient(card.x,card.y,card.x+cw,card.y+ch);

gg.addColorStop(0,'rgba(108,92,231,.38)');
gg.addColorStop(1,'rgba(72,52,211,.16)');

x.fillStyle=gg;

round(card.x,card.y,cw,ch,14);

x.strokeStyle=card.done?'rgba(162,155,254,.95)':'rgba(255,255,255,.18)';
x.lineWidth=2;
x.stroke();

x.textAlign='center';
x.textBaseline='middle';
x.font=Math.min(cw,ch)*.48+'px Arial';

if(card.done){

x.shadowColor='rgba(162,155,254,.9)';
x.shadowBlur=15;

}

x.fillText(card.v,card.x+cw/2,card.y+ch/2+2);

x.shadowBlur=0;

}else{

let g=x.createLinearGradient(card.x,card.y,card.x+cw,card.y+ch);

g.addColorStop(0,'#211c3d');
g.addColorStop(.5,'#15122a');
g.addColorStop(1,'#0b0915');

x.fillStyle=g;

round(card.x,card.y,cw,ch,14);

x.strokeStyle='rgba(108,92,231,.42)';
x.lineWidth=2;
x.stroke();

x.textAlign='center';
x.textBaseline='middle';
x.font='bold '+Math.min(cw,ch)*.35+'px Arial';

x.fillStyle='rgba(162,155,254,.35)';
x.fillText('?',card.x+cw/2,card.y+ch/2);

}

});

}

function round(a,b,w,h,r){

x.beginPath();
x.moveTo(a+r,b);
x.lineTo(a+w-r,b);
x.quadraticCurveTo(a+w,b,a+w,b+r);
x.lineTo(a+w,b+h-r);
x.quadraticCurveTo(a+w,b+h,a+w-r,b+h);
x.lineTo(a+r,b+h);
x.quadraticCurveTo(a,b+h,a,b+h-r);
x.lineTo(a,b+r);
x.quadraticCurveTo(a,b,a+r,b);
x.closePath();
x.fill();

}

function getCard(mx,my){

for(let i=0;i<cards.length;i++){

let z=cards[i];

let gap=12;
let pad=25;

let cw=(640-pad*2-gap*(cols-1))/cols;
let ch=(640-pad*2-gap*(rows-1))/rows;

if(mx>=z.x&&mx<=z.x+cw&&my>=z.y&&my<=z.y+ch)return i;

}

return -1;

}

c.addEventListener('pointerdown',e=>{

if(finished)return;

if(lock)return;

if(!cards.length)return;

let rect=c.getBoundingClientRect();

let mx=(e.clientX-rect.left)*(c.width/rect.width);
let my=(e.clientY-rect.top)*(c.height/rect.height);

let i=getCard(mx,my);

if(i<0)return;

let card=cards[i];

if(!card)return;

if(card.open||card.done)return;

if(first!==null&&i===first)return;

card.open=true;

sound('flip');

if(first===null){

first=i;
draw();
return;

}

second=i;

moves++;
movesEl.textContent=moves;

lock=true;

let myFirst=first;
let mySecond=second;
let currentToken=gameToken;

draw();

setTimeout(()=>{

if(currentToken!==gameToken)return;

if(myFirst===null||mySecond===null)return;

if(!cards[myFirst]||!cards[mySecond])return;

if(cards[myFirst].v===cards[mySecond].v){

cards[myFirst].done=true;
cards[mySecond].done=true;

score+=100*level;

scoreEl.textContent=score;

sound('match');

first=null;
second=null;

let all=cards.every(z=>z.done);

if(all){

clearInterval(timer);

if(level>=30){

winGame();

}else{

lock=true;

sound('level');

level++;

levelEl.textContent='LEVEL '+level;

setTimeout(()=>{

if(currentToken!==gameToken)return;

setup();

},1000);

}

}else{

lock=false;
draw();

}

}else{

sound('wrong');

cards[myFirst].open=false;
cards[mySecond].open=false;

first=null;
second=null;

lives--;

livesEl.textContent='❤️'.repeat(Math.max(0,lives))+'🖤'.repeat(Math.max(0,3-lives));

if(lives<=0){

gameOver('KEHABISAN NYAWA');

}else{

lock=false;
draw();

}

}

},700);

});

function gameOver(reason){

finished=true;
lock=true;

clearInterval(timer);

sound('gameover');

draw();

x.fillStyle='rgba(5,5,12,.9)';
x.fillRect(0,0,c.width,c.height);

x.textAlign='center';
x.textBaseline='middle';

x.fillStyle='#fff';
x.font='bold 42px Arial';
x.fillText('GAME OVER',c.width/2,c.height/2-40);

x.fillStyle='#ff7675';
x.font='bold 20px Arial';
x.fillText(reason,c.width/2,c.height/2+5);

x.fillStyle='#999';
x.font='14px Arial';
x.fillText('Tekan RESET untuk mulai lagi',c.width/2,c.height/2+48);

}

function winGame(){

finished=true;
lock=true;

clearInterval(timer);

sound('win');

draw();

x.fillStyle='rgba(5,5,12,.92)';
x.fillRect(0,0,c.width,c.height);

x.textAlign='center';
x.textBaseline='middle';

x.fillStyle='#fff';
x.font='48px Arial';
x.fillText('🏆',c.width/2,c.height/2-80);

x.font='bold 36px Arial';
x.fillText('YOU WIN',c.width/2,c.height/2-25);

x.fillStyle='#a29bfe';
x.font='bold 18px Arial';
x.fillText('30 LEVEL COMPLETED!',c.width/2,c.height/2+18);

x.fillStyle='#aaa';
x.font='14px Arial';
x.fillText('FINAL SCORE: '+score,c.width/2,c.height/2+55);

}

reset.addEventListener('pointerdown',e=>{

e.stopPropagation();

gameToken++;

clearInterval(timer);

level=1;
score=0;

scoreEl.textContent='0';

setup();

sound('flip');

});

setup();

</script>`,
"trusted_sources":[
"adam.dev"
]
},
"__typename":"GenAISingleLayoutViewModel"
}
}
]
})).toString('base64')
},
contextInfo:{
forwardingScore:1,
isForwarded:true,
forwardedAiBotMessageInfo:{
botJid:"867051314767696@bot"
},
forwardOrigin:4
}
}
}
}
},
{}
)
}

handler.help=['memorymatch']
handler.tags=['game']
handler.command=/^memorymatch$/i

export default handler