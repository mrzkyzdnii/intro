const getRegisteredCommands = () => {
    const commands = new Set()

    try {
        const plugins = global.plugins || {}

        for (const plugin of Object.values(plugins)) {
            if (!plugin) continue

            const command = plugin.command

            if (Array.isArray(command)) {
                for (const cmd of command) {
                    if (typeof cmd === 'string') {
                        const clean = cmd
                            .replace(/^\^/, '')
                            .replace(/\$$/, '')
                            .trim()
                            .toLowerCase()

                        if (
                            clean &&
                            clean.length <= 50 &&
                            /^[a-z0-9][a-z0-9_-]*$/i.test(clean)
                        ) {
                            commands.add(clean)
                        }
                    }
                }

                continue
            }

            if (typeof command === 'string') {
                const clean = command
                    .replace(/^\^/, '')
                    .replace(/\$$/, '')
                    .trim()
                    .toLowerCase()

                if (
                    clean &&
                    clean.length <= 50 &&
                    /^[a-z0-9][a-z0-9_-]*$/i.test(clean)
                ) {
                    commands.add(clean)
                }

                continue
            }

            if (command instanceof RegExp) {
                let source = command.source

                source = source
                    .replace(/^\^/, '')
                    .replace(/\$$/, '')
                    .replace(/\(\?:/g, '(')

                const parts = source.split('|')

                for (let part of parts) {
                    part = part
                        .replace(/^\(/, '')
                        .replace(/\)$/, '')
                        .replace(/\\[dDsSwW]/g, '')
                        .replace(/\\(.)/g, '$1')
                        .trim()
                        .toLowerCase()

                    if (
                        part &&
                        part.length <= 50 &&
                        /^[a-z0-9][a-z0-9_-]*$/i.test(part)
                    ) {
                        commands.add(part)
                    }
                }
            }
        }
    } catch (e) {
        console.error('[TOTALHIT] Gagal membaca global.plugins:', e)
    }

    return commands
}

const cleanCommand = (command) => {
    return String(command || '')
        .replace(/[\r\n\t]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toLowerCase()
}

const handler = async (m, { conn }) => {
    global.db.data.stats = global.db.data.stats || {}

    const stats = global.db.data.stats
    const registeredCommands = getRegisteredCommands()

    const entries = Object.entries(stats)
        .map(([command, count]) => [
            cleanCommand(command),
            Number(count || 0)
        ])
        .filter(([command, count]) => {
            if (!command) return false
            if (!Number.isFinite(count)) return false
            if (count <= 0) return false

            if (
                registeredCommands.size > 0 &&
                !registeredCommands.has(command)
            ) {
                return false
            }

            if (
                command.includes(' ') ||
                command.includes('.') ||
                command.includes('/') ||
                command.includes('\\') ||
                command.includes('(') ||
                command.includes(')') ||
                command.includes('{') ||
                command.includes('}') ||
                command.includes('[') ||
                command.includes(']') ||
                command.includes(':') ||
                command.includes(';') ||
                command.includes(',') ||
                command.includes('=') ||
                command.includes('=>')
            ) {
                return false
            }

            if (!/^[a-z0-9][a-z0-9_-]*$/i.test(command)) {
                return false
            }

            return true
        })
        .sort((a, b) => b[1] - a[1])

    const total = entries.reduce(
        (sum, [, count]) => sum + count,
        0
    )

    const commands = entries.length
    const top = entries[0]

    const tree = entries
        .map(([command, count], index) => {
            const last = index === entries.length - 1
            const branch = last ? '╰─' : '├─'

            const rank =
                index === 0 ? '◆' :
                index === 1 ? '◇' :
                index === 2 ? '◇' :
                '•'

            return `┃  ${branch} ${rank} ${command}  ›  ${count}x`
        })
        .join('\n')

    const text = [
        `╭━━〔 ◈ COMMAND STATISTICS 〕━━╮`,
        `┃`,
        `┃  ◆ Total Hit    ›  ${total}x`,
        `┃  ◆ Commands     ›  ${commands}`,
        `┃  ◆ Top Command  ›  ${top?.[0] || '-'}`,
        `┃`,
        `┣━━〔 ◇ USAGE TREE 〕`,
        `┃`,
        tree || `┃  ╰─ • No command used`,
        `┃`,
        `╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`
    ].join('\n')

    await conn.reply(m.chat, text, m)
}

handler.help = ['totalhit', 'dashboard']
handler.tags = ['info']
handler.command = /^(totalhit|dashboard)$/i

export default handler