import axios from 'axios'
import * as cheerio from 'cheerio'

const BROWSER_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  'Accept':
    'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
}

const scraper = async (query) => {
  if (!query) throw new Error('Query tidak boleh kosong!')

  const cleanQuery = query.trim()
  const formattedTag = cleanQuery.toLowerCase().replace(/\s+/g, '-')

  const sources = [
    {
      url: `https://www.goodreads.com/quotes/tag/${encodeURIComponent(formattedTag)}`,
      type: 'goodreads',
    },
    {
      url: `https://www.goodreads.com/quotes/search?q=${encodeURIComponent(cleanQuery)}&commit=Search`,
      type: 'goodreads',
    },
  ]

  const pool = []

  // 1. Scraping dari Goodreads (Tag & Search)
  for (const src of sources) {
    try {
      const res = await axios.get(src.url, {
        headers: BROWSER_HEADERS,
        timeout: 10000,
      })
      const $ = cheerio.load(res.data)

      $('.quoteDetails').each((_, el) => {
        const $el = $(el)

        let rawText = $el.find('.quoteText').contents().first().text().trim()
        if (!rawText || rawText.length < 5) {
          rawText = $el.find('.quoteText').text().trim()
        }

        // Clean quote text
        let quote = rawText
          .replace(/^["'“«\s]+|["'”»\s]+$/g, '')
          .replace(/―.*$/, '')
          .replace(/—.*$/, '')
          .replace(/\s+/g, ' ')
          .trim()

        // Author name
        let author = $el.find('.quoteText .authorOrTitle').first().text().trim()
        author = author.replace(/,\s*$/, '').trim()

        // Book or work title
        let book = $el.find('.quoteText a.authorOrTitle').last().text().trim()
        if (book === author) book = ''

        // Author photo
        let img = $el.find('img').attr('src') || null
        if (img && (img.includes('nophoto') || img.includes('blank'))) {
          img = null
        }

        // Likes count
        const likesText = $el.find('.quoteFooter .right .smallText').text().trim()
        const likesMatch = likesText.match(/(\d+)\s*likes/i)
        const likes = likesMatch ? parseInt(likesMatch[1], 10) : 0

        if (quote && quote.length > 5) {
          pool.push({
            quote,
            author: author || 'Anonim',
            book: book || null,
            likes,
            img,
            source: 'Goodreads',
          })
        }
      })
    } catch (_) {
      // Abaikan error individual URL
    }
  }

  // Deduplikasi quotes
  const uniqueMap = new Map()
  for (const item of pool) {
    const key = item.quote.toLowerCase()
    if (!uniqueMap.has(key)) {
      uniqueMap.set(key, item)
    }
  }

  let uniquePool = Array.from(uniqueMap.values())

  // 2. Fallback ke Wikiquote Indonesia jika Goodreads kosong
  if (!uniquePool.length) {
    try {
      const wikiUrl = `https://id.wikiquote.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(cleanQuery)}&format=json&origin=*`
      const wikiRes = await axios.get(wikiUrl, {
        headers: BROWSER_HEADERS,
        timeout: 8000,
      })
      const hits = wikiRes.data?.query?.search || []

      for (const hit of hits.slice(0, 3)) {
        const parseUrl = `https://id.wikiquote.org/w/api.php?action=parse&page=${encodeURIComponent(hit.title)}&format=json&prop=text&origin=*`
        const parseRes = await axios.get(parseUrl, {
          headers: BROWSER_HEADERS,
          timeout: 8000,
        })
        const html = parseRes.data?.parse?.text?.['*'] || ''
        const $ = cheerio.load(html)

        $('table, .toc, .mw-empty-elt, style, script, .reference').remove()

        $('ul > li, ol > li').each((_, el) => {
          const text = $(el).text().trim()
          if (text.length >= 15 && text.length <= 400) {
            const clean = text
              .replace(/^["'“«\s]+|["'”»\s]+$/g, '')
              .replace(/\[\d+\]/g, '')
              .trim()

            const parts = clean.split('\n')
            const quoteStr = parts[0].trim()

            if (quoteStr.length >= 10) {
              uniquePool.push({
                quote: quoteStr,
                author: hit.title,
                book: null,
                likes: 0,
                img: null,
                source: 'Wikiquote ID',
              })
            }
          }
        })
      }
    } catch (_) {
      // Abaikan error Wikiquote
    }
  }

  if (!uniquePool.length) {
    throw new Error(`Kata bijak untuk query "${cleanQuery}" tidak ditemukan!`)
  }

  // Pilih 1 quote secara acak dari hasil
  const pick = uniquePool[Math.floor(Math.random() * uniquePool.length)]

  return {
    totalQuotesFound: uniquePool.length,
    query: cleanQuery,
    ...pick,
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} motivasi`

  try {
    const result = await scraper(text)

    let caption = `*[ KATA BIJAK & QUOTES ]*\n\n`
    caption += `💬 "${result.quote}"\n\n`
    caption += `👤 *Penulis:* ${result.author}`
    if (result.book) caption += `\n📚 *Karya/Buku:* ${result.book}`
    if (result.likes) caption += `\n❤️ *Likes:* ${result.likes}`
    caption += `\n\n🔎 *Query:* ${text} • *Pool:* ${result.totalQuotesFound} quotes (${result.source})`

    if (result.img) {
      try {
        await conn.sendFile(m.chat, result.img, 'author.jpg', caption, m)
        return
      } catch (_) {
        // Jika kirim gambar gagal, fallback ke teks
      }
    }

    await conn.reply(m.chat, caption, m)
  } catch (err) {
    await conn.reply(
      m.chat,
      `❌ Error: ${err.message || err}\n\n` +
        `_Coba query lain seperti: cinta, motivasi, rindu, kehidupan, Soekarno_`,
      m
    )
  }
}

handler.help = ['quotes']
handler.tags = ['search']
handler.command = /^quotes$/i

handler.limit = 10
export default handler