import axios from 'axios'
import * as cheerio from 'cheerio'

class Mrzkyzdnii {
    constructor() {
        this.baseUrl = 'https://spotidown.app'
        this.siteKey = '6LcXkaUqAAAAAGvO0z9Mg54lpG22HE4gkl3XYFTK'
        this.version = 'AI7Fbyu7OpLvtxXargsbepSz'
        this.userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }

    headers(extra = {}) {
        return {
            'User-Agent': this.userAgent,
            ...extra
        }
    }

    async recaptcha(domain = 'spotidown.app') {
        const co = Buffer.from(`https://${domain}:443`).toString('base64').replace(/=/g, '.')

        const anchor = new URL('https://www.google.com/recaptcha/api2/anchor')
        anchor.searchParams.set('ar', '1')
        anchor.searchParams.set('k', this.siteKey)
        anchor.searchParams.set('co', co)
        anchor.searchParams.set('hl', 'en')
        anchor.searchParams.set('v', this.version)
        anchor.searchParams.set('size', 'invisible')
        anchor.searchParams.set('cb', '123')

        const { data: anchorHtml } = await axios.get(anchor.toString(), {
            headers: this.headers()
        })

        const tokenMatch = anchorHtml.match(/id="recaptcha-token" value="([^"]+)"/)

        if (!tokenMatch) {
            throw new Error('Gagal mendapatkan token.')
        }

        const token = tokenMatch[1]

        const reload = await axios.post(
            `https://www.google.com/recaptcha/api2/reload?k=${this.siteKey}`,
            new URLSearchParams({
                v: this.version,
                reason: 'q',
                c: token,
                k: this.siteKey,
                co,
                hl: 'en',
                size: 'invisible'
            }).toString(),
            {
                headers: this.headers({
                    'Content-Type': 'application/x-www-form-urlencoded'
                })
            }
        )

        const response = reload.data.match(/"rresp","([^"]+)"/)

        if (!response) {
            throw new Error('Gagal memproses token.')
        }

        return response[1]
    }

    async session() {
        const response = await axios.get(`${this.baseUrl}/en6`, {
            headers: this.headers()
        })

        const cookie = response.headers['set-cookie']
            ? response.headers['set-cookie'].map(v => v.split(';')[0]).join('; ')
            : ''

        const $ = cheerio.load(response.data)
        const input = $("form[name='spotifyurl'] input[type='hidden']")
            .not('#g-recaptcha-response')
            .first()

        const name = input.attr('name')
        const value = input.attr('value')

        if (!name || !value) {
            throw new Error('Gagal mendapatkan token.')
        }

        return {
            cookie,
            csrfName: name,
            csrfValue: value
        }
    }

    async action(query, session, captcha) {
        const form = new FormData()

        form.append('url', query.trim())
        form.append('g-recaptcha-response', captcha)
        form.append(session.csrfName, session.csrfValue)

        const response = await axios.post(
            `${this.baseUrl}/action`,
            form,
            {
                headers: this.headers({
                    Cookie: session.cookie,
                    Referer: `${this.baseUrl}/en6`,
                    Origin: this.baseUrl,
                    'X-Requested-With': 'XMLHttpRequest'
                })
            }
        )

        if (response.data.error) {
            throw new Error(response.data.message || 'Lagu tidak ditemukan.')
        }

        const $ = cheerio.load(response.data.data)
        const formTrack = $("form[name='submitspurl']").first()

        if (!formTrack.length) {
            throw new Error('Lagu tidak ditemukan.')
        }

        const data = formTrack.find("input[name='data']").val()
        const base = formTrack.find("input[name='base']").val()
        const token = formTrack.find("input[name='token']").val()

        if (!data || !base || !token) {
            throw new Error('Data lagu tidak valid.')
        }

        let info = {}

        try {
            info = JSON.parse(
                Buffer.from(data, 'base64').toString('utf-8')
            )
        } catch {}

        return {
            data,
            base,
            token,
            info
        }
    }

    async track(data, session) {
        const form = new FormData()

        form.append('data', data.data)
        form.append('base', data.base)
        form.append('token', data.token)

        const response = await axios.post(
            `${this.baseUrl}/action/track`,
            form,
            {
                headers: this.headers({
                    Cookie: session.cookie,
                    Referer: `${this.baseUrl}/en6`,
                    Origin: this.baseUrl,
                    'X-Requested-With': 'XMLHttpRequest'
                })
            }
        )

        if (response.data.error) {
            throw new Error(response.data.message || 'Gagal membuat link.')
        }

        const $ = cheerio.load(response.data.data)
        const downloadUrl = $("a[href*='rapid.spotidown.app']").attr('href')

        if (!downloadUrl) {
            throw new Error('Link audio tidak ditemukan.')
        }

        return {
            $,
            downloadUrl
        }
    }

    async download(url) {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            headers: this.headers()
        })

        return Buffer.from(response.data)
    }

    async search(query) {
        if (!query?.trim()) {
            throw new Error('Query kosong.')
        }

        const session = await this.session()
        const captcha = await this.recaptcha()
        const data = await this.action(query, session, captcha)
        const result = await this.track(data, session)
        const audio = await this.download(result.downloadUrl)

        const info = data.info
        const $ = result.$

        return {
            title: info.name || $("h3[itemprop='name']").text().trim() || 'Spotify Audio',
            artist: info.artist || $('.spotidown-downloader-middle p').text().trim() || 'Unknown Artist',
            album: info.album || '-',
            duration: info.duration || '-',
            cover: info.cover || $('.spotidown-downloader-left img').attr('src') || '',
            downloadUrl: result.downloadUrl,
            audio
        }
    }
}

const spotify = new Mrzkyzdnii()

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        throw `Contoh Penggunaan:\n• ${usedPrefix + command} https://open.spotify.com/track/\n• ${usedPrefix + command} dj dalinda`
    }

    await conn.reply(
        m.chat,
        '⏳ _Sedang mencari dan mengunduh audio dari Spotify..._',
        m
    )

    const result = await spotify.search(text)

    const caption =
        `🎵 *SPOTIFY DOWNLOADER*\n\n` +
        `📌 *Judul:* ${result.title}\n` +
        `👤 *Artis:* ${result.artist}\n` +
        `💿 *Album:* ${result.album}\n` +
        `⏱️ *Durasi:* ${result.duration}\n\n` +
        `_Audio file sedang dikirim..._`

    if (result.cover) {
        await conn.sendFile(
            m.chat,
            result.cover,
            'cover.jpg',
            caption,
            m
        )
    } else {
        await conn.reply(
            m.chat,
            caption,
            m
        )
    }

    await conn.sendFile(
        m.chat,
        result.audio,
        `${result.title}.mp3`,
        '',
        m,
        false,
        {
            mimetype: 'audio/mpeg'
        }
    )
}

handler.help = ['splay <url/judul>']
handler.tags = ['downloader']
handler.command = /^splay$/i

export default handler