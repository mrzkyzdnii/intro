import fs from 'fs'

let timeout = 60000 // 60 detik

let handler = async (m, { conn, command, isAdmin, isOwner }) => {
  global.tebakbuah = global.tebakbuah || {}
  global.db = global.db || { users: {} }
  
  const chat = m.chat
  const room = global.tebakbuah[chat] || {}

  if (command === "tebakbuah" || command === "tbuah") {
    if (room.answer) 
      return conn.reply(chat, "❌ Masih ada soal belum terjawab di chat ini.", m)

    try {
      // Ambil data dari JSON
      let src = JSON.parse(fs.readFileSync('./json/tebakbuah.json', 'utf-8'))
      let json = src[Math.floor(Math.random() * src.length)]

      // Kirim gambar dengan deskripsi
      await conn.sendMessage(
        chat,
        {
          image: { url: json.img },
          caption: `🍎 *TEBAK BUAH*\n\n📝 *Deskripsi:* ${json.deskripsi}\n💰 Hadiah: *Rp${formatMoney(getRandomInt(5000, 10000))}*\n⏳ Waktu: *60 detik*\n💡 Ketik jawaban langsung.\n📝 Ketik *.hintbuah* untuk hint (Semua user).`,
        },
        { quoted: m }
      )

      // Generate reward acak 5000-10000
      const reward = getRandomInt(5000, 10000)

      global.tebakbuah[chat] = {
        answer: json.jawaban.toLowerCase(),
        player: m.sender,
        reward: reward,
        timer: setTimeout(() => {
          conn.reply(chat, `❌ Waktu habis!\nJawaban: *${json.jawaban}*`)
          delete global.tebakbuah[chat]
        }, timeout),
      }

    } catch (error) {
      console.error('Error:', error)
      return conn.reply(chat, "❌ Gagal memuat data. Coba lagi!", m)
    }
  }

  // Fitur clue (hanya admin/owner) - Full clue
  if (command === "whob uah") {
    if (!room.answer) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    if (!isAdmin && !isOwner)
      return conn.reply(chat, "❌ Klu hanya untuk admin/owner.", m)

    const ans = room.answer
    const words = ans.split(' ')
    let hint = words.map(word => {
      if (word.length <= 2) return word
      return word[0] + "_".repeat(word.length - 2) + word.slice(-1)
    }).join(' ')
    
    return conn.reply(chat, `🧩 *KLU:* ${hint}`, m)
  }

  // Fitur hint (semua user) - Simple hint
  if (command === "hintbuah") {
    if (!room.answer) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    
    const ans = room.answer
    const hint = ans[0] + "_".repeat(Math.max(ans.length - 2, 1)) + ans.slice(-1)
    return conn.reply(chat, `🧩 *HINT:* ${hint}`, m)
  }

  // Fitur cek player
  if (command === "whoplayerbuah") {
    if (!room.player) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    return conn.reply(
      chat,
      `👤 Player: @${room.player.split("@")[0]}`,
      m,
      { mentions: [room.player] }
    )
  }

  // Fitur cek total buah
  if (command === "totalbuah") {
    try {
      let src = JSON.parse(fs.readFileSync('./json/tebakbuah.json', 'utf-8'))
      return conn.reply(chat, `🍎 *Total Buah:* ${src.length} jenis`, m)
    } catch (error) {
      return conn.reply(chat, "❌ Gagal membaca data!", m)
    }
  }
}

handler.all = async function (m) {
  const room = global.tebakbuah?.[m.chat]
  if (!room?.answer) return

  const text = (m.text || "").trim().toLowerCase()
  if (!text) return

  // Cek jawaban (case insensitive)
  if (text === room.answer) {
    clearTimeout(room.timer)
    
    // Berikan reward
    const reward = room.reward || getRandomInt(5000, 10000)
    
    // Tambahkan money ke user
    if (!global.db.users[m.sender]) {
      global.db.users[m.sender] = { money: 0 }
    }
    global.db.users[m.sender].money = (global.db.users[m.sender].money || 0) + reward

    await this.reply(
      m.chat, 
      `✅ *Benar!* 🎉\nJawaban: *${room.answer}*\n💰 +Rp${formatMoney(reward)} 🤑\n💵 Total Money: Rp${formatMoney(global.db.users[m.sender].money)}`, 
      m
    )
    
    delete global.tebakbuah[m.chat]
  }
}

// Fungsi helper
function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function formatMoney(amount) {
  return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
}

handler.help = ["tebakbuah"]
handler.tags = ["game"]
handler.command = /^(tebakbuah|tbuah|hintbuah|whoplayerbuah|totalbuah)$/i
handler.limit = 10

export default handler