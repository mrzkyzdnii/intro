import axios from 'axios'

const HISTORY_LIMIT = 12
const recentByUser = new Map()

let sessionCache = {
  cookie: '',
  csrf: '',
  expires: 0
}

const getSession = async () => {
  if (sessionCache.cookie && Date.now() < sessionCache.expires) {
    return sessionCache
  }

  const res = await axios.get('https://www.pinterest.com/', {
    headers: {
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'accept-language': 'en-US,en;q=0.9'
    },
    timeout: 10000
  })

  const cookies = (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ')
  const csrfMatch = cookies.match(/csrftoken=([^;]+)/)
  const csrf = csrfMatch ? csrfMatch[1] : ''

  sessionCache = {
    cookie: cookies,
    csrf,
    expires: Date.now() + 1000 * 60 * 30
  }

  return sessionCache
}

const remember = (userId, url) => {
  if (!userId) return
  const list = recentByUser.get(userId) || []
  list.push(url)
  while (list.length > HISTORY_LIMIT) list.shift()
  recentByUser.set(userId, list)
}

const shuffleArray = (array) => {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[array[i], array[j]] = [array[j], array[i]]
  }
  return array
}

const fetchPool = async (query) => {
  const images = []
  const seen = new Set()
  let bookmark = ''
  let page = 0
  const maxPages = 2

  while (page < maxPages) {
    page++
    const session = await getSession()
    const data = {
      options: {
        isPrefetch: false,
        query,
        scope: 'pins',
        bookmarks: [bookmark],
        page_size: 25,
        source_url: `/search/pins/?q=${encodeURIComponent(query)}`,
        no_fetch_context_on_resources: false,
        rs: 'typed'
      },
      context: {}
    }

    let res
    try {
      res = await axios.get('https://www.pinterest.com/resource/BaseSearchResource/get/', {
        params: {
          source_url: `/search/pins/?q=${encodeURIComponent(query)}`,
          data: JSON.stringify(data),
          _: Date.now()
        },
        headers: {
          'cookie': session.cookie,
          'x-csrftoken': session.csrf,
          'x-requested-with': 'XMLHttpRequest',
          'x-pinterest-appstate': 'active',
          'x-pinterest-pws-handler': 'www/[partner]/index.js',
          'referer': `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(query)}`,
          'accept': 'application/json, text/javascript, */*; q=0.01',
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
        },
        timeout: 12000
      })
    } catch (err) {
      if (err.response?.status === 401 || err.response?.status === 403) {
        sessionCache.cookie = ''
        sessionCache.expires = 0
      }
      break
    }

    const resp = res?.data?.resource_response
    if (!resp) break

    const rawData = resp.data?.results || (Array.isArray(resp.data) ? resp.data : [])
    for (const item of rawData) {
      const img = item?.images?.orig?.url || item?.images?.['736x']?.url || item?.images?.['474x']?.url || item?.images?.['236x']?.url
      if (img && !seen.has(img)) {
        seen.add(img)
        images.push({
          url: img,
          width: item?.images?.orig?.width || item?.images?.['736x']?.width || null,
          height: item?.images?.orig?.height || item?.images?.['736x']?.height || null
        })
      }
    }

    if (!resp.bookmark || resp.bookmark === bookmark) break
    bookmark = resp.bookmark
    if (images.length >= 60) break
  }

  return images
}

const pinterestScraper = async (query, userId, limit = 35) => {
  const pool = await fetchPool(query)
  if (!pool.length) return []

  const seen = new Set(recentByUser.get(userId) || [])
  const fresh = pool.filter(p => !seen.has(p.url))
  const choices = fresh.length ? fresh : pool

  const shuffled = shuffleArray([...choices])
  const picked = []
  const batchSeen = new Set()
  for (const item of shuffled) {
    if (picked.length >= limit) break
    if (!batchSeen.has(item.url)) {
      batchSeen.add(item.url)
      picked.push(item)
    }
  }

  if (picked.length < limit) {
    for (const item of shuffleArray([...pool])) {
      if (picked.length >= limit) break
      if (!batchSeen.has(item.url)) {
        batchSeen.add(item.url)
        picked.push(item)
      }
    }
  }

  for (const item of picked) remember(userId, item.url)

  return picked.map(p => p.url)
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`Format Penggunaan:\n${usedPrefix + command} query\n\nContoh:\n${usedPrefix + command} anime girl`)
  }

  await m.reply('🔎 Sedang mencari gambar Pinterest...')

  try {
    const results = await pinterestScraper(text, m.sender, 35)

    if (!results.length) {
      return m.reply('❌ Tidak ada hasil ditemukan.')
    }

    const selectedUrls = results.slice(0, 2)

    try {
      const album = selectedUrls.map(url => ({
        image: { url },
        caption: `📌 ${text}\n\navosky-F`
      }))
      await conn.sendMessage(m.chat, { album }, { quoted: m })
    } catch {
      for (const url of selectedUrls) {
        await conn.sendFile(m.chat, url, 'pinterest.jpg', `📌 ${text}\n\navosky-F`, m)
      }
    }
  } catch (e) {
    m.reply('❌ Gagal mengambil hasil Pinterest.')
  }
}

handler.command = /^(pinterest|pin)$/i
handler.help = ['pinterest <query>']
handler.tags = ['internet']
handler.register = true
handler.limit = 10

export default handler