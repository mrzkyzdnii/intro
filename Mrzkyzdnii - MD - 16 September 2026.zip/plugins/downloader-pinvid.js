import axios from 'axios'

const HISTORY_LIMIT = 20
const recentByUser = new Map()

let sessionCache = {
  cookie: '',
  csrf: '',
  expires: 0
}

const getSession = async () => {
  if (sessionCache.cookie && Date.now() < sessionCache.expires) {
    return sessionCache
  }

  const res = await axios.get('https://www.pinterest.com/', {
    headers: {
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'accept-language': 'en-US,en;q=0.9'
    },
    timeout: 10000
  })

  const cookies = (res.headers['set-cookie'] || []).map(c => c.split(';')[0]).join('; ')
  const csrfMatch = cookies.match(/csrftoken=([^;]+)/)
  const csrf = csrfMatch ? csrfMatch[1] : ''

  sessionCache = {
    cookie: cookies,
    csrf,
    expires: Date.now() + 1000 * 60 * 30
  }

  return sessionCache
}

const remember = (userId, url) => {
  if (!userId) return
  const list = recentByUser.get(userId) || []
  list.push(url)
  while (list.length > HISTORY_LIMIT) list.shift()
  recentByUser.set(userId, list)
}

const resolveMp4 = async (hlsUrl) => {
  if (!hlsUrl) return null
  if (hlsUrl.includes('.mp4')) return hlsUrl

  const candidates = [
    hlsUrl.replace('/hls/', '/expMp4/').replace('.m3u8', '_720w.mp4'),
    hlsUrl.replace('/hls/', '/720p/').replace('.m3u8', '.mp4'),
    hlsUrl.replace('/videos/iht/hls/', '/videos/mc/720p/').replace('.m3u8', '.mp4'),
    hlsUrl.replace('/hls/', '/expMp4/').replace('.m3u8', '_1080w.mp4'),
    hlsUrl.replace('/hls/', '/expMp4/').replace('.m3u8', '_540w.mp4')
  ]

  for (const c of candidates) {
    try {
      const res = await axios.head(c, {
        headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        validateStatus: () => true,
        timeout: 4000
      })
      if (res.status === 200 && (res.headers['content-type']?.includes('mp4') || res.headers['content-type']?.includes('octet-stream'))) {
        return c
      }
    } catch {}
  }
  return null
}

const extractVideoFromPin = async (pin) => {
  let videoList = pin.videos?.video_list
  if (!videoList && pin.story_pin_data) {
    for (const page of pin.story_pin_data.pages || []) {
      for (const block of page.blocks || []) {
        if (block.video?.video_list) {
          videoList = block.video.video_list
          break
        }
      }
      if (videoList) break
    }
  }

  if (!videoList) return null

  for (const [k, v] of Object.entries(videoList)) {
    if (v.url && v.url.includes('.mp4') && !v.url.includes('hevc')) {
      return {
        id: pin.id,
        title: pin.title || pin.grid_title || 'Pinterest Video',
        url: v.url
      }
    }
  }

  const hlsUrl = videoList.V_HLSV4?.url || videoList.V_HLSV3_MOBILE?.url || Object.values(videoList)[0]?.url
  const mp4Url = await resolveMp4(hlsUrl)
  if (mp4Url) {
    return {
      id: pin.id,
      title: pin.title || pin.grid_title || 'Pinterest Video',
      url: mp4Url
    }
  }

  return null
}

const pinvidScraper = async (query, userId) => {
  const isUrl = /^https?:\/\//i.test(query.trim())

  if (isUrl) {
    const pageRes = await axios.get(query.trim(), {
      headers: {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      },
      maxRedirects: 5,
      timeout: 10000
    })

    const mp4s = pageRes.data.match(/https?:\/\/[^\s"'<>]*\.mp4/g) || []
    const best = mp4s.find(u => u.includes('/720p/')) || mp4s.find(u => u.includes('expMp4')) || mp4s.find(u => !u.includes('hevc')) || mp4s[0]

    if (!best) return null

    let title = 'Pinterest Video'
    const titleMatch = pageRes.data.match(/<meta property="og:title" content="([^"]+)"/i)
      || pageRes.data.match(/<title>([^<]+)<\/title>/i)
    if (titleMatch) title = titleMatch[1].replace(/ - Pinterest.*$/i, '').trim()

    return { title, url: best }
  }

  const searchTerm = /video|edit|reels|tiktok/i.test(query) ? query : query + ' video'
  const session = await getSession()

  const data = {
    options: {
      isPrefetch: false,
      query: searchTerm,
      scope: 'pins',
      bookmarks: [''],
      page_size: 35,
      source_url: `/search/pins/?q=${encodeURIComponent(searchTerm)}`,
      no_fetch_context_on_resources: false,
      rs: 'typed'
    },
    context: {}
  }

  const res = await axios.get('https://www.pinterest.com/resource/BaseSearchResource/get/', {
    params: {
      source_url: `/search/pins/?q=${encodeURIComponent(searchTerm)}`,
      data: JSON.stringify(data),
      _: Date.now()
    },
    headers: {
      'cookie': session.cookie,
      'x-csrftoken': session.csrf,
      'x-requested-with': 'XMLHttpRequest',
      'x-pinterest-appstate': 'active',
      'x-pinterest-pws-handler': 'www/[partner]/index.js',
      'referer': `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(searchTerm)}`,
      'accept': 'application/json, text/javascript, */*; q=0.01',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    },
    timeout: 15000
  })

  const results = res.data?.resource_response?.data?.results || []
  if (!results.length) return null

  const seen = new Set(recentByUser.get(userId) || [])
  const candidates = []

  for (const pin of results) {
    const vid = await extractVideoFromPin(pin)
    if (vid && vid.url) {
      candidates.push(vid)
    }
  }

  if (!candidates.length) return null

  const unvisited = candidates.filter(v => !seen.has(v.url))
  const pool = unvisited.length ? unvisited : candidates
  const chosen = pool[Math.floor(Math.random() * pool.length)]

  remember(userId, chosen.url)
  return chosen
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`Format Penggunaan:\n${usedPrefix + command} query\n${usedPrefix + command} link\n\nContoh:\n${usedPrefix + command} anime edit\n${usedPrefix + command} aesthetic nature\n${usedPrefix + command} https://pin.it/xxxxx`)
  }

  await m.reply('🎬 Sedang mencari dan menyiapkan video Pinterest, tunggu sebentar...')

  try {
    const video = await pinvidScraper(text, m.sender)

    if (!video || !video.url) {
      return m.reply('❌ Tidak ada video ditemukan untuk query atau link tersebut.')
    }

    const caption = `📌 *Pinterest Video*\n🏷️ *Judul:* ${video.title}\n\navosky-F`

    try {
      await conn.sendFile(m.chat, video.url, 'pinvid.mp4', caption, m)
    } catch {
      const vidBuffer = await axios.get(video.url, {
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        timeout: 40000
      })
      await conn.sendFile(m.chat, Buffer.from(vidBuffer.data), 'pinvid.mp4', caption, m)
    }
  } catch (e) {
    m.reply('❌ Gagal mengambil video dari Pinterest.')
  }
}

handler.command = /^(pinvid|pinterestvideo|pvideo)$/i
handler.help = ['pinvid <query/url>']
handler.tags = ['downloader']
handler.register = true
handler.limit = 10

export default handler