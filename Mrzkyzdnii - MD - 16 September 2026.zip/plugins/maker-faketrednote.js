import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import axios from 'axios'
import fs from 'node:fs'

const W = 1080
const H = 1116

const BG = '#766f5d'
const WHITE = '#f7f6f4'
const SOFT = '#dedbd4'
const CARD = 'rgba(190,184,164,.28)'
const PINK = '#ff1744'

const formatCount = (value) => {
    const raw = String(value ?? '').trim().replace(/,/g, '')
    const number = Number(raw)

    if (!Number.isFinite(number)) {
        return String(value ?? '0')
    }

    const abs = Math.abs(number)
    const trim = (n) => String(Number(n.toFixed(1)))

    if (abs >= 1_000_000_000) {
        return `${trim(number / 1_000_000_000)}B`
    }

    if (abs >= 1_000_000) {
        return `${trim(number / 1_000_000)}M`
    }

    if (abs >= 1_000) {
        return `${trim(number / 1_000)}K`
    }

    return String(number)
}

// ==============================
// FONT
// ==============================

try {
    GlobalFonts.registerFromPath(
        './src/font/Roboto-Medium.ttf',
        'Roboto'
    )

    GlobalFonts.registerFromPath(
        '/usr/share/fonts/opentype/noto/NotoSansCJKsc-Regular.otf',
        'Noto CJK'
    )

    GlobalFonts.registerFromPath(
        '/usr/share/fonts/opentype/noto/NotoSansCJKsc-Medium.otf',
        'Noto CJK'
    )
} catch {}

// ==============================
// IMAGE LOADER
// ==============================

const loadImageInput = async (input, timeout = 12000) => {
    try {
        if (!input) return null

        if (Buffer.isBuffer(input)) {
            return await loadImage(input)
        }

        if (typeof input === 'string') {
            if (fs.existsSync(input)) {
                return await loadImage(input)
            }

            if (/^https?:\/\//i.test(input)) {
                const response = await axios.get(input, {
                    responseType: 'arraybuffer',
                    timeout
                })

                return await loadImage(Buffer.from(response.data))
            }
        }
    } catch {}

    return null
}

// ==============================
// FAKE REDNOTE GENERATOR
// ==============================

const makeFakeRednote = async ({
    name = 'avosky md',
    id = '63818449066',
    following = '0',
    followers = '0',
    likes = '0',
    bio = 'Tap here to fill in your bio',
    avatarInput = 'https://i.pravatar.cc/190?img=12',

    recommendations = [
        {
            name: 'Hian',
            sub: 'Liked recently',
            avatar: 'https://i.pravatar.cc/95?img=47'
        },
        {
            name: 'MsB',
            sub: 'Viral',
            avatar: 'https://i.pravatar.cc/95?img=32',
            verified: true
        },
        {
            name: 'Xia',
            sub: 'Trending',
            avatar: 'https://i.pravatar.cc/95?img=12'
        },
        {
            name: 'vicky',
            sub: 'Trending',
            avatar: 'https://i.pravatar.cc/95?img=44'
        },
        {
            name: 'i',
            sub: 'Followers',
            avatar: 'https://i.pravatar.cc/95?img=5'
        }
    ]
} = {}) => {
    const canvas = createCanvas(W, H)
    const ctx = canvas.getContext('2d')

    // ==========================
    // DRAW HELPERS
    // ==========================

    const font = (size, weight = 500) =>
        `${weight} ${size}px "Roboto", "Noto CJK", Arial, sans-serif`

    const text = (
        value,
        x,
        y,
        size,
        color = WHITE,
        weight = 500,
        align = 'left'
    ) => {
        ctx.font = font(size, weight)
        ctx.fillStyle = color
        ctx.textAlign = align
        ctx.textBaseline = 'alphabetic'
        ctx.fillText(String(value ?? ''), x, y)
    }

    const roundedRect = (
        x,
        y,
        width,
        height,
        radius,
        fill,
        border = null,
        borderWidth = 1
    ) => {
        ctx.beginPath()
        ctx.roundRect(x, y, width, height, radius)

        if (fill) {
            ctx.fillStyle = fill
            ctx.fill()
        }

        if (border) {
            ctx.strokeStyle = border
            ctx.lineWidth = borderWidth
            ctx.stroke()
        }
    }

    const lineStyle = (color = WHITE, width = 4) => {
        ctx.strokeStyle = color
        ctx.lineWidth = width
        ctx.lineCap = 'round'
        ctx.lineJoin = 'round'
    }

    // ==========================
    // BACKGROUND
    // ==========================

    ctx.fillStyle = BG
    ctx.fillRect(0, 0, W, H)

    // ==========================
    // HEADER
    // ==========================

    // Menu
    lineStyle(WHITE, 4)

    for (const y of [21, 35, 49]) {
        ctx.beginPath()
        ctx.moveTo(43, y)
        ctx.lineTo(81, y)
        ctx.stroke()
    }

    // Edit profile button
    roundedRect(
        623,
        9,
        255,
        61,
        34,
        'rgba(220,218,214,.34)'
    )

    lineStyle(WHITE, 4)

    ctx.beginPath()
    ctx.moveTo(653, 49)
    ctx.lineTo(675, 26)
    ctx.lineTo(681, 31)
    ctx.lineTo(660, 54)
    ctx.lineTo(650, 56)
    ctx.closePath()
    ctx.stroke()

    text('Edit Profile', 695, 49, 31, WHITE, 500)

    // Header icons
    lineStyle(WHITE, 4)

    ctx.beginPath()
    ctx.roundRect(913, 20, 40, 37, 9)
    ctx.moveTo(907, 29)
    ctx.lineTo(907, 49)
    ctx.moveTo(959, 29)
    ctx.lineTo(959, 49)
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(994, 21)
    ctx.lineTo(1028, 47)
    ctx.lineTo(1007, 53)
    ctx.stroke()

    ctx.beginPath()
    ctx.moveTo(994, 21)
    ctx.lineTo(995, 45)
    ctx.lineTo(1016, 37)
    ctx.stroke()

    // ==========================
    // MAIN AVATAR
    // ==========================

    const avatar = await loadImageInput(avatarInput, 15000)

    const avatarX = 130
    const avatarY = 213
    const avatarRadius = 95

    ctx.save()

    ctx.beginPath()
    ctx.arc(
        avatarX,
        avatarY,
        avatarRadius,
        0,
        Math.PI * 2
    )
    ctx.clip()

    if (avatar) {
        const ratio = avatar.width / avatar.height

        const drawWidth =
            ratio > 1
                ? avatarRadius * 2 * ratio
                : avatarRadius * 2

        const drawHeight =
            ratio > 1
                ? avatarRadius * 2
                : avatarRadius * 2 / ratio

        ctx.drawImage(
            avatar,
            avatarX - drawWidth / 2,
            avatarY - drawHeight / 2,
            drawWidth,
            drawHeight
        )
    } else {
        ctx.fillStyle = '#8b8679'

        ctx.fillRect(
            avatarX - avatarRadius,
            avatarY - avatarRadius,
            avatarRadius * 2,
            avatarRadius * 2
        )

        text(
            String(name || 'U')[0].toUpperCase(),
            avatarX,
            avatarY + 35,
            90,
            WHITE,
            500,
            'center'
        )
    }

    ctx.restore()

    lineStyle(WHITE, 1)

    ctx.beginPath()
    ctx.arc(
        avatarX,
        avatarY,
        avatarRadius,
        0,
        Math.PI * 2
    )
    ctx.stroke()

    // ==========================
    // PROFILE INFORMATION
    // ==========================

    text(
        String(name).slice(0, 24),
        267,
        201,
        43,
        WHITE,
        500
    )

    text(
        `rednote ID: ${id}`,
        267,
        263,
        28,
        SOFT,
        500
    )

    // QR glyph
    lineStyle(SOFT, 2)

    for (const [x, y] of [
        [615, 246],
        [626, 246],
        [615, 257],
        [626, 257]
    ]) {
        ctx.strokeRect(x, y, 7, 7)
    }

    // ==========================
    // STATISTICS
    // ==========================

    const stat = (
        value,
        label,
        startX,
        maxWidth
    ) => {
        const valueText = String(value ?? '0')
        const gap = 10

        let size = 37

        while (size > 28) {
            ctx.font = font(size, 500)

            const valueWidth = ctx.measureText(valueText).width
            const labelWidth = ctx.measureText(label).width

            if (valueWidth + gap + labelWidth <= maxWidth) {
                break
            }

            size--
        }

        ctx.font = font(size, 500)

        const valueWidth =
            ctx.measureText(valueText).width

        text(
            valueText,
            startX,
            393,
            size,
            WHITE,
            500
        )

        text(
            label,
            startX + valueWidth + gap,
            393,
            size,
            WHITE,
            500
        )
    }

    stat(
        formatCount(following),
        'Following',
        39,
        200
    )

    stat(
        formatCount(followers),
        'Followers',
        251,
        200
    )

    stat(
        formatCount(likes),
        'Likes & Saves',
        461,
        290
    )

    text(
        String(
            bio || 'Tap here to fill in your bio'
        ).slice(0, 55),
        38,
        457,
        31,
        WHITE,
        500
    )

    // ==========================
    // HISTORY & WALLET
    // ==========================

    roundedRect(
        28,
        508,
        502,
        114,
        19,
        CARD
    )

    roundedRect(
        548,
        508,
        502,
        114,
        19,
        CARD
    )

    // History icon
    lineStyle(WHITE, 3)

    ctx.beginPath()
    ctx.arc(76, 550, 15, 0, Math.PI * 2)

    ctx.moveTo(76, 539)
    ctx.lineTo(76, 551)
    ctx.lineTo(84, 557)

    ctx.moveTo(91, 542)
    ctx.lineTo(96, 542)
    ctx.lineTo(96, 548)

    ctx.stroke()

    text(
        'History',
        104,
        560,
        29,
        WHITE,
        500
    )

    text(
        '看过的笔记',
        57,
        597,
        22,
        SOFT,
        500
    )

    // Wallet icon
    lineStyle(WHITE, 3)

    ctx.beginPath()
    ctx.roundRect(580, 536, 31, 23, 6)
    ctx.arc(603, 547, 4, 0, Math.PI * 2)
    ctx.stroke()

    text(
        'Wallet',
        625,
        560,
        29,
        WHITE,
        500
    )

    text(
        '查看详情',
        577,
        597,
        22,
        SOFT,
        500
    )

    // ==========================
    // RECOMMENDATION PANEL
    // ==========================

    const panelX = 28
    const panelY = 641
    const panelW = 1024
    const panelH = 439

    roundedRect(
        panelX,
        panelY,
        panelW,
        panelH,
        20,
        'rgba(188,182,161,.30)'
    )

    text(
        'Recommended for You',
        57,
        699,
        30,
        WHITE,
        500
    )

    // Info icon
    lineStyle(SOFT, 3)

    ctx.beginPath()
    ctx.arc(402, 690, 11, 0, Math.PI * 2)
    ctx.stroke()

    text(
        'i',
        402,
        695,
        15,
        SOFT,
        500,
        'center'
    )

    // Close icon
    lineStyle(SOFT, 3)

    ctx.beginPath()
    ctx.moveTo(999, 682)
    ctx.lineTo(1017, 701)
    ctx.moveTo(1017, 682)
    ctx.lineTo(999, 701)
    ctx.stroke()

    // ==========================
    // CAROUSEL
    // ==========================

    ctx.save()

    ctx.beginPath()
    ctx.roundRect(
        panelX,
        panelY,
        panelW,
        panelH,
        20
    )
    ctx.clip()

    const startX = 54
    const columnWidth = 236

    const items = [...recommendations]

    while (items.length < 5) {
        items.push({
            name: '',
            sub: '',
            avatar: null
        })
    }

    for (let i = 0; i < Math.min(items.length, 5); i++) {
        const item = items[i]

        const positionX =
            startX + i * columnWidth

        const centerX =
            positionX + 74

        // Recommendation avatar
        const image = await loadImageInput(
            item.avatar
        )

        ctx.save()

        ctx.beginPath()
        ctx.arc(
            centerX,
            786,
            47,
            0,
            Math.PI * 2
        )
        ctx.clip()

        if (image) {
            ctx.drawImage(
                image,
                centerX - 47,
                739,
                94,
                94
            )
        } else if (avatar) {
            const ratio =
                avatar.width / avatar.height

            const drawWidth =
                ratio > 1
                    ? 94 * ratio
                    : 94

            const drawHeight =
                ratio > 1
                    ? 94
                    : 94 / ratio

            ctx.drawImage(
                avatar,
                centerX - drawWidth / 2,
                786 - drawHeight / 2,
                drawWidth,
                drawHeight
            )
        } else {
            ctx.fillStyle = '#9e9a8c'

            ctx.fillRect(
                centerX - 47,
                739,
                94,
                94
            )
        }

        ctx.restore()

        // Name
        const label =
            String(item.name || '').slice(0, 16)

        text(
            label,
            centerX,
            897,
            25,
            WHITE,
            500,
            'center'
        )

        // Verified badge
        if (item.verified) {
            ctx.fillStyle = PINK

            ctx.beginPath()
            ctx.arc(
                centerX + 52,
                889,
                14,
                0,
                Math.PI * 2
            )
            ctx.fill()

            text(
                '✓',
                centerX + 52,
                895,
                18,
                WHITE,
                500,
                'center'
            )
        }

        // Subtitle
        text(
            String(item.sub || '').slice(0, 19),
            centerX,
            946,
            22,
            SOFT,
            500,
            'center'
        )

        // Follow button
        roundedRect(
            centerX - 61,
            982,
            122,
            57,
            30,
            PINK
        )

        text(
            'Follow',
            centerX,
            1019,
            24,
            WHITE,
            500,
            'center'
        )

        // Divider
        if (i < 4) {
            ctx.fillStyle =
                'rgba(235,230,217,.18)'

            ctx.fillRect(
                positionX + 234,
                829,
                1,
                190
            )
        }
    }

    ctx.restore()

    return canvas.toBuffer('image/png')
}

// ==============================
// HANDLER
// ==============================

const handler = async (
    m,
    {
        conn,
        text,
        usedPrefix,
        command
    }
) => {
    try {
        const quoted = m.quoted || m
        const mime =
            (quoted.msg || quoted).mimetype || ''

        // ==========================
        // USAGE
        // ==========================

        if (!text) {
            return m.reply(
                `*Format:*
${usedPrefix + command} name | id | following | followers | likes | bio | url_avatar

*Contoh:*
${usedPrefix + command} avosky md | 63818449066 | 0 | 0 | 0 | Tap here to fill in your bio`
            )
        }

        // ==========================
        // PROCESS REACTION
        // ==========================

        await conn.sendMessage(
            m.chat,
            {
                react: {
                    text: '⏳',
                    key: m.key
                }
            }
        )

        // ==========================
        // PARSE ARGUMENTS
        // ==========================

        const args = text
            .split('|')
            .map(value => value.trim())

        const [
            name,
            id,
            following,
            followers,
            likes,
            bio,
            url
        ] = args

        if (
            !name ||
            !id ||
            following === undefined ||
            followers === undefined ||
            likes === undefined
        ) {
            throw `🍂 *Format tidak valid!*

${usedPrefix + command} name | id | following | followers | likes | bio`
        }

        // ==========================
        // AVATAR
        // ==========================

        let avatarInput = null

        if (
            url &&
            /^https?:\/\//i.test(url)
        ) {
            avatarInput = url
        }

        if (
            !avatarInput &&
            mime.startsWith('image/')
        ) {
            avatarInput = await quoted.download()
        }

        // ==========================
        // GENERATE IMAGE
        // ==========================

        const image = await makeFakeRednote({
            name,
            id,
            following,
            followers,
            likes,
            bio:
                bio ||
                'Tap here to fill in your bio',
            avatarInput
        })

        // ==========================
        // SEND RESULT
        // ==========================

        await conn.sendMessage(
            m.chat,
            {
                image,
                caption:
                    `*RedNote Profile Created*\n\n` +
                    `• *Name:* ${name}\n` +
                    `• *ID:* ${id}\n` +
                    `• *Following:* ${formatCount(following)}\n` +
                    `• *Followers:* ${formatCount(followers)}\n` +
                    `• *Likes & Saves:* ${formatCount(likes)}`
            },
            {
                quoted: m
            }
        )
    } catch (error) {
        console.error(
            'FAKEREDNOTE ERROR:',
            error
        )

        await m.reply(
            typeof error === 'string'
                ? error
                : '🍂 *Terjadi kesalahan saat membuat fake RedNote profile.*'
        )
    } finally {
        try {
            await conn.sendMessage(
                m.chat,
                {
                    react: {
                        text: '',
                        key: m.key
                    }
                }
            )
        } catch {}
    }
}

// ==============================
// HANDLER CONFIG
// ==============================

handler.help = [
    'fakerednote',
    'fakenote'
]

handler.tags = ['maker']

handler.command =
    /^(fakerednote|fakenote)$/i

handler.limit = 10
handler.register = false

export default handler