import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import moment from 'moment-timezone'

class Config {
    constructor() {
        let wibh = moment.tz('Asia/Jakarta').format('HH')
        let wibm = moment.tz('Asia/Jakarta').format('mm')
        let wibs = moment.tz('Asia/Jakarta').format('ss')
        let wktuwib = `${wibh} H ${wibm} M ${wibs} S`
        let wktugeneral = `${wibh}:${wibm}:${wibs}`

        let d = new Date(new Date + 3600000)
        let locale = 'id'
        let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
        let week = d.toLocaleDateString(locale, { weekday: 'long' })
        let date = d.toLocaleDateString(locale, {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        })
        const more = String.fromCharCode(8206)
        const readMore = more.repeat(4001)

        global.pairing = '6285727726423'
        global.owner = [['628386484120', 'mrzkyzdnii', true]]
        global.mods = []
        global.prems = []
        global.nomorbot = '6285727726423'
        global.nomorown = '628386484120'
        global.nameown = 'kyyavos'
        global.version = '7'
        global.autotyping = false
        global.autorecording = false

        global.wait = 'tunggu'
        global.eror = 'rusak'

        global.readMore = readMore
        global.author = 'mrzkyzdnii.jpeg'
        global.namebot = 'mrzkyzdnii-F'
        global.wm = 'mrzkyzdnii-F'
        global.watermark = global.wm
        global.botdate = `⫹⫺ DATE: ${week} ${date}\n⫹⫺ 𝗧𝗶𝗺𝗲: ${wktuwib}`
        global.bottime = `T I M E : ${wktuwib}`
        global.stickpack = `mrzkyzdnii-F ✦\nPowered by ${global.namebot}\nwa.me/${global.nomorbot}`
        global.stickauth = `mrzkyzdnii.jpeg`
        global.week = `${week} ${date}`
        global.wibb = `${wktuwib}`

        global.linkch = ''
        global.chId = ''
        global.newsletterName = ''

        global.htki = '☾'
        global.htka = '☽'
        global.lopr = 'Ⓟ'
        global.lolm = 'Ⓛ'
        global.htjava = '⫹⫺'
        global.hsquere = ['⬢', '⬡', '⟁']

        global.flaaa2 = [
            "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=",
            "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=",
            "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=",
            "https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=",
            "https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text="
        ]

        global.fla = [
            "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=",
            "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=",
            "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=",
            "https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=",
            "https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text="
        ]

        global.rpg = {
            emoticon(string) {
                string = string.toLowerCase()
                let emot = {
                    level: '🧬',
                    limit: '🌌',
                    health: '❤️',
                    exp: '✉️',
                    money: '💵',
                    potion: '🥤',
                    diamond: '💎',
                    common: '📦',
                    uncommon: '🎁',
                    mythic: '🗳️',
                    legendary: '🗃️',
                    pet: '🎁',
                    trash: '🗑',
                    armor: '🥼',
                    sword: '⚔️',
                    pickaxe: '⛏️',
                    fishingrod: '🎣',
                    bow: '🏹',
                    wood: '🪵',
                    rock: '🪨',
                    string: '🕸️',
                    horse: '🐎',
                    cat: '🐈',
                    dog: '🐕',
                    fox: '🦊',
                    wolf: '🐺',
                    centaur: '🐎',
                    phoenix: '🦜',
                    dragon: '🐉',
                    petfood: '🍖',
                    iron: '⛓️',
                    gold: '👑',
                    emerald: '💚',
                    bibitmangga: '🌾',
                    bibitanggur: '🌾',
                    bibitjeruk: '🌾',
                    bibitpisang: '🌾',
                    bibitapel: '🌾',
                    mangga: '🥭',
                    anggur: '🍇',
                    jeruk: '🍊',
                    pisang: '🍌',
                    apel: '🍎',
                    ayam: '🐔',
                    kambing: '🐐',
                    sapi: '🐄',
                    kerbau: '🐃',
                    babi: '🐖',
                    harimau: '🐅',
                    banteng: '🐂',
                    monyet: '🐒',
                    babihutan: '🐗',
                    panda: '🐼',
                    gajah: '🐘',
                    buaya: '🐊',
                    orca: '🐋',
                    paus: '🐳',
                    lumba: '🐬',
                    hiu: '🦈',
                    ikan: '🐟',
                    lele: '🐟',
                    bawal: '🐡',
                    nila: '🐠',
                    kepiting: '🦀',
                    lobster: '🦞',
                    gurita: '🐙',
                    cumi: '🦑',
                    udang: '🦐',
                    steak: '🍝',
                    sate: '🍢',
                    rendang: '🍜',
                    kornet: '🥣',
                    nugget: '🍱',
                    bluefin: '🍲',
                    seafood: '🍛',
                    sushi: '🍣',
                    moluska: '🥘',
                    squidprawm: '🍤',
                    rumahsakit: '🏥',
                    restoran: '🏭',
                    pabrik: '🏯',
                    tambang: '⚒️',
                    pelabuhan: '🛳️'
                }

                let results = Object.keys(emot)
                    .map(v => [v, new RegExp(v, 'gi')])
                    .filter(v => v[1].test(string))

                if (!results.length) return ''
                else return emot[results[0][0]]
            }
        }

        this.setupWatcher()
    }

    setupWatcher() {
        let file = fileURLToPath(import.meta.url)

        watchFile(file, () => {
            unwatchFile(file)
            console.log(chalk.redBright("Update 'config.js'"))
            import(`${file}?update=${Date.now()}`)
        })
    }
}

export default new Config()