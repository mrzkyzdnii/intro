import os
import glob
import json
import shutil
import tarfile
import subprocess
import threading
import time
import telebot
from telebot import types

# --- KONFIGURASI BOT ---
BOT_TOKEN = "8701334770:AAHkbYV6i5FGvsO7NxixqPQi9yEQUZRce58"
OWNER_ID = "8423519124"  # Owner Utama (Target tombol Chat Owner)
ADMIN_IDS = ["8423519124", "6011858838", "1577396317"] # Akses Panel Admin

bot = telebot.TeleBot(BOT_TOKEN)

# Direktori Penyimpanan Session WA & Database
SESSIONS_DIR = "./sessions"
USED_DB_FILE = "./used_sessions.json"
os.makedirs(SESSIONS_DIR, exist_ok=True)

# Database In-Memory
user_balances = {
    "8423519124": 1000000,
    "6011858838": 1000000
}
active_orders = {}

# Tracking Proses Node.js per Sesi untuk Mencegah Bentrok
running_processes = {}
process_lock = threading.Lock()

def stop_session_process(session_id):
    """Mematikan skrip Node.js lama jika sesi tersebut sedang berjalan"""
    with process_lock:
        if session_id in running_processes:
            proc = running_processes[session_id]
            try:
                proc.terminate()
                proc.wait(timeout=3)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            del running_processes[session_id]

# --- FUNGSI DATABASE SESI PER APLIKASI ---
def load_used_sessions():
    if os.path.exists(USED_DB_FILE):
        try:
            with open(USED_DB_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def save_used_session(session_id, app_name):
    data = load_used_sessions()
    app_key = app_name.lower().strip()
    if session_id not in data:
        data[session_id] = []
    if app_key not in data[session_id]:
        data[session_id].append(app_key)
    with open(USED_DB_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def is_session_used_for_app(session_id, app_name):
    data = load_used_sessions()
    app_key = app_name.lower().strip()
    if session_id in data:
        return app_key in data[session_id]
    return False

def get_available_wa_sessions_for_app(app_name):
    sessions = []
    if os.path.exists(SESSIONS_DIR):
        for item in os.listdir(SESSIONS_DIR):
            folder_path = os.path.join(SESSIONS_DIR, item)
            if os.path.isdir(folder_path):
                if not is_session_used_for_app(item, app_name):
                    sessions.append(item)
    return sessions

def get_all_sessions():
    sessions = []
    if os.path.exists(SESSIONS_DIR):
        for item in os.listdir(SESSIONS_DIR):
            folder_path = os.path.join(SESSIONS_DIR, item)
            if os.path.isdir(folder_path):
                sessions.append(item)
    return sessions

def get_balance(user_id):
    return user_balances.get(str(user_id), 0)

def set_balance(user_id, amount):
    user_balances[str(user_id)] = amount

def is_admin(user_id):
    return str(user_id) in ADMIN_IDS

# --- KATA KUNCI VALIDASI APLIKASI (PROTEKSI ANTI-CURANG) ---
APP_KEYWORDS = {
    "shopee": ["shopee"],
    "shopee + shopeepay": ["shopee"],
    "dana": ["dana"],
    "gojek": ["gojek", "goba"],
    "gopay": ["gopay", "gojek"],
    "ovo": ["ovo"],
    "ovograb": ["ovo", "grab"],
    "lazada": ["lazada"],
    "tokopedia": ["tokopedia", "tokped"],
    "facebook": ["facebook", "fb"],
    "tiktok": ["tiktok"],
    "telegram": ["telegram"],
    "whatsapp": ["whatsapp"]
}

def validate_otp_content(app_name, full_text):
    app_key = app_name.lower().strip()
    if app_key not in APP_KEYWORDS:
        return True
    
    keywords = APP_KEYWORDS[app_key]
    text_lower = full_text.lower()
    for kw in keywords:
        if kw in text_lower:
            return True
    return False

# --- KEYBOARD MENU UTAMA USER ---
def user_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    btn_wa = types.InlineKeyboardButton("📱 OTP Via WA", callback_data="otp_wa")
    btn_depo = types.InlineKeyboardButton("💳 Deposit Saldo", callback_data="deposit")
    btn_profile = types.InlineKeyboardButton("👤 Profil Saya", callback_data="profile")
    btn_help = types.InlineKeyboardButton("❓ Help OTP", callback_data="help")
    btn_ref = types.InlineKeyboardButton("🎁 Referral 5%", callback_data="referral")
    btn_owner = types.InlineKeyboardButton("💬 Chat Owner", url=f"tg://user?id={OWNER_ID}")

    markup.add(btn_wa, btn_depo)
    markup.add(btn_profile, btn_help)
    markup.add(btn_ref)
    markup.add(btn_owner)
    return markup

# --- KEYBOARD MENU ADMIN ---
def admin_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    btn_wa = types.InlineKeyboardButton("📱 OTP Via WA (Test)", callback_data="otp_wa")
    btn_profile = types.InlineKeyboardButton("👤 Profil Admin", callback_data="profile")
    btn_add_saldo = types.InlineKeyboardButton("➕ Tambah Saldo User", callback_data="admin_add_saldo")
    btn_stok = types.InlineKeyboardButton("📦 Stok WA Aktif", callback_data="admin_stok")
    btn_sortir = types.InlineKeyboardButton("🔍 Sortir / Cek Status WA", callback_data="admin_check_wa")
    btn_targz = types.InlineKeyboardButton("📁 Upload Targz WA", callback_data="targz_menu")
    btn_pair = types.InlineKeyboardButton("🔗 Tautkan WA Baru", callback_data="pair_wa")

    markup.add(btn_wa, btn_profile)
    markup.add(btn_add_saldo, btn_stok)
    markup.add(btn_sortir)
    markup.add(btn_targz, btn_pair)
    return markup

# --- KEYBOARD DAFTAR APLIKASI ---
def app_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    apps = [
        "Alfa gift", "Allobank", "Baby Happy", "Bilibili", "CGV", "Dana",
        "Douyin", "Evmoto", "Facebook", "Fore", "Gojek", "Gopay",
        "Janji jiwa", "KFC", "Kopken", "Kopken filter", "Kpoint", "Kuaisho",
        "Lainnya", "Lazada", "Motoran", "Ovo", "Ovograb", "Qpoon",
        "Rednote", "Royal dream", "Shopee", "Shopee + Shopeepay", "Slot",
        "Susu", "Tiket", "Tiktok", "Tokopedia", "Wingstore"
    ]
    buttons = [types.InlineKeyboardButton(app, callback_data=f"order_{app}") for app in apps]
    markup.add(*buttons)
    markup.add(types.InlineKeyboardButton("⬅ Kembali", callback_data="back_main"))
    return markup

# --- KEYBOARD DEPOSIT ---
def deposit_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=2)
    nominals = [2000, 5000, 10000, 20000, 50000, 100000]
    buttons = [types.InlineKeyboardButton(f"Rp {n:,}".replace(",", "."), callback_data=f"depo_{n}") for n in nominals]
    markup.add(*buttons)
    markup.add(types.InlineKeyboardButton("🔙 Kembali ke Menu", callback_data="back_main"))
    return markup

# --- PROSES CHECK / SORTIR STATUS SESSION WA ---
def run_wa_check_process(chat_id, message_id):
    sessions = get_all_sessions()
    if not sessions:
        bot.edit_message_text("❌ Tidak ada stok session WA untuk diproses.", chat_id, message_id)
        return

    bot.edit_message_text(f"⏳ **Sedang memeriksa {len(sessions)} stok WA...**\nMohon tunggu beberapa saat.", chat_id, message_id, parse_mode="Markdown")

    normal_list, banned_list, off_list = [], [], []

    def process_check():
        for sess in sessions:
            stop_session_process(sess)  # Matikan proses berjalan sebelum pengecekan
            cmd = ["node", "wa_engine.js", "check", sess]
            try:
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
                output = result.stdout.strip()

                status = "OFF"
                for line in output.split("\n"):
                    if "CHECK_RESULT:" in line:
                        status = line.split(":")[-1].strip()

                if status == "NORMAL":
                    normal_list.append(sess)
                elif status == "BANNED":
                    banned_list.append(sess)
                else:
                    off_list.append(sess)
            except Exception:
                off_list.append(sess)

        res_text = (
            f"📊 **HASIL SORTIR & CEK STATUS WA**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🟢 **NORMAL / AKTIF ({len(normal_list)}):**\n"
        )
        for s in normal_list:
            res_text += f"• `{s}`\n"
        if not normal_list:
            res_text += "_Tidak ada_\n"

        res_text += f"\n🔴 **BANNED ({len(banned_list)}):**\n"
        for s in banned_list:
            res_text += f"• `{s}`\n"
        if not banned_list:
            res_text += "_Tidak ada_\n"

        res_text += f"\n⚪ **OFF / LOGGED OUT ({len(off_list)}):**\n"
        for s in off_list:
            res_text += f"• `{s}`\n"
        if not off_list:
            res_text += "_Tidak ada_\n"

        res_text += "━━━━━━━━━━━━━━━━━━━━━━"

        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Kembali", callback_data="back_main"))

        bot.edit_message_text(res_text, chat_id, message_id, parse_mode="Markdown", reply_markup=markup)

    threading.Thread(target=process_check, daemon=True).start()

# --- PROSES REQUEST PAIRING CODE ---
def request_wa_pairing_code(chat_id, user_id, phone_number):
    session_id = f"wa_{phone_number}"
    stop_session_process(session_id)
    
    bot.send_message(chat_id, f"⏳ Sedang meminta Kode Pairing untuk nomor `{phone_number}`...", parse_mode="Markdown")

    cmd = ["node", "wa_engine.js", "pair", session_id, phone_number]
    process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    def monitor_pairing():
        for line in iter(process.stdout.readline, ''):
            line = line.strip()
            if "PAIRING_CODE:" in line:
                code = line.split("PAIRING_CODE:")[1]
                formatted_code = f"{code[:4]}-{code[4:]}" if len(code) == 8 else code
                bot.send_message(
                    chat_id,
                    f"✅ **KODE PAIRING PERANGKAT TERTAUT**\n\n"
                    f"Kode Anda: `{formatted_code}`\n\n"
                    f"👉 **Cara Menautkan:**\n"
                    f"1. Buka aplikasi WhatsApp di HP Anda.\n"
                    f"2. Klik titik 3 di kanan atas -> **Perangkat Tertaut**.\n"
                    f"3. Pilih **Tautkan Perangkat** -> **Tautkan dengan nomor telepon saja**.\n"
                    f"4. Masukkan kode di atas.",
                    parse_mode="Markdown"
                )
                break
            elif "ERROR:" in line:
                bot.send_message(chat_id, f"❌ Gagal meminta kode: {line.split('ERROR:')[1]}")
                break

    threading.Thread(target=monitor_pairing, daemon=True).start()

# --- PEMANTAUAN OTP REAL-TIME ---
def start_wa_monitoring_for_order(user_id, chat_id, session_id, app_name):
    # Hentikan proses lama pada nomor ini jika ada
    stop_session_process(session_id)

    cmd = ["node", "wa_engine.js", "start", session_id]
    process = subprocess.Popen(
        cmd, 
        stdout=subprocess.PIPE, 
        stderr=subprocess.PIPE, 
        text=True, 
        bufsize=1
    )

    with process_lock:
        running_processes[session_id] = process

    def listen_stdout():
        for line in iter(process.stdout.readline, ''):
            line = line.strip()
            if "OTP_DETECTED" in line:
                parts = line.split("|")
                if len(parts) >= 5:
                    detected_session = parts[1]
                    sender = parts[2].split("@")[0]
                    otp_code = parts[3]
                    full_text = parts[4]

                    if user_id in active_orders and active_orders[user_id]["session_id"] == detected_session:
                        # PROTEKSI ANTI-CURANG
                        if not validate_otp_content(app_name, full_text):
                            print(f"[PROTEKSI] Mencegah OTP curang untuk {app_name}. Teks: {full_text}")
                            continue

                        # KIRIM OTP KEPADA USER
                        msg_text = (
                            f"🎉 **KODE OTP BERHASIL DITERIMA!**\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━\n"
                            f"📱 **Aplikasi:** {app_name}\n"
                            f"🔑 **Kode OTP:** `{otp_code}`\n"
                            f"👤 **Pengirim:** `{sender}`\n\n"
                            f"📄 **Pesan Lengkap:**\n_{full_text}_\n"
                            f"━━━━━━━━━━━━━━━━━━━━━━"
                        )
                        bot.send_message(chat_id, msg_text, parse_mode="Markdown")

                        # SIMPAN REKAP SESI TERPAKAI PER APLIKASI
                        save_used_session(detected_session, app_name)

                        del active_orders[user_id]
                        stop_session_process(detected_session)
                        break

    threading.Thread(target=listen_stdout, daemon=True).start()

# ==================== HANDLER COMMANDS ====================

@bot.message_handler(commands=['start', 'menu'])
def cmd_start(message):
    uid = str(message.from_user.id)
    if is_admin(uid):
        text = (
            "👑 **PANEL UTAMA ADMIN**\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "Halo Admin! Anda dapat mengelola stok WhatsApp, menambah saldo, mengunggah session, dan mengecek status WA di sini."
        )
        bot.send_message(message.chat.id, text, parse_mode="Markdown", reply_markup=admin_keyboard())
    else:
        text = (
            "✨ Keyboard menu siap digunakan di bawah.\n\n"
            "✦ **LAYANAN OTP ONLINE** ✦\n"
            "Silakan pilih layanan di bawah ini:"
        )
        bot.send_message(message.chat.id, text, parse_mode="Markdown", reply_markup=user_keyboard())

@bot.message_handler(commands=['profile', 'profil'])
def cmd_profile(message):
    uid = str(message.from_user.id)
    saldo = get_balance(uid)
    username = f"@{message.from_user.username}" if message.from_user.username else message.from_user.first_name
    text = (
        "👤 **PROFIL PENGGUNA**\n"
        "━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🆔 **ID Telegram:** `{uid}`\n"
        f"👤 **Nama/User:** {username}\n"
        f"💰 **Saldo Aktif:** Rp {saldo:,}\n"
        "━━━━━━━━━━━━━━━━━━━━━━"
    ).replace(",", ".")
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 Kembali", callback_data="back_main"))
    bot.send_message(message.chat.id, text, parse_mode="Markdown", reply_markup=markup)

@bot.message_handler(commands=['deposit', 'depo'])
def cmd_deposit(message):
    uid = str(message.from_user.id)
    saldo = get_balance(uid)
    text = (
        "✦ **DEPOSIT SALDO OTOMATIS** ✦\n\n"
        f"💰 **Saldo Saat Ini:** Rp {saldo:,}\n"
        "💳 **Metode:** QRIS Dinamis (All Payment)\n"
        "Pilih nominal deposit di bawah ini:"
    ).replace(",", ".")
    bot.send_message(message.chat.id, text, parse_mode="Markdown", reply_markup=deposit_keyboard())

@bot.message_handler(commands=['addsaldo'])
def cmd_add_saldo_admin(message):
    if not is_admin(message.from_user.id):
        return
    try:
        args = message.text.split()
        target_id = args[1]
        amount = int(args[2])
        current = get_balance(target_id)
        set_balance(target_id, current + amount)
        bot.reply_to(message, f"✅ Saldo user `{target_id}` berhasil ditambah **Rp {amount:,}**!".replace(",", "."), parse_mode="Markdown")
        bot.send_message(target_id, f"🎉 Saldo Anda telah ditambahkan oleh Admin sebesar **Rp {amount:,}**!".replace(",", "."), parse_mode="Markdown")
    except Exception:
        bot.reply_to(message, "⚠️ Format salah! Gunakan: `/addsaldo <id_user> <nominal>`", parse_mode="Markdown")

# ==================== HANDLER UPLOAD TARGZ ====================

@bot.message_handler(content_types=['document'])
def handle_targz_upload(message):
    uid = str(message.from_user.id)
    if not is_admin(uid):
        bot.reply_to(message, "⚠️ Hanya Admin yang dapat mengunggah stok session `.tar.gz`!")
        return

    file_name = message.document.file_name
    if file_name.endswith('.tar.gz') or file_name.endswith('.tgz') or file_name.endswith('.gz'):
        msg = bot.reply_to(message, "⏳ Mengunduh dan mengekstrak file `.tar.gz` session...")
        
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)
        
        session_name = file_name.split('.')[0]
        target_dir = os.path.join(SESSIONS_DIR, session_name)
        os.makedirs(target_dir, exist_ok=True)
        
        tar_path = f"./temp_{session_name}.tar.gz"
        with open(tar_path, 'wb') as f:
            f.write(downloaded_file)
            
        try:
            with tarfile.open(tar_path, "r:gz") as tar:
                tar.extractall(path=target_dir)
            os.remove(tar_path)
            bot.edit_message_text(f"✅ **Stok WA Session `{session_name}` Berhasil Ditambahkan!**", message.chat.id, msg.message_id, parse_mode="Markdown")
        except Exception as e:
            bot.edit_message_text(f"❌ Gagal mengekstrak: {str(e)}", message.chat.id, msg.message_id)
    else:
        bot.reply_to(message, "⚠️ Mohon kirimkan file dengan ekstensi `.tar.gz`!")

# ==================== HANDLER CALLBACK QUERY ====================

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    uid = str(call.from_user.id)
    bot.answer_callback_query(call.id)

    if call.data == "back_main":
        kb = admin_keyboard() if is_admin(uid) else user_keyboard()
        bot.edit_message_text("✦ **LAYANAN OTP ONLINE** ✦\nSilakan pilih layanan di bawah ini:", call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=kb)

    elif call.data == "otp_wa":
        bot.edit_message_text("📱 **PILIH APLIKASI (SERVER WA)**\n\nSilakan pilih aplikasi yang ingin dipesan:", call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=app_keyboard())

    elif call.data == "deposit":
        saldo = get_balance(uid)
        text = f"✦ **DEPOSIT SALDO OTOMATIS** ✦\n\n💰 **Saldo Saat Ini:** Rp {saldo:,}\n💳 **Metode:** QRIS Dinamis\n\nPilih nominal deposit di bawah ini:".replace(",", ".")
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=deposit_keyboard())

    elif call.data == "profile":
        saldo = get_balance(uid)
        text = f"👤 **PROFIL PENGGUNA**\n━━━━━━━━━━━━━━━━━━━━━━\n🆔 **ID:** `{uid}`\n💰 **Saldo:** Rp {saldo:,}\n━━━━━━━━━━━━━━━━━━━━━━".replace(",", ".")
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Kembali", callback_data="back_main"))
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)

    elif call.data == "admin_stok":
        sessions = get_all_sessions()
        text = f"📦 **STOK WA AKTIF DI SERVER**\n━━━━━━━━━━━━━━━━━━━━━━\nTotal Sesi Siap Dipakai: **{len(sessions)}**\n"
        for s in sessions:
            text += f"• `{s}`\n"
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Kembali", callback_data="back_main"))
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)

    elif call.data == "admin_add_saldo":
        bot.send_message(call.message.chat.id, "Gunakan perintah berikut untuk menambah saldo user:\n`/addsaldo <id_user> <nominal>`\nContoh: `/addsaldo 8423519124 50000`", parse_mode="Markdown")

    elif call.data == "admin_check_wa":
        if not is_admin(uid):
            return
        run_wa_check_process(call.message.chat.id, call.message.message_id)

    elif call.data == "targz_menu":
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔙 Kembali", callback_data="back_main"))
        text = (
            "📁 **UPLOAD TARGZ WA (STOK SESSION)**\n"
            "━━━━━━━━━━━━━━━━━━━━━━\n"
            "Silakan **kirimkan file dokumen `.tar.gz`** Anda langsung ke chat ini.\n"
            "Bot akan otomatis mengunduh dan mengekstraknya sebagai stok session baru."
        )
        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown", reply_markup=markup)

    elif call.data == "pair_wa":
        msg = bot.send_message(
            call.message.chat.id,
            "🔗 **TAUTKAN WA BARU (PAIRING CODE)**\n\n"
            "Silakan ketik/kirimkan **nomor WhatsApp** yang ingin ditautkan (awali dengan kode negara, contoh: `6281234567890`):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(msg, process_pair_input)

    elif call.data.startswith("order_"):
        app_name = call.data.replace("order_", "")
        price = 2000
        saldo = get_balance(uid)

        if saldo < price:
            bot.send_message(call.message.chat.id, "❌ Saldo Anda tidak cukup! Silakan isi saldo terlebih dahulu.")
            return

        sessions = get_available_wa_sessions_for_app(app_name)
        if not sessions:
            bot.send_message(call.message.chat.id, f"❌ Stok nomor WA untuk aplikasi **{app_name}** sedang habis/sudah terpakai semua. Hubungi Admin!")
            return

        selected_session = sessions[0]
        set_balance(uid, saldo - price)
        active_orders[uid] = {"app": app_name, "session_id": selected_session}

        # Dapatkan nomor asli dari nama folder sesi jika ada (format: wa_085...)
        clean_num = selected_session.replace("wa_", "")
        if clean_num.startswith("08"):
            clean_num = "628" + clean_num[2:]

        text = (
            f"✅ **PESANAN BERHASIL PROSES**\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📱 **Aplikasi:** {app_name}\n"
            f"💰 **Biaya:** Rp {price:,}\n"
            f"📦 **Nomor WA:** `{clean_num}`\n"
            f"🆔 **Session ID:** `{selected_session}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👉 Masukkan nomor `{clean_num}` pada aplikasi **{app_name}** dan pastikan Anda memilih **Kirim OTP via WA**.\n"
            f"⏳ Bot sedang menunggu kode OTP masuk secara otomatis..."
        ).replace(",", ".")

        bot.edit_message_text(text, call.message.chat.id, call.message.message_id, parse_mode="Markdown")
        start_wa_monitoring_for_order(uid, call.message.chat.id, selected_session, app_name)

def process_pair_input(message):
    phone = message.text.strip().replace("+", "").replace("-", "")
    if not phone.isdigit():
        bot.reply_to(message, "❌ Format nomor tidak valid. Gunakan angka saja, contoh: `6281234567890`", parse_mode="Markdown")
        return
    request_wa_pairing_code(message.chat.id, message.from_user.id, phone)

if __name__ == "__main__":
    print("Bot Telegram OTP WhatsApp Berhasil Dijalankan...")
    bot.infinity_polling()