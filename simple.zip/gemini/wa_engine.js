const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, delay } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs');

const mode = process.argv[2];        // 'pair', 'start', atau 'check'
const sessionId = process.argv[3];   // ID/Folder Session
const extraParam = process.argv[4];  // Nomor HP (khusus mode pair)

if (!sessionId) {
    console.error("ERROR: Session ID required.");
    process.exit(1);
}

// EKSTRAKSI TEKS LENGKAP UNTUK SEMUA TIPE PESAN (WA BUSINESS, TEMPLATE, INTERACTIVE, BUTTONS)
function extractTextFromMessage(msg) {
    if (!msg || !msg.message) return '';
    const m = msg.message;

    if (m.conversation) return m.conversation;
    if (m.extendedTextMessage?.text) return m.extendedTextMessage.text;
    if (m.imageMessage?.caption) return m.imageMessage.caption;
    if (m.videoMessage?.caption) return m.videoMessage.caption;
    
    // Pesan Template WhatsApp Official (Tokopedia, DANA, Gojek, dll)
    if (m.templateMessage?.hydratedTemplate?.hydratedContentText) {
        return m.templateMessage.hydratedTemplate.hydratedContentText;
    }
    if (m.templateMessage?.hydratedFourRowTemplate?.hydratedContentText) {
        return m.templateMessage.hydratedFourRowTemplate.hydratedContentText;
    }
    if (m.interactiveMessage?.body?.text) {
        return m.interactiveMessage.body.text;
    }
    if (m.interactiveMessage?.header?.title) {
        return m.interactiveMessage.header.title;
    }
    if (m.buttonsResponseMessage?.selectedButtonId) {
        return m.buttonsResponseMessage.selectedButtonId;
    }
    if (m.listResponseMessage?.singleSelectReply?.selectedRowId) {
        return m.listResponseMessage.singleSelectReply.selectedRowId;
    }

    try {
        return JSON.stringify(m);
    } catch (e) {
        return '';
    }
}

async function startWA() {
    const sessionPath = `./sessions/${sessionId}`;
    if (!fs.existsSync(sessionPath)) {
        if (mode === 'check') {
            console.log(`CHECK_RESULT:${sessionId}:OFF`);
            process.exit(0);
        }
        fs.mkdirSync(sessionPath, { recursive: true });
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const sock = makeWASocket({
        auth: state,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        connectTimeoutMs: 20000,
        defaultQueryTimeoutMs: 20000,
        keepAliveIntervalMs: 15000,
        markOnlineOnConnect: true
    });

    sock.ev.on('creds.update', saveCreds);

    // MODE 1: CEK / SORTIR STATUS WA (ADMIN)
    if (mode === 'check') {
        let handled = false;
        const timeout = setTimeout(() => {
            if (!handled) {
                handled = true;
                console.log(`CHECK_RESULT:${sessionId}:OFF`);
                process.exit(0);
            }
        }, 12000);

        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === 'open') {
                if (!handled) {
                    handled = true;
                    clearTimeout(timeout);
                    console.log(`CHECK_RESULT:${sessionId}:NORMAL`);
                    try { await sock.ws.close(); } catch (e) {}
                    process.exit(0);
                }
            } else if (connection === 'close') {
                if (!handled) {
                    handled = true;
                    clearTimeout(timeout);
                    const statusCode = lastDisconnect?.error?.output?.statusCode;
                    const errMsg = (lastDisconnect?.error?.message || '').toLowerCase();

                    if (statusCode === 403 || errMsg.includes('banned') || errMsg.includes('403')) {
                        console.log(`CHECK_RESULT:${sessionId}:BANNED`);
                    } else {
                        console.log(`CHECK_RESULT:${sessionId}:OFF`);
                    }
                    process.exit(0);
                }
            }
        });
        return;
    }

    // MODE 2: PAIRING CODE (TAMBAH WA BARU)
    let pairRequested = false;
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;

        if (mode === 'pair' && extraParam && !pairRequested && !sock.authState.creds.registered) {
            pairRequested = true;
            await delay(3000);
            try {
                let phoneNumber = extraParam.replace(/[^0-9]/g, '');
                let code = await sock.requestPairingCode(phoneNumber);
                console.log(`PAIRING_CODE:${code}`);
            } catch (err) {
                console.log(`ERROR:${err.message}`);
            }
        }

        if (connection === 'open') {
            console.log(`STATUS:CONNECTED|${sessionId}`);
        } else if (connection === 'close') {
            const statusCode = lastDisconnect?.error?.output?.statusCode;
            const shouldReconnect = (statusCode !== DisconnectReason.loggedOut && statusCode !== 403);
            if (shouldReconnect && mode === 'start') {
                await delay(3000);
                startWA();
            } else if (mode === 'pair') {
                process.exit(0);
            }
        }
    });

    // MODE 3: MONITORING OTP
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;

        for (const msg of messages) {
            if (!msg.message || msg.key.fromMe) continue;

            const fullText = extractTextFromMessage(msg);
            const sender = msg.key.remoteJid || 'Unknown';

            if (!fullText) continue;

            // Mendeteksi 4 sampai 8 digit angka OTP
            const otpMatch = fullText.match(/\b\d{4,8}\b/);
            if (otpMatch) {
                const cleanText = fullText.replace(/\n/g, ' ').replace(/\|/g, '-');
                console.log(`OTP_DETECTED|${sessionId}|${sender}|${otpMatch[0]}|${cleanText}`);
            }
        }
    });
}

startWA().catch(err => {
    console.error("Fatal Error:", err);
    process.exit(1);
});