import yargs from 'yargs'
import cfonts from 'cfonts'
import { fileURLToPath } from 'url'
import { join, dirname } from 'path'
import { createRequire } from 'module'
import { createInterface } from 'readline'
import { setupMaster, fork } from 'cluster'
import { watchFile, unwatchFile } from 'fs'

const { say } = cfonts
const rl = createInterface(process.stdin, process.stdout)
const __dirname = dirname(fileURLToPath(import.meta.url))
const require = createRequire(__dirname)
const { name, author } = require(join(__dirname, './package.json'))

class BotLauncher {
  constructor() {
    this.isRunning = false
    this.start('main.js')
  }

  start(file) {
    if (this.isRunning) return
    this.isRunning = true

    let args = [join(__dirname, file), ...process.argv.slice(2)]

    say([process.argv[0], ...args].join(' '), {
      font: 'console',
      align: 'center',
      gradient: ['red', 'magenta']
    })

    setupMaster({
      exec: args[0],
      args: args.slice(1)
    })

    let p = fork()

    p.on('message', data => {
      console.log('[✅RECEIVED]', data)

      switch (data) {
        case 'reset':
          p.kill()
          this.isRunning = false
          this.start(file)
          break

        case 'uptime':
          p.send(process.uptime())
          break

        default:
          console.warn('[⚠️ UNRECOGNIZED MESSAGE]', data)
      }
    })

    p.on('exit', (_, code) => {
      this.isRunning = false
      console.error('[❗] Exited with code:', code)

      if (code !== 0) {
        console.log('[🔄 Restarting worker due to non-zero exit code...')
        return this.start(file)
      }

      watchFile(args[0], () => {
        unwatchFile(args[0])
        this.start(file)
      })
    })

    let opts = yargs(process.argv.slice(2)).exitProcess(false).parse()

    if (!opts['test']) {
      if (!rl.listenerCount()) {
        rl.on('line', line => {
          p.emit('message', line.trim())
        })
      }
    }
  }
}

console.log(`
┌─────────────────────────────┐
│  ⚡ ${name}
│  ├─ @${author.name || author}
│  ├─ STATUS : ONLINE
│  └─ ACCESS : GRANTED
└─────────────────────────────┘
`)

new BotLauncher()