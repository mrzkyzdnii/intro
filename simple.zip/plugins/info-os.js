let handler = async (m, { conn, text, usedPrefix, command }) => {
  await m.react('🏎️')

  await conn.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: {
        body: {
          text: ""
        },
        nativeFlowMessage: {
          buttons: [
            {
              name: ""
            }
          ],
          messageParamsJson: JSON.stringify({})
        },
        bloksWidget: {
          uuid: "5c9e3a72-8b4d-4f6a-9c1e-7d3b5a8f2c64",
          data: "{\"version\":\"v0.9\",\"createSurface\":{\"surfaceId\":\"starcore-os=1788097307625\",\"catalogId\":\"https://a2ui.org/specification/v0_9/catalogs/basic/catalog.json\",\"components\":[{\"id\":\"root\",\"component\":\"Column\",\"children\":[\"hero\",\"system\",\"resources\",\"node_memory\",\"swap\",\"network\",\"runtime\"]},{\"id\":\"hero\",\"component\":\"Card\",\"child\":\"hero_content\"},{\"id\":\"hero_content\",\"component\":\"Column\",\"children\":[\"hero_title\",\"hero_subtitle\",\"hero_status\"]},{\"id\":\"hero_title\",\"component\":\"Text\",\"text\":\"Server Inspector\",\"variant\":\"h1\"},{\"id\":\"hero_subtitle\",\"component\":\"Text\",\"text\":\"Live operating system information\",\"variant\":\"caption\"},{\"id\":\"hero_status\",\"component\":\"Text\",\"text\":\"● bangsul\",\"variant\":\"body\"},{\"id\":\"system\",\"component\":\"Card\",\"child\":\"system_content\"},{\"id\":\"system_content\",\"component\":\"Column\",\"children\":[\"system_title\",\"system_divider\",\"os_info\",\"kernel\",\"architecture\",\"cpu_model\",\"cpu_cores\",\"hostname\",\"username\",\"endianness\"]},{\"id\":\"system_title\",\"component\":\"Text\",\"text\":\"System Information\",\"variant\":\"h2\"},{\"id\":\"system_divider\",\"component\":\"Divider\"},{\"id\":\"os_info\",\"component\":\"Text\",\"text\":\"OS · linux #124-Ubuntu SMP PREEMPT_DYNAMIC Tue May 26 13:00:45 UTC 2026\",\"variant\":\"body\"},{\"id\":\"kernel\",\"component\":\"Text\",\"text\":\"Kernel · 6.8.0-124-generic\",\"variant\":\"body\"},{\"id\":\"architecture\",\"component\":\"Text\",\"text\":\"Architecture · x64\",\"variant\":\"body\"},{\"id\":\"cpu_model\",\"component\":\"Text\",\"text\":\"CPU · Intel(R) Xeon(R) Gold 6146 CPU @ 3.20GHz\",\"variant\":\"body\"},{\"id\":\"cpu_cores\",\"component\":\"Text\",\"text\":\"CPU Cores · 2\",\"variant\":\"body\"},{\"id\":\"hostname\",\"component\":\"Text\",\"text\":\"Hostname · bangsul\",\"variant\":\"body\"},{\"id\":\"username\",\"component\":\"Text\",\"text\":\"User · root\",\"variant\":\"body\"},{\"id\":\"endianness\",\"component\":\"Text\",\"text\":\"Endianness · LE\",\"variant\":\"body\"},{\"id\":\"resources\",\"component\":\"Card\",\"child\":\"resources_content\"},{\"id\":\"resources_content\",\"component\":\"Column\",\"children\":[\"resources_title\",\"resources_divider\",\"cpu_slider\",\"ram_slider\",\"storage_slider\",\"resource_details\"]},{\"id\":\"resources_title\",\"component\":\"Text\",\"text\":\"System Resources\",\"variant\":\"h2\"},{\"id\":\"resources_divider\",\"component\":\"Divider\"},{\"id\":\"cpu_slider\",\"component\":\"Slider\",\"label\":\"CPU · 84.5%\",\"min\":0,\"max\":100,\"value\":84.5},{\"id\":\"ram_slider\",\"component\":\"Slider\",\"label\":\"RAM · 71.6%\",\"min\":0,\"max\":100,\"value\":71.6},{\"id\":\"storage_slider\",\"component\":\"Slider\",\"label\":\"SSD Storage · 44.6%\",\"min\":0,\"max\":100,\"value\":44.6},{\"id\":\"resource_details\",\"component\":\"Text\",\"text\":\"CPU Load · 1.69 · 0.85 · 0.50\\nRAM · 1.38 GB / 1.92 GB\\nSSD · 21.9 GB / 49.1 GB\",\"variant\":\"caption\"},{\"id\":\"node_memory\",\"component\":\"Card\",\"child\":\"node_memory_content\"},{\"id\":\"node_memory_content\",\"component\":\"Column\",\"children\":[\"node_memory_title\",\"node_memory_divider\",\"rss\",\"heap_total\",\"heap_used\",\"external\",\"array_buffers\"]},{\"id\":\"node_memory_title\",\"component\":\"Text\",\"text\":\"Node.js Memory\",\"variant\":\"h2\"},{\"id\":\"node_memory_divider\",\"component\":\"Divider\"},{\"id\":\"rss\",\"component\":\"Text\",\"text\":\"RSS · 66.16 MB\",\"variant\":\"body\"},{\"id\":\"heap_total\",\"component\":\"Text\",\"text\":\"Heap Total · 46.48 MB\",\"variant\":\"body\"},{\"id\":\"heap_used\",\"component\":\"Text\",\"text\":\"Heap Used · 38.63 MB\",\"variant\":\"body\"},{\"id\":\"external\",\"component\":\"Text\",\"text\":\"External · 5.91 MB\",\"variant\":\"body\"},{\"id\":\"array_buffers\",\"component\":\"Text\",\"text\":\"ArrayBuffers · 903.66 KB\",\"variant\":\"body\"},{\"id\":\"swap\",\"component\":\"Card\",\"child\":\"swap_content\"},{\"id\":\"swap_content\",\"component\":\"Column\",\"children\":[\"swap_title\",\"swap_divider\",\"swap_slider\",\"swap_total\",\"swap_used\",\"swap_free\"]},{\"id\":\"swap_title\",\"component\":\"Text\",\"text\":\"Swap Memory\",\"variant\":\"h2\"},{\"id\":\"swap_divider\",\"component\":\"Divider\"},{\"id\":\"swap_slider\",\"component\":\"Slider\",\"label\":\"Swap Usage · 16.5%\",\"min\":0,\"max\":100,\"value\":16.5},{\"id\":\"swap_total\",\"component\":\"Text\",\"text\":\"Total · 5.94 GB\",\"variant\":\"body\"},{\"id\":\"swap_used\",\"component\":\"Text\",\"text\":\"Used · 1001.63 MB\",\"variant\":\"body\"},{\"id\":\"swap_free\",\"component\":\"Text\",\"text\":\"Free · 4.96 GB\",\"variant\":\"body\"},{\"id\":\"network\",\"component\":\"Card\",\"child\":\"network_content\"},{\"id\":\"network_content\",\"component\":\"Column\",\"children\":[\"network_title\",\"network_divider\",\"primary_ip\",\"network_count\",\"network_list\"]},{\"id\":\"network_title\",\"component\":\"Text\",\"text\":\"Network\",\"variant\":\"h2\"},{\"id\":\"network_divider\",\"component\":\"Divider\"},{\"id\":\"primary_ip\",\"component\":\"Text\",\"text\":\"Primary IP · 10.3.0.17\",\"variant\":\"body\"},{\"id\":\"network_count\",\"component\":\"Text\",\"text\":\"Interfaces · 2\",\"variant\":\"body\"},{\"id\":\"network_list\",\"component\":\"Text\",\"text\":\"eth0 · 10.3.0.17\\neth0 · fe80::5054:ff:fe2f:5c0\",\"variant\":\"caption\"},{\"id\":\"runtime\",\"component\":\"Card\",\"child\":\"runtime_content\"},{\"id\":\"runtime_content\",\"component\":\"Column\",\"children\":[\"runtime_title\",\"runtime_divider\",\"runtime_name\",\"runtime_version\",\"node_compat\",\"engine\",\"pid\",\"bot_uptime\",\"system_uptime\",\"executable\"]},{\"id\":\"runtime_title\",\"component\":\"Text\",\"text\":\"Runtime\",\"variant\":\"h2\"},{\"id\":\"runtime_divider\",\"component\":\"Divider\"},{\"id\":\"runtime_name\",\"component\":\"Text\",\"text\":\"Runtime · Node.js\",\"variant\":\"body\"},{\"id\":\"runtime_version\",\"component\":\"Text\",\"text\":\"Node.js Version · v24.18.0\",\"variant\":\"body\"},{\"id\":\"node_compat\",\"component\":\"Text\",\"text\":\"Node Compatibility · v24.18.0\",\"variant\":\"body\"},{\"id\":\"engine\",\"component\":\"Text\",\"text\":\"JavaScript Engine · V8\",\"variant\":\"body\"},{\"id\":\"pid\",\"component\":\"Text\",\"text\":\"PID · 3457325\",\"variant\":\"body\"},{\"id\":\"bot_uptime\",\"component\":\"Text\",\"text\":\"Bot Uptime · 18 menit, 8 detik\",\"variant\":\"body\"},{\"id\":\"system_uptime\",\"component\":\"Text\",\"text\":\"System Uptime · 49 hari, 21 jam, 26 menit, 22 detik\",\"variant\":\"body\"},{\"id\":\"executable\",\"component\":\"Text\",\"text\":\"Executable · /root/.nvm/versions/node/v24.18.0/bin/node\",\"variant\":\"caption\"}]}}",
          type: "im_a2ui"
        },
        contextInfo: {
          mentionedJid: [],
          groupMentions: [],
          statusAttributions: [],
          stanzaId: "ACD12719915458D17AC2843508837C27",
          participant: "233109920456838@lid",
          quotedMessage: {
            conversation: "os",
            messageContextInfo: {
              threadId: [],
              messageSecret: Buffer.from(
                'MivgN/P90ur9sVPfxO1OO4og1K8cEQyXy+Q7YXj1L74=',
                'base64'
              ),
              limitSharingV2: {
                sharingLimited: true,
                trigger: 1,
                limitSharingSettingTimestamp: 1786889219833,
                initiatedByMe: true
              }
            }
          }
        }
      }
    },
    {},
    {
      participant: m.chat
    }
  )
}

handler.help = ['info']
handler.tags = ['info']
handler.command = /^os$/i
handler.limit = 10