import { addExif } from '../lib/sticker.js'
import { Sticker } from 'wa-sticker-formatter'

const HF_TOKENS = [
  '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',
  'hf_lUub1ETSULfCmxDAZKgHDNRYmKlOYGcOpD',
  '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'
].filter(Boolean)

let tokenIndex = 0

const getNextToken = () => {
  if (!HF_TOKENS.length) {
    return global.hf_token || process.env.HF_TOKEN || ''
  }
  const token = HF_TOKENS[tokenIndex % HF_TOKENS.length]
  tokenIndex = (tokenIndex + 1) % HF_TOKENS.length
  return token
}

const MAX_PROMPT_LENGTH = 300
const SSE_TIMEOUT_MS = 120000

const createSticker = async (img, packName, authorName, quality = 70) => {
  const metadata = {
    type: 'full',
    pack: packName || global.stickpack,
    author: authorName || global.stickauth,
    quality
  }
  return new Sticker(img, metadata).toBuffer()
}

const upsamplerEditImage = async (imageBuffer, prompt, style = 'None') => {
  const host = 'https://upsampler-qwen-image-edit.hf.space'
  const sessionHash = Math.random().toString(36).substring(2)
  const token = getNextToken()
  const authHeader = token ? { 'Authorization': `Bearer ${token}` } : {}

  const fd = new FormData()
  const blob = new Blob([imageBuffer], { type: 'image/jpeg' })
  fd.append('files', blob, 'input.jpg')

  const uploadRes = await fetch(`${host}/gradio_api/upload`, {
    method: 'POST',
    headers: { ...authHeader },
    body: fd
  })

  if (!uploadRes.ok) {
    throw new Error(`Upload gagal: ${uploadRes.status} ${uploadRes.statusText}`)
  }

  const uploadJson = await uploadRes.json()
  const uploadedPath = uploadJson[0]
  if (!uploadedPath) {
    throw new Error('Gagal mendapatkan path file dari server.')
  }

  const joinPayload = {
    data: [
      { path: uploadedPath, meta: { _type: 'gradio.FileData' } },
      prompt,
      style,
      0,
      true,
      1,
      4
    ],
    event_data: null,
    fn_index: 0,
    trigger_id: null,
    session_hash: sessionHash
  }

  const joinRes = await fetch(`${host}/gradio_api/queue/join?`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...authHeader
    },
    body: JSON.stringify(joinPayload)
  })

  if (!joinRes.ok) {
    if (joinRes.status === 403) {
      throw new Error('QUOTA_EXCEEDED')
    }
    throw new Error(`Queue join gagal: ${joinRes.status} ${joinRes.statusText}`)
  }

  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), SSE_TIMEOUT_MS)

  let eventRes
  try {
    eventRes = await fetch(`${host}/gradio_api/queue/data?session_hash=${sessionHash}`, {
      headers: {
        'Accept': 'text/event-stream',
        ...authHeader
      },
      signal: controller.signal
    })
  } catch (err) {
    clearTimeout(timeoutId)
    if (err.name === 'AbortError') {
      throw new Error('Timeout: server tidak merespon dalam 2 menit.')
    }
    throw err
  }

  if (!eventRes.ok || !eventRes.body) {
    clearTimeout(timeoutId)
    if (eventRes.status === 403) {
      throw new Error('QUOTA_EXCEEDED')
    }
    throw new Error('Gagal membuka koneksi SSE ke server.')
  }

  const reader = eventRes.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      const parts = buffer.split('\n\n')
      buffer = parts.pop()

      for (const part of parts) {
        if (!part.trim()) continue
        const match = part.match(/data:\s*(.+)/s)
        if (!match) continue

        let msg
        try {
          msg = JSON.parse(match[1])
        } catch {
          continue
        }

        if (msg.msg === 'process_completed') {
          if (!msg.success) {
            const errMsg = String(msg.output?.error || msg.title || '')
            if (errMsg.toLowerCase().includes('quota') || errMsg.toLowerCase().includes('zerogpu')) {
              throw new Error('QUOTA_EXCEEDED')
            }
            throw new Error(errMsg || 'Gagal memproses gambar.')
          }

          const fileData = msg.output?.data?.[0]
          const imgUrl = fileData?.url || (fileData?.path ? `${host}/gradio_api/file=${fileData.path}` : null)
          if (!imgUrl) {
            throw new Error('URL gambar hasil tidak ditemukan.')
          }

          const dlRes = await fetch(imgUrl, { headers: { ...authHeader } })
          if (!dlRes.ok) {
            throw new Error('Gagal mengunduh buffer gambar hasil.')
          }

          const outBuf = Buffer.from(await dlRes.arrayBuffer())
          return { url: imgUrl, buffer: outBuf }
        }

        if (msg.msg === 'process_generating' && msg.success === false) {
          const errMsg = String(msg.output?.error || '')
          if (errMsg.toLowerCase().includes('quota') || errMsg.toLowerCase().includes('zerogpu')) {
            throw new Error('QUOTA_EXCEEDED')
          }
        }
      }
    }
  } finally {
    clearTimeout(timeoutId)
    try { reader.releaseLock() } catch {}
  }

  throw new Error('Koneksi terputus sebelum gambar selesai dirender.')
}

const upsamplerEditImageWithRetry = async (imageBuffer, prompt, maxRetry = HF_TOKENS.length) => {
  let lastErr
  const attempts = Math.max(1, maxRetry)

  for (let i = 0; i < attempts; i++) {
    try {
      return await upsamplerEditImage(imageBuffer, prompt)
    } catch (err) {
      lastErr = err
      if (err.message === 'QUOTA_EXCEEDED') {
        console.log(`[imagedit] Token ${i + 1}/${attempts} kena quota, coba token berikutnya...`)
        continue
      }
      throw err
    }
  }

  throw new Error('Semua token HF sudah habis kuota ZeroGPU. Coba lagi nanti.')
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted || m
  const mime = (q.msg || q).mimetype || q.mediaType || ''

  if (!mime.startsWith('image/')) {
    throw (
      `Kirim atau balas gambar dengan caption:\n\n` +
      `*${usedPrefix}${command} <prompt> [--sticker|--image]*\n\n` +
      `Contoh:\n` +
      `• *${usedPrefix}${command} ubah background jadi pantai --sticker*\n` +
      `• *${usedPrefix}${command} tambahkan kacamata hitam --image*`
    )
  }

  const flagSticker = /(?:^|\s)--sticker(?:\s|$)/i.test(text || '')
  const flagImage = /(?:^|\s)--image(?:\s|$)/i.test(text || '')
  const isSticker = flagSticker && !flagImage

  const cleanPrompt = (text || '')
    .replace(/(?:^|\s)--(sticker|image)(?:\s|$)/gi, ' ')
    .trim()

  if (!cleanPrompt) {
    throw (
      `Prompt tidak boleh kosong.\n\n` +
      `Contoh:\n` +
      `*${usedPrefix}${command} ubah background jadi pantai --sticker*`
    )
  }

  if (cleanPrompt.length > MAX_PROMPT_LENGTH) {
    throw (
      `Prompt terlalu panjang (${cleanPrompt.length}/${MAX_PROMPT_LENGTH} karakter).\n` +
      `Prompt panjang memicu error 403 (ZeroGPU quota). Ringkas prompt Anda.`
    )
  }

  try {
    await m.react('⏳')
  } catch {}

  try {
    let media = null

    if (typeof q.download === 'function') {
      media = await q.download()
    } else if (conn.downloadMediaMessage) {
      media = await conn.downloadMediaMessage(q)
    } else if (typeof m.download === 'function') {
      media = await m.download()
    }

    if (!media || !Buffer.isBuffer(media)) {
      throw new Error('Gagal mendownload media gambar dari WhatsApp.')
    }

    const result = await upsamplerEditImageWithRetry(media, cleanPrompt)

    if (!result?.buffer || !Buffer.isBuffer(result.buffer) || !result.buffer.length) {
      throw new Error('Server tidak mengembalikan buffer gambar.')
    }

    if (isSticker) {
      const packname = global.stickpack || 'AI Edit'
      const author = global.stickauth || 'Bot'

      let stickerBuffer = null
      try {
        stickerBuffer = await addExif(result.buffer, packname, author)
      } catch {}

      if (!stickerBuffer || !Buffer.isBuffer(stickerBuffer) || !stickerBuffer.length) {
        stickerBuffer = await createSticker(result.buffer, packname, author)
      }

      if (!Buffer.isBuffer(stickerBuffer) || !stickerBuffer.length) {
        throw new Error('Gagal membuat buffer sticker.')
      }

      await conn.sendFile(m.chat, stickerBuffer, 'sticker.webp', '', m)
    } else {
      const caption =
        `✨ *CUSTOM IMAGE EDIT*\n\n` +
        `╭─〔 ◈ IMAGEDIT 〕\n` +
        `│ ✓ Custom Prompt\n` +
        `│ ✓ AI Image Edit\n` +
        `│ ✓ High Quality\n` +
        `╰───────────────\n\n` +
        `> _${cleanPrompt.slice(0, 100)}${cleanPrompt.length > 100 ? '...' : ''}_`

      await conn.sendMessage(
        m.chat,
        { image: result.buffer, caption },
        { quoted: m }
      )
    }

    try {
      await m.react('✅')
    } catch {}
  } catch (err) {
    console.error(`[imagedit error]`, err)
    try {
      await m.react('❌')
    } catch {}

    const msg = err?.message === 'QUOTA_EXCEEDED'
      ? 'Server AI sedang penuh (ZeroGPU quota). Coba lagi beberapa saat.'
      : (err?.message || err)

    await conn.reply(
      m.chat,
      `❌ *Image Edit Gagal*\n\n> ${msg}`,
      m
    )
  }
}

handler.help = ['imagedit <prompt> [--sticker|--image]']
handler.tags = ['ai']
handler.command = /^imagedit$/i
handler.premium = true

export default handler