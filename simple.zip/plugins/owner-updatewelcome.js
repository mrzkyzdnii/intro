import fs from 'fs'

const handler = async (m, { text, usedPrefix, command }) => {
    if (!global.owner?.some(([number]) => `${number}@s.whatsapp.net` === m.sender)) {
        throw '❌ Khusus owner.'
    }

    if (!m.quoted) {
        throw `Reply kode yang mau dipasang.\n\nContoh:\nReply kode → ${usedPrefix + command}`
    }

    let code = m.quoted.text

    if (!code) {
        throw '❌ Pesan yang direply tidak berisi kode.'
    }

    const file = './lib/welcomeCanvas.js'

    fs.writeFileSync(file, code, 'utf8')

    await conn.reply(
        m.chat,
        `✅ *welcomeCanvas.js berhasil diupdate!*\n\n📁 ${file}`,
        m
    )
}

handler.help = ['updatewelcome']
handler.tags = ['owner']
handler.command = /^updatewelcome$/i
handler.owner = true

export default handler