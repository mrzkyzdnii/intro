const formatNumber = (value) => {
    try {
        return BigInt(value).toLocaleString('id-ID')
    } catch {
        return String(value)
    }
}

// ==========================================
// NORMALIZE JID - PRIORITASKAN LID
// ==========================================
const normalizeJid = (number, conn) => {
    number = String(number).replace(/\D/g, '')

    if (number.startsWith('0')) {
        number = '62' + number.slice(1)
    }

    if (!number.startsWith('62')) {
        number = '62' + number
    }

    const pn = number + '@s.whatsapp.net'
    
    // Coba cari LID dari signal repository
    try {
        const mapping = conn?.signalRepository?.lidMapping
        if (mapping?.getLIDForPN) {
            const lid = mapping.getLIDForPN(pn)
            if (lid && lid.endsWith('@lid')) {
                return lid
            }
        }
    } catch {}

    // Coba cari di database
    try {
        const users = global.db?.data?.users
        if (users) {
            // Cari LID dengan nama yang sama atau data yang sama
            for (const [key, value] of Object.entries(users)) {
                if (key.endsWith('@lid') && value.number === number) {
                    return key
                }
            }
        }
    } catch {}

    // Fallback ke PN
    return pn
}

const handler = async (m, { conn, text, command }) => {
    if (!global.db || !db.data || !db.data.users) {
        throw 'Database user tidak ditemukan.'
    }

    const users = db.data.users
    text = text || ''

    const args = text.trim().split(/\s+/).filter(Boolean)

    let target = null
    let amount = null

    // ==========================================
    // 1. TARGET DARI REPLY
    // ==========================================
    if (m.quoted && m.quoted.sender) {
        target = m.quoted.sender
    }

    // ==========================================
    // 2. TARGET DARI TAG
    // ==========================================
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        target = m.mentionedJid[0]
    }

    // ==========================================
    // 3. CARI ARGUMEN
    // ==========================================
    for (let i = 0; i < args.length; i++) {
        const arg = args[i]

        // ------------------------------------------
        // TAG DI TEXT
        // ------------------------------------------
        if (arg.startsWith('@')) {
            const tagNumber = arg.replace(/\D/g, '')

            if (tagNumber.length >= 8) {
                target = normalizeJid(tagNumber, conn)
            }

            continue
        }

        // ------------------------------------------
        // ANGKA
        // ------------------------------------------
        const clean = arg.replace(/[.,]/g, '')

        if (!/^\d+$/.test(clean)) {
            continue
        }

        if (target) {
            if (amount === null) {
                amount = clean
            }
            continue
        }

        if (target === null) {
            if (clean.length >= 8 && i === 0) {
                target = normalizeJid(clean, conn)
                continue
            }

            if (amount === null) {
                amount = clean
            }
        }
    }

    // ==========================================
    // SUPPORT JUMLAH NOMOR
    // ==========================================
    if (!target && args.length >= 2) {
        const first = args[0].replace(/\D/g, '')
        const second = args[1].replace(/\D/g, '')

        if (first.length >= 8 && /^\d+$/.test(second)) {
            target = normalizeJid(first, conn)
            amount = second
        } else if (second.length >= 8 && /^\d+$/.test(first)) {
            target = normalizeJid(second, conn)
            amount = first
        }
    }

    // ==========================================
    // VALIDASI TARGET
    // ==========================================
    if (!target) {
        throw `Target tidak ditemukan.

Contoh:

.addmoney 50000 @user
.addmoney @user 50000
.addmoney 628123456789 50000
.addmoney 50000 628123456789

Atau reply pesan user:

.addmoney 50000`
    }

    // ==========================================
    // VALIDASI AMOUNT
    // ==========================================
    if (amount === null) {
        throw `Jumlah tidak ditemukan.

Contoh:

.addmoney 50000 @user
.addmoney @user 50000
.addmoney 628123456789 50000

Atau reply:

.addmoney 50000`
    }

    let amountBig

    try {
        amountBig = BigInt(amount)
    } catch {
        throw 'Jumlah tidak valid.'
    }

    if (amountBig <= 0n) {
        throw 'Jumlah harus lebih dari 0.'
    }

    // ==========================================
    // BUAT USER
    // ==========================================
    if (!users[target]) {
        users[target] = {}
    }

    if (typeof users[target].limit !== 'number') {
        users[target].limit = 0
    }

    if (users[target].money === undefined || users[target].money === null) {
        users[target].money = 0
    }

    // ==========================================
    // ADD LIMIT
    // ==========================================
    if (/^addlimit$/i.test(command)) {
        const before = BigInt(
            Math.trunc(Number(users[target].limit) || 0)
        )

        const after = before + amountBig

        if (after <= BigInt(Number.MAX_SAFE_INTEGER)) {
            users[target].limit = Number(after)
        } else {
            users[target].limit = after.toString()
        }

        await conn.reply(
            m.chat,
            `╭━━〔 ✦ ADD LIMIT 〕━━╮
┃
┃ 👤 Target   › @${target.split('@')[0]}
┃
┃ ✦ Sebelum  › ${formatNumber(before)}
┃ ✦ Tambah   › +${formatNumber(amountBig)}
┃ ✦ Sekarang › ${formatNumber(after)}
┃
╰━━━━━━━━━━━━━━━━━━╯`,
            m,
            {
                mentions: [target]
            }
        )

        return
    }

    // ==========================================
    // ADD MONEY
    // ==========================================
    if (/^addmoney$/i.test(command)) {
        let before

        try {
            before = BigInt(String(users[target].money || 0))
        } catch {
            before = 0n
        }

        const after = before + amountBig

        if (after <= BigInt(Number.MAX_SAFE_INTEGER)) {
            users[target].money = Number(after)
        } else {
            users[target].money = after.toString()
        }

        await conn.reply(
            m.chat,
            `╭━━〔 ✦ ADD MONEY 〕━━╮
┃
┃ 👤 Target   › @${target.split('@')[0]}
┃
┃ ✦ Sebelum  › ${formatNumber(before)}
┃ ✦ Tambah   › +${formatNumber(amountBig)}
┃ ✦ Sekarang › ${formatNumber(after)}
┃
╰━━━━━━━━━━━━━━━━━━╯`,
            m,
            {
                mentions: [target]
            }
        )

        return
    }
}

handler.help = [
    'addlimit',
    'addmoney'
]

handler.tags = ['owner']

handler.command = /^(addlimit|addmoney)$/i

handler.owner = true

export default handler