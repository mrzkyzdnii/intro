import moment from 'moment-timezone'

const handler = async (m, { conn, isOwner, text, usedPrefix, command }) => {
    if (!isOwner) return m.reply('Owner only!')

    try {
        if (text && text.startsWith('ban|')) {
            const id = text.split('ban|')[1]?.trim()

            if (!id || !id.endsWith('@g.us')) {
                return m.reply('❌ ID grup tidak valid.')
            }

            if (!global.db.data.chats[id]) {
                global.db.data.chats[id] = {}
            }

            global.db.data.chats[id].isBanned = true

            let groupName = id

            try {
                const metadata = await conn.groupMetadata(id)
                groupName = metadata.subject || id
            } catch {}

            return m.reply(
                `✅ *GROUP BANNED*\n\n` +
                `📛 *Nama:* ${groupName}\n` +
                `🆔 *ID:* ${id}\n` +
                `🚫 *Status:* Banned`
            )
        }

        const groups = Object.values(
            await conn.groupFetchAllParticipating()
        )

        if (!groups.length) {
            return m.reply('❌ Bot belum bergabung di grup manapun.')
        }

        const rows = groups.slice(0, 10).map((g, i) => {
            const created = g.creation
                ? moment(g.creation * 1000)
                    .tz('Asia/Jakarta')
                    .format('DD/MM/YYYY HH:mm') + ' WIB'
                : 'Tidak diketahui'

            const memberCount = g.participants?.length || 0

            return {
                header: '',
                title: `${i + 1}. ${g.subject || 'Tanpa Nama'}`.slice(0, 24),
                description: `👥 ${memberCount} Member • 🕐 ${created}`,
                id: `${usedPrefix + command} ban|${g.id}`
            }
        })

        await conn.sendMessage(
            m.chat,
            {
                text:
                    `🚫 *BAN GROUP*\n\n` +
                    `📊 Total Grup: ${groups.length}\n` +
                    `📋 Menampilkan: ${rows.length} grup\n\n` +
                    `Pilih grup yang ingin dibanned:`,
                footer: 'Ban Group Manager',
                optionText: 'Pilih Grup',
                optionTitle: 'Daftar Grup',
                nativeFlow: [
                    {
                        text: '🚫 Pilih Grup',
                        sections: [
                            {
                                title: `Daftar Grup (${rows.length})`,
                                rows
                            }
                        ]
                    }
                ]
            },
            { quoted: m }
        )
    } catch (e) {
        console.error(e)
        return m.reply(`❌ Gagal:\n${e.message}`)
    }
}

handler.help = ['banchat2']
handler.tags = ['owner']
handler.command = /^banchat2$/i
handler.owner = true
handler.limit = 10

export default handler