import axios from 'axios'

class N {
  ord(e) {
    let t = '' + e, n = t.charCodeAt(0)
    if (n >= 55296 && n <= 56319) {
      let r = t.charCodeAt(1)
      return (n - 55296) * 1024 + (r - 56320) + 65536
    }
    return n
  }
  encode64(e) {
    let t = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', n = 0, r, i, a, o = []
    while (n < e.length) {
      switch (r = e.charCodeAt(n), a = n % 3, a) {
        case 0: o.push(t.charAt(r >> 2)); break
        case 1: o.push(t.charAt((i & 3) << 4 | r >> 4)); break
        case 2: o.push(t.charAt((i & 15) << 2 | r >> 6)); o.push(t.charAt(r & 63)); break
      }
      i = r
      n++
    }
    return a === 0 ? (o.push(t.charAt((i & 3) << 4)), o.push('==')) : a === 1 && (o.push(t.charAt((i & 15) << 2)), o.push('=')), o.join('')
  }
  encrypt(e, t) {
    let n = '', r = 0
    for (r = 0; r < e.length; r++) {
      let i = e.substr(r, 1), a = t.substr(r % t.length - 1, 1)
      i = Math.floor(this.ord(i) + this.ord(a))
      i = String.fromCharCode(i)
      n += i
    }
    return this.encode64(n)
  }
}

const hex2bin = (e) => {
  let t = [], n = 0, r
  for (e += '', r = e.length; n < r; n += 2) {
    let r = parseInt(e.substr(n, 1), 16), i = parseInt(e.substr(n + 1, 1), 16)
    if (isNaN(r) || isNaN(i)) return false
    t.push(r << 4 | i)
  }
  return String.fromCharCode(...t)
}

const decode64 = (e) => {
  if (!e) return ''
  e = e.replace(/\s/g, '')
  if (!/^[a-z0-9\+\/\s]+=*$/i.test(e)) return ''
  let t = 0, n, r, i, a = []
  for (e = e.replace(/=/g, ''); t < e.length;) {
    switch (n = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'.indexOf(e.charAt(t)), i = t % 4, i) {
      case 1: a.push(String.fromCharCode(r << 2 | n >> 4)); break
      case 2: a.push(String.fromCharCode((r & 15) << 4 | n >> 2)); break
      case 3: a.push(String.fromCharCode((r & 3) << 6 | n)); break
    }
    r = n
    t++
  }
  return a.join('')
}

const decrypt = (e, t) => {
  let n = ''
  e = decode64(e)
  for (let r = 0; r < e.length; r++) {
    let i = e.substr(r, 1), a = t.substr(r % t.length - 1, 1)
    i = Math.floor(new N().ord(i) - new N().ord(a))
    i = String.fromCharCode(i)
    n += i
  }
  return n
}

const decryptUrl = (e, t, cssHash, hostname) => {
  if (!e || !t) return null
  let i = cssHash
  let a = hex2bin(e)
  if (!a) return e
  let o = a.split('').reverse().join('')
  let sorryMate = [69, 84, 65, 77, 95, 89, 82, 82, 79, 83].map(c => String.fromCharCode(c)).join('').split('').reverse().join('')
  let s = `${sorryMate}${hostname.length}${i}${t}`
  let c = decrypt(o, s)
  return typeof c !== 'string' || !/^[\x20-\x7e]+$/.test(c) ? null : c
}

const scraper = async (url) => {
  const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  const hostname = '9xbuddy.site'

  const pageRes = await axios.get(`https://${hostname}/process?url=${encodeURIComponent(url)}`, {
    headers: {
      'User-Agent': USER_AGENT,
      'Referer': `https://${hostname}/`
    }
  })

  const html = pageRes.data
  const initMatch = html.match(/window\.__INIT__\s*=\s*({[\s\S]*?})(?:;|<\/script>)/)
  if (!initMatch) throw 'Gagal mengambil konfigurasi awal 9xbuddy'
  const init = JSON.parse(initMatch[1])

  const cssMatch = /\/build\/(?:assets\/)?main\.([^\"']+?)\.css/g.exec(html)
  const cssHash = cssMatch ? cssMatch[1] : ''
  const i = cssHash.split('').reverse().join('')
  const a = init.ua.split('').reverse().join('').substr(0, 10)
  const o = [90, 84, 94, 100, 81, 81, 74, 89, 100, 70, 83, 83, 84, 76, 100, 89, 84, 83, 100, 82, 78, 100, 74, 89, 70, 82, 100, 94, 87, 87, 84, 88].map(e => String.fromCharCode(e - 5)).reverse().join('')
  const s = init.appVersion
  const c = 'xbuddy123sudo-' + s
  const l = hostname + i + a + o + c + s
  const authToken = new N().encrypt(l, i)

  const tokenRes = await axios.post(init.apiBase + '/token', {}, {
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      'X-Requested-With': 'xmlhttprequest',
      'x-auth-token': authToken,
      'x-requested-domain': hostname,
      'User-Agent': USER_AGENT,
      'Origin': `https://${hostname}`,
      'Referer': `https://${hostname}/`
    }
  })

  const accessToken = tokenRes.data?.access_token
  if (!accessToken) throw 'Gagal otentikasi token 9xbuddy'

  const r = encodeURIComponent(url)
  const sigKey = `${authToken}jv7g2_DAMNN_DUDE`
  const sig = new N().encrypt(r, sigKey)

  const extractRes = await axios.post(init.apiBase + '/extract', {
    url: encodeURIComponent(url),
    _sig: sig
  }, {
    headers: {
      'Content-Type': 'application/json; charset=UTF-8',
      'X-Requested-With': 'xmlhttprequest',
      'x-auth-token': authToken,
      'x-requested-domain': hostname,
      'x-access-token': accessToken,
      'User-Agent': USER_AGENT,
      'Origin': `https://${hostname}`,
      'Referer': `https://${hostname}/`
    }
  })

  const resData = extractRes.data?.response
  if (!resData) throw extractRes.data?.message || 'Media tidak ditemukan atau URL tidak didukung'

  const token = resData.token
  const rawFormats = resData.formats || []

  const formats = []
  for (const item of rawFormats) {
    const decUrl = decryptUrl(item.url, token, cssHash, hostname)
    if (!decUrl) continue
    formats.push({
      quality: item.quality || 'Standard',
      type: item.type || 'media',
      ext: item.ext || 'mp4',
      size: item.size || null,
      external: item.external === 'true' || item.external === true,
      url: decUrl.startsWith('//') ? 'https:' + decUrl : decUrl
    })
  }

  const qualityScore = (q) => {
    const str = String(q).toLowerCase()
    if (str.includes('2160') || str.includes('4k')) return 100
    if (str.includes('1440') || str.includes('2k')) return 90
    if (str.includes('1080')) return 80
    if (str.includes('720') || str.includes('hd')) return 70
    if (str.includes('540')) return 60
    if (str.includes('480')) return 50
    if (str.includes('360')) return 40
    if (str.includes('270') || str.includes('sd')) return 30
    return 10
  }

  const videoFormats = formats.filter(f => !f.external && (f.ext === 'mp4' || f.type === 'video' || f.type === 'media') && !f.url.startsWith('/download/'))

  videoFormats.sort((a, b) => {
    const diff = qualityScore(b.quality) - qualityScore(a.quality)
    if (diff !== 0) return diff
    const isDirectA = a.url.includes('cdn') || a.url.includes('twimg') || a.url.includes('fbcdn')
    const isDirectB = b.url.includes('cdn') || b.url.includes('twimg') || b.url.includes('fbcdn')
    if (isDirectA && !isDirectB) return -1
    if (!isDirectA && isDirectB) return 1
    return 0
  })

  const bestVideo = videoFormats[0] || null

  const audioFormats = formats.filter(f => !f.external && (f.type === 'audio' || f.ext === 'mp3' || f.ext === 'm4a') && !f.url.startsWith('/download/'))
  const bestAudio = audioFormats[0] || (bestVideo ? {
    quality: 'Audio',
    type: 'audio',
    ext: 'mp3',
    url: bestVideo.url
  } : null)

  return {
    title: resData.title || '9xbuddy Download',
    thumbnail: resData.thumbnail || null,
    uploader: resData.uploader || null,
    duration: resData.duration || null,
    video: bestVideo,
    audio: bestAudio
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} https://x.com/...`

  await conn.reply(m.chat, 'Sedang memproses dan mendownload media via 9xbuddy...', m)

  const result = await scraper(text)

  if (!result.video && !result.audio) throw 'Gagal mengekstrak video maupun audio dari URL tersebut.'

  let caption = `*9XBUDDY DOWNLOADER*\n\n`
  caption += `• *Judul:* ${result.title}\n`
  if (result.uploader) caption += `• *Uploader:* ${result.uploader}\n`
  if (result.duration) caption += `• *Durasi:* ${result.duration}\n`
  if (result.video) caption += `• *Kualitas Video:* ${result.video.quality} (${result.video.ext})\n`
  caption += `\n_Mengirim video dan audio kualitas terbaik..._`

  if (result.video) {
    await conn.sendFile(m.chat, result.video.url, `video_${Date.now()}.${result.video.ext || 'mp4'}`, caption, m)
  }

  if (result.audio) {
    await conn.sendFile(m.chat, result.audio.url, `audio_${Date.now()}.mp3`, '', m, null, { mimetype: 'audio/mp4' })
  }
}

handler.help = ['9xbuddy <url>']
handler.tags = ['downloader']
handler.command = /^9xbuddy$/i

export default handler