import { generateWAMessage, areJidsSameUser, proto } from '@mrzkyzdnii/baileys'

export async function all(m, chatUpdate) {
  if (!m || m.isBaileys) return
  if (!m.message) return

  global.db.data = global.db.data || {}
  global.db.data.sticker = global.db.data.sticker || {}

  const msg = m.msg || m.message[m.mtype]
  if (!msg) return

  const fileSha256 = msg.fileSha256 || m.msg?.fileSha256 || m.fileSha256
  if (!fileSha256) return

  const hashKey = Buffer.isBuffer(fileSha256)
    ? fileSha256.toString('base64')
    : Buffer.from(fileSha256).toString('base64')

  if (!(hashKey in global.db.data.sticker)) return

  let hash = global.db.data.sticker[hashKey]
  if (!hash || !hash.text) return
  let { text, mentionedJid } = hash

  m.text = text
  if (m.msg && typeof m.msg === 'object') m.msg.text = text
  if (Array.isArray(mentionedJid)) {
    m.mentionedJid = [...new Set([...(m.mentionedJid || []), ...mentionedJid])]
  }
}