import crypto from 'crypto'

const handler = async (m, { conn }) => {
  const responseId = crypto.randomUUID()
  const toolCallId1 = crypto.randomUUID()
  const toolCallId2 = crypto.randomUUID()
  const toolCallId3 = crypto.randomUUID()

  await conn.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        messageSecret: "v/3VN8Gfr2dbKzgt1GKDEU7ovyYW+nswh4Duwq6KDuU="
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            unifiedResponse: {
              data: Buffer.from(JSON.stringify({
                response_id: responseId,
                sections: [
                  {
                    view_model: {
                      primitive: {
                        __typename: "FOATextPrimitive",
                        text: "Menu Tampilan 2"
                      },
                      __typename: "GenAISingleLayoutViewModel"
                    }
                  },
                  {
                    view_model: {
                      primitive: {
                        text: ":)",
                        __typename: "GenAIMarkdownTextUXPrimitive"
                      },
                      __typename: "GenAISingleLayoutViewModel"
                    }
                  },
                  {
                    view_model: {
                      primitive: {
                        __typename: "GenAIImagePrimitive",
                        preview_image: {
                          __typename: "GenAIMediaItem",
                          mime_type: "image/jpeg",
                          url: "https://cdn.nekohime.site/file/ei19akfe.jpeg"
                        },
                        full_image: {
                          __typename: "GenAIMediaItem",
                          mime_type: "image/jpeg",
                          url: "https://cdn.nekohime.site/file/ei19akfe.jpeg"
                        }
                      },
                      __typename: "GenAISingleLayoutViewModel"
                    }
                  },
                  {
                    view_model: {
                      primitives: [
                        {
                          __typename: "GenAI3PExtWidgetPrimitive",
                          header: {
                            __typename: "GenAI3PExtWidgetStandardHeader",
                            title: "SAMPLE MENU"
                          },
                          body: {
                            __typename: "GenAI3PExtCalendarEventList",
                            sections: [],
                            ctas: [
                              {
                                __typename: "GenAI3PExtWidgetCTA",
                                label: ".menu",
                                state: "PENDING",
                                kind: "OTHER",
                                tool_call_id: toolCallId1,
                                toast: {
                                  __typename: "GenAI3PExtWidgetToast",
                                  label: "Menu"
                                }
                              },
                              {
                                __typename: "GenAI3PExtWidgetCTA",
                                label: ".menu all",
                                state: "PENDING",
                                kind: "OTHER",
                                tool_call_id: toolCallId2,
                                toast: {
                                  __typename: "GenAI3PExtWidgetToast",
                                  label: "Menu All"
                                }
                              },
                              {
                                __typename: "GenAI3PExtWidgetCTA",
                                label: ".play beautiful in white",
                                state: "PENDING",
                                kind: "OTHER",
                                tool_call_id: toolCallId3,
                                toast: {
                                  __typename: "GenAI3PExtWidgetToast",
                                  label: "Play"
                                }
                              }
                            ]
                          }
                        }
                      ],
                      __typename: "GenAIHScrollLayoutViewModel"
                    }
                  },
                  {
                    view_model: {
                      primitives: [
                        {
                          __typename: "GenAIFooterActionPrimitive",
                          cta_text: "Chat Owner",
                          cta_type: "OPEN_URL",
                          cta_url: "https://wa.me/628386484120?text=halo"
                        },
                        {
                          __typename: "GenAIFooterActionPrimitive",
                          cta_text: "Chat Owner",
                          cta_type: "OPEN_URL",
                          cta_url: "https://wa.me/628386484120?text=halo"
                        }
                      ],
                      __typename: "GenAIHScrollLayoutViewModel"
                    }
                  }
                ]
              })).toString('base64')
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardOrigin: 4
            }
          }
        }
      }
    },
    {}
  )
}

handler.help = ['menu2']
handler.tags = ['main']
handler.command = /^menu2$/i

export default handler