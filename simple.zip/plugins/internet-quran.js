import axios from 'axios'

let chaptersMapCache = null

async function getChaptersMap() {
  if (chaptersMapCache) return chaptersMapCache

  try {
    const { data } = await axios.get(
      'https://api.quran.com/api/v4/chapters?language=id',
      {
        headers: {
          'User-Agent': 'Mozilla/5.0'
        },
        timeout: 10000
      }
    )

    const map = {}

    for (const ch of data.chapters || []) {
      map[ch.id] = {
        nameSimple: ch.name_simple,
        nameArabic: ch.name_arabic,
        translatedName: ch.translated_name?.name || ch.name_simple,
        revelationPlace: ch.revelation_place
      }
    }

    chaptersMapCache = map
    return map
  } catch {
    return {}
  }
}

function parseInput(input) {
  let query
  let startPage = 1

  if (input?.startsWith('http')) {
    try {
      const url = new URL(input)
      query = url.searchParams.get('query') || url.searchParams.get('q')
      startPage = Number(url.searchParams.get('page')) || 1
    } catch {
      query = input.trim()
    }
  } else {
    query = input?.trim()
  }

  return { query, startPage }
}

async function getVerseDetail(verseKey) {
  const { data } = await axios.get(
    `https://api.quran.com/api/v4/verses/by_key/${verseKey}`,
    {
      params: {
        language: 'id',
        words: true,
        translations: '33',
        fields: 'text_uthmani'
      },
      headers: {
        'User-Agent': 'Mozilla/5.0'
      },
      timeout: 10000
    }
  )

  const verse = data.verse || {}

  return {
    arabic: verse.text_uthmani || '',
    translation: (verse.translations?.[0]?.text || '')
      .replace(/<[^>]+>/g, '')
      .replace(/\s+/g, ' ')
      .trim()
  }
}

async function scrapeQuranSearch(input, maxPages = 3) {
  const { query, startPage } = parseInput(input)

  if (!query) throw new Error('Keyword wajib diisi.')

  const chapters = await getChaptersMap()

  const verses = []
  let totalResults = 0

  for (let page = startPage; page < startPage + maxPages; page++) {
    try {
      const { data } = await axios.get(
        `https://api.quran.com/api/v4/search?q=${encodeURIComponent(query)}&language=id&page=${page}`,
        {
          headers: {
            'User-Agent': 'Mozilla/5.0',
            'Accept': 'application/json'
          },
          timeout: 10000
        }
      )

      const search = data.search || {}
      const results = search.results || []

      totalResults = search.total_results || totalResults

      for (const item of results) {
        const [surah, ayat] = item.verse_key.split(':')

        const info = chapters[Number(surah)] || {}

        let detail = {
          arabic: '',
          translation: ''
        }

        try {
          detail = await getVerseDetail(item.verse_key)
        } catch {}

        verses.push({
          verseKey: item.verse_key,
          surahNumber: Number(surah),
          verseNumber: Number(ayat),
          surahName: info.nameSimple || `Surah ${surah}`,
          surahArabic: info.nameArabic || '',
          surahTranslated: info.translatedName || '',
          arabic: detail.arabic,
          translation: detail.translation,
          url: `https://quran.com/id/${item.verse_key}`
        })
      }

      if (
        results.length === 0 ||
        page >= (search.total_pages || maxPages)
      ) break

    } catch (e) {
      console.error(e)
      break
    }
  }

  return {
    success: true,
    query,
    totalResults,
    verses
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text)
    throw `Contoh:\n${usedPrefix + command} kejahatan`

  await m.react('🔎')

  try {

    const result = await scrapeQuranSearch(text)

    if (!result.verses.length)
      throw 'Ayat tidak ditemukan.'

    let caption = `📖 *Quran Search*\n\n`
    caption += `🔎 *Keyword:* ${result.query}\n`
    caption += `📚 *Total Hasil:* ${result.totalResults}\n\n`

    for (const v of result.verses.slice(0, 20)) {
      caption += `📌 *${v.surahName} (${v.verseKey})*\n\n`

      if (v.arabic)
        caption += `${v.arabic}\n\n`

      if (v.translation)
        caption += `🇮🇩 ${v.translation}\n\n`

      caption += `🔗 ${v.url}\n\n`
    }

    if (result.verses.length > 20) {
      caption += `_Menampilkan 20 hasil pertama._`
    }

    await conn.sendMessage(
      m.chat,
      { text: caption.trim() },
      { quoted: m }
    )

    await m.react('✅')

  } catch (e) {
    await m.react('❌')
    throw e.message || 'Terjadi kesalahan.'
  }

}

handler.help = ['quransearch <keyword>']
handler.tags = ['internet']
handler.command = /^(quransearch|qsearch|quranfind)$/i
handler.limit = 10

export default handler