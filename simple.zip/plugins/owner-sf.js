import fs from 'fs'
import syntaxError from 'syntax-error'
import path from 'path'

const _fs = fs.promises

const getQuotedText = m => {
  const q = m?.quoted
  if (!q) return ''

  const msg = q?.message || q?.msg || q

  if (typeof msg === 'string') return msg
  if (typeof msg?.conversation === 'string') return msg.conversation
  if (typeof msg?.extendedTextMessage?.text === 'string') return msg.extendedTextMessage.text
  if (typeof msg?.imageMessage?.caption === 'string') return msg.imageMessage.caption
  if (typeof msg?.videoMessage?.caption === 'string') return msg.videoMessage.caption
  if (typeof q?.text === 'string') return q.text

  return ''
}

const handler = async (m, { conn, text, usedPrefix, command, __dirname }) => {
  if (!text) throw `
Penggunaan: ${usedPrefix}${command} <name file>
Contoh: ${usedPrefix}savefile main.js
        ${usedPrefix}saveplugin owner
`.trim()

  if (!m.quoted) throw 'Reply Kodenya'

  const code = getQuotedText(m)

  if (!code) {
    console.log('QUOTED:', JSON.stringify(m.quoted, null, 2))
    throw '❌ Teks reply tidak terbaca.'
  }

  if (/p(lugin)?/i.test(command)) {
    const filename = text
      .trim()
      .replace(/^plugins?\//i, '')
      .replace(/\.js$/i, '') + '.js'

    const error = syntaxError(code, filename, {
      sourceType: 'module',
      allowReturnOutsideFunction: true,
      allowAwaitOutsideFunction: true
    })

    if (error) throw error

    const filePath = path.join(__dirname, filename)

    await _fs.mkdir(path.dirname(filePath), { recursive: true })
    await _fs.writeFile(filePath, code, 'utf8')

    return conn.reply(
      m.chat,
      `✅ Sukses Menyimpan Di *${filename}*\n📦 ${Buffer.byteLength(code, 'utf8')} bytes`,
      m
    )
  }

  if (/\.js$/i.test(text.trim())) {
    const filename = text.trim()

    const error = syntaxError(code, filename, {
      sourceType: 'module',
      allowReturnOutsideFunction: true,
      allowAwaitOutsideFunction: true
    })

    if (error) throw error

    await _fs.mkdir(path.dirname(filename), { recursive: true })
    await _fs.writeFile(filename, code, 'utf8')

    return conn.reply(
      m.chat,
      `✅ Sukses Menyimpan Di *${filename}*\n📦 ${Buffer.byteLength(code, 'utf8')} bytes`,
      m
    )
  }

  throw '❌ Nama file harus menggunakan ekstensi .js'
}

handler.help = ['saveplugin', 'savefile']
handler.tags = ['owner']
handler.command = /^(sf|saveplugin|sp|savefile)$/i
handler.rowner = true
handler.limit = 10

export default handler