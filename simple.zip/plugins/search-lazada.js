import axios from 'axios'

const getImageBuffer = async (url) => {
  if (!url) return null
  try {
    const thumb = (url.includes('slatic.net') || url.includes('lazada.co.id'))
      ? url + '_300x300q80.jpg'
      : url
    const res = await axios.get(thumb, {
      responseType: 'arraybuffer',
      timeout: 4000,
      headers: {
        'User-Agent': 'Mozilla/5.0'
      }
    })
    return Buffer.from(res.data)
  } catch {
    try {
      const res = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 4000,
        headers: {
          'User-Agent': 'Mozilla/5.0'
        }
      })
      return Buffer.from(res.data)
    } catch {
      return null
    }
  }
}

const scraper = async (query) => {
  let q = query.trim()
  if (q.startsWith('http://') || q.startsWith('https://')) {
    try {
      const parsed = new URL(q)
      const searchParam = parsed.searchParams.get('q')
      if (searchParam) {
        q = searchParam.trim()
      } else {
        const tagMatch = parsed.pathname.match(/\/(?:tag|catalog|beli|jual)\/([^\/]+)/)
        if (tagMatch) q = decodeURIComponent(tagMatch[1]).replace(/[-_+]/g, ' ').trim()
      }
    } catch {}
  }

  const mirrors = [
    'https://www.daraz.pk/catalog/',
    'https://www.daraz.com.bd/catalog/',
    'https://www.daraz.com.np/catalog/'
  ]

  let list = []
  for (const endpoint of mirrors) {
    try {
      const { data } = await axios.get(endpoint, {
        params: {
          q,
          ajax: 'true',
          region: 'id'
        },
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
        },
        timeout: 6000
      })

      const items = data?.mods?.listItems
      if (Array.isArray(items) && items.length > 0) {
        list = items
        break
      }
    } catch {}
  }

  if (!list.length) throw 'Produk tidak ditemukan!'

  return list.slice(0, 10).map((item) => {
    let url = item.itemUrl || ''
    if (url.startsWith('//')) url = 'https:' + url

    let image = item.image || ''
    if (image.startsWith('//')) image = 'https:' + image

    const rating = item.ratingScore ? parseFloat(item.ratingScore).toFixed(1) : 'Belum ada rating'

    return {
      title: item.name || 'Tanpa Judul',
      price: item.priceShow || (item.price ? 'Rp' + Number(item.price).toLocaleString('id-ID') : 'N/A'),
      rating,
      reviews: item.review || '0',
      seller: item.sellerName || 'N/A',
      location: item.location || 'N/A',
      url,
      image
    }
  })
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} laptop\natau\n${usedPrefix + command} https://www.lazada.co.id/tag/laptop/?q=laptop`

  await conn.reply(m.chat, 'Sedang mencari item di lazada', m)

  const results = await scraper(text)

  let caption = `*LAZADA INDONESIA SEARCH*\n`
  caption += `Query: ${text}\n`
  caption += `Total Hasil: ${results.length} produk\n\n`

  for (let i = 0; i < results.length; i++) {
    const item = results[i]
    caption += `*${i + 1}. ${item.title}*\n`
    caption += `💰 *Harga:* ${item.price}\n`
    caption += `⭐ *Rating:* ${item.rating} (${item.reviews} ulasan)\n`
    caption += `🏪 *Toko:* ${item.seller} (${item.location})\n`
    caption += `🔗 *Link:* ${item.url}\n`
    caption += `🖼️ *Gambar:* ${item.image}\n\n`
  }

  const imageBuffer = await getImageBuffer(results[0]?.image)

  if (imageBuffer) {
    try {
      await conn.sendFile(m.chat, imageBuffer, 'lazada.jpg', caption.trim(), m)
    } catch {
      await conn.reply(m.chat, caption.trim(), m)
    }
  } else {
    await conn.reply(m.chat, caption.trim(), m)
  }
}

handler.help = ['lazada <query/url>']
handler.tags = ['tools', 'internet']
handler.command = /^(lazada|lzd)$/i
handler.limit = 10

export default handler