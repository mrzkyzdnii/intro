import crypto from 'crypto'

// Secret key & IV resmi hasil ekstrak dari bundle Nuxt Alfagift
const AES_KEY = Buffer.from('m4p1-W3bc0mm-4lf@giFt-3ncRyp-022', 'utf8')
const AES_IV = Buffer.from('m4p1-4lf@giFt-1v', 'utf8')

/**
 * Enkripsi visitorId menjadi fingerprint resmi Alfagift (AES-256-CBC)
 */
function generateFingerprint() {
  const visitorId = crypto.randomBytes(16).toString('hex')
  const cipher = crypto.createCipheriv('aes-256-cbc', AES_KEY, AES_IV)
  let encrypted = cipher.update(visitorId, 'utf8', 'base64')
  encrypted += cipher.final('base64')
  return encrypted
}

/**
 * Format URL produk sesuai struktur resmi Alfagift
 */
function generateProductUrl(productName, productId) {
  const slug = (productName || '')
    .toLowerCase()
    .replace(/ /g, '-')
    .replace(/[^\w-]+/g, '')
  return `https://alfagift.id/p/${slug}-${productId}`
}

/**
 * Scraper Alfagift Direct API (Tanpa ScrapingBee / Proxy)
 */
const scraper = async (query, limit = 10) => {
  const fingerprint = generateFingerprint()
  const targetUrl = `https://webcommerce-gw.alfagift.id/v2/products/searches?keyword=${encodeURIComponent(query)}&start=0&limit=${limit}`

  const headers = {
    fingerprint: fingerprint,
    deviceType: 'Web',
    deviceModel: 'chrome',
    Accept: 'application/json',
    'Accept-Language': 'id',
    trxId: String(Math.floor(9e9 * Math.random()) + 1e9),
    latitude: '0',
    longitude: '0',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    Origin: 'https://alfagift.id',
    Referer: 'https://alfagift.id/'
  }

  const res = await fetch(targetUrl, { headers })
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}: Gagal request ke server Alfagift`)
  }

  const data = await res.json()
  const products = data.products || []

  return products.map((item) => ({
    ...item,
    url: generateProductUrl(item.productName, item.productId)
  }))
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} indomie`

  const products = await scraper(text, 10)
  if (!products.length) {
    return conn.reply(m.chat, `Produk dengan kata kunci *"${text}"* tidak ditemukan di Alfamart.`, m)
  }

  let caption = `*ALFAMART / ALFAGIFT SEARCH*\n`
  caption += `Pencarian: *${text}*\n`
  caption += `Ditemukan: *${products.length} produk*\n`
  caption += `────────────────────────\n\n`

  products.forEach((item, index) => {
    const price = `Rp ${Number(item.finalPrice || item.basePrice || 0).toLocaleString('id-ID')}`
    const isDiscount = item.discountPercent && item.discountPercent > 0
    const originalPrice = isDiscount ? ` ~Rp ${Number(item.basePrice || 0).toLocaleString('id-ID')}~ (-${Math.round(item.discountPercent)}%)` : ''
    const stockStatus = item.stock > 0 ? `Tersedia (${item.stock})` : 'Stok Habis'
    const category = item.categoryNameLvl2 || item.categoryNameLvl1 || item.categoryNameLvl0 || '-'

    caption += `*${index + 1}. ${item.productName}*\n`
    caption += `• Harga: *${price}*${originalPrice}\n`
    caption += `• Status: ${stockStatus}\n`
    caption += `• Kategori: ${category}\n`
    if (item.deliveryInfo) caption += `• Info: ${item.deliveryInfo}\n`
    caption += `• Link: ${item.url}\n\n`
  })

  // Kirim cover gambar produk pertama jika ada
  const firstImage = products[0]?.image
  if (firstImage) {
    try {
      await conn.sendFile(m.chat, firstImage, 'alfamart.jpg', caption.trim(), m)
      return
    } catch {
      // Fallback kirim text biasa
    }
  }

  await conn.reply(m.chat, caption.trim(), m)
}

handler.help = ['alfamart <query>']
handler.tags = ['internet']
handler.command = /^(alfamart|alfa|alfagift)$/i

export default handler