import { io } from 'socket.io-client'
import crypto from 'node:crypto'

let cachedWorker = null

const getWorker = async () => {
  if (cachedWorker) return cachedWorker
  const res = await fetch('https://app.sigmabrowser.com/chat/assets/pow-worker-nrh_zVxb.js')
  if (!res.ok) throw new Error('Gagal mengambil worker PoW')
  cachedWorker = await res.text()
  return cachedWorker
}

const solvePoW = async (userUuid) => {
  const chalRes = await fetch('https://bagoodex.io/api/v1/security/pow/challenge', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Origin': 'https://app.sigmabrowser.com',
      'Referer': 'https://app.sigmabrowser.com/'
    },
    body: JSON.stringify({ user_uuid: userUuid, action: 'chat' })
  })
  if (!chalRes.ok) throw new Error('Gagal mengambil tantangan PoW')
  const chal = await chalRes.json()

  const workerCode = await getWorker()
  const t0 = performance.now()

  const proof = await new Promise((resolve, reject) => {
    const mockSelf = {
      onmessage: null,
      postMessage: (msg) => {
        if (msg && msg.ok) resolve(msg.proof)
        else reject(new Error((msg && msg.error) || 'Worker PoW gagal'))
      }
    }
    const runner = new Function('self', 'atob', 'btoa', workerCode)
    runner(
      mockSelf,
      (s) => Buffer.from(s, 'base64').toString('binary'),
      (s) => Buffer.from(s, 'binary').toString('base64')
    )
    mockSelf.onmessage({
      data: {
        challengeId: chal.challenge_id,
        userUuid: userUuid,
        salt: chal.salt,
        memKib: chal.mem_kib,
        iter: chal.iter,
        parallelism: chal.parallelism,
        hashLen: chal.hash_len
      }
    })
  })

  const solveMs = Math.round(performance.now() - t0)

  const redeemRes = await fetch('https://bagoodex.io/api/v1/security/pow/redeem', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Origin': 'https://app.sigmabrowser.com',
      'Referer': 'https://app.sigmabrowser.com/'
    },
    body: JSON.stringify({
      challenge_id: chal.challenge_id,
      proof: proof,
      solve_ms: solveMs
    })
  })
  if (!redeemRes.ok) throw new Error('Gagal redeem token PoW')
  const data = await redeemRes.json()
  return data.session_token
}

const uploadFile = async (sessionId, buffer, mimeType = 'image/jpeg') => {
  const ext = mimeType.split('/')[1] || 'jpg'
  const res = await fetch('https://bagoodex.io/api/v1/file-upload', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Origin': 'https://app.sigmabrowser.com',
      'Referer': 'https://app.sigmabrowser.com/'
    },
    body: JSON.stringify({
      sid: sessionId,
      filename: `upload_${Date.now()}.${ext}`,
      content_type: mimeType,
      content: buffer.toString('base64')
    })
  })
  if (!res.ok) throw new Error('Gagal upload media ke server')
  const data = await res.json()
  if (data.status !== 'success' || !data.file_id) throw new Error('Format upload media gagal')
  return data.file_id
}

const scraper = (query, imageBuffer = null, mimeType = 'image/jpeg') => {
  return new Promise(async (resolve, reject) => {
    try {
      const sessionId = crypto.randomUUID()
      const powToken = await solvePoW(sessionId)
      const fileIds = []

      if (imageBuffer) {
        const fileId = await uploadFile(sessionId, imageBuffer, mimeType)
        fileIds.push(fileId)
      }

      const socket = io('wss://bagoodex.io', {
        path: '/api/socket.io',
        transports: ['websocket'],
        auth: {
          token: undefined,
          sessionId: sessionId
        },
        extraHeaders: {
          Origin: 'https://app.sigmabrowser.com'
        }
      })

      let fullText = ''
      let timer = setTimeout(() => {
        socket.disconnect()
        if (fullText.trim()) resolve(fullText.trim())
        else reject(new Error('Request timeout'))
      }, 45000)

      socket.on('connect', () => {
        const payload = {
          query: query || (imageBuffer ? 'Deskripsikan gambar ini' : ''),
          sessionId: sessionId,
          platform_type: 'web',
          query_type: 'text-chat',
          file_ids: fileIds,
          powSessionToken: powToken
        }
        socket.emit('search', JSON.stringify(payload))
      })

      socket.on('summary', (raw) => {
        try {
          const data = typeof raw === 'string' ? JSON.parse(raw) : raw
          if (data && data.value) fullText += data.value
        } catch {}
      })

      socket.on('finished', () => {
        clearTimeout(timer)
        socket.disconnect()
        resolve(fullText.trim())
      })

      socket.on('error', (err) => {
        clearTimeout(timer)
        socket.disconnect()
        reject(err)
      })

      socket.on('connect_error', (err) => {
        clearTimeout(timer)
        socket.disconnect()
        reject(new Error('Socket connection error: ' + err.message))
      })
    } catch (err) {
      reject(err)
    }
  })
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''

  if (!text && !/image/.test(mime)) {
    throw `Example:\n${usedPrefix + command} halo kamu siapa?\nAtau kirim/reply gambar dengan caption ${usedPrefix + command} apa isi gambar ini?`
  }

  let mediaBuffer = null
  let mediaMime = 'image/jpeg'

  if (/image/.test(mime)) {
    mediaBuffer = await q.download()
    mediaMime = mime
  }

  const result = await scraper(text, mediaBuffer, mediaMime)

  await conn.reply(m.chat, result, m)
}

handler.help = ['sigma']
handler.tags = ['ai']
handler.command = /^(sigma)$/i
handler.limit = 10

export default handler