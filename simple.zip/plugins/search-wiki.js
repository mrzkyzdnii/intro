import axios from 'axios'
import * as cheerio from 'cheerio'
import fs from 'fs'

const CACHE_FILE = './wikipedia_cache.json'
const API_URL = 'https://id.wikipedia.org/w/api.php'
const USER_AGENT = 'MrzkyzdniiWikiBot/1.0 (contact: admin@example.com)'

function loadCache() {
  try {
    if (!fs.existsSync(CACHE_FILE)) return {}
    return JSON.parse(fs.readFileSync(CACHE_FILE, 'utf8'))
  } catch {
    return {}
  }
}

function saveCache(cache) {
  fs.writeFileSync(CACHE_FILE, JSON.stringify(cache, null, 2), 'utf8')
}

function normalizeKeyword(keyword) {
  return keyword
    .trim()
    .replace(/\\s+/g, ' ')
}

async function scrapeWikipedia(keyword, paragraphCount = 3) {
  const query = normalizeKeyword(keyword)
  const cacheKey = query.toLowerCase()
  const cache = loadCache()

  if (cache[cacheKey]?.content) {
    console.log(`Mengambil data dari cache untuk: ${query}`)
    return cache[cacheKey]
  }

  try {
    const { data } = await axios.get(API_URL, {
      params: {
        action: 'parse',
        page: query,
        prop: 'text',
        format: 'json',
        formatversion: 2,
        redirects: 1
      },
      headers: {
        'User-Agent': USER_AGENT,
        Accept: 'application/json'
      },
      timeout: 15000,
      validateStatus: status => status >= 200 && status < 500
    })

    if (data?.error) {
      if (data.error.code === 'missingtitle') {
        throw new Error(`Artikel "${query}" tidak ditemukan.`)
      }
      throw new Error(data.error.info || 'Wikipedia API mengembalikan error.')
    }

    if (!data?.parse?.text) {
      throw new Error(`Konten artikel "${query}" tidak tersedia.`)
    }

    const $ = cheerio.load(data.parse.text)
    const paragraphs = $('.mw-parser-output > p')
      .map((_, element) => $(element).text().replace(/\\s+/g, ' ').trim())
      .get()
      .filter(Boolean)

    if (!paragraphs.length) {
      throw new Error(`Tidak ada paragraf yang dapat dibaca dari artikel "${query}".`)
    }

    const content = paragraphs
      .slice(0, Math.max(1, Number(paragraphCount) || 3))
      .join('\n\n')

    const result = {
      title: data.parse.title,
      pageId: data.parse.pageid,
      content,
      url: `https://id.wikipedia.org/wiki/${encodeURIComponent(data.parse.title.replace(/ /g, '_'))}`
    }

    cache[cacheKey] = result
    saveCache(cache)

    return result
  } catch (error) {
    if (error.response) {
      throw new Error(
        `Wikipedia mengembalikan HTTP ${error.response.status}: ${error.message}`
      )
    }

    throw new Error(`Gagal mengambil data untuk "${query}": ${error.message}`)
  }
}

const handler = async (m, { conn, text }) => {
  if (!text?.trim()) {
    return m.reply('Silakan masukkan kata kunci untuk dicari di Wikipedia.')
  }

  try {
    const result = await scrapeWikipedia(text, 3)
    const message = [
      `*${result.title}*`,
      '',
      result.content,
      '',
      `Sumber: ${result.url}`
    ].join('\n')

    await conn.sendMessage(
      m.chat,
      {
        image: { url: 'https://files.catbox.moe/b21sgz.jpg' },
        caption: message
      },
      { quoted: m }
    )
  } catch (error) {
    console.error('[Wikipedia]', error)
    await m.reply(`Error: ${error.message}`)
  }
}

handler.help = ['wiki']
handler.command = /^(wiki|wikipedia)$/i
handler.tags = ['search']
handler.limit = 10

export default handler