let handler = async (m, { conn, args, usedPrefix, command, isAdmin }) => {
    if (!m.isGroup) return m.reply('Hanya bisa di grup!')
    if (!isAdmin) return m.reply('Hanya admin yang bisa pakai!')
    let chat = global.db.data.chats[m.chat] || (global.db.data.chats[m.chat] = {})
    if (!args[0]) return m.reply(`Contoh: *${usedPrefix + command} on* atau *off*`)
    let mode = args[0].toLowerCase()
    if (mode === 'on') {
        chat.antiBot = true
        return m.reply('✅ Anti-Bot aktif!')
    }
    if (mode === 'off') {
        chat.antiBot = false
        return m.reply('❌ Anti-Bot mati!')
    }
    return m.reply(`Contoh: *${usedPrefix + command} on* atau *off*`)
}

handler.before = async function (m, { conn, isBotAdmin }) {
    if (!m.isGroup || !isBotAdmin || m.fromMe) return
    let chat = global.db.data.chats[m.chat]
    if (!chat?.antiBot) return

    const id = String(m.key?.id || m.id || m.quoted?.id || '').toUpperCase()
    if (!id) return

    const isBotId =
        /^3EB0[0-9A-F]{18}$/.test(id) ||
        /^3EB0[0-9A-F]+$/.test(id) ||
        /^ILSYM-[0-9A-F]+$/.test(id) ||
        id.length === 22 ||
        id.startsWith('ILSYM-')

    if (!isBotId) return

    try {
        await conn.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.sender
            }
        })
    } catch (e) {
        console.error('[ANTIBOT]', e)
    }
}

handler.help = ['antibot']
handler.tags = ['group']
handler.command = /^antibot$/i
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler