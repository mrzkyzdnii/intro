import axios from 'axios'
import * as cheerio from 'cheerio'
import PDFDocument from 'pdfkit'

/**
 * Clean & normalize text for PDFKit (eliminates encoding issues/garbled characters)
 * @param {string} str
 * @returns {string}
 */
const cleanText = (str) => {
    if (!str) return ''
    return str
        .replace(/[’‘`′]/g, "'")
        .replace(/[“”«»]/g, '"')
        .replace(/[–—]/g, '-')
        .replace(/…/g, '...')
        .replace(/ā/g, 'a').replace(/Ā/g, 'A')
        .replace(/ī/g, 'i').replace(/Ī/g, 'I')
        .replace(/ū/g, 'u').replace(/Ū/g, 'U')
        .replace(/ṣ/g, 's').replace(/Ṣ/g, 'S')
        .replace(/ḍ/g, 'd').replace(/Ḍ/g, 'D')
        .replace(/ṭ/g, 't').replace(/Ṭ/g, 'T')
        .replace(/ẓ/g, 'z').replace(/Ż/g, 'Z')
        .replace(/ḥ/g, 'h').replace(/Ḥ/g, 'H')
        .replace(/ʿ/g, "'").replace(/ʾ/g, "'")
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^\x20-\x7E\n]/g, '')
        .replace(/ +/g, ' ')
        .trim()
}

/**
 * Scraper TafsirWeb & PDF Generator
 * @param {string} queryOrUrl - URL TafsirWeb atau kata kunci pencarian
 * @returns {Promise<{title: string, url: string, tafsirs: Array, pdfBuffer: Buffer, filename: string}>}
 */
const scraper = async (queryOrUrl) => {
    let targetUrl = queryOrUrl.trim()

    // Jika input berupa kata kunci atau URL pencarian (?s=)
    const isSearch = !targetUrl.startsWith('http://') && !targetUrl.startsWith('https://') || targetUrl.includes('?s=')

    if (isSearch) {
        const searchUrl = targetUrl.startsWith('http')
            ? targetUrl
            : `https://tafsirweb.com/?s=${encodeURIComponent(queryOrUrl)}`

        const searchRes = await axios.get(searchUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            },
            timeout: 15000
        })

        const $s = cheerio.load(searchRes.data)
        const firstLink = $s('.entry-title a, article h2 a, .post-title a').first().attr('href')

        if (!firstLink) {
            throw new Error(`Tafsir untuk "${queryOrUrl}" tidak ditemukan. Coba kata kunci lain.`)
        }
        targetUrl = firstLink
    }

    // Ambil detail halaman tafsir
    const res = await axios.get(targetUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        },
        timeout: 15000
    })

    const $ = cheerio.load(res.data)
    const rawTitle = $('h1.entry-title, h1').first().text().trim() || 'TafsirWeb'
    const title = cleanText(rawTitle)

    let rawArab = ''
    let rawLatin = ''
    let rawArti = ''

    $('p').each((_, el) => {
        const t = $(el).text().trim()
        if (t.startsWith('Arab-Latin:')) {
            rawLatin = t.replace('Arab-Latin:', '').trim()
        } else if (t.startsWith('Artinya:')) {
            rawArti = t.replace('Artinya:', '').trim()
        } else if (
            $(el).find('strong').length > 0 &&
            t.length > 15 &&
            !rawArab &&
            !t.includes('Tafsir') &&
            !t.includes('Pahami') &&
            !t.includes('Mau pahala')
        ) {
            rawArab = t
        }
    })

    const latin = cleanText(rawLatin)
    const arti = cleanText(rawArti)

    // Extract daftar tafsir dari berbagai sumber pakar
    const tafsirs = []
    $('p').each((_, el) => {
        const strong = $(el).find('strong')
        if (strong.length > 0 && strong.text().includes('📚')) {
            const source = cleanText(strong.text())
            const $clone = $(el).clone()
            $clone.find('strong').remove()
            $clone.find('br').replaceWith('\n')
            const content = cleanText($clone.text())

            if (content) {
                tafsirs.push({ source, content })
            }
        }
    })

    if (tafsirs.length === 0) {
        throw new Error('Gagal mengekstrak pengertian/tafsir dari halaman tersebut.')
    }

    // Generate PDF menggunakan PDFKit
    const pdfBuffer = await new Promise((resolve, reject) => {
        const doc = new PDFDocument({ margin: 45, size: 'A4' })
        const buffers = []

        doc.on('data', (chunk) => buffers.push(chunk))
        doc.on('end', () => resolve(Buffer.concat(buffers)))
        doc.on('error', reject)

        // Header Banner
        doc.rect(0, 0, 595.28, 55).fill('#1E40AF')
        doc.fontSize(18).fillColor('#FFFFFF').text(title, 45, 16, { align: 'center', width: 505 })

        doc.y = 75
        doc.fontSize(8).fillColor('#6B7280').text(`Sumber: ${targetUrl}`, { align: 'center' })
        doc.moveDown(1)

        // Teks latin & terjemahan
        if (latin || arti) {
            if (latin) {
                doc.font('Helvetica-Bold').fontSize(10).fillColor('#1F2937').text('Teks Latin:')
                doc.font('Helvetica').fontSize(10).fillColor('#374151').text(latin)
                doc.moveDown(0.5)
            }
            if (arti) {
                doc.font('Helvetica-Bold').fontSize(10).fillColor('#1F2937').text('Terjemahan / Artinya:')
                doc.font('Helvetica').fontSize(10).fillColor('#374151').text(arti)
                doc.moveDown(0.8)
            }
            doc.moveTo(45, doc.y).lineTo(550, doc.y).strokeColor('#E5E7EB').lineWidth(1).stroke()
            doc.moveDown(1)
        }

        doc.font('Helvetica-Bold').fontSize(13).fillColor('#1E40AF').text('KUMPULAN PENGERTIAN & TAFSIR', { underline: true })
        doc.moveDown(0.8)

        // Iterasi tiap tafsir
        tafsirs.forEach((t, i) => {
            if (doc.y > 720) {
                doc.addPage()
            }
            doc.font('Helvetica-Bold').fontSize(10.5).fillColor('#065F46').text(`${i + 1}. ${t.source}`)
            doc.moveDown(0.3)
            doc.font('Helvetica').fontSize(9.5).fillColor('#1F2937').text(t.content, { align: 'justify' })
            doc.moveDown(0.8)
        })

        doc.end()
    })

    const safeFilename = title.toLowerCase().replace(/[^a-z0-9]/g, '_').replace(/_+/g, '_')

    return {
        title,
        url: targetUrl,
        tafsirs,
        pdfBuffer,
        filename: safeFilename || 'tafsir_penjelasan'
    }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Example:\n${usedPrefix + command} https://tafsirweb.com/?s=surga\natau\n${usedPrefix + command} surga`

    await conn.reply(m.chat, '⏳ Sedang mengunduh dan menyusun PDF tafsir lengkap, tunggu sebentar...', m)

    const result = await scraper(text)

    const caption = `✨ *TafsirWeb Scraper*\n\n📖 *Judul:* ${result.title}\n🔗 *URL:* ${result.url}\n📚 *Total Tafsir:* ${result.tafsirs.length} Penafsiran Pakar\n\n📄 File PDF berisi penjelasan lengkap telah terlampir.`

    await conn.sendFile(
        m.chat,
        result.pdfBuffer,
        `${result.filename}.pdf`,
        caption,
        m,
        false,
        { mimetype: 'application/pdf' }
    )
}

handler.help = ['tafsir']
handler.tags = ['internet']
handler.command = /^(tafsir)$/i

handler.limit = 10
export default handler