import { addExif } from '../lib/sticker.js'
import { Sticker } from 'wa-sticker-formatter'

const HF_TOKENS = [
  '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',
  'hf_lUub1ETSULfCmxDAZKgHDNRYmKlOYGcOpD',
  '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'
].filter(Boolean)

let tokenIndex = 0

const getNextToken = () => {
  if (!HF_TOKENS.length) {
    return global.hf_token || process.env.HF_TOKEN || ''
  }
  const token = HF_TOKENS[tokenIndex % HF_TOKENS.length]
  tokenIndex = (tokenIndex + 1) % HF_TOKENS.length
  return token
}

const PROMPTS = {
  toanime: `Transform the uploaded photo into a high-quality Japanese anime illustration. Preserve the subject's identity, pose, framing, clothing, and background composition, but reinterpret facial features, eyes, hair, and skin using clean anime-style linework, cel-shading, and vibrant flat color palettes. Keep proportions natural, avoid distortion, and render crisp, well-defined outlines with soft anime lighting.`,
  toreal: `Convert the uploaded image into an ultra-realistic photograph. Preserve the subject's identity, pose, expression, clothing, and composition exactly. Reconstruct skin with natural pores and texture, realistic hair strands, lifelike eyes with proper reflection and depth, and physically accurate lighting and shadows, as if captured by a professional DSLR camera with a high-quality lens.`,
  toblack: `ubah warna kulit nya saja jadi warna hitam seperti orang papua, jangan ubah raut bentuk gaya pose pada objek nya hanya kulit nya saja`,
  tobald: `Edit the uploaded photo so the subject appears completely bald, with a smooth, naturally shaded scalp that matches their skin tone and lighting. Preserve facial identity, expression, clothing, background, and composition exactly. Do not alter facial features, only remove the hair and render realistic scalp texture and highlights.`,
  tocartoon: `Transform the uploaded photo into a modern Western cartoon illustration. Preserve the subject's identity, pose, clothing, and composition. Simplify facial features slightly with bold clean outlines, smooth flat shading, and playful proportions, similar to a professional animated character design, while keeping the person clearly recognizable.`,
  to3d: `Convert the uploaded photo into a polished 3D-rendered character, similar to a modern Pixar/DreamWorks-style CGI render. Preserve identity, pose, clothing, and composition. Add realistic subsurface-scattering skin shading, soft studio lighting, smooth rounded facial forms, and high-quality 3D texture detail on hair, fabric, and surfaces.`,
  toghibli: `Reimagine the uploaded photo in the hand-painted Studio Ghibli animation style. Preserve the subject's identity, pose, clothing, and composition. Use soft painterly brushstrokes, warm nostalgic lighting, gentle color grading, and whimsical background detailing consistent with classic Ghibli film aesthetics.`,
  tofantasy: `Transform the uploaded photo into an epic fantasy illustration. Preserve the subject's identity, pose, and composition, but enhance the scene with atmospheric fantasy lighting, magical ambient particles, richly detailed painterly textures, and a mystical, otherworldly color palette, as seen in high-end fantasy concept art.`,
  tocyberpunk: `Transform the uploaded photo into a futuristic cyberpunk scene. Preserve the subject's identity, pose, and composition. Add neon rim lighting in pink, blue, and purple tones, subtle holographic or tech-inspired accents, moody urban night atmosphere, and high-contrast cinematic color grading typical of cyberpunk aesthetics.`,
  tovintage: `Convert the uploaded photo into a vintage retro-style photograph reminiscent of the 1970s-80s. Preserve subject identity, pose, and composition. Apply warm faded color tones, soft film grain, slight vignette, and nostalgic analog-camera color grading while keeping all details sharp and clear.`,
  topixel: `Transform the uploaded photo into detailed pixel art. Preserve the subject's identity, pose, clothing, and general composition, translated into a clean retro pixel-art style with a limited but vibrant color palette, crisp pixel edges, and consistent pixel grid density, similar to high-quality 16-bit/32-bit game character art.`,
  tochibi: `Convert the uploaded photo into an adorable chibi-style character illustration. Preserve the subject's clothing, colors, and identifiable features, but stylize with an oversized head, small simplified body proportions, big expressive eyes, and soft clean shading typical of chibi anime art.`,
  tosketch: `Transform the uploaded photo into a detailed pencil sketch drawing. Preserve the subject's identity, pose, and composition exactly. Render fine graphite linework, realistic cross-hatching and shading for depth, natural paper texture, and crisp, well-defined contour lines throughout.`,
  tocinematic: `Enhance the uploaded photo with a premium cinematic color grade. Preserve the subject's identity, pose, clothing, and composition exactly. Apply teal-and-orange or filmic color grading, deep dynamic range, subtle film grain, and dramatic directional lighting to give it the look of a high-budget movie frame.`,
  toheadscarf: `Edit the uploaded photo so the subject is wearing an elegant, naturally draped headscarf/hijab that matches realistic fabric folds, shadows, and lighting consistent with the original photo. Preserve facial identity, expression, clothing style, background, and composition exactly, only adding the headscarf naturally.`,
  toold: `Edit the uploaded photo to realistically age the subject into an elderly version of themselves. Preserve identity, pose, clothing, and composition. Add natural wrinkles, age spots, thinner and greying hair, and realistic aged skin texture while keeping facial structure and expression recognizable.`,
  toyoung: `Edit the uploaded photo to realistically make the subject appear younger, as a child or teenager version of themselves. Preserve identity, pose, clothing style, and composition. Render smoother youthful skin, proportionally younger facial features, and natural youthful hair texture while keeping the person clearly recognizable.`,
  tosuperhero: `Transform the uploaded photo so the subject is wearing a sleek, high-quality superhero costume with a fitted suit, subtle armor detailing, and a heroic dramatic pose implied by lighting. Preserve facial identity and composition. Add cinematic superhero-movie lighting and a slightly epic atmospheric background.`,
  towatercolor: `Convert the uploaded photo into a delicate watercolor painting. Preserve the subject's identity, pose, and composition. Apply soft bleeding color washes, visible paper texture, gentle color gradients, and loose expressive brushstrokes typical of fine-art watercolor portraits.`,
  tooilpainting: `Transform the uploaded photo into a classical oil painting. Preserve the subject's identity, pose, and composition. Render rich, textured brushstrokes, deep layered color blending, canvas texture, and dramatic chiaroscuro lighting reminiscent of Renaissance-era portrait paintings.`,
  tolego: `Convert the uploaded photo into a LEGO minifigure-style character. Preserve the subject's identity cues, clothing colors, and pose as closely as possible while adapting to LEGO's characteristic blocky plastic shapes, cylindrical head, simplified facial print, and glossy plastic material rendering.`,
  toclay: `Transform the uploaded photo into a claymation-style character, similar to stop-motion animation figures. Preserve the subject's identity, pose, clothing, and composition. Render soft sculpted clay textures, visible fingerprint-like surface imperfections, and warm stop-motion studio lighting.`,
  remaster: `4K upscale from reference image with exact fidelity to face, identity, pose, camera, and composition. Keep clothing, hair, skin, and background unchanged. Enhance real details (pores, hair, fabric) with original colors, lighting, and shadows—no relight, no reshape. Remove grain, noise, and artifacts; apply sharpness without smoothing or fake gloss. No warping, no facial drift, no added/missing anatomy, no distortion, no perspective shift, no text/graphics, no hallucination, no stylization. Output must be identical to original—only sharper, clearer, higher resolution.`
}

const STYLE_KEYS = Object.keys(PROMPTS)

const createSticker = async (img, packName, authorName, quality = 70) => {
  const metadata = {
    type: 'full',
    pack: packName || global.stickpack,
    author: authorName || global.stickauth,
    quality
  }
  return new Sticker(img, metadata).toBuffer()
}

const upsamplerEditImage = async (imageBuffer, prompt = 'make it anime style', style = 'None') => {
  const host = 'https://upsampler-qwen-image-edit.hf.space'
  const sessionHash = Math.random().toString(36).substring(2)
  const token = getNextToken()
  const authHeader = token ? { 'Authorization': `Bearer ${token}` } : {}

  const fd = new FormData()
  const blob = new Blob([imageBuffer], { type: 'image/jpeg' })
  fd.append('files', blob, 'input.jpg')

  const uploadRes = await fetch(`${host}/gradio_api/upload`, {
    method: 'POST',
    headers: { ...authHeader },
    body: fd
  })

  if (!uploadRes.ok) {
    throw new Error(`Upload gagal: ${uploadRes.status} ${uploadRes.statusText}`)
  }

  const uploadJson = await uploadRes.json()
  const uploadedPath = uploadJson[0]
  if (!uploadedPath) {
    throw new Error('Gagal mendapatkan path file dari server.')
  }

  const joinPayload = {
    data: [
      { path: uploadedPath, meta: { _type: 'gradio.FileData' } },
      prompt,
      style,
      0,
      true,
      1,
      4
    ],
    event_data: null,
    fn_index: 0,
    trigger_id: null,
    session_hash: sessionHash
  }

  const joinRes = await fetch(`${host}/gradio_api/queue/join?`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...authHeader
    },
    body: JSON.stringify(joinPayload)
  })

  if (!joinRes.ok) {
    throw new Error(`Queue join gagal: ${joinRes.status} ${joinRes.statusText}`)
  }

  const eventRes = await fetch(`${host}/gradio_api/queue/data?session_hash=${sessionHash}`, {
    headers: {
      'Accept': 'text/event-stream',
      ...authHeader
    }
  })

  if (!eventRes.ok || !eventRes.body) {
    throw new Error('Gagal membuka koneksi SSE ke server.')
  }

  const reader = eventRes.body.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const parts = buffer.split('\n\n')
    buffer = parts.pop()

    for (const part of parts) {
      if (!part.trim()) continue
      const match = part.match(/data:\s*(.+)/s)
      if (!match) continue

      try {
        const msg = JSON.parse(match[1])
        if (msg.msg === 'process_completed') {
          if (!msg.success) {
            const err = msg.output?.error || msg.title || 'Gagal memproses gambar.'
            throw new Error(err)
          }

          const fileData = msg.output?.data?.[0]
          const imgUrl = fileData?.url || (fileData?.path ? `${host}/gradio_api/file=${fileData.path}` : null)
          if (!imgUrl) {
            throw new Error('URL gambar hasil tidak ditemukan.')
          }

          const dlRes = await fetch(imgUrl, { headers: { ...authHeader } })
          if (!dlRes.ok) {
            throw new Error('Gagal mengunduh buffer gambar hasil.')
          }

          const outBuf = Buffer.from(await dlRes.arrayBuffer())
          return {
            url: imgUrl,
            buffer: outBuf
          }
        }
      } catch (err) {
        if (err.message && (err.message.includes('Gagal') || err.message.includes('ZeroGPU') || err.message.includes('quota'))) {
          throw err
        }
      }
    }
  }

  throw new Error('Koneksi terputus sebelum gambar selesai dirender.')
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted || m
  const mime = (q.msg || q).mimetype || q.mediaType || ''

  const styleKey = command.toLowerCase()

  if (!PROMPTS[styleKey]) {
    throw (
      `Style tidak dikenali.\n\n` +
      `Style tersedia:\n\n` +
      STYLE_KEYS.map((k) => `• ${usedPrefix}${k}`).join('\n')
    )
  }

  if (!mime.startsWith('image/')) {
    throw (
      `Kirim atau reply gambar dengan caption:\n\n` +
      `*${usedPrefix + command} --sticker*\n` +
      `*${usedPrefix + command} --image*`
    )
  }

  const flagSticker = /(?:^|\s)--sticker(?:\s|$)/i.test(text || '')
  const flagImage = /(?:^|\s)--image(?:\s|$)/i.test(text || '')
  const isSticker = flagSticker && !flagImage

  const finalPrompt = PROMPTS[styleKey]

  try {
    await m.react('⏳')
  } catch {}

  try {
    let media = null

    if (typeof q.download === 'function') {
      media = await q.download()
    } else if (conn.downloadMediaMessage) {
      media = await conn.downloadMediaMessage(q)
    } else if (typeof m.download === 'function') {
      media = await m.download()
    }

    if (!media || !Buffer.isBuffer(media)) {
      throw new Error('Gagal mendownload media gambar dari WhatsApp.')
    }

    const result = await upsamplerEditImage(media, finalPrompt)

    if (!result?.buffer || !Buffer.isBuffer(result.buffer) || !result.buffer.length) {
      throw new Error('Server tidak mengembalikan buffer gambar.')
    }

    if (isSticker) {
      const packname = global.stickpack || 'AI Transform'
      const author = global.stickauth || 'Bot'

      let stickerBuffer = null
      try {
        stickerBuffer = await addExif(result.buffer, packname, author)
      } catch {}

      if (!stickerBuffer || !Buffer.isBuffer(stickerBuffer) || !stickerBuffer.length) {
        stickerBuffer = await createSticker(result.buffer, packname, author)
      }

      if (!Buffer.isBuffer(stickerBuffer) || !stickerBuffer.length) {
        throw new Error('Gagal membuat buffer sticker.')
      }

      await conn.sendFile(m.chat, stickerBuffer, 'sticker.webp', '', m)
    } else {
      const label = styleKey.toUpperCase()
      const caption =
        `✨ *IMAGE TRANSFORMED*\n\n` +
        `╭─〔 ◈ ${label} 〕\n` +
        `│ ✓ AI Image Edit\n` +
        `│ ✓ Style Applied\n` +
        `│ ✓ Prompt Applied\n` +
        `│ ✓ High Quality\n` +
        `╰───────────────`

      await conn.sendMessage(
        m.chat,
        { image: result.buffer, caption },
        { quoted: m }
      )
    }

    try {
      await m.react('✅')
    } catch {}
  } catch (err) {
    console.error(`[${styleKey} error]`, err)
    try {
      await m.react('❌')
    } catch {}

    await conn.reply(
      m.chat,
      `❌ *Transform Gagal*\n\n> ${err?.message || err}`,
      m
    )
  }
}

handler.help = [...STYLE_KEYS]
handler.tags = ['ai']
handler.command = new RegExp(
  `^(${STYLE_KEYS.join('|')})$`,
  'i'
)
handler.premium = true

export default handler