import axios from 'axios'
import * as cheerio from 'cheerio'

const scraper = async (query) => {
  const { data } = await axios.post(
    'https://jagokata.com/kata-bijak/cari.html',
    new URLSearchParams({
      citaat: query,
      zoekbutton: 'Zoeken'
    }).toString(),
    {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    }
  )

  const $ = cheerio.load(data)
  const results = []

  $('#citatenrijen > li').each((_, el) => {
    const $el = $(el)

    const quote = $el.find('q.fbquote').text().trim()

    const author =
      $el.find('.citatenlijst-auteur a.auteurfbnaam').text().trim() ||
      $el.find('.auteurfbnaam').text().trim()

    const origin = $el.find('.auteur-beschrijving').text().trim()

    const publisher =
      $el.find('.bron-citaat a').text().trim() ||
      $el.find('.bron-citaat').text().trim()

    let image =
      $el.find('img').attr('data-src') ||
      $el.find('img').attr('src')

    if (image && !image.startsWith('http')) {
      image = 'https://jagokata.com/' + image.replace(/^\/+/, '')
    }

    if (
      image &&
      (image.includes('onbekend.jpg') || image.includes('transp.gif'))
    ) {
      image = null
    }

    if (quote) {
      results.push({
        quote,
        author: author || 'Anonim',
        penerbit: publisher || '-',
        asal: origin || '-',
        image: image || null
      })
    }
  })

  return results
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} cinta`

  const results = await scraper(text)

  if (!results.length) {
    throw `Quotes dengan kata kunci "${text}" tidak ditemukan.`
  }

  const res = results[Math.floor(Math.random() * results.length)]

  const caption =
    `*───「 JAGOKATA QUOTES 」───*\n\n` +
    `💬 "${res.quote}"\n\n` +
    `👤 *Penulis:* ${res.author}\n` +
    `🏢 *Penerbit / Sumber:* ${res.penerbit}\n` +
    `📍 *Asal / Profesi:* ${res.asal}`

  if (res.image) {
    await conn.sendFile(
      m.chat,
      res.image,
      'quotes.jpg',
      caption,
      m
    )
  } else {
    await conn.reply(m.chat, caption, m)
  }
}

handler.help = ['quotes']
handler.tags = ['quotes']
handler.command = /^quotes$/i
handler.limit = 10

export default handler