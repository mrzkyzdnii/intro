let handler = async (m, { text }) => {
  if (!text) {
    return m.reply(`FlamingText Model | Text

> fluffy-logo
> lava-logo
> cool-logo
> comic-logo
> fire-logo
> water-logo
> ice-logo
> elegant-logo
> gold-logo
> blue-logo
> silver-logo
> neon-logo
> sparkle-logo
> retro-logo
> candy-logo
> glossy-logo

Contoh:
.flamingtext fire-logo | Rizky AI`)
  }

  await m.reply("_We will process your request immediately_")

  const model = text.split(" | ")[0]?.trim() || "-"
  const logo = text.split(" | ")[1]?.trim() || "-"

  try {
    const url = `https://flamingtext.com/net-fu/proxy_form.cgi?script=${encodeURIComponent(model)}&text=${encodeURIComponent(logo)}&imageoutput=true&output=direct&doScale=true&scaleWidth=550&scaleHeight=550`

    const res = await fetch(url)
    if (!res.ok) throw new Error("Failed to generate image")

    const buffer = Buffer.from(await res.arrayBuffer())

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `Created by ${m.pushName || "User"}`
      },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    m.reply("Terjadi kesalahan saat membuat logo.")
  }
}

handler.help = ["flamingtext <model> | <text>"]
handler.tags = ["maker"]
handler.command = /^flamingtext$/i
handler.limit = 10
handler.register = true

export default handler