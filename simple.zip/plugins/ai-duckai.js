import { JSDOM } from 'jsdom'

const AVAILABLE_MODELS = {
  gpt: { id: 'gpt-5.4-mini', name: 'GPT-5.4 Mini', vision: true },
  luna: { id: 'gpt-5.6-luna', name: 'GPT-5.6 Luna', vision: true },
  claude: { id: 'claude-haiku-4-5', name: 'Claude Haiku 4.5', vision: false },
  mistral: { id: 'mistral-small-2603', name: 'Mistral Small 4', vision: false },
  gemma: { id: 'tinfoil/gemma4-31b', name: 'Gemma 4 31B', vision: true }
}

const DEFAULT_TEXT_MODEL = 'gpt-5.4-mini'
const DEFAULT_IMAGE_MODEL = 'tinfoil/gemma4-31b'
const DUCK_DOMAIN = 'https://duck.ai'
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'

const solveChallenge = async (rawHash, domain, ua) => {
  const startTime = Date.now()
  const challengeCode = Buffer.from(rawHash, 'base64').toString('utf8')

  const dom = new JSDOM('<!DOCTYPE html><html><body></body></html>', {
    url: `${domain}/`,
    referrer: `${domain}/`,
    runScripts: 'outside-only'
  })

  const { window } = dom
  Object.defineProperty(window.navigator, 'userAgent', { get: () => ua })
  Object.defineProperty(window.navigator, 'webdriver', { get: () => false })

  window.HTMLDivElement.prototype.getBoundingClientRect = () => ({
    width: 24,
    height: 24,
    top: 0,
    left: 0,
    bottom: 24,
    right: 24
  })
  Object.defineProperty(window.HTMLDivElement.prototype, 'offsetWidth', { get: () => 24 })
  Object.defineProperty(window.HTMLDivElement.prototype, 'offsetHeight', { get: () => 24 })
  Object.defineProperty(window.HTMLDivElement.prototype, 'scrollHeight', { get: () => 24 })

  const evalResult = await window.eval(`(${challengeCode})`)

  const clientHashesHashed = await Promise.all(
    evalResult.client_hashes.map(async (item) => {
      const data = new TextEncoder().encode(item)
      const digest = await globalThis.crypto.subtle.digest('SHA-256', data)
      const bytes = new Uint8Array(digest)
      return btoa(bytes.reduce((acc, byte) => acc + String.fromCharCode(byte), ''))
    })
  )

  return Buffer.from(
    JSON.stringify({
      ...evalResult,
      client_hashes: clientHashesHashed,
      meta: {
        ...evalResult.meta,
        origin: domain,
        stack: 'no-stack',
        duration: String(Date.now() - startTime)
      }
    })
  ).toString('base64')
}

const getFreshVqdToken = async (domain, ua) => {
  const statusRes = await fetch(`${domain}/duckchat/v1/status`, {
    headers: {
      'User-Agent': ua,
      'x-vqd-accept': '1',
      'Origin': domain,
      'Referer': `${domain}/`
    }
  })
  const rawHash = statusRes.headers.get('x-vqd-hash-1')
  if (!rawHash) throw new Error('Gagal mendapatkan token verifikasi Duck.ai')
  return await solveChallenge(rawHash, domain, ua)
}

const scraper = async (prompt, options = {}) => {
  let { model, imageBuffer, mimeType } = options
  let targetModel = DEFAULT_TEXT_MODEL

  if (model) {
    const key = model.toLowerCase().replace(/^--/, '')
    if (AVAILABLE_MODELS[key]) {
      targetModel = AVAILABLE_MODELS[key].id
    } else {
      targetModel = model
    }
  } else if (imageBuffer) {
    targetModel = DEFAULT_IMAGE_MODEL
  }

  let userContent
  if (imageBuffer) {
    const mime = mimeType || 'image/png'
    const b64 = Buffer.isBuffer(imageBuffer)
      ? imageBuffer.toString('base64')
      : Buffer.from(imageBuffer).toString('base64')
    const dataUrl = `data:${mime};base64,${b64}`

    userContent = [
      { type: 'text', text: prompt || 'Deskripsikan gambar ini secara detail.' },
      { type: 'image', mimeType: mime, image: dataUrl }
    ]
  } else {
    userContent = [{ type: 'text', text: prompt }]
  }

  const payload = {
    model: targetModel,
    messages: [{ role: 'user', content: userContent }],
    canUploadFiles: !!imageBuffer,
    canUseTools: false,
    reasoningEffort: 'none'
  }

  const signals = Buffer.from(JSON.stringify({ start: Date.now(), events: [], end: 0 })).toString('base64')
  let solvedToken = await getFreshVqdToken(DUCK_DOMAIN, USER_AGENT)

  let finalReply = ''
  const maxAttempts = 4

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const response = await fetch(`${DUCK_DOMAIN}/duckchat/v1/chat`, {
      method: 'POST',
      headers: {
        'User-Agent': USER_AGENT,
        'Accept': 'text/event-stream',
        'Content-Type': 'application/json',
        'Origin': DUCK_DOMAIN,
        'Referer': `${DUCK_DOMAIN}/`,
        'x-fe-version': 'dev-hash',
        'x-fe-signals': signals,
        'x-vqd-hash-1': solvedToken
      },
      body: JSON.stringify(payload)
    })

    const rotatedHash = response.headers.get('x-vqd-hash-1')
    if (rotatedHash) {
      solvedToken = await solveChallenge(rotatedHash, DUCK_DOMAIN, USER_AGENT)
    } else {
      solvedToken = await getFreshVqdToken(DUCK_DOMAIN, USER_AGENT)
    }

    const textStream = await response.text()

    if (response.status === 200 && !textStream.includes('ERR_BN_LIMIT')) {
      const lines = textStream.split('\n')
      for (const line of lines) {
        if (line.startsWith('data: ')) {
          const rawData = line.slice(6).trim()
          if (rawData === '[DONE]') break
          try {
            const parsed = JSON.parse(rawData)
            if (parsed.message) finalReply += parsed.message
          } catch {}
        }
      }
      if (finalReply) return finalReply.trim()
    }

    if (attempt < maxAttempts) {
      await new Promise((resolve) => setTimeout(resolve, 1000 + attempt * 500))
    }
  }

  if (!finalReply) throw new Error('Gagal mendapatkan respon dari Duck.ai')
  return finalReply.trim()
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''

  let imageBuffer = null
  if (/image/.test(mime)) {
    imageBuffer = await q.download()
  }

  if (!text && !imageBuffer) {
    const modelList = Object.entries(AVAILABLE_MODELS)
      .map(([key, val]) => `  • *--${key}* : ${val.name} ${val.vision ? '(Support Gambar)' : '(Teks Saja)'}`)
      .join('\n')

    throw `*DUCK.AI ASSISTANT*

*Format Penggunaan:*
• Chat Teks Biasa:
  ${usedPrefix + command} <pertanyaan>

• Pilih Model Langsung:
  ${usedPrefix + command} --<model> <pertanyaan>

• Analisis Gambar:
  Kirim/balas gambar dengan caption:
  ${usedPrefix + command} <pertanyaan>
  _atau tentukan model:_
  ${usedPrefix + command} --gemma <pertanyaan>

*Daftar Model:*
${modelList}

*Contoh Praktis:*
• ${usedPrefix + command} apa itu black hole?
• ${usedPrefix + command} --gpt jelaskan teori evolusi
• ${usedPrefix + command} --claude buat pantun lucu
• ${usedPrefix + command} --luna analisa kode berikut
• ${usedPrefix + command} --mistral translate ke bahasa jerman
• Balas gambar: ${usedPrefix + command} --gemma deskripsikan ini`
  }

  let selectedModel = null
  let cleanText = (text || '').trim()

  const flagMatch = cleanText.match(/^--([a-zA-Z0-9_-]+)\s*/i)
  if (flagMatch) {
    const flagKey = flagMatch[1].toLowerCase()
    if (AVAILABLE_MODELS[flagKey]) {
      selectedModel = flagKey
      cleanText = cleanText.replace(flagMatch[0], '').trim()
    }
  }

  const result = await scraper(cleanText, {
    model: selectedModel,
    imageBuffer,
    mimeType: mime || 'image/png'
  })

  await conn.reply(m.chat, result, m)
}

handler.help = ['duckai']
handler.tags = ['ai']
handler.command = /^(duckai|duckchat|dak)$/i
handler.limit = 5

export default handler