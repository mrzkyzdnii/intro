const URL_PANTUN = 'https://raw.githubusercontent.com/zxrow/Asupan/refs/heads/main/gabut/pantun2.json'

let cache = []
let lastFetch = 0
const TTL = 5 * 60 * 1000

async function getPantun() {
  const now = Date.now()
  if (cache.length && now - lastFetch < TTL) return cache

  const res = await fetch(URL_PANTUN)
  const json = await res.json()

  if (!Array.isArray(json)) return []

  cache = json
  lastFetch = now
  return cache
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

const handler = async (m, { conn }) => {
  try {
    const list = await getPantun()

    if (!list.length) {
      return m.reply('Pantun lagi kosong 🥀')
    }

    const item = pick(list)

    let text =
      typeof item === 'string'
        ? item
        : item.pantun || item.text || Object.values(item)[0]

    if (typeof text !== 'string') {
      text = JSON.stringify(text)
    }

    const payload = {
      messageContextInfo: {
        threadId: [],
        deviceListMetadata: {
          senderKeyIndexes: [],
          recipientKeyIndexes: []
        },
        deviceListMetadataVersion: 2,
        botMetadata: {
          messageDisclaimerText: '',
          richResponseSourcesMetadata: {
            sources: []
          }
        }
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            submessages: [
              {
                messageType: 8,
                latexMetadata: {
                  expressions: [
                    {
                      latexExpression: text,
                      url: 'https://mmg.whatsapp.net/o1/v/t24/f2/m232/AQPzYMm3MujwSlPkLXqhqiJL28Uove6Bo_gMefsTFdXADg6N1afQk4IRsDIeWeQqpSuY_RYy8BiEJfSnWn39ZfsHNTjX76s_NPOCQC8aHA?ccb=9-4&oh=01_Q5Aa5gGAx_z9AmmC6cQ9LEW0GFJeOPSQZyEWRxumIJ7Y7ejxTg&oe=6ACB17FE&_nc_sid=e6ed6c&mms3=true',
                      width: 261,
                      height: 64,
                      fontHeight: 24,
                      imageTopPadding: 0,
                      imageLeadingPadding: 0,
                      imageBottomPadding: 0,
                      imageTrailingPadding: 0
                    }
                  ],
                  text
                }
              }
            ],
            messageType: 1,
            unifiedResponse: {
              data: Buffer.from('', 'base64')
            },
            contextInfo: {
              mentionedJid: [],
              groupMentions: [],
              statusAttributions: [],
              forwardingScore: 1,
              isForwarded: true,
              featureEligibilities: {
                canBeReshared: true
              },
              forwardedAiBotMessageInfo: {
                botJid: '0@bot'
              },
              forwardOrigin: 4
            }
          }
        }
      }
    }

    await conn.relayMessage(m.chat, payload, {
      messageId: m.id
    })
  } catch {
    await m.reply('Gagal mengambil pantun 🥀')
  }
}

handler.help = ['pantun']
handler.tags = ['quotes']
handler.command = /^pantun$/i
handler.limit = 10

export default handler