const getRawText = m => {
    try {
        if (m.message?.extendedTextMessage?.text) {
            return m.message.extendedTextMessage.text
        }

        if (m.message?.conversation) {
            return m.message.conversation
        }

        if (m.message?.imageMessage?.caption) {
            return m.message.imageMessage.caption
        }

        if (m.message?.videoMessage?.caption) {
            return m.message.videoMessage.caption
        }

        return m.text || ''
    } catch {
        return m.text || ''
    }
}

const getLidFromPn = async (conn, pn) => {
    try {
        pn = pn.replace(/[^0-9]/g, '')
        if (!pn) return null

        if (conn.signalRepository?.lidMapping?.getLIDForPN) {
            const lid = await conn.signalRepository.lidMapping.getLIDForPN(
                `${pn}@s.whatsapp.net`
            )

            if (lid) {
                return lid.endsWith('@lid')
                    ? lid
                    : `${lid}@lid`
            }
        }
    } catch (e) {
        console.error('getLidFromPn:', e)
    }

    return null
}

const getPnFromLid = async (conn, lid) => {
    try {
        lid = lid.replace(/@lid$/i, '')

        if (conn.signalRepository?.lidMapping?.getPNForLID) {
            const pn = await conn.signalRepository.lidMapping.getPNForLID(
                `${lid}@lid`
            )

            if (pn) {
                return pn.endsWith('@s.whatsapp.net')
                    ? pn
                    : `${pn}@s.whatsapp.net`
            }
        }
    } catch (e) {
        console.error('getPnFromLid:', e)
    }

    return null
}

const normalizeJid = jid => {
    if (!jid) return null

    jid = String(jid).trim()
    jid = jid.split(':')[0]

    if (/@lid$/i.test(jid)) {
        return jid
    }

    if (/@s\.whatsapp\.net$/i.test(jid)) {
        return jid
    }

    if (/^\d+$/.test(jid)) {
        return `${jid}@s.whatsapp.net`
    }

    return jid
}

const findUserKey = async (conn, jid, users) => {
    jid = normalizeJid(jid)

    if (!jid) return null

    if (users[jid]) {
        return jid
    }

    // PN -> LID
    if (jid.endsWith('@s.whatsapp.net')) {
        const lid = await getLidFromPn(conn, jid)

        if (lid && users[lid]) {
            return lid
        }

        return lid || jid
    }

    // LID -> PN
    if (jid.endsWith('@lid')) {
        const pn = await getPnFromLid(conn, jid)

        if (pn && users[pn]) {
            return pn
        }

        return jid
    }

    return jid
}

const getTarget = async (m, targetText) => {
    // =====================================================
    // REPLY
    // =====================================================
    if (m.quoted) {
        const jid =
            m.quoted.sender ||
            m.quoted.participant ||
            m.quoted.key?.participant

        if (jid) {
            return normalizeJid(jid)
        }
    }

    // =====================================================
    // MENTION
    // =====================================================
    if (m.mentionedJid?.length) {
        return normalizeJid(m.mentionedJid[0])
    }

    // =====================================================
    // NOMOR / JID
    // =====================================================
    targetText = String(targetText || '').trim()

    if (!targetText) return null

    let target = targetText.split(/\s+/)[0]

    target = target.replace(/^@/, '')

    return normalizeJid(target)
}

/**
 * Ambil nama TARGET, bukan nama pengirim command.
 *
 * Jangan menggunakan m.pushName di sini karena:
 * m.pushName = nama orang yang mengirim command.
 */
const getTargetName = async (conn, m, targetJid, finalKey) => {
    try {
        // =================================================
        // 1. Kalau reply, ambil nama dari quoted
        // =================================================
        if (m.quoted) {
            if (m.quoted.name) {
                return m.quoted.name
            }

            if (m.quoted.pushName) {
                return m.quoted.pushName
            }
        }

        // =================================================
        // 2. Cari dari contact menggunakan TARGET JID
        // =================================================
        const possibleJids = [
            targetJid,
            finalKey
        ].filter(Boolean)

        for (const jid of possibleJids) {
            const contact =
                conn.contacts?.[jid] ||
                conn.store?.contacts?.[jid]

            if (contact) {
                if (contact.name) {
                    return contact.name
                }

                if (contact.notify) {
                    return contact.notify
                }

                if (contact.vname) {
                    return contact.vname
                }
            }
        }

        // =================================================
        // 3. getName() Baileys
        // =================================================
        if (typeof conn.getName === 'function') {
            for (const jid of possibleJids) {
                try {
                    const name = await conn.getName(jid)

                    if (
                        name &&
                        name !== jid &&
                        !name.includes('@s.whatsapp.net') &&
                        !name.includes('@lid')
                    ) {
                        return name
                    }
                } catch {}
            }
        }

        // =================================================
        // 4. Cari di participants metadata
        // =================================================
        const mentioned =
            m.message?.extendedTextMessage
                ?.contextInfo
                ?.mentionedJid || []

        if (mentioned.length) {
            const index = mentioned.findIndex(
                jid => normalizeJid(jid) === normalizeJid(targetJid)
            )

            if (index !== -1) {
                const participant =
                    m.message?.extendedTextMessage
                        ?.contextInfo
                        ?.participant

                if (participant) {
                    const contact =
                        conn.contacts?.[participant] ||
                        conn.store?.contacts?.[participant]

                    if (contact?.name) {
                        return contact.name
                    }

                    if (contact?.notify) {
                        return contact.notify
                    }
                }
            }
        }
    } catch (e) {
        console.error('getTargetName:', e)
    }

    // =====================================================
    // 5. FALLBACK
    // =====================================================
    return (
        targetJid?.split('@')[0] ||
        finalKey?.split('@')[0] ||
        'Unknown User'
    )
}

let handler = async (m, { conn, text, command }) => {
    const users = global.db.data.users

    if (!users) {
        throw 'Database users tidak ditemukan.'
    }

    const isBan = /^ban(user)?$/i.test(command)
    const isUnban = /^unban(user)?$/i.test(command)

    // =====================================================
    // RAW MESSAGE
    // =====================================================
    const raw = getRawText(m)

    const body = raw
        .replace(
            /^[.!#/]?(?:banuser|ban|unbanuser|unban)\b/i,
            ''
        )
        .trim()

    // =====================================================
    // BAN
    // =====================================================
    if (isBan) {
        if (!body.includes('|')) {
            throw `╭─「 🚫 *BAN* 」
│
│ ❌ Format tidak valid.
│
├─ *Contoh:*
│ .ban @user | spam
│ .ban 628xxx | percobaan
│ .ban reply | pelanggaran
│
╰─────────────`
        }

        const separatorIndex = body.indexOf('|')

        const targetText = body
            .slice(0, separatorIndex)
            .trim()

        const reason = body
            .slice(separatorIndex + 1)
            .trim()

        if (!reason) {
            throw `╭─「 🚫 *BAN* 」
│
│ ❌ Alasan tidak boleh kosong.
│
├─ *Contoh:*
│ .ban @user | spam
│
╰─────────────`
        }

        // =================================================
        // TARGET
        // =================================================
        const target = await getTarget(
            m,
            targetText
        )

        if (!target) {
            throw `╭─「 🚫 *BAN* 」
│
│ ❌ Target tidak ditemukan.
│
╰─────────────`
        }

        // =================================================
        // DATABASE KEY
        // =================================================
        const userKey = await findUserKey(
            conn,
            target,
            users
        )

        if (!userKey) {
            throw 'User tidak ditemukan.'
        }

        let dbUser = users[userKey]
        let finalKey = userKey

        // =================================================
        // PN / LID PAIR
        // =================================================
        if (!dbUser) {
            // LID -> PN
            if (userKey.endsWith('@lid')) {
                const pn = await getPnFromLid(
                    conn,
                    userKey
                )

                if (pn && users[pn]) {
                    dbUser = users[pn]
                    finalKey = pn
                }
            }

            // PN -> LID
            if (
                !dbUser &&
                userKey.endsWith('@s.whatsapp.net')
            ) {
                const lid = await getLidFromPn(
                    conn,
                    userKey
                )

                if (lid && users[lid]) {
                    dbUser = users[lid]
                    finalKey = lid
                }
            }
        }

        if (!dbUser) {
            throw `╭─「 🚫 *BAN FAILED* 」
│
│ ❌ User tidak ditemukan.
│
│ 🆔 ${userKey}
│
╰─────────────`
        }

        // =================================================
        // NAMA TARGET
        // =================================================
        const displayName = await getTargetName(
            conn,
            m,
            target,
            finalKey
        )

        // =================================================
        // BAN
        // =================================================
        dbUser.banned = true
        dbUser.banReason = reason

        return conn.reply(
            m.chat,
            `╭─「 🚫 *BAN SUCCESS* 」
│
│ 👤 *User*
│ ${displayName}
│
│ 🆔 *ID*
│ ${finalKey}
│
│ 📝 *Alasan*
│ ${reason}
│
│ 🔒 Status: User diblokir
│
╰─────────────`,
            m
        )
    }

    // =====================================================
    // UNBAN
    // =====================================================
    if (isUnban) {
        const target = await getTarget(
            m,
            body
        )

        if (!target) {
            throw `╭─「 🔓 *UNBAN* 」
│
│ ❌ Target tidak ditemukan.
│
├─ *Contoh:*
│ .unban @user
│ .unban 628xxx
│ .unban reply
│
╰─────────────`
        }

        // =================================================
        // DATABASE KEY
        // =================================================
        const userKey = await findUserKey(
            conn,
            target,
            users
        )

        if (!userKey) {
            throw 'User tidak ditemukan.'
        }

        let dbUser = users[userKey]
        let finalKey = userKey

        // =================================================
        // PN / LID PAIR
        // =================================================
        if (!dbUser) {
            // LID -> PN
            if (userKey.endsWith('@lid')) {
                const pn = await getPnFromLid(
                    conn,
                    userKey
                )

                if (pn && users[pn]) {
                    dbUser = users[pn]
                    finalKey = pn
                }
            }

            // PN -> LID
            if (
                !dbUser &&
                userKey.endsWith('@s.whatsapp.net')
            ) {
                const lid = await getLidFromPn(
                    conn,
                    userKey
                )

                if (lid && users[lid]) {
                    dbUser = users[lid]
                    finalKey = lid
                }
            }
        }

        if (!dbUser) {
            throw `╭─「 🔓 *UNBAN FAILED* 」
│
│ ❌ User tidak ditemukan.
│
│ 🆔 ${userKey}
│
╰─────────────`
        }

        // =================================================
        // NAMA TARGET
        // =================================================
        const displayName = await getTargetName(
            conn,
            m,
            target,
            finalKey
        )

        // =================================================
        // CHECK STATUS
        // =================================================
        if (!dbUser.banned) {
            return conn.reply(
                m.chat,
                `╭─「 🔓 *UNBAN* 」
│
│ 👤 *User*
│ ${displayName}
│
│ 🆔 *ID*
│ ${finalKey}
│
│ ℹ️ Status: Tidak sedang di-ban
│
╰─────────────`,
                m
            )
        }

        // =================================================
        // UNBAN
        // =================================================
        dbUser.banned = false
        delete dbUser.banReason

        return conn.reply(
            m.chat,
            `╭─「 🔓 *UNBAN SUCCESS* 」
│
│ 👤 *User*
│ ${displayName}
│
│ 🆔 *ID*
│ ${finalKey}
│
│ ✅ Status: User berhasil di-unban
│
╰─────────────`,
            m
        )
    }
}

handler.help = ['ban', 'unban']
handler.tags = ['owner']
handler.command = /^(ban|banuser|unban|unbanuser)$/i
handler.rowner = true
handler.limit = 10

export default handler