import cp, { exec as _exec } from 'child_process'
import { promisify } from 'util'
import { generateWAMessageFromContent, proto } from '@mrzkyzdnii/baileys'

let exec = promisify(_exec).bind(cp)

const sendCode = async (conn, m, code, filename, language = 'javascript') => {
  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `📦 *PLUGIN: ${filename}*\n\n\`\`\`${language}\n${code}\n\`\`\``,
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: 'MRZKYZDNII • Get Plugin',
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: '📋 Copy Code',
                    copy_code: code,
                  }),
                },
              ],
            }),
          }),
        },
      },
    },
    {},
  )

  await conn.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id,
  })
}

let handler = async (m, { conn, isROwner, usedPrefix, command, text }) => {
  if (!isROwner) return
  if (!text) throw `uhm.. where the text?\n\nexample:\n${usedPrefix + command} menu`

  await m.reply(global.wait)

  let ar = Object.keys(global.plugins)
  let ar1 = ar.map(v => v.replace('.js', ''))

  if (!ar1.includes(text)) {
    let list = ar1.map(v => `• ${v}`).join('\n')
    return m.reply(
      `❌ *Plugin Tidak Ditemukan*\n\n` +
      `📦 *Daftar Plugin:*\n${list}`
    )
  }

  let o
  try {
    o = await exec('cat plugins/' + text + '.js')
  } catch (e) {
    o = e
  }

  let { stdout, stderr } = o

  if (stdout) {
    await sendCode(conn, m, stdout.trim(), `${text}.js`, 'javascript')
  }

  if (stderr) {
    await sendCode(conn, m, stderr.trim(), `${text}.js`, 'bash')
  }
}

handler.help = ['getplugin']
handler.tags = ['owner']
handler.command = /^(getplugin|gp)$/i
handler.rowner = true
handler.limit = 10

export default handler