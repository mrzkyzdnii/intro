import { createCanvas, loadImage } from '@napi-rs/canvas'
import axios from 'axios'

const TEMPLATE_URL = 'https://cdn.nekohime.site/file/gx8ksl1f.jpeg'

const fakecall = async (name = 'avosky', duration = '20.30', profileUrl = '') => {
    // 1. Load Gambar Background Template Utama
    const templateRes = await axios.get(TEMPLATE_URL, { responseType: 'arraybuffer' })
    const templateImg = await loadImage(Buffer.from(templateRes.data))

    const width = templateImg.width
    const height = templateImg.height
    const canvas = createCanvas(width, height)
    const ctx = canvas.getContext('2d')

    // Gambar template asli sebagai dasar
    ctx.drawImage(templateImg, 0, 0, width, height)

    // 2. Lingkaran Foto Profil di Tengah
    const avatarX = width / 2
    const avatarY = height * 0.425
    const avatarRadius = width * 0.28

    let loaded = false
    if (profileUrl && profileUrl.trim()) {
        try {
            const res = await axios.get(profileUrl, { responseType: 'arraybuffer' })
            const userImg = await loadImage(Buffer.from(res.data))

            ctx.save()
            ctx.beginPath()
            ctx.arc(avatarX, avatarY, avatarRadius, 0, Math.PI * 2)
            ctx.closePath()
            ctx.clip()

            // Menyesuaikan rasio foto profil agar pas di lingkaran
            const aspect = userImg.width / userImg.height
            let drawW = avatarRadius * 2
            let drawH = avatarRadius * 2
            let drawX = avatarX - avatarRadius
            let drawY = avatarY - avatarRadius

            if (aspect > 1) {
                drawW = drawH * aspect
                drawX = avatarX - drawW / 2
            } else {
                drawH = drawW / aspect
                drawY = avatarY - drawH / 2
            }

            ctx.drawImage(userImg, drawX, drawY, drawW, drawH)
            ctx.restore()
            loaded = true
        } catch (e) {
            loaded = false
        }
    }

    if (!loaded) {
        // Inisial Nama jika gambar gagal di-load
        ctx.save()
        ctx.beginPath()
        ctx.arc(avatarX, avatarY, avatarRadius, 0, Math.PI * 2)
        ctx.fillStyle = '#3d2622'
        ctx.fill()

        const letter = (name || 'A').charAt(0).toUpperCase()
        ctx.fillStyle = '#ffab91'
        ctx.font = `bold ${Math.round(avatarRadius * 0.8)}px sans-serif`
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        ctx.fillText(letter, avatarX, avatarY)
        ctx.restore()
    }

    // 3. Menutup teks lama & Menuliskan Nama + Durasi Baru
    // Mengambil patch doodle dari bagian background yang bersih agar 100% transparan & seamless
    const patchX = width * 0.2
    const patchY = height * 0.18
    const patchW = width * 0.6
    const patchH = height * 0.075
    const targetY = height * 0.048

    ctx.drawImage(templateImg, patchX, patchY, patchW, patchH, patchX, targetY, patchW, patchH)

    // Menuliskan Nama Panggilan baru
    ctx.fillStyle = '#f1f5f9'
    ctx.font = `bold ${Math.round(width * 0.045)}px sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'alphabetic'
    ctx.fillText(name, width / 2, height * 0.072)

    // Menuliskan Durasi Panggilan
    ctx.fillStyle = '#8696a0'
    ctx.font = `${Math.round(width * 0.03)}px sans-serif`
    const formattedDuration = duration.replace('.', ':')
    ctx.fillText(formattedDuration, width / 2, height * 0.095)

    return canvas.toBuffer('image/png')
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Example:\n${usedPrefix + command} avosky | 20.30 | https://cdn.nekohime.site/file/rjj7sxzt.jpeg`

    const [nama, duration, profileUrl] = text.split('|').map(v => v.trim())

    if (!nama) throw 'Masukkan nama panggilannya!'

    const imageBuffer = await fakecall(nama, duration || '0:25', profileUrl || '')

    await conn.sendFile(m.chat, imageBuffer, 'fakecall.png', `Call from ${nama}`, m)
}

handler.help = ['fakecall']
handler.tags = ['maker']
handler.command = /^(fakecall)$/i

handler.limit = 10
export default handler