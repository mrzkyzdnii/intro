import axios from 'axios'

const decodeHtml = (str) => {
  if (!str) return ''
  return str
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCharCode(parseInt(h, 16)))
    .replace(/&#([0-9]+);/gi, (_, d) => String.fromCharCode(parseInt(d, 10)))
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
}

const parseDuration = (sec) => {
  const m = Math.floor(sec / 60)
  const s = Math.floor(sec % 60)
  return `${m}:${s.toString().padStart(2, '0')} (${sec}s)`
}

const parseViews = (str) => {
  if (!str) return null
  const decoded = decodeHtml(str)
  const pattern = new RegExp('([0-9.,]+)\\s*([KMBkmb]|rb|jt|miliar)?\\s*(views|tayangan)', 'i')
  const m = decoded.match(pattern)
  if (!m) return null
  const rawNum = m[1].replace(/,/g, '.')
  const unit = (m[2] || '').toLowerCase()
  let num = parseFloat(rawNum)
  let label = m[1] + (m[2] ? m[2].toUpperCase() : '')
  if (unit === 'k' || unit === 'rb') {
    num = Math.round(num * 1000)
    label = m[1] + 'K'
  } else if (unit === 'm' || unit === 'jt') {
    num = Math.round(num * 1000000)
    label = m[1] + 'M'
  } else if (unit === 'b' || unit === 'miliar') {
    num = Math.round(num * 1000000000)
    label = m[1] + 'B'
  }
  return `${label} (${num})`
}

const scraper = async (fbUrl) => {
  const response = await axios.get(fbUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'sec-fetch-site': 'none',
      'sec-fetch-mode': 'navigate',
      'sec-fetch-user': '?1',
      'sec-fetch-dest': 'document'
    },
    maxRedirects: 5
  })

  const html = typeof response.data === 'string' ? response.data : ''
  const finalUrl = response.request?.res?.responseUrl || fbUrl

  const ogTitle = decodeHtml(html.match(/<meta[^>]*property="og:title"[^>]*content="([^"]*)"/i)?.[1] || '')
  const ogDesc = decodeHtml(html.match(/<meta[^>]*(?:property="og:description"|name="description")[^>]*content="([^"]*)"/i)?.[1] || '')
  const ogUrl = decodeHtml(html.match(/<meta[^>]*property="og:url"[^>]*content="([^"]*)"/i)?.[1] || '')

  const scriptRegex = new RegExp('<script[^>]*data-sjs[^>]*>([\\s\\S]*?)<\\/script>', 'gi')
  let match
  let videoData = null
  let feedbackData = null

  while ((match = scriptRegex.exec(html)) !== null) {
    const content = match[1]
    if (!videoData && (content.includes('videoDeliveryLegacyFields') || content.includes('short_form_video_context'))) {
      try {
        const json = JSON.parse(content)
        const findObj = (obj) => {
          if (!obj || typeof obj !== 'object' || videoData) return
          if (obj.creation_story && obj.creation_story.short_form_video_context) {
            videoData = obj.creation_story
            return
          }
          for (const k of Object.keys(obj)) findObj(obj[k])
        }
        findObj(json)
      } catch (e) {}
    }

    if (content.includes('total_comment_count') || (content.includes('likers') && content.includes('unified_reactors'))) {
      try {
        const json = JSON.parse(content)
        const findFeedback = (obj) => {
          if (!obj || typeof obj !== 'object' || feedbackData) return
          if (obj.feedback && (obj.feedback.total_comment_count !== undefined || obj.fb_reel_react_button)) {
            feedbackData = obj
            return
          }
          if (obj.total_comment_count !== undefined && obj.share_count_reduced !== undefined) {
            feedbackData = { feedback: obj }
            return
          }
          for (const k of Object.keys(obj)) findFeedback(obj[k])
        }
        findFeedback(json)
      } catch (e) {}
    }
  }

  const sdUrl = videoData?.short_form_video_context?.playback_video?.videoDeliveryLegacyFields?.browser_native_sd_url ||
    html.match(/"browser_native_sd_url":"([^"]+)"/)?.[1]?.replace(/\\/g, '')
  const hdUrl = videoData?.short_form_video_context?.playback_video?.videoDeliveryLegacyFields?.browser_native_hd_url ||
    html.match(/"browser_native_hd_url":"([^"]+)"/)?.[1]?.replace(/\\/g, '')

  const id = videoData?.short_form_video_context?.video?.id ||
    html.match(/"video_id":"([0-9]+)"/)?.[1] ||
    finalUrl.match(/reel\/([0-9]+)/)?.[1]

  const sfvc = videoData?.short_form_video_context || {}
  const pv = sfvc.playback_video || {}
  const owner = sfvc.video_owner || {}

  const rxPattern = new RegExp('([0-9.,]+)\\s*([KMBkmb]|rb|jt)?\\s*(reactions|tanggapan)', 'i')
  const likes = feedbackData?.fb_reel_react_button?.story?.feedback?.likers?.count ??
    parseInt(ogTitle.match(rxPattern)?.[1] || html.match(/"likers":\{"count":([0-9]+)\}/)?.[1] || '0')
  const comments = feedbackData?.feedback?.total_comment_count ??
    parseInt(html.match(/"total_comment_count":([0-9]+)/)?.[1] || '0')
  const shares = parseInt(feedbackData?.feedback?.share_count_reduced || html.match(/"share_count_reduced":"?([0-9]+)"?/)?.[1] || '0')

  const durationSec = pv.length_in_second || Math.round((sfvc.video?.playable_duration_in_ms || 0) / 1000)
  const audioLang = pv.dubbed_track_mapping?.[0]?.audio_lang
  let subtitleLang = 'Bahasa Indonesia'
  if (audioLang) {
    try {
      subtitleLang = new Intl.DisplayNames(['id'], { type: 'language' }).of(audioLang)
    } catch (e) {
      subtitleLang = audioLang
    }
  }

  const result = {
    id,
    title: ogTitle,
    caption: videoData?.message?.text || ogDesc,
    owner: owner.name || html.match(/"video_owner":\{[^}]*"name":"([^"]+)"/)?.[1] || null,
    ownerId: owner.id || sfvc.video?.owner?.id || null,
    url: `https://www.facebook.com/reel/${id}/`,
    watchUrl: ogUrl ? ogUrl.replace('web.facebook.com', 'www.facebook.com') : null,
    uploaded: videoData?.creation_time ? new Date(videoData.creation_time * 1000).toISOString() : null,
    privacy: videoData?.privacy_scope?.label || 'Public',
    duration: durationSec ? parseDuration(durationSec) : null,
    resolution: pv.width && pv.height ? `${pv.width}x${pv.height}` : null,
    views: parseViews(ogTitle),
    likes,
    comments,
    shares,
    originalAudio: sfvc.is_original_audio_on_facebook ?? true,
    remixable: sfvc.remix_info?.is_remixable ?? false,
    thumbnail: sfvc.video?.first_frame_thumbnail || pv.thumbnailImage?.uri || null,
    subtitles: subtitleLang,
    videos: []
  }

  if (hdUrl) {
    const bitrateMatch = hdUrl.match(/bitrate=([0-9]+)/)
    const bitrateKbps = bitrateMatch ? Math.round(parseInt(bitrateMatch[1]) / 1000) : null
    result.videos.push({
      quality: 'hd',
      bitrate: bitrateKbps ? `${bitrateKbps}kbps` : null,
      codec: 'h264',
      url: hdUrl
    })
  }

  if (sdUrl) {
    const bitrateMatch = sdUrl.match(/bitrate=([0-9]+)/)
    const bitrateKbps = bitrateMatch ? Math.round(parseInt(bitrateMatch[1]) / 1000) : null
    result.videos.push({
      quality: 'sd',
      bitrate: bitrateKbps ? `${bitrateKbps}kbps` : null,
      codec: 'h264',
      url: sdUrl
    })
  }

  return result
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} https://www.facebook.com/share/v/1LiqWQpJs5/`

  const result = await scraper(text)

  const caption = `*Reel:* ${result.id}
*Title:* ${result.title}
*Caption:* ${result.caption}
*Owner:* ${result.owner} (${result.ownerId})
*Duration:* ${result.duration}
*Resolution:* ${result.resolution}
*Views:* ${result.views || '-'}
*Likes:* ${result.likes}
*Comments:* ${result.comments}
*Shares:* ${result.shares}`

  const targetVideo = result.videos?.[0]?.url || result.videos?.[1]?.url

  if (targetVideo) {
    await conn.sendFile(m.chat, targetVideo, `${result.id}.mp4`, caption, m)
  } else {
    await conn.reply(m.chat, caption, m)
  }
}

handler.help = ['fb']
handler.tags = ['downloader']
handler.command = /^(fb)$/i
handler.limit = 10

export default handler