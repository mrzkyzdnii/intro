import axios from 'axios'
import * as cheerio from 'cheerio'
import FormData from 'form-data'
import querystring from 'querystring'
import fs from 'fs'
import path from 'path'

// File database style lokal agar penambahan dinamis tersimpan permanen
const DB_PATH = path.resolve('./data/src/ephoto_styles.json')

// Database default awal
const defaultStyles = [
  { title: "Dragon Ball Style", url: "https://en.ephoto360.com/create-dragon-ball-style-text-effects-online-809.html" },
  { title: "3D Wooden Style", url: "https://en.ephoto360.com/3d-wooden-text-effects-online-104.html" },
  { title: "Glossy Silver 3D", url: "https://en.ephoto360.com/create-glossy-silver-3d-text-effect-online-802.html" },
  { title: "Typography Pavement", url: "https://en.ephoto360.com/create-typography-text-effect-on-pavement-online-774.html" },
  { title: "Digital Glitch Text", url: "https://en.ephoto360.com/create-digital-glitch-text-effects-online-767.html" },
  { title: "Wet Glass Text", url: "https://en.ephoto360.com/write-text-on-wet-glass-online-589.html" },
  { title: "Typography Multilayer Art", url: "https://en.ephoto360.com/create-online-typography-art-effects-with-multiple-layers-811.html" },
  { title: "Naruto Shippuden Logo", url: "https://en.ephoto360.com/naruto-shippuden-logo-style-text-effect-online-808.html" },
  { title: "3D Foil Balloon", url: "https://en.ephoto360.com/beautiful-3d-foil-balloon-effects-for-holidays-and-birthday-803.html" },
  { title: "Pixel Glitch Text", url: "https://en.ephoto360.com/create-pixel-glitch-text-effect-online-769.html" },
  { title: "Neon Glitch Text", url: "https://en.ephoto360.com/create-impressive-neon-glitch-text-effects-online-768.html" },
  { title: "American Flag 3D", url: "https://en.ephoto360.com/free-online-american-flag-3d-text-effect-generator-725.html" },
  { title: "Eraser Deleting Text", url: "https://en.ephoto360.com/create-eraser-deleting-text-effect-online-717.html" },
  { title: "Blackpink Style Logo", url: "https://en.ephoto360.com/online-blackpink-style-logo-maker-effect-711.html" },
  { title: "Glowing Text Effects", url: "https://en.ephoto360.com/create-glowing-text-effects-online-706.html" },
  { title: "3D Underwater Text", url: "https://en.ephoto360.com/3d-underwater-text-effect-online-682.html" },
  { title: "Bear Logo Maker", url: "https://en.ephoto360.com/free-bear-logo-maker-online-673.html" },
  { title: "Realistic Embroidery Text", url: "https://en.ephoto360.com/create-a-realistic-embroidery-text-effect-online-662.html" },
  { title: "Watercolor Text Effect", url: "https://en.ephoto360.com/create-a-watercolor-text-effect-online-655.html" },
  { title: "Blackpink Logo Free", url: "https://en.ephoto360.com/create-blackpink-logo-online-free-607.html" },
  { title: "3D Gradient Text", url: "https://en.ephoto360.com/create-3d-gradient-text-effect-online-600.html" },
  { title: "Write In Sand Beach", url: "https://en.ephoto360.com/write-in-sand-summer-beach-online-595.html" },
  { title: "Luxury Gold 3D Text", url: "https://en.ephoto360.com/create-a-luxury-gold-text-effect-online-594.html" },
  { title: "Write In Sand Summer", url: "https://en.ephoto360.com/write-in-sand-summer-beach-online-576.html" },
  { title: "Galaxy Wallpaper Mobile", url: "https://en.ephoto360.com/create-galaxy-wallpaper-mobile-online-528.html" },
  { title: "1917 Movie Style", url: "https://en.ephoto360.com/1917-style-text-effect-523.html" },
  { title: "Neon Light Galaxy", url: "https://en.ephoto360.com/making-neon-light-text-effect-with-galaxy-style-521.html" },
  { title: "Royal Gold Text", url: "https://en.ephoto360.com/royal-text-effect-online-free-471.html" },
  { title: "Galaxy Style Free Logo", url: "https://en.ephoto360.com/create-galaxy-style-free-name-logo-438.html" },
  { title: "Green Neon Light", url: "https://en.ephoto360.com/create-light-effects-green-neon-online-429.html" },
  { title: "Titanium iPhone 15 Text", url: "https://en.ephoto360.com/create-the-titanium-text-effect-to-introduce-iphone-15-812.html" },
  { title: "Sunset Light Text", url: "https://en.ephoto360.com/create-sunset-light-text-effects-online-807.html" },
  { title: "3D Metal Decorative", url: "https://en.ephoto360.com/impressive-decorative-3d-metal-text-effect-798.html" },
  { title: "Glittering 3D Golden", url: "https://en.ephoto360.com/christmas-and-new-year-glittering-3d-golden-text-effect-794.html" },
  { title: "Nigeria Flag 3D Text", url: "https://en.ephoto360.com/nigeria-3d-flag-text-effect-online-free-753.html" },
  { title: "Blackpink Neon Logo", url: "https://en.ephoto360.com/create-a-blackpink-neon-logo-text-effect-online-710.html" },
  { title: "Broken Glass Text", url: "https://en.ephoto360.com/create-broken-glass-text-effect-online-698.html" },
  { title: "3D Gradient Color Text", url: "https://en.ephoto360.com/create-3d-gradient-text-effect-online-686.html" },
  { title: "3D Shiny Metallic", url: "https://en.ephoto360.com/create-a-3d-shiny-metallic-text-effect-online-685.html" },
  { title: "Neon Devil Wings", url: "https://en.ephoto360.com/neon-devil-wings-text-effect-online-683.html" },
  { title: "Snow 3D Text Effect", url: "https://en.ephoto360.com/create-a-snow-3d-text-effect-free-online-621.html" },
  { title: "Realistic 3D Sand", url: "https://en.ephoto360.com/realistic-3d-sand-text-effect-online-580.html" }
]

// Fungsi ambil list style yang tersimpan
const getStyles = () => {
  try {
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(defaultStyles, null, 2))
      return defaultStyles
    }
    const raw = fs.readFileSync(DB_PATH, 'utf-8')
    return JSON.parse(raw)
  } catch {
    return defaultStyles
  }
}

// Fungsi simpan list style
const saveStyles = (styles) => {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(styles, null, 2))
  } catch (err) {
    console.error('Gagal menyimpan styles:', err)
  }
}

// Scraper Ephoto360 Single-Text
const scraper = async (pageUrl, text) => {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9,id;q=0.8'
  }

  const getRes = await axios.get(pageUrl, { headers })
  const cookies = getRes.headers['set-cookie']?.map(c => c.split(';')[0]).join('; ') || ''
  const $ = cheerio.load(getRes.data)

  const token = $('input[name="token"]').val()
  const buildServer = $('input[name="build_server"]').val()
  const buildServerId = $('input[name="build_server_id"]').val()

  if (!token || !buildServer) {
    throw new Error('Gagal mengekstrak form token/server dari halaman.')
  }

  const form = new FormData()
  form.append('text[]', text)
  form.append('submit', 'GO')
  form.append('token', token)
  form.append('build_server', buildServer)
  form.append('build_server_id', buildServerId)

  const postRes = await axios.post(pageUrl, form, {
    headers: {
      ...form.getHeaders(),
      'Cookie': cookies,
      'User-Agent': headers['User-Agent'],
      'Referer': pageUrl,
      'Origin': 'https://en.ephoto360.com'
    }
  })

  const cookies2 = postRes.headers['set-cookie'] 
    ? postRes.headers['set-cookie'].map(c => c.split(';')[0]).join('; ') 
    : cookies

  const $post = cheerio.load(postRes.data)
  const formValueRaw = $post('input[name="form_value_input"]').val()

  if (!formValueRaw) {
    throw new Error('Server menolak parameter efek (form_value_input tidak ditemukan).')
  }

  const formDataObj = JSON.parse(formValueRaw)

  const postData = querystring.stringify({
    id: formDataObj.id,
    'text[]': formDataObj.text,
    token: formDataObj.token,
    build_server: formDataObj.build_server,
    build_server_id: formDataObj.build_server_id
  })

  const createRes = await axios.post('https://en.ephoto360.com/effect/create-image', postData, {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'Cookie': cookies2,
      'User-Agent': headers['User-Agent'],
      'Referer': pageUrl,
      'Origin': 'https://en.ephoto360.com',
      'X-Requested-With': 'XMLHttpRequest'
    }
  })

  if (!createRes.data || !createRes.data.success) {
    throw new Error(createRes.data?.info || 'Gagal generate gambar dari Ephoto360.')
  }

  return formDataObj.build_server + createRes.data.image
}

// Bot Handler
const handler = async (m, { conn, text, usedPrefix, command }) => {
  const styles = getStyles()

  if (!text) {
    throw `*乂 E P H O T O  3 6 0  M A K E R*

📌 *Perintah yang Tersedia:*
• *${usedPrefix + command} list* ➔ Melihat semua daftar style
• *${usedPrefix + command} add <url>* ➔ Menambahkan style ephoto baru otomatis
• *${usedPrefix + command} <nomor/nama> | <teks>* ➔ Membuat efek teks

💡 *Contoh:*
• *${usedPrefix + command} 1 | Son Goku*
• *${usedPrefix + command} add https://en.ephoto360.com/3d-wooden-text-effects-online-104.html*`
  }

  const trimmedText = text.trim()

  // 1. FITUR LIST STYLE
  if (trimmedText.toLowerCase() === 'list') {
    let caption = `*乂 E P H O T O  3 6 0  S T Y L E S  (Total: ${styles.length})*\n\n`
    styles.forEach((style, index) => {
      caption += `*${index + 1}.* ${style.title}\n`
    })
    caption += `\n_Gunakan: *${usedPrefix + command} <nomor> | <teks>*_\n_Tambah style: *${usedPrefix + command} add <url>*_`
    return await conn.reply(m.chat, caption.trim(), m)
  }

  // 2. FITUR ADD STYLE OTOMATIS
  if (trimmedText.toLowerCase().startsWith('add')) {
    const targetUrl = trimmedText.slice(3).trim()

    if (!targetUrl || !/^https?:\/\/(en\.)?ephoto360\.com\/.+\.html/i.test(targetUrl)) {
      throw `Link tidak valid! Pastikan link ephoto360 berakhiran .html\nContoh:\n*${usedPrefix + command} add https://en.ephoto360.com/3d-wooden-text-effects-online-104.html*`
    }

    // Cek apakah sudah ada di database
    const isExist = styles.find(s => s.url.toLowerCase() === targetUrl.toLowerCase())
    if (isExist) {
      return await conn.reply(m.chat, `⚠️ udah ada style ny cuy:\n*${isExist.title}* (Nomor ${styles.indexOf(isExist) + 1})`, m)
    }

    await conn.reply(m.chat, '🔍 Memeriksa link dan mengambil judul style...', m)

    try {
      const res = await axios.get(targetUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      })
      const $ = cheerio.load(res.data)

      // Validasi single text input
      const form = $('form.ajax-submit, form[enctype="multipart/form-data"]')
      const textInputs = form.find('input[name="text[]"]')
      const fileInputs = form.find('input[type="file"], input[name="myfile"]')

      if (textInputs.length !== 1 || fileInputs.length > 0) {
        throw new Error('Style ini bukan tipe single-text atau memerlukan upload file gambar.')
      }

      // Ambil judul otomatis
      let autoTitle = $('h1, #effect_title').first().text().trim()
      if (!autoTitle) {
        autoTitle = $('title').text().replace(/\s*-\s*Ephoto360\.com/gi, '').replace(/\s*online\s*/gi, ' ').trim()
      }

      // Simpan style baru
      const newStyle = { title: autoTitle, url: targetUrl }
      styles.push(newStyle)
      saveStyles(styles)

      return await conn.reply(
        m.chat,
        `✅ *Berhasil Ditambahkan!*\n\n• *Nomor:* ${styles.length}\n• *Title:* ${autoTitle}\n• *URL:* ${targetUrl}\n\nSekarang bisa langsung dipake dengan:\n*${usedPrefix + command} ${styles.length} | teks kamu*`,
        m
      )
    } catch (err) {
      return await conn.reply(m.chat, `❌ Gagal menambahkan style: ${err.message}`, m)
    }
  }

  // 3. FITUR GENERATE TEKS EFEK
  const [styleInput, ...textInputArr] = text.split('|')
  const styleQuery = styleInput?.trim().toLowerCase()
  const customText = textInputArr.join('|').trim()

  if (!styleQuery || !customText) {
    throw `Format salah! Gunakan:\n*${usedPrefix + command} <nomor/nama/link> | <teks>*\n\nContoh:\n*${usedPrefix + command} 1 | Goku*\n*${usedPrefix + command} list*`
  }

  let targetUrl = ''
  const styleIndex = parseInt(styleQuery) - 1

  if (!isNaN(styleIndex) && styles[styleIndex]) {
    targetUrl = styles[styleIndex].url
  } else if (styleQuery.startsWith('http://') || styleQuery.startsWith('https://')) {
    targetUrl = styleInput.trim()
  } else {
    const matched = styles.find(s => s.title.toLowerCase().includes(styleQuery))
    if (matched) {
      targetUrl = matched.url
    } else {
      throw `Style *"${styleInput.trim()}"* tidak ditemukan!\nKetik *${usedPrefix + command} list* untuk melihat daftar style.`
    }
  }

  await conn.reply(m.chat, '⏳ Sedang membuat teks efek, mohon tunggu...', m)

  try {
    const imageUrl = await scraper(targetUrl, customText)
    const isVideo = imageUrl.endsWith('.mp4') || imageUrl.endsWith('.gif')

    await conn.sendFile(
      m.chat,
      imageUrl,
      isVideo ? 'ephoto.mp4' : 'ephoto.jpg',
      `*Ephoto360 Text Effect*\n• *Text:* ${customText}\n• *URL:* ${imageUrl}`,
      m
    )
  } catch (err) {
    await conn.reply(m.chat, `❌ Error: ${err.message}`, m)
  }
}

handler.help = ['ephoto']
handler.tags = ['maker']
handler.command = /^ephoto$/i

export default handler