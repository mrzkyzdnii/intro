import axios from 'axios'

class YtMusic {
static UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36'

static async getMyIp() {
try {
const { data } = await axios.get('https://api.ipify.org', { timeout: 4000 })
return String(data).trim()
} catch {
return null
}
}

static async scraper(url) {
if (!url) throw new Error('URL tidak boleh kosong!')

const clientIp = await this.getMyIp()
const baseHeaders = {
'Content-Type': 'application/x-www-form-urlencoded',
'User-Agent': this.UA,
'Origin': 'https://id.vidssave.com',
'Referer': 'https://id.vidssave.com/youtube-music-download'
}

if (clientIp) {
baseHeaders['X-Forwarded-For'] = clientIp
baseHeaders['Client-IP'] = clientIp
}

const parsePayload = new URLSearchParams({
auth: '20250901majwlqo',
domain: 'api-ak.vidssave.com',
origin: 'source',
link: url
})

let parseRes = await axios.post('https://api.vidssave.com/api/contentsite_api/media/parse', parsePayload.toString(), {
headers: baseHeaders,
timeout: 15000
})

if (!parseRes.data || parseRes.data.status !== 1) {
baseHeaders['X-Forwarded-For'] = '114.124.212.50'
baseHeaders['Client-IP'] = '114.124.212.50'
parseRes = await axios.post('https://api.vidssave.com/api/contentsite_api/media/parse', parsePayload.toString(), {
headers: baseHeaders,
timeout: 15000
})
}

if (!parseRes.data || parseRes.data.status !== 1 || !parseRes.data.data?.resources) {
throw new Error(parseRes.data?.msg || 'Gagal memproses media dari Vidssave')
}

const data = parseRes.data.data
const title = data.title || 'audio'
const duration = data.duration || ''
const resources = data.resources || []

let targetAudio = resources.find(r => r.type === 'audio' && (r.quality.includes('128') || r.quality_index === '128k'))

if (!targetAudio) {
targetAudio = resources.find(r => r.type === 'audio')
}

if (!targetAudio || !targetAudio.resource_content) {
throw new Error('Format audio tidak ditemukan')
}

const dlPayload = new URLSearchParams({
auth: '20250901majwlqo',
domain: 'api-ak.vidssave.com',
origin: 'source',
request: targetAudio.resource_content,
no_encrypt: '1'
})

const dlRes = await axios.post('https://api.vidssave.com/api/contentsite_api/media/download', dlPayload.toString(), {
headers: baseHeaders,
timeout: 15000
})

if (!dlRes.data || dlRes.data.status !== 1 || !dlRes.data.data?.task_id) {
throw new Error(dlRes.data?.msg || 'Gagal membuat task download')
}

const taskId = dlRes.data.data.task_id
const queryUrl = `https://api.vidssave.com/api/contentsite_api/media/download_query?auth=20250901majwlqo&domain=api-ak.vidssave.com&task_id=${encodeURIComponent(taskId)}&download_domain=vidssave.com&origin=content_site`

let downloadUrl = null

for (let i = 0; i < 20; i++) {
await new Promise(resolve => setTimeout(resolve, 1500))

const qRes = await axios.get(queryUrl, {
headers: {
'User-Agent': this.UA,
'Referer': 'https://id.vidssave.com/youtube-music-download'
},
responseType: 'text',
timeout: 10000
})

const body = qRes.data

if (body.includes('"status":"success"')) {
const match = body.match(/"download_link":"([^"]+)"/)

if (match && match[1]) {
downloadUrl = match[1].replace(/\\/g, '')
break
}
} else if (body.includes('"status":"failed"')) {
throw new Error('Konversi audio di server gagal')
}
}

if (!downloadUrl) {
throw new Error('Waktu tunggu proses download habis')
}

let finalUrl = downloadUrl

try {
const headCheck = await axios.get(downloadUrl, {
maxRedirects: 0,
validateStatus: s => s >= 200 && s < 400,
headers: {
'User-Agent': this.UA,
'Referer': 'https://id.vidssave.com/'
},
timeout: 10000
})

if (headCheck.headers?.location) {
finalUrl = headCheck.headers.location
}
} catch (err) {
if (err.response?.headers?.location) {
finalUrl = err.response.headers.location
}
}

const audioStream = await axios.get(finalUrl, {
responseType: 'arraybuffer',
headers: {
'User-Agent': this.UA,
'Referer': 'https://id.vidssave.com/',
'Accept': '*/*'
},
timeout: 30000
})

return {
title,
duration,
quality: targetAudio.quality || '128k',
buffer: Buffer.from(audioStream.data)
}
}

static async handler(m, { conn, text, usedPrefix, command }) {
if (!text) throw `Example:\n${usedPrefix + command} https://music.youtube.com/watch?v=KbQVk18ZYFg`

await conn.reply(m.chat, 'Sedang memproses dan mengunduh audio...', m)

const result = await this.scraper(text)

await conn.sendFile(
m.chat,
result.buffer,
`${result.title}.mp3`,
'',
m,
false,
{ mimetype: 'audio/mpeg' }
)
}
}

const handler = async (m, options) => {
return YtMusic.handler(m, options)
}

handler.help = ['ytmusic']
handler.tags = ['downloader']
handler.command = /^(ytmusic)$/i
handler.limit = 10

export default handler