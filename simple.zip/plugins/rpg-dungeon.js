const COOLDOWN = 3 * 60 * 60 * 1000 // 3 jam

const fmt = (number) =>
    Number(number || 0).toLocaleString('id-ID')

const pickRandom = (array) =>
    array[Math.floor(Math.random() * array.length)]

const randomInt = (min, max) =>
    Math.floor(Math.random() * (max - min + 1)) + min

const sleep = (ms) =>
    new Promise(resolve => setTimeout(resolve, ms))

const clockString = (ms) => {
    ms = Math.max(0, Number(ms) || 0)

    const h = Math.floor(ms / 3600000)
    const m = Math.floor(ms / 60000) % 60
    const s = Math.floor(ms / 1000) % 60

    return `${h} jam ${m} menit ${s} detik`
}

const getName = async (conn, jid) => {
    try {
        return await conn.getName(jid)
    } catch {
        return jid.split('@')[0]
    }
}

const safeNumber = (value, fallback = 0) => {
    const n = Number(value)

    return Number.isFinite(n) ? n : fallback
}

const addItem = (user, key, amount) => {
    amount = safeNumber(amount)

    if (!amount) return

    user[key] = Math.max(
        0,
        safeNumber(user[key]) + amount
    )
}

const createReward = () => {
    return {
        money: randomInt(5000, 15000),
        exp: randomInt(1000, 5000),
        trash: randomInt(50, 500),
        wood: randomInt(2, 10),
        rock: randomInt(2, 10),
        string: randomInt(1, 5),
        iron: randomInt(0, 3),

        diamond: pickRandom([
            0, 0, 0, 0, 0,
            1, 1,
            2
        ]),

        common: pickRandom([
            0, 0, 0, 1, 1, 2
        ]),

        uncommon: pickRandom([
            0, 0, 0, 0, 1, 1
        ]),

        mythic: pickRandom([
            0, 0, 0, 0, 0, 1
        ]),

        legendary: pickRandom([
            0, 0, 0, 0, 0, 1
        ]),

        pet: pickRandom([
            0, 0, 0, 0, 1
        ]),

        petfood: pickRandom([
            0, 0, 1, 1, 2
        ])
    }
}

const createEvents = () => {
    return [
        {
            type: 'damage',
            title: '💥 KECELAKAAN!',
            text: [
                'Kamu terpeleset dan jatuh ke jurang kecil.',
                'Sebuah batu besar jatuh dari atas.',
                'Kamu terkena jebakan tersembunyi.',
                'Seekor monster menyerang secara tiba-tiba.',
                'Kamu terjatuh saat melewati jalan yang licin.',
                'Sebuah anak panah hampir mengenai tubuhmu.'
            ],
            min: 8,
            max: 20
        },

        {
            type: 'damage',
            title: '👹 MONSTER MENYERANG!',
            text: [
                'Monster kecil muncul dari kegelapan.',
                'Seekor monster liar mengejarmu.',
                'Kamu harus bertarung melawan monster.',
                'Monster besar menghadang jalanmu.'
            ],
            min: 10,
            max: 25
        },

        {
            type: 'damage',
            title: '🔥 RUANGAN TERBAKAR!',
            text: [
                'Api tiba-tiba muncul di sekitar dungeon.',
                'Lantai dungeon mulai terbakar.',
                'Asap memenuhi ruangan.'
            ],
            min: 7,
            max: 18
        },

        {
            type: 'damage',
            title: '☠️ JEBakan!',
            text: [
                'Kamu menginjak sebuah jebakan.',
                'Dinding dungeon tiba-tiba bergerak.',
                'Sebuah perangkap kuno aktif.'
            ],
            min: 5,
            max: 15
        },

        {
            type: 'heal',
            title: '💚 SUMBER AIR!',
            text: [
                'Kamu menemukan sumber air misterius.',
                'Kamu menemukan tanaman penyembuh.',
                'Sebuah tempat aman membuat tubuhmu pulih.'
            ],
            min: 5,
            max: 15
        },

        {
            type: 'nothing',
            title: '🌫️ JALAN SEPI',
            text: [
                'Kamu berjalan melewati lorong yang sangat panjang.',
                'Tidak ada apa-apa di ruangan ini.',
                'Kamu menemukan jalan yang aman.',
                'Suasana dungeon tiba-tiba menjadi tenang.'
            ]
        }
    ]
}

const makeHeader = (name, health, maxHealth, eventNumber) => {
    const hpPercent = Math.max(
        0,
        Math.min(100, Math.floor((health / maxHealth) * 100))
    )

    const barLength = 10
    const filled = Math.round(
        (hpPercent / 100) * barLength
    )

    const hpBar =
        '█'.repeat(filled) +
        '░'.repeat(barLength - filled)

    return `
╭━━━━━━━━━━━━━━━━━━━━━━━━╮
│      🏰 *DUNGEON RPG*      │
╰━━━━━━━━━━━━━━━━━━━━━━━━╯

👤 *PLAYER*
│ ${name}

❤️ *HEALTH*
│ ${hpBar}
│ ${fmt(health)} / ${fmt(maxHealth)}

⚔️ *KEJADIAN ${eventNumber}*
`.trim()
}

const makeRewardText = (reward) => {
    let text = `
╭─「 🎁 REWARD 」`

    if (reward.money)
        text += `\n│ 💰 Money      +${fmt(reward.money)}`

    if (reward.exp)
        text += `\n│ ✨ EXP        +${fmt(reward.exp)}`

    if (reward.trash)
        text += `\n│ 🗑️ Trash      +${fmt(reward.trash)}`

    if (reward.wood)
        text += `\n│ 🪵 Wood       +${fmt(reward.wood)}`

    if (reward.rock)
        text += `\n│ 🪨 Rock       +${fmt(reward.rock)}`

    if (reward.string)
        text += `\n│ 🧵 String     +${fmt(reward.string)}`

    if (reward.iron)
        text += `\n│ ⛓️ Iron       +${fmt(reward.iron)}`

    if (reward.diamond)
        text += `\n│ 💎 Diamond    +${fmt(reward.diamond)}`

    if (reward.common)
        text += `\n│ 📦 Common     +${fmt(reward.common)}`

    if (reward.uncommon)
        text += `\n│ 🎁 Uncommon   +${fmt(reward.uncommon)}`

    if (reward.mythic)
        text += `\n│ 🔮 Mythic     +${fmt(reward.mythic)}`

    if (reward.legendary)
        text += `\n│ 👑 Legendary  +${fmt(reward.legendary)}`

    if (reward.pet)
        text += `\n│ 🐾 Pet        +${fmt(reward.pet)}`

    if (reward.petfood)
        text += `\n│ 🍖 Pet Food   +${fmt(reward.petfood)}`

    text += `
╰────────────────────────╯`

    return text
}

let handler = async (m, { conn }) => {
    const users = global.db?.data?.users

    if (!users) {
        return m.reply(
            '❌ Database user belum siap.'
        )
    }

    const user = users[m.sender]

    if (!user) {
        return m.reply(
            '❌ Data pengguna tidak ditemukan.'
        )
    }

    /*
     * =========================
     * NORMALISASI DATA
     * =========================
     */

    user.health = Math.max(
        0,
        safeNumber(user.health, 100)
    )

    user.money = Math.max(
        0,
        safeNumber(user.money)
    )

    user.exp = Math.max(
        0,
        safeNumber(user.exp)
    )

    /*
     * =========================
     * COOLDOWN 3 JAM
     * =========================
     *
     * lastdungeon disimpan di DB.
     * Jadi restart bot tidak mereset cooldown.
     */

    const now = Date.now()
    const lastDungeon = safeNumber(
        user.lastdungeon
    )

    const remaining =
        COOLDOWN -
        (now - lastDungeon)

    if (lastDungeon > 0 && remaining > 0) {
        return m.reply(
            `
╭━━━━━━━━━━━━━━━━━━━━━━╮
│   ⏳ *DUNGEON COOLDOWN*
╰━━━━━━━━━━━━━━━━━━━━━━╯

🏰 Kamu baru saja menyelesaikan
dungeon sebelumnya.

⏱️ *Bisa dungeon lagi dalam:*
> ${clockString(remaining)}

💡 Cooldown tetap tersimpan
meskipun bot direstart.

╰──────────────────────╯
`.trim()
        )
    }

    /*
     * =========================
     * CEK HEALTH
     * =========================
     */

    if (user.health < 1) {
        return m.reply(
            `
╭━━━━━━━━━━━━━━━━━━━━━━╮
│   ❤️ *HEALTH HABIS*
╰━━━━━━━━━━━━━━━━━━━━━━╯

Health kamu sekarang:

❤️ ${fmt(user.health)}

Pulihkan health terlebih dahulu
sebelum masuk dungeon.

💡 Gunakan command heal kamu.
`.trim()
        )
    }

    /*
     * =========================
     * LOCK COOLDOWN
     * =========================
     *
     * Langsung simpan waktu ketika
     * dungeon dimulai supaya user
     * tidak bisa spam command.
     */

    user.lastdungeon = now

    /*
     * =========================
     * DATA DUNGEON
     * =========================
     */

    const name = await getName(
        conn,
        m.sender
    )

    const maxHealth = Math.max(
        100,
        safeNumber(user.health)
    )

    let health = maxHealth

    const events = createEvents()

    /*
     * Batasi jumlah kejadian agar
     * dungeon tidak terlalu panjang.
     */

    const maxEvents = randomInt(7, 12)

    /*
     * =========================
     * PESAN AWAL
     * =========================
     */

    let message = await conn.sendMessage(
        m.chat,
        {
            text: `
╭━━━━━━━━━━━━━━━━━━━━━━━━╮
│      🏰 *DUNGEON RPG*      │
╰━━━━━━━━━━━━━━━━━━━━━━━━╯

👤 *${name}*

🚪 Kamu memasuki dungeon...

🔦 Lorong gelap terbentang
di depanmu.

⚔️ Bersiap menghadapi
berbagai kejadian!

⏳ *Dungeon dimulai...*
`.trim()
        },
        {
            quoted: m
        }
    )

    const key = message?.key

    if (!key) {
        return m.reply(
            '❌ Gagal membuat pesan dungeon.'
        )
    }

    await sleep(1800)

    /*
     * =========================
     * DUNGEON EVENT
     * =========================
     */

    let eventCount = 0
    let completed = false
    let death = false

    for (
        let i = 0;
        i < maxEvents;
        i++
    ) {
        eventCount++

        /*
         * Kalau HP sudah habis,
         * langsung berhenti.
         */

        if (health <= 0) {
            death = true
            break
        }

        const event = pickRandom(events)

        let change = 0
        let description = ''

        if (event.type === 'damage') {
            change = randomInt(
                event.min,
                event.max
            )

            health -= change

            if (health < 0)
                health = 0

            description = `${pickRandom(event.text)}\n\n❤️ Health *-${fmt(change)}*`
        }

        else if (event.type === 'heal') {
            change = randomInt(
                event.min,
                event.max
            )

            const oldHealth = health

            health = Math.min(
                maxHealth,
                health + change
            )

            const actualHeal =
                health - oldHealth

            description = `${pickRandom(event.text)}\n\n💚 Health *+${fmt(actualHeal)}*`
        }

        else {
            description =
                `${pickRandom(event.text)}\n\n✨ Tidak terjadi apa-apa.`
        }

        /*
         * =========================
         * CEK STATUS
         * =========================
         */

        let status = ''

        if (health <= 0) {
            status = `
☠️ *KAMU TUMBANG!*

Health kamu mencapai *0*.
Dungeon berakhir di sini.
`
            death = true
        } else {
            status = `
🚶 Kamu masih bisa melanjutkan
perjalanan...

❤️ Health tersisa:
*${fmt(health)}*
`
        }

        const eventText = `
${makeHeader(
    name,
    health,
    maxHealth,
    eventCount
)}

📖 ${event.title}

${description}

${status}

╰────────────────────────╯
`.trim()

        /*
         * EDIT PESAN YANG SAMA
         */

        await conn.sendMessage(
            m.chat,
            {
                text: eventText,
                edit: key
            }
        )

        /*
         * Kalau mati, jangan lanjut.
         */

        if (death) {
            break
        }

        /*
         * Jeda antar kejadian.
         */

        await sleep(
            randomInt(1800, 3000)
        )
    }

    /*
     * =========================
     * SELESAI / MATI
     * =========================
     */

    user.health = Math.max(
        0,
        Math.floor(health)
    )

    /*
     * Kalau mati, tidak dapat
     * reward besar.
     */

    if (death) {
        const deathText = `
╭━━━━━━━━━━━━━━━━━━━━━━━━╮
│      ☠️ *DUNGEON GAGAL*      │
╰━━━━━━━━━━━━━━━━━━━━━━━━╯

👤 ${name}

💀 Kamu tumbang di dalam dungeon.

❤️ Health:
*0 / ${fmt(maxHealth)}*

📖 Jumlah kejadian:
*${eventCount}*

❌ Tidak mendapatkan reward.

⏳ Dungeon berikutnya:
*3 jam lagi*

💡 Pulihkan health terlebih dahulu.
`.trim()

        await conn.sendMessage(
            m.chat,
            {
                text: deathText,
                edit: key
            }
        )

        return
    }

    /*
     * =========================
     * REWARD
     * =========================
     */

    const reward = createReward()

    addItem(
        user,
        'money',
        reward.money
    )

    addItem(
        user,
        'exp',
        reward.exp
    )

    addItem(
        user,
        'trash',
        reward.trash
    )

    addItem(
        user,
        'wood',
        reward.wood
    )

    addItem(
        user,
        'rock',
        reward.rock
    )

    addItem(
        user,
        'string',
        reward.string
    )

    addItem(
        user,
        'iron',
        reward.iron
    )

    addItem(
        user,
        'diamond',
        reward.diamond
    )

    addItem(
        user,
        'common',
        reward.common
    )

    addItem(
        user,
        'uncommon',
        reward.uncommon
    )

    addItem(
        user,
        'mythic',
        reward.mythic
    )

    addItem(
        user,
        'legendary',
        reward.legendary
    )

    addItem(
        user,
        'pet',
        reward.pet
    )

    addItem(
        user,
        'petfood',
        reward.petfood
    )

    /*
     * =========================
     * FINAL RESULT
     * =========================
     */

    const rewardText = makeRewardText(
        reward
    )

    const finalText = `
╭━━━━━━━━━━━━━━━━━━━━━━━━╮
│    🏆 *DUNGEON SELESAI!*    │
╰━━━━━━━━━━━━━━━━━━━━━━━━╯

👤 *${name}*

🎉 Kamu berhasil keluar
dari dungeon dengan selamat!

📖 Total kejadian:
*${eventCount}*

❤️ Health tersisa:
*${fmt(user.health)} / ${fmt(maxHealth)}*

${rewardText}

⏳ *Dungeon berikutnya*
> 3 jam lagi

💡 Cooldown tetap tersimpan
meskipun bot direstart.

╰━━━━━━━━━━━━━━━━━━━━━━━━╯
`.trim()

    /*
     * EDIT PESAN YANG SAMA
     */

    await conn.sendMessage(
        m.chat,
        {
            text: finalText,
            edit: key
        }
    )
}

handler.help = ['dungeon']
handler.tags = ['rpg']
handler.command = /^dungeon$/i

handler.level = 15
handler.rpg = true
handler.group = true
handler.register = true

export default handler