import axios from 'axios'

/**
 * Search TikTok via DuckDuckGo Video Index (Bypass Cloudflare 403 TikWM Search)
 */
async function searchTikTok(query) {
  const searchUrl = `site:tiktok.com ${query}`
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
  }

  // 1. Ambil vqd token
  const resHtml = await axios.get(`https://duckduckgo.com/?q=${encodeURIComponent(searchUrl)}`, {
    headers,
    timeout: 10000
  })

  const vqd = (resHtml.data.match(/vqd=([a-zA-Z0-9_-]+)/) || resHtml.data.match(/vqd="([^"]+)"/))?.[1]
  if (!vqd) throw 'Gagal mendapatkan token pencarian TikTok'

  // 2. Fetch hasil index video
  const { data } = await axios.get(`https://duckduckgo.com/v.js?q=${encodeURIComponent(searchUrl)}&vqd=${vqd}&p=-1&s=0`, {
    headers: {
      ...headers,
      Referer: 'https://duckduckgo.com/'
    },
    timeout: 10000
  })

  const video = data?.results?.find(r => /tiktok\.com\/@[^/]+\/video\/\d+/i.test(r?.content || ''))
  if (!video?.content) throw 'Video TikTok tidak ditemukan dengan kata kunci tersebut'

  return video.content
}

/**
 * Ambil data metadata & media TikTok via TikWM API
 */
async function getTikTok(url) {
  const { data } = await axios.get('https://tikwm.com/api/', {
    params: { url, hd: 1 },
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    },
    timeout: 20000
  })

  if (!data || data.code !== 0 || !data.data) {
    throw data?.msg || 'Gagal mengambil data dari TikTok'
  }

  return data.data
}

/**
 * Fetch buffer langsung dengan header anti-403
 */
async function fetchBuffer(url) {
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Referer': 'https://tikwm.com/'
    },
    timeout: 30000
  })
  return Buffer.from(res.data)
}

function formatNumber(num = 0) {
  return Number(num).toLocaleString('id-ID')
}

function formatDuration(sec = 0) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0')
  const s = Math.floor(sec % 60).toString().padStart(2, '0')
  return `${m}:${s}`
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const input = (m.quoted?.text || text || '').trim()
  if (!input) {
    return m.reply(`Contoh:\n${usedPrefix + command} https://vt.tiktok.com/xxxx\n${usedPrefix + command} story wa 30 detik`)
  }

  await m.react('⏳')

  try {
    let url = input
    const isUrl = /^https?:\/\//i.test(input)

    if (!isUrl) {
      url = await searchTikTok(input)
    }

    const res = await getTikTok(url)

    const title = (res.title || '-').replace(/\s+/g, ' ').trim()
    const uploader = res.author?.nickname || res.author?.unique_id || '-'
    const duration = formatDuration(res.duration || 0)
    const views = formatNumber(res.play_count || res.views || 0)

    const caption = [
      '— DOWNLOADER TIKTOK —',
      `❀ Judul : ${title.length > 80 ? title.slice(0, 80) + '...' : title}`,
      `❀ Uploader : ${uploader}`,
      `❀ Durasi : ${duration}`,
      `❀ Views : ${views}`
    ].join('\n')

    // 1. Handle Slide Gambar / Foto
    if (Array.isArray(res.images) && res.images.length > 0) {
      if (typeof conn.sendMessage === 'function' && conn.sendMessage.length) {
        await conn.sendMessage(
          m.chat,
          {
            album: res.images.map((img, i) => ({
              image: { url: img.startsWith('http') ? img : `https://tikwm.com${img}` },
              caption: i === 0 ? caption : ''
            }))
          },
          { quoted: m }
        ).catch(async () => {
          // Fallback jika album tidak disupport
          for (let i = 0; i < res.images.length; i++) {
            const imgUrl = res.images[i].startsWith('http') ? res.images[i] : `https://tikwm.com${res.images[i]}`
            const buf = await fetchBuffer(imgUrl)
            await conn.sendMessage(m.chat, { image: buf, caption: i === 0 ? caption : '' }, { quoted: m })
          }
        })
      }

      if (res.music) {
        const musicUrl = res.music.startsWith('http') ? res.music : `https://tikwm.com${res.music}`
        const audioBuf = await fetchBuffer(musicUrl)
        await conn.sendMessage(m.chat, { audio: audioBuf, mimetype: 'audio/mpeg' }, { quoted: m })
      }

      await m.react('✅')
      return
    }

    // 2. Handle Video
    const rawVideoUrl = res.play || res.hdplay || res.wmplay
    if (rawVideoUrl) {
      const videoUrl = rawVideoUrl.startsWith('http') ? rawVideoUrl : `https://tikwm.com${rawVideoUrl}`
      const videoBuffer = await fetchBuffer(videoUrl)

      await conn.sendMessage(
        m.chat,
        {
          video: videoBuffer,
          caption
        },
        { quoted: m }
      )
    }

    // 3. Handle Audio Terpisah
    if (res.music) {
      const musicUrl = res.music.startsWith('http') ? res.music : `https://tikwm.com${res.music}`
      const audioBuffer = await fetchBuffer(musicUrl)
      await conn.sendMessage(
        m.chat,
        {
          audio: audioBuffer,
          mimetype: 'audio/mpeg'
        },
        { quoted: m }
      )
    }

    await m.react('✅')
  } catch (e) {
    await m.react('❌')
    m.reply(`Terjadi kesalahan: ${e?.message || e}`)
  }
}

handler.help = ['tt', 'tiktok']
handler.tags = ['downloader']
handler.command = /^(tt|tiktok)$/i
handler.limit = 10
handler.register = false

export default handler