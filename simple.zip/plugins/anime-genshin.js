import axios from 'axios'
import * as cheerio from 'cheerio'

const BASE_URL = 'https://genshin.gg'

const getHeaders = () => ({
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9'
})

const getCharacterList = async () => {
  const { data } = await axios.get(BASE_URL, { headers: getHeaders() })
  const $ = cheerio.load(data)
  const list = []

  $('a[href*="/characters/"]').each((_, el) => {
    const href = $(el).attr('href') || ''
    const slug = href.replace(/\/characters\//g, '').replace(/\//g, '').trim().toLowerCase()
    const name = $(el).find('.character-name, .name').text().trim() || $(el).text().trim()
    const rarityClass = $(el).find('[class*="rarity-"]').attr('class') || $(el).attr('class') || ''
    const rarity = rarityClass.includes('rarity-5') ? 5 : rarityClass.includes('rarity-4') ? 4 : null

    if (slug && name && !list.some(c => c.slug === slug)) {
      list.push({ name, slug, rarity })
    }
  })

  return list.sort((a, b) => a.name.localeCompare(b.name))
}

const getCharacterDetail = async (query) => {
  const cleanQuery = query.toLowerCase().replace(/[^a-z0-9]/g, '')
  const charList = await getCharacterList()
  const matched = charList.find(c => 
    c.slug === cleanQuery || 
    c.name.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanQuery || 
    c.slug.includes(cleanQuery)
  )

  const slug = matched ? matched.slug : cleanQuery
  const url = `${BASE_URL}/characters/${slug}/`

  const { data } = await axios.get(url, { headers: getHeaders() })
  const $ = cheerio.load(data)

  const name = $('.character-name').text().trim() || $('h1').text().replace(/Genshin Impact/i, '').replace(/Build/i, '').trim() || (matched ? matched.name : slug)
  const rarityClass = $('.character-portrait').attr('class') || ''
  const rarity = rarityClass.includes('rarity-5') ? '★★★★★ (5 Star)' : rarityClass.includes('rarity-4') ? '★★★★ (4 Star)' : (matched?.rarity ? '★'.repeat(matched.rarity) : '-')
  const role = $('.character-role').text().trim() || '-'
  const element = $('.character-path').first().text().trim() || '-'
  const weapon = $('.character-path').last().text().trim() || '-'
  const avatar = $('.character-portrait img, .character-image img').attr('src') || ''

  const upgradeMaterials = []
  $('.character-materials-item').each((_, el) => {
    const matName = $(el).find('.character-materials-name').text().trim()
    if (matName) upgradeMaterials.push(matName)
  })

  const weapons = []
  $('.character-build-section').first().find('.character-build-weapon').each((_, el) => {
    const rank = $(el).find('.character-build-weapon-rank').text().trim()
    const wName = $(el).find('.character-build-weapon-name').text().trim()
    if (wName) weapons.push({ rank, name: wName })
  })

  const artifacts = []
  $('.character-build-section').eq(1).find('.character-build-weapon').each((_, el) => {
    const rank = $(el).find('.character-build-weapon-rank').text().trim()
    const artNames = $(el).find('.character-build-weapon-name').map((__, a) => $(a).text().trim()).get().filter(Boolean)
    const counts = $(el).find('.character-build-weapon-count').map((__, c) => $(c).text().trim()).get().filter(Boolean)
    const combined = artNames.map((n, i) => `${n} (${counts[i] || counts[0] || '4'}-Piece)`).join(' + ')
    if (combined) artifacts.push({ rank, name: combined })
  })

  const stats = {}
  $('.character-stats-item').each((_, el) => {
    const text = $(el).text().replace(/\s+/g, ' ').trim()
    const [key, ...val] = text.split(':')
    if (key && val.length) stats[key.trim()] = val.join(':').trim()
  })

  const teams = []
  $('.character-team').each((_, el) => {
    const teamName = $(el).find('.character-team-name').text().trim()
    const members = []
    $(el).find('.character-team-characters a').each((__, a) => {
      const charName = $(a).find('img').first().attr('alt') || $(a).find('.character-name').text().trim()
      const elem = $(a).find('img[src*="Elements"]').attr('alt') || ''
      if (charName) members.push(`${charName}${elem ? ` (${elem})` : ''}`)
    })
    if (teamName && members.length) teams.push({ name: teamName, members: members.join(' • ') })
  })

  const talents = []
  $('.character-skills').first().find('.character-skill').each((_, el) => {
    const type = $(el).find('.character-skill-header').text().trim()
    const tName = $(el).find('.character-skill-body h3, .character-skill-body h4, .character-skill-name').text().trim() || $(el).find('.character-skill-body').text().split('\n')[0].trim()
    const desc = $(el).find('.character-skill-description').text().trim()
    if (type || tName) talents.push({ type, name: tName, desc })
  })

  const passives = []
  $('.character-skills').eq(1).find('.character-skill').each((_, el) => {
    const type = $(el).find('.character-skill-header').text().trim()
    const pName = $(el).find('.character-skill-body h3, .character-skill-body h4, .character-skill-name').text().trim() || $(el).find('.character-skill-body').text().split('\n')[0].trim()
    const desc = $(el).find('.character-skill-description').text().trim()
    if (type || pName) passives.push({ type, name: pName, desc })
  })

  const constellations = []
  $('.character-skills').eq(2).find('.character-skill').each((_, el) => {
    const type = $(el).find('.character-skill-header').text().trim()
    const cName = $(el).find('.character-skill-body h3, .character-skill-body h4, .character-skill-name').text().trim() || $(el).find('.character-skill-body').text().split('\n')[0].trim()
    const desc = $(el).find('.character-skill-description').text().trim()
    if (type || cName) constellations.push({ type, name: cName, desc })
  })

  const ascensionCosts = []
  $('.character-ascension .rt-tbody .rt-tr-group, .character-ascension table tbody tr').each((_, row) => {
    const cells = $(row).find('.rt-td, td')
    if (cells.length >= 3) {
      const rank = $(cells[0]).text().trim()
      const lvl = $(cells[1]).text().trim()
      const cost = $(cells[2]).text().trim()
      const mats = []
      cells.slice(3).each((__, cell) => {
        const count = $(cell).find('.table-image-count').text().trim()
        const matName = $(cell).find('img').attr('alt') || $(cell).text().trim()
        if (matName) mats.push(`${count ? `${count}x ` : ''}${matName}`)
      })
      ascensionCosts.push({ rank, lvl, cost, mats: mats.join(', ') })
    }
  })

  return {
    name,
    rarity,
    element,
    weapon,
    role,
    avatar,
    upgradeMaterials,
    weapons,
    artifacts,
    stats,
    teams,
    talents,
    passives,
    constellations,
    ascensionCosts
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    throw `Contoh Penggunaan:\n• ${usedPrefix + command} odette\n• ${usedPrefix + command} --list`
  }

  const query = text.trim()

  if (query === '--list') {
    const charList = await getCharacterList()
    if (!charList.length) throw 'Gagal mengambil daftar karakter.'

    const star5 = charList.filter(c => c.rarity === 5).map(c => c.name)
    const star4 = charList.filter(c => c.rarity === 4).map(c => c.name)
    const others = charList.filter(c => !c.rarity).map(c => c.name)

    let caption = `乂 *GENSHIN IMPACT CHARACTER LIST* 乂\n`
    caption += `Total: ${charList.length} Karakter\n\n`

    if (star5.length) {
      caption += `*★ 5-Star Characters:*\n`
      caption += star5.map(name => `• ${name}`).join('\n') + '\n\n'
    }

    if (star4.length) {
      caption += `*★ 4-Star Characters:*\n`
      caption += star4.map(name => `• ${name}`).join('\n') + '\n\n'
    }

    if (others.length) {
      caption += `*★ Others:*\n`
      caption += others.map(name => `• ${name}`).join('\n') + '\n\n'
    }

    caption += `Ketik *${usedPrefix + command} <nama karakter>* untuk melihat detail build.`

    return conn.reply(m.chat, caption.trim(), m)
  }

  try {
    const data = await getCharacterDetail(query)

    let caption = `乂 *GENSHIN IMPACT - ${data.name.toUpperCase()}* 乂\n\n`
    caption += `• *Rarity:* ${data.rarity}\n`
    caption += `• *Element:* ${data.element}\n`
    caption += `• *Weapon:* ${data.weapon}\n`
    caption += `• *Role:* ${data.role}\n\n`

    if (data.upgradeMaterials.length) {
      caption += `┌─「 *UPGRADE MATERIALS* 」\n`
      caption += data.upgradeMaterials.map(m => `│ • ${m}`).join('\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.weapons.length) {
      caption += `┌─「 *BEST WEAPONS* 」\n`
      caption += data.weapons.map(w => `│ ${w.rank}. ${w.name}`).join('\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.artifacts.length) {
      caption += `┌─「 *BEST ARTIFACTS* 」\n`
      caption += data.artifacts.map(a => `│ ${a.rank}. ${a.name}`).join('\n') + '\n'
      caption += `└────\n\n`
    }

    if (Object.keys(data.stats).length) {
      caption += `┌─「 *BEST STATS* 」\n`
      for (const [k, v] of Object.entries(data.stats)) {
        caption += `│ • *${k}:* ${v}\n`
      }
      caption += `└────\n\n`
    }

    if (data.teams.length) {
      caption += `┌─「 *BEST TEAMS* 」\n`
      caption += data.teams.map(t => `│ • *${t.name}*\n│   └ ${t.members}`).join('\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.talents.length) {
      caption += `┌─「 *TALENTS* 」\n`
      caption += data.talents.map(t => `│ • *${t.type}:* ${t.name}\n│   ${t.desc}`).join('\n│\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.passives.length) {
      caption += `┌─「 *PASSIVES* 」\n`
      caption += data.passives.map(p => `│ • *${p.type}:* ${p.name}\n│   ${p.desc}`).join('\n│\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.constellations.length) {
      caption += `┌─「 *CONSTELLATIONS* 」\n`
      caption += data.constellations.map(c => `│ • *${c.type}:* ${c.name}\n│   ${c.desc}`).join('\n│\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.ascensionCosts.length) {
      caption += `┌─「 *${data.name.toUpperCase()} ASCENSION COSTS* 」\n`
      caption += data.ascensionCosts.map(a => `│ • *Phase ${a.rank} (Lvl ${a.lvl})*\n│   Cost: ${Number(a.cost).toLocaleString()} Mora\n│   Materials: ${a.mats}`).join('\n│\n') + '\n'
      caption += `└────`
    }

    if (data.avatar && conn.sendFile) {
      return conn.sendFile(m.chat, data.avatar, `${data.name}.png`, caption.trim(), m)
    }

    return conn.reply(m.chat, caption.trim(), m)
  } catch (err) {
    throw `Karakter "${query}" tidak ditemukan atau terjadi kesalahan saat mengambil data.`
  }
}

handler.help = ['genshin <character>', 'genshin --list']
handler.tags = ['anime']
handler.command = /^genshin$/i

export default handler