import axios from 'axios'
import * as cheerio from 'cheerio'
import https from 'https'

const agent = new https.Agent({
    keepAlive: true,
    keepAliveMsecs: 10000,
    timeout: 60000
})

class Mrzkyzdnii {
    constructor() {
        this.baseUrl = 'https://spotidown.app'
        this.siteKey = '6LcXkaUqAAAAAGvO0z9Mg54lpG22HE4gkl3XYFTK'
        this.version = 'AI7Fbyu7OpLvtxXargsbepSz'
        this.userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
    }

    headers(extra = {}) {
        return {
            'User-Agent': this.userAgent,
            ...extra
        }
    }

    async recaptcha(domain = 'spotidown.app') {
        try {
            const co = Buffer.from(`https://${domain}:443`).toString('base64').replace(/=/g, '.')
            const anchor = new URL('https://www.google.com/recaptcha/api2/anchor')
            anchor.searchParams.set('ar', '1')
            anchor.searchParams.set('k', this.siteKey)
            anchor.searchParams.set('co', co)
            anchor.searchParams.set('hl', 'en')
            anchor.searchParams.set('v', this.version)
            anchor.searchParams.set('size', 'invisible')
            anchor.searchParams.set('cb', '123')

            const { data: anchorHtml } = await axios.get(anchor.toString(), {
                headers: this.headers(),
                httpsAgent: agent,
                timeout: 10000
            })

            const tokenMatch = anchorHtml.match(/id="recaptcha-token" value="([^"]+)"/)
            if (!tokenMatch) return ''

            const reload = await axios.post(
                `https://www.google.com/recaptcha/api2/reload?k=${this.siteKey}`,
                new URLSearchParams({
                    v: this.version,
                    reason: 'q',
                    c: tokenMatch[1],
                    k: this.siteKey,
                    co,
                    hl: 'en',
                    size: 'invisible',
                    action: 'submit'
                }).toString(),
                {
                    headers: this.headers({
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }),
                    httpsAgent: agent,
                    timeout: 10000
                }
            )

            const response = reload.data.match(/"rresp","([^"]+)"/)
            return response ? response[1] : ''
        } catch {
            return ''
        }
    }

    async action(query, captcha = '') {
        const form = new FormData()
        form.append('url', query.trim())
        form.append('g-recaptcha-response', captcha)

        const response = await axios.post(
            `${this.baseUrl}/action`,
            form,
            {
                headers: this.headers({
                    Referer: `${this.baseUrl}/en7`,
                    Origin: this.baseUrl,
                    'X-Requested-With': 'XMLHttpRequest'
                }),
                httpsAgent: agent,
                timeout: 20000
            }
        )

        if (response.data.error) {
            if (!captcha) {
                const newCaptcha = await this.recaptcha()
                return this.action(query, newCaptcha)
            }
            throw new Error(response.data.message || 'Lagu tidak ditemukan.')
        }

        const setCookies = response.headers['set-cookie'] || []
        const cookie = setCookies.map(v => v.split(';')[0]).join('; ')

        const $ = cheerio.load(response.data.data)
        const formTrack = $("form[name='submitspurl']").first()

        if (!formTrack.length) {
            throw new Error('Lagu tidak ditemukan.')
        }

        const data = formTrack.find("input[name='data']").val()
        const base = formTrack.find("input[name='base']").val()
        const token = formTrack.find("input[name='token']").val()

        if (!data || !base || !token) {
            throw new Error('Data lagu tidak valid.')
        }

        let info = {}
        try {
            info = JSON.parse(
                Buffer.from(data, 'base64').toString('utf-8')
            )
        } catch {}

        return {
            cookie,
            data,
            base,
            token,
            info
        }
    }

    async track(data) {
        const form = new FormData()
        form.append('data', data.data)
        form.append('base', data.base)
        form.append('token', data.token)

        const response = await axios.post(
            `${this.baseUrl}/action/track`,
            form,
            {
                headers: this.headers({
                    Cookie: data.cookie,
                    Referer: `${this.baseUrl}/en7`,
                    Origin: this.baseUrl,
                    'X-Requested-With': 'XMLHttpRequest'
                }),
                httpsAgent: agent,
                timeout: 25000
            }
        )

        if (response.data.error) {
            throw new Error(response.data.message || 'Gagal membuat link download.')
        }

        const $ = cheerio.load(response.data.data)
        const downloadUrl = $("a[href*='rapid.spotidown.app']").attr('href')

        if (!downloadUrl) {
            throw new Error('Link audio tidak ditemukan.')
        }

        return downloadUrl
    }

    async download(url) {
        try {
            const response = await fetch(url, {
                headers: {
                    'User-Agent': this.userAgent,
                    Referer: `${this.baseUrl}/`
                },
                signal: AbortSignal.timeout(45000)
            })

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: Gagal mengunduh audio`)
            }

            const arrayBuffer = await response.arrayBuffer()
            return Buffer.from(arrayBuffer)
        } catch {
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                headers: this.headers({
                    Referer: `${this.baseUrl}/`
                }),
                httpsAgent: agent,
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                timeout: 45000
            })

            return Buffer.from(response.data)
        }
    }

    async search(query) {
        if (!query?.trim()) {
            throw new Error('Query kosong.')
        }

        const data = await this.action(query)
        const downloadUrl = await this.track(data)
        const audio = await this.download(downloadUrl)

        const info = data.info

        return {
            title: info.name || 'Spotify Audio',
            artist: info.artist || 'Unknown Artist',
            album: info.album || '-',
            duration: info.duration || '-',
            cover: info.cover || '',
            downloadUrl,
            audio
        }
    }
}

const spotify = new Mrzkyzdnii()

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        throw `Contoh Penggunaan:\n• ${usedPrefix + command} https://open.spotify.com/track/0lUdYoSr8Hm3GL0HZld4ac\n• ${usedPrefix + command} beautiful in white`
    }

    await conn.reply(
        m.chat,
        '⏳ _Sedang mencari dan mengunduh audio dari Spotify..._',
        m
    )

    const result = await spotify.search(text)

    const caption =
        `🎵 *SPOTIFY DOWNLOADER*\n\n` +
        `📌 *Judul:* ${result.title}\n` +
        `👤 *Artis:* ${result.artist}\n` +
        `💿 *Album:* ${result.album}\n` +
        `⏱️ *Durasi:* ${result.duration}\n\n` +
        `_Audio file sedang dikirim..._`

    if (result.cover) {
        await conn.sendFile(
            m.chat,
            result.cover,
            'cover.jpg',
            caption,
            m
        )
    } else {
        await conn.reply(
            m.chat,
            caption,
            m
        )
    }

    await conn.sendFile(
        m.chat,
        result.audio,
        `${result.title}.mp3`,
        '',
        m,
        false,
        {
            mimetype: 'audio/mpeg'
        }
    )
}

handler.help = ['splay <url/judul>']
handler.tags = ['downloader']
handler.command = /^splay$/i

export default handler