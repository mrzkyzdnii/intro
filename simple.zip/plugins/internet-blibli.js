import axios from 'axios'

// API Key ScrapingBee milik lu
const SCRAPINGBEE_API_KEY = 'GNEBBI02AGE5M9JG52A43H46OZMFX7CROZNI6RGOM04Y19VV9JCMT38583VCHMCG5AUILO5NABX3LFWG'

const scraper = async (query) => {
  if (!query) throw new Error('Query pencarian tidak boleh kosong!')

  // Target endpoint JSON internal Blibli
  const targetUrl = `https://www.blibli.com/backend/search/products?searchTerm=${encodeURIComponent(query)}&start=0&itemPerPage=10`

  // Parameter ScrapingBee:
  // - render_js=false (karena targetnya API JSON, jadi jauh lebih cepat & hemat kuota)
  // - premium_proxy=true & country_code=id (melewati proteksi Cloudflare WAF Blibli)
  const apiUrl = `https://app.scrapingbee.com/api/v1/?api_key=${SCRAPINGBEE_API_KEY}&url=${encodeURIComponent(targetUrl)}&render_js=false&premium_proxy=true&country_code=id`

  const response = await axios.get(apiUrl, {
    timeout: 30000,
    headers: {
      'Accept': 'application/json'
    }
  })

  const rawData = response.data
  const rawProducts = rawData?.data?.products || []

  if (!rawProducts.length) {
    throw new Error(`Tidak ada produk ditemukan untuk pencarian "${query}".`)
  }

  return rawProducts.map((p) => {
    const rawImg = (p.images && p.images[0]) || ''
    const fullImg = rawImg.startsWith('http')
      ? rawImg
      : rawImg
      ? `https://www.static-src.com/wcsstore/Indraprastha/images/catalog/medium/${rawImg}`
      : null

    const productUrl = p.url?.startsWith('http')
      ? p.url
      : `https://www.blibli.com${p.url || ''}`

    return {
      name: p.name || 'Tanpa Nama',
      price: p.price?.priceDisplay || (p.price?.minPrice ? `Rp ${p.price.minPrice.toLocaleString('id-ID')}` : 'N/A'),
      originalPrice: p.price?.strikeThroughPriceDisplay || null,
      discount: p.price?.discount ? `${p.price.discount}%` : null,
      store: p.merchantName || 'Official Store',
      location: p.location || 'Indonesia',
      rating: p.review?.rating || 'Belum ada rating',
      sold: p.soldRangeCount?.en || (p.review?.count ? `${p.review.count} ulasan` : '0 terjual'),
      image: fullImg,
      url: productUrl
    }
  })
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh penggunaan:\n${usedPrefix + command} minyak goreng`

  await conn.reply(m.chat, `🔍 Sedang mencari produk *"${text}"* di Blibli...`, m)

  try {
    const products = await scraper(text)

    let caption = `🛍️ *HASIL PENCARIAN BLIBLI*\n`
    caption += `🔎 Keyword: _${text}_\n`
    caption += `📦 Ditemukan: ${products.length} produk\n`
    caption += `─────────────────────────\n\n`

    products.slice(0, 5).forEach((p, idx) => {
      caption += `*${idx + 1}. ${p.name}*\n`
      caption += `💰 Harga: *${p.price}*`
      if (p.originalPrice && p.discount) {
        caption += ` ~( ${p.originalPrice} - Diskon ${p.discount} )~`
      }
      caption += `\n🏪 Toko: ${p.store} (${p.location})\n`
      caption += `⭐ Rating: ${p.rating} | ${p.sold}\n`
      caption += `🔗 Link: ${p.url}\n\n`
    })

    caption += `─────────────────────────\n`
    caption += `_Gunakan link di atas untuk langsung membuka produk di Blibli._`

    const firstImage = products.find((p) => p.image)?.image

    if (firstImage) {
      await conn.sendFile(m.chat, firstImage, 'blibli.jpg', caption.trim(), m)
    } else {
      await conn.reply(m.chat, caption.trim(), m)
    }
  } catch (err) {
    await conn.reply(m.chat, `❌ *Gagal mengambil data Blibli:* ${err.message}`, m)
  }
}

handler.help = ['bliblimarket <barang>']
handler.tags = ['internet']
handler.command = /^(bliblimarket)$/i

export default handler