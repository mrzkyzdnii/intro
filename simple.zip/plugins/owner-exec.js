import cp from 'child_process'
import { promisify } from 'util'

const exec = promisify(cp.exec)

const BASE_DIR = '/root/bot/intro'
const PWD_MARKER = '__OWNER_SHELL_PWD_9F8A7C__'

if (!global.ownerShellCwd) global.ownerShellCwd = BASE_DIR

const handler = async (m, { conn, command, text }) => {
  if (global.conn?.user?.jid !== conn.user.jid) return

  const cmd = `${command || ''} ${text || ''}`.trim()
  if (!cmd) return

  try {
    const cwd = global.ownerShellCwd || BASE_DIR

    const script = [
      'export HOME=/root',
      'export USER=root',
      'export LOGNAME=root',
      'export SHELL=/bin/bash',
      'export NVM_DIR=/root/.nvm',
      '[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"',
      `cd -- ${JSON.stringify(cwd)}`,
      `{ ${cmd}; }`,
      `printf '\\n${PWD_MARKER}%s\\n' "$PWD"`
    ].join(' && ')

    const { stdout, stderr } = await exec(script, {
      shell: '/bin/bash',
      cwd,
      env: {
        ...process.env,
        HOME: '/root',
        USER: 'root',
        LOGNAME: 'root',
        SHELL: '/bin/bash',
        NVM_DIR: '/root/.nvm',
        PATH: `/root/.nvm/versions/node/v20.20.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:${process.env.PATH || ''}`
      },
      maxBuffer: 50 * 1024 * 1024
    })

    const markerIndex = stdout.lastIndexOf(PWD_MARKER)

    let output = stdout
    let newCwd = cwd

    if (markerIndex !== -1) {
      output = stdout.slice(0, markerIndex).trim()

      const pwdPart = stdout.slice(markerIndex + PWD_MARKER.length)
      const detectedCwd = pwdPart.trim().split(/\r?\n/)[0]?.trim()

      if (detectedCwd && detectedCwd.startsWith('/')) {
        newCwd = detectedCwd
        global.ownerShellCwd = detectedCwd
      }
    }

    if (output) await m.reply(output)
    if (stderr?.trim()) await m.reply(stderr.trim())
  } catch (e) {
    const stdout = e.stdout || ''
    const stderr = e.stderr || ''
    const message = e.message || ''

    const markerIndex = stdout.lastIndexOf(PWD_MARKER)

    let output = stdout
    let newCwd = global.ownerShellCwd || BASE_DIR

    if (markerIndex !== -1) {
      output = stdout.slice(0, markerIndex).trim()

      const pwdPart = stdout.slice(markerIndex + PWD_MARKER.length)
      const detectedCwd = pwdPart.trim().split(/\r?\n/)[0]?.trim()

      if (detectedCwd && detectedCwd.startsWith('/')) {
        newCwd = detectedCwd
        global.ownerShellCwd = detectedCwd
      }
    }

    const result = `${output}${stderr || message}`.trim()

    if (result) await m.reply(result)
  }
}

handler.customPrefix = /^\$ /
handler.command = new RegExp
handler.rowner = true
handler.limit = 10

export default handler