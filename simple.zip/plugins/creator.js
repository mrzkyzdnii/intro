const handler = async (m, { conn }) => {
    const nomor = '628386484120'

    const vcard = `BEGIN:VCARD
VERSION:3.0
FN: Mrzkyzdnii 
TEL;type=CELL;type=VOICE;waid=${nomor}:${nomor}
END:VCARD`

    await conn.sendMessage(
        m.chat,
        {
            contacts: {
                displayName: 'mrzkyzdnii',
                contacts: [
                    {
                        vcard
                    }
                ]
            }
        },
        {
            quoted: m
        }
    )
}

handler.help = ['owner']
handler.tags = ['main']
handler.command = /^(owner|creator)$/i

handler.limit = 10
export default handler