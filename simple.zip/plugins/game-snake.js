const handler = async (m, { conn }) => {
  await conn.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {
          messageDisclaimerText: "",
          botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860",
          verificationMetadata: {
            proofs: [
              {
                version: 1,
                useCase: 1,
                signature:
                  "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                certificateChain: [
                  "TklYRUwuTWVzc2FnZUJ1bGRlc..."
                ]
              }
            ]
          }
        }
      },

      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,

            submessages: [
              {
                messageType: 2,
                messageText: "🐍 ULAR NOKIA"
              }
            ],

            unifiedResponse: {
              data: Buffer.from(
                JSON.stringify({
                  response_id: "snake-nokia-001",

                  sections: [
                    {
                      view_model: {
                        primitive: {
                          __typename: "GenAIaeacdsnwHtmlPrimitive",

                          payload: `
<style>
*{
  box-sizing:border-box;
  -webkit-tap-highlight-color:transparent;
  user-select:none;
  -webkit-user-select:none
}

body{
  margin:0;
  background:transparent;
  font-family:Arial,sans-serif;
  color:#eee;
  touch-action:manipulation
}

.wrap{
  width:100%;
  max-width:420px;
  margin:auto;
  padding:12px
}

.card{
  background:
    linear-gradient(
      145deg,
      rgba(20,30,20,.95),
      rgba(10,18,10,.98)
    );
  border:1px solid rgba(80,180,80,.25);
  border-radius:20px;
  overflow:hidden;
  box-shadow:0 12px 40px rgba(0,0,0,.5)
}

.head{
  padding:14px 16px;
  border-bottom:1px solid rgba(80,180,80,.2);
  display:flex;
  justify-content:space-between;
  align-items:center
}

.logo{
  font-size:9px;
  letter-spacing:2px;
  color:#6a9;
  text-transform:uppercase
}

.title{
  font-size:20px;
  font-weight:800;
  margin-top:2px;
  color:#9f9
}

.stats{
  text-align:right;
  font-size:12px;
  line-height:1.4
}

.stats b{
  color:#7f7
}

.boardWrap{
  padding:12px;
  display:flex;
  justify-content:center
}

canvas{
  border-radius:10px;
  border:2px solid rgba(80,180,80,.3);
  background:#0a120a;
  display:block;
  max-width:100%;
  height:auto
}

.pad{
  padding:8px 16px 16px;
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:6px
}

.row{
  display:flex;
  gap:6px;
  justify-content:center
}

.btn{
  width:64px;
  height:52px;
  border:0;
  border-radius:12px;
  background:rgba(60,140,60,.25);
  color:#cfc;
  font-size:22px;
  font-weight:bold;
  border:1px solid rgba(80,180,80,.35);
  display:flex;
  align-items:center;
  justify-content:center
}

.btn:active{
  background:rgba(80,200,80,.45);
  transform:scale(.94)
}

.btn.mid{
  background:rgba(40,100,40,.35)
}

.act{
  display:flex;
  gap:8px;
  padding:0 16px 14px;
  justify-content:center
}

.act .btn{
  width:auto;
  padding:0 18px;
  font-size:13px;
  height:42px
}

.start{
  background:linear-gradient(135deg,#2d8,#185)
}

.reset{
  background:rgba(180,60,40,.35);
  border-color:rgba(220,80,60,.4);
  color:#fcc
}

.info{
  padding:0 16px 14px;
  color:#687;
  font-size:11px;
  text-align:center;
  line-height:1.45
}

.overlay{
  position:absolute;
  inset:0;
  background:rgba(5,12,5,.88);
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  border-radius:10px;
  pointer-events:none
}

.overlay h2{
  margin:0 0 6px;
  font-size:26px;
  color:#afa
}

.overlay p{
  margin:0;
  font-size:13px;
  color:#8a8
}

.boardRel{
  position:relative;
  display:inline-block
}
</style>

<body>

<div class="wrap">

<div class="card">

  <div class="head">

    <div>
      <div class="logo">NOKIA STYLE</div>
      <div class="title">🐍 Ular</div>
    </div>

    <div class="stats">
      <div>
        Skor:
        <b id="score">0</b>
      </div>

      <div>
        Level:
        <b id="level">1</b>
      </div>

      <div>
        Panjang:
        <b id="len">3</b>
      </div>
    </div>

  </div>

  <div class="boardWrap">

    <div class="boardRel">

      <canvas
        id="g"
        width="320"
        height="320">
      </canvas>

      <div
        id="ov"
        class="overlay"
        style="display:none">

        <h2 id="ovt">
          GAME OVER
        </h2>

        <p id="ovm">
          Nabrak ekor sendiri!
        </p>

      </div>

    </div>

  </div>

  <div class="pad">

    <div class="row">

      <button
        class="btn"
        id="up">
        ▲
      </button>

    </div>

    <div class="row">

      <button
        class="btn"
        id="left">
        ◀
      </button>

      <button
        class="btn mid"
        id="pause">
        ❚❚
      </button>

      <button
        class="btn"
        id="right">
        ▶
      </button>

    </div>

    <div class="row">

      <button
        class="btn"
        id="down">
        ▼
      </button>

    </div>

  </div>

  <div class="act">

    <button
      class="btn start"
      id="start">
      ▶ MULAI
    </button>

    <button
      class="btn reset"
      id="reset">
      ↻ RESET
    </button>

  </div>

  <div class="info">
    Makan makanan • Hindari tembok & ekor sendiri
    <br>
    Setiap level ular makin cepat & warna berubah
  </div>

</div>

</div>

<script>

const c =
  document.getElementById('g')

const x =
  c.getContext('2d')

const scEl =
  document.getElementById('score')

const lvEl =
  document.getElementById('level')

const lnEl =
  document.getElementById('len')

const ov =
  document.getElementById('ov')

const ovt =
  document.getElementById('ovt')

const ovm =
  document.getElementById('ovm')


const GRID = 16
const CELL = 20

const W = GRID
const H = GRID


const LEVELS = [
  {
    spd:180,
    name:'Hijau',
    body:'#3a3',
    head:'#6f6',
    food:'#f55'
  },

  {
    spd:150,
    name:'Biru',
    body:'#38a',
    head:'#6cf',
    food:'#fa0'
  },

  {
    spd:120,
    name:'Ungu',
    body:'#84c',
    head:'#c8f',
    food:'#0f8'
  },

  {
    spd:95,
    name:'Emas',
    body:'#b80',
    head:'#fc3',
    food:'#f3f'
  },

  {
    spd:75,
    name:'Merah',
    body:'#c33',
    head:'#f66',
    food:'#ff0'
  },

  {
    spd:55,
    name:'Neon',
    body:'#0c8',
    head:'#0ff',
    food:'#f0f'
  }
]


let snake
let dir
let nextDir
let food
let score
let level
let alive
let paused
let loop
let eatNeed


function randFood(){

  let p

  do{

    p = {
      x:Math.floor(
        Math.random() * W
      ),

      y:Math.floor(
        Math.random() * H
      )
    }

  }while(
    snake.some(
      s =>
        s.x === p.x &&
        s.y === p.y
    )
  )

  return p
}


function init(){

  snake = [
    {
      x:8,
      y:8
    },

    {
      x:7,
      y:8
    },

    {
      x:6,
      y:8
    }
  ]

  dir = {
    x:1,
    y:0
  }

  nextDir = {
    x:1,
    y:0
  }

  food = randFood()

  score = 0
  level = 1
  eatNeed = 4

  alive = true
  paused = false

  ov.style.display = 'none'

  updateUI()
  draw()

  clearInterval(loop)

  loop = null
}


function updateUI(){

  scEl.textContent = score

  lvEl.textContent =
    level +
    ' · ' +
    LEVELS[
      Math.min(
        level - 1,
        LEVELS.length - 1
      )
    ].name

  lnEl.textContent =
    snake.length
}


function setDir(nx,ny){

  if(!alive || paused)
    return

  if(
    nx === -dir.x &&
    ny === -dir.y
  )
    return

  nextDir = {
    x:nx,
    y:ny
  }
}


document
  .getElementById('up')
  .onclick = () =>
    setDir(0,-1)


document
  .getElementById('down')
  .onclick = () =>
    setDir(0,1)


document
  .getElementById('left')
  .onclick = () =>
    setDir(-1,0)


document
  .getElementById('right')
  .onclick = () =>
    setDir(1,0)


document
  .getElementById('pause')
  .onclick = () => {

    if(
      !alive ||
      !loop
    )
      return

    paused = !paused

    document
      .getElementById('pause')
      .textContent =
        paused
          ? '▶'
          : '❚❚'
  }


document
  .getElementById('start')
  .onclick = () => {

    if(loop && alive)
      return

    if(!alive)
      init()

    alive = true
    paused = false

    document
      .getElementById('pause')
      .textContent = '❚❚'

    ov.style.display = 'none'

    clearInterval(loop)

    const spd =
      LEVELS[
        Math.min(
          level - 1,
          LEVELS.length - 1
        )
      ].spd

    loop =
      setInterval(
        tick,
        spd
      )
  }


document
  .getElementById('reset')
  .onclick = () => {

    clearInterval(loop)

    loop = null

    init()
  }


function tick(){

  if(
    paused ||
    !alive
  )
    return

  dir = nextDir

  const head = {
    x:
      snake[0].x +
      dir.x,

    y:
      snake[0].y +
      dir.y
  }


  if(
    head.x < 0 ||
    head.x >= W ||
    head.y < 0 ||
    head.y >= H
  ){

    die(
      'Nabrak tembok!'
    )

    return
  }


  if(
    snake.some(
      s =>
        s.x === head.x &&
        s.y === head.y
    )
  ){

    die(
      'Nabrak ekor sendiri!'
    )

    return
  }


  snake.unshift(head)


  if(
    head.x === food.x &&
    head.y === food.y
  ){

    score += 10 * level

    eatNeed--

    food = randFood()


    if(eatNeed <= 0){

      level++

      eatNeed = 4 + level

      clearInterval(loop)

      const spd =
        LEVELS[
          Math.min(
            level - 1,
            LEVELS.length - 1
          )
        ].spd

      loop =
        setInterval(
          tick,
          spd
        )
    }

  }else{

    snake.pop()

  }


  updateUI()
  draw()
}


function die(msg){

  alive = false

  clearInterval(loop)

  loop = null

  ovt.textContent =
    'GAME OVER'

  ovm.textContent =
    msg +
    ' · Skor ' +
    score

  ov.style.display =
    'flex'

  draw()
}


function draw(){

  const L =
    LEVELS[
      Math.min(
        level - 1,
        LEVELS.length - 1
      )
    ]


  x.fillStyle =
    '#0a120a'

  x.fillRect(
    0,
    0,
    c.width,
    c.height
  )


  x.strokeStyle =
    'rgba(40,80,40,.25)'

  x.lineWidth = 1


  for(
    let i = 0;
    i <= W;
    i++
  ){

    x.beginPath()

    x.moveTo(
      i * CELL,
      0
    )

    x.lineTo(
      i * CELL,
      H * CELL
    )

    x.stroke()


    x.beginPath()

    x.moveTo(
      0,
      i * CELL
    )

    x.lineTo(
      W * CELL,
      i * CELL
    )

    x.stroke()
  }


  x.fillStyle =
    L.food

  x.beginPath()

  x.arc(
    food.x * CELL + CELL / 2,
    food.y * CELL + CELL / 2,
    CELL * 0.38,
    0,
    Math.PI * 2
  )

  x.fill()


  x.fillStyle =
    'rgba(255,255,255,.35)'

  x.beginPath()

  x.arc(
    food.x * CELL +
      CELL / 2 - 3,

    food.y * CELL +
      CELL / 2 - 3,

    CELL * 0.12,

    0,
    Math.PI * 2
  )

  x.fill()


  snake.forEach(
    (s,i) => {

      const isHead =
        i === 0

      x.fillStyle =
        isHead
          ? L.head
          : L.body

      const pad =
        isHead
          ? 1
          : 2

      x.fillRect(
        s.x * CELL + pad,
        s.y * CELL + pad,
        CELL - pad * 2,
        CELL - pad * 2
      )


      if(isHead){

        x.fillStyle =
          '#111'

        const ex =
          dir.x

        const ey =
          dir.y

        const cx =
          s.x * CELL +
          CELL / 2

        const cy =
          s.y * CELL +
          CELL / 2


        if(ex === 1){

          x.fillRect(
            cx + 3,
            cy - 5,
            4,
            4
          )

          x.fillRect(
            cx + 3,
            cy + 1,
            4,
            4
          )

        }else if(ex === -1){

          x.fillRect(
            cx - 7,
            cy - 5,
            4,
            4
          )

          x.fillRect(
            cx - 7,
            cy + 1,
            4,
            4
          )

        }else if(ey === -1){

          x.fillRect(
            cx - 5,
            cy - 7,
            4,
            4
          )

          x.fillRect(
            cx + 1,
            cy - 7,
            4,
            4
          )

        }else{

          x.fillRect(
            cx - 5,
            cy + 3,
            4,
            4
          )

          x.fillRect(
            cx + 1,
            cy + 3,
            4,
            4
          )
        }
      }
    }
  )
}


init()

</script>
`,

                          trusted_sources: [
                            "adam.dev"
                          ]
                        },

                        __typename:
                          "GenAISingleLayoutViewModel"
                      }
                    }
                  ]
                })
              ).toString("base64")
            },

            contextInfo: {
              forwardingScore: 1,

              isForwarded: true,

              forwardedAiBotMessageInfo: {
                botJid:
                  "867051314767696@bot"
              },

              forwardOrigin: 4
            }
          }
        }
      }
    },

    {}
  )
}


handler.help = [
  "snake"
]

handler.tags = [
  "game"
]

handler.command =
  /^(snake)$/i

handler.limit = false
handler.premium = false

export default handler