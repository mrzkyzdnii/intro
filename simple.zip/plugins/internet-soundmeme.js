import cloudscraper from 'cloudscraper'
import * as cheerio from 'cheerio'

const getWithRetry = async (options, maxRetries = 5, delay = 800) => {
    let lastError
    for (let i = 0; i < maxRetries; i++) {
        try {
            return await cloudscraper(options)
        } catch (err) {
            lastError = err
            const status = err.statusCode || err.response?.statusCode
            if (status === 403 || err.name === 'CloudflareError' || err.name === 'RequestError' || i < maxRetries - 1) {
                if (delay > 0) await new Promise((r) => setTimeout(r, delay))
                continue
            }
            throw err
        }
    }
    throw lastError
}

const scraper = async (query) => {
    try {
        const data = await getWithRetry({
            method: 'GET',
            uri: `https://www.myinstants.com/en/search/?name=${encodeURIComponent(query)}`
        })
        const $ = cheerio.load(data)
        const results = []

        $('.instant').each((_, el) => {
            const title = $(el).find('a.instant-link').text().trim()
            const onclick = $(el).find('button.small-button').attr('onclick') || ''
            const soundMatch = onclick.match(/play\((['"])(.*?)\1/)
            
            if (title && soundMatch) {
                const soundPath = soundMatch[2]
                results.push({
                    title,
                    music: soundPath.startsWith('http') ? soundPath : `https://www.myinstants.com${soundPath}`
                })
            }
        })

        return results
    } catch {
        throw new Error('Gagal mengambil data dari MyInstants.')
    }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Contoh penggunaan:\n${usedPrefix + command} haha`

    if (text.startsWith('get|')) {
        const audioUrl = text.split('get|')[1]

        try {
            const buffer = await getWithRetry({
                method: 'GET',
                uri: audioUrl,
                encoding: null
            })

            await conn.sendMessage(
                m.chat,
                {
                    audio: buffer,
                    mimetype: 'audio/mpeg'
                },
                { quoted: m }
            )
        } catch {
            await conn.sendMessage(
                m.chat,
                {
                    audio: { url: audioUrl },
                    mimetype: 'audio/mpeg'
                },
                { quoted: m }
            )
        }
        return
    }

    const results = await scraper(text)

    if (!results || results.length === 0) {
        return conn.reply(m.chat, `Sound dengan kata kunci "${text}" tidak ditemukan.`, m)
    }

    const topResults = results.slice(0, 10)

    const rows = topResults.map((item) => ({
        header: '',
        title: item.title.slice(0, 24),
        description: `Kirim audio: ${item.title}`,
        id: `${usedPrefix + command} get|${item.music}`
    }))

    await conn.sendMessage(m.chat, {
        text: `*MYINSTANTS SOUND SEARCH*\n\nHasil pencarian untuk: *${text}*\nJumlah ditemukan: ${results.length} sound.\nPilih sound pada tombol di bawah:`,
        footer: 'MyInstants Soundboard',
        optionText: 'Pilih Sound',
        optionTitle: 'Daftar Sound',
        nativeFlow: [
            {
                text: '🎵 Pilih Sound',
                sections: [
                    {
                        title: `Hasil Sound (${topResults.length})`,
                        rows: rows
                    }
                ]
            }
        ]
    }, { quoted: m })
}

handler.help = ['soundmeme']
handler.tags = ['internet']
handler.command = /^(soundmeme)$/i
handler.limit = 10

export default handler