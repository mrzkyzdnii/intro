const formatMoney = value => Number(value || 0).toLocaleString('id-ID')
const roll = () => Math.floor(Math.random() * 20) + 1

const DUEL_STAKE = 100000

const getMessageId = message => (
  message?.key?.id ||
  message?.id ||
  message?.stanzaId ||
  null
)

const getQuotedId = quoted => (
  quoted?.key?.id ||
  quoted?.id ||
  quoted?.stanzaId ||
  null
)

const sendMention = (conn, chat, text, mentions, quoted) => {
  return conn.sendMessage(chat, { text, mentions }, { quoted })
}

const finishDuel = (conn, target, pending) => {
  if (conn.duelChallenge?.[target] === pending) {
    delete conn.duelChallenge[target]
  }
  if (pending.timer) clearTimeout(pending.timer)
}

let handler = async (m, { conn, usedPrefix }) => {
  conn.duelChallenge = conn.duelChallenge || {}

  const target = m.mentionedJid?.[0]

  if (!target) {
    return m.reply(`Cara pakai:\n${usedPrefix}duel @user`)
  }

  if (target === m.sender) {
    return m.reply('Kamu tidak dapat menantang diri sendiri. (￣▽￣)')
  }

  if (conn.duelChallenge[target]) {
    return m.reply('Pengguna tersebut masih memiliki tantangan duel yang belum selesai.')
  }

  const challengerUser = global.db.data.users[m.sender]
  const targetUser = global.db.data.users[target]

  if (!challengerUser || !targetUser) {
    return m.reply('Data salah satu pengguna tidak ditemukan di database.')
  }

  const challengerMoney = Number(challengerUser.money || 0)
  const targetMoney = Number(targetUser.money || 0)

  if (challengerMoney < DUEL_STAKE) {
    return m.reply(`Saldo kamu tidak mencukupi. Minimal Rp${formatMoney(DUEL_STAKE)}, saldo kamu: Rp${formatMoney(challengerMoney)}.`)
  }

  if (targetMoney < DUEL_STAKE) {
    return sendMention(
      conn,
      m.chat,
      `Saldo @${target.split('@')[0]} tidak mencukupi untuk duel (min. Rp${formatMoney(DUEL_STAKE)}).`,
      [target],
      m
    )
  }

  const challengeText = `╭─〔 ⚔ TANTANGAN DUEL 〕\n│ @${m.sender.split('@')[0]} menantang\n│ @${target.split('@')[0]} untuk duel!\n│\n│ Taruhan : Rp${formatMoney(DUEL_STAKE)}\n│ Menang  : +Rp${formatMoney(DUEL_STAKE)}\n│ Kalah   : -Rp${formatMoney(DUEL_STAKE)}\n│\n│ @${target.split('@')[0]}, apakah kamu terima?\n│\n│ Balas pesan ini dengan:\n│ *gass* untuk menerima\n│ *tolak* untuk menolak\n│\n│ Batas waktu: 20 detik\n╰────────────`

  const challengeMessage = await sendMention(
    conn,
    m.chat,
    challengeText,
    [m.sender, target],
    m
  )

  const pending = {
    chat: m.chat,
    challenger: m.sender,
    target,
    amount: DUEL_STAKE,
    messageId: getMessageId(challengeMessage),
    createdAt: Date.now(),
    timer: null
  }

  conn.duelChallenge[target] = pending

  pending.timer = setTimeout(async () => {
    if (conn.duelChallenge?.[target] !== pending) return

    delete conn.duelChallenge[target]

    await sendMention(
      conn,
      pending.chat,
      `╭─〔 DUEL EXPIRED 〕\n│ Tantangan dari @${pending.challenger.split('@')[0]} dibatalkan.\n│ @${pending.target.split('@')[0]} tidak merespons dalam 20 detik.\n│\n│ Tidak ada money yang dipotong.\n╰────────────`,
      [pending.challenger, pending.target],
      m
    )
  }, 20000)
}

handler.before = async (m, { conn }) => {
  conn.duelChallenge = conn.duelChallenge || {}

  const answer = String(m.text || '').trim().toLowerCase()
  if (!/^(gass|tolak)$/.test(answer)) return

  const pending = conn.duelChallenge[m.sender]
  if (!pending) return

  if (!m.quoted) return
  if (getQuotedId(m.quoted) !== pending.messageId) return

  finishDuel(conn, m.sender, pending)

  if (answer === 'tolak') {
    return sendMention(
      conn,
      m.chat,
      `╭─〔 DUEL DITOLAK 〕\n│ @${pending.target.split('@')[0]} menolak tantangan duel.\n╰────────────`,
      [pending.challenger, pending.target],
      m
    )
  }

  const challengerUser = global.db.data.users[pending.challenger]
  const targetUser = global.db.data.users[pending.target]

  if (!challengerUser || !targetUser) {
    return m.reply('Data salah satu pemain tidak ditemukan di database.')
  }

  const challengerMoney = Number(challengerUser.money || 0)
  const targetMoney = Number(targetUser.money || 0)

  // Cek ulang saldo saat diterima untuk mencegah saldo negatif atau race condition.
  if (challengerMoney < pending.amount) {
    return m.reply(`Duel dibatalkan karena saldo penantang tidak lagi mencukupi. Saldo: Rp${formatMoney(challengerMoney)}`)
  }

  if (targetMoney < pending.amount) {
    return sendMention(
      conn,
      m.chat,
      `Duel dibatalkan karena saldo @${pending.target.split('@')[0]} tidak lagi mencukupi.`,
      [pending.target],
      m
    )
  }

  const challengerRoll = roll()
  const targetRoll = roll()
  let winner = null
  let loser = null
  let resultText

  if (challengerRoll > targetRoll) {
    winner = pending.challenger
    loser = pending.target
  } else if (targetRoll > challengerRoll) {
    winner = pending.target
    loser = pending.challenger
  }

  if (winner) {
    const winnerUser = global.db.data.users[winner]
    const loserUser = global.db.data.users[loser]

    winnerUser.money = Number(winnerUser.money || 0) + pending.amount
    loserUser.money = Number(loserUser.money || 0) - pending.amount

    resultText = `@${winner.split('@')[0]} menang! +Rp${formatMoney(pending.amount)}\n│ @${loser.split('@')[0]} kalah. -Rp${formatMoney(pending.amount)}`
  } else {
    resultText = 'Hasil seri. Tidak ada money yang dipotong atau ditambah.'
  }

  return sendMention(
    conn,
    m.chat,
    `╭─〔 ⚔ HASIL DUEL 〕\n│ @${pending.challenger.split('@')[0]}  ::  ${challengerRoll}\n│ @${pending.target.split('@')[0]}  ::  ${targetRoll}\n│\n│ ${resultText}\n╰────────────`,
    [pending.challenger, pending.target, ...(winner ? [winner] : [])],
    m
  )
}

handler.help = ['duel']
handler.tags = ['rpg']
handler.command = /^(duel)$/i
handler.register = true
handler.group = true
handler.rpg = true

export default handler