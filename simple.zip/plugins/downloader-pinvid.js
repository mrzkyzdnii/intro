import axios from 'axios'

const HISTORY_LIMIT = 30
const recentByUser = new Map()

let sessionCache = {
  cookie: '',
  csrf: '',
  expires: 0
}

const getSession = async () => {
  if (sessionCache.cookie && Date.now() < sessionCache.expires) {
    return sessionCache
  }

  const res = await axios.get('https://www.pinterest.com/', {
    headers: {
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
      'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'accept-language': 'en-US,en;q=0.9'
    },
    timeout: 10000
  })

  const rawCookies = res.headers['set-cookie'] || []
  const cookies = rawCookies.map(c => c.split(';')[0]).join('; ')
  const csrfMatch = cookies.match(/csrftoken=([^;]+)/)
  const csrf = csrfMatch ? csrfMatch[1] : ''

  sessionCache = {
    cookie: cookies,
    csrf,
    expires: Date.now() + 1000 * 60 * 60
  }

  return sessionCache
}

const remember = (userId, id) => {
  if (!userId) return
  const list = recentByUser.get(userId) || []
  list.push(id)
  while (list.length > HISTORY_LIMIT) list.shift()
  recentByUser.set(userId, list)
}

const resolveMp4 = async (hlsUrl) => {
  if (!hlsUrl) return null
  if (hlsUrl.includes('.mp4')) return hlsUrl

  const candidates = [
    hlsUrl.replace('/hls/', '/720p/').replace('.m3u8', '.mp4'),
    hlsUrl.replace('/hls/', '/expMp4/').replace('.m3u8', '_720w.mp4'),
    hlsUrl.replace('/videos/iht/hls/v2/', '/videos/mc/720p/').replace('.m3u8', '.mp4'),
    hlsUrl.replace('/videos/iht/hls/', '/videos/mc/720p/').replace('.m3u8', '.mp4'),
    hlsUrl.replace('/videos/iht/hls/', '/videos/iht/expMp4/').replace('.m3u8', '_720w.mp4'),
    hlsUrl.replace('/hls/', '/expMp4/').replace('.m3u8', '_1080w.mp4'),
    hlsUrl.replace('/hls/', '/expMp4/').replace('.m3u8', '_540w.mp4'),
    hlsUrl.replace('/hls/', '/480p/').replace('.m3u8', '.mp4')
  ]

  const unique = [...new Set(candidates)]
  try {
    return await Promise.any(
      unique.map(url =>
        axios.head(url, {
          headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
          timeout: 2500
        }).then(r => {
          if (r.status === 200) return url
          throw new Error()
        })
      )
    )
  } catch {
    return null
  }
}

const extractVideoFromPin = async (pin) => {
  if (!pin) return null
  let videoList = pin.videos?.video_list

  if (!videoList && pin.story_pin_data) {
    for (const page of pin.story_pin_data.pages || []) {
      for (const block of page.blocks || []) {
        if (block.video?.video_list) {
          videoList = block.video.video_list
          break
        }
      }
      if (videoList) break
    }
  }

  if (!videoList) return null

  for (const [k, v] of Object.entries(videoList)) {
    if (v.url && v.url.includes('.mp4') && !v.url.includes('hevc')) {
      return {
        id: pin.id,
        title: pin.title || pin.grid_title || 'Pinterest Video',
        url: v.url
      }
    }
  }

  const hlsUrl = videoList.V_HLSV4?.url || videoList.V_HLSV3_MOBILE?.url || Object.values(videoList)[0]?.url
  const mp4Url = await resolveMp4(hlsUrl)
  if (mp4Url) {
    return {
      id: pin.id,
      title: pin.title || pin.grid_title || 'Pinterest Video',
      url: mp4Url
    }
  }

  return null
}

const pinvidScraper = async (query, userId) => {
  const isUrl = /^https?:\/\//i.test(query.trim())
  const session = await getSession()

  if (isUrl) {
    let targetUrl = query.trim()
    if (/pin\.it/i.test(targetUrl)) {
      try {
        const res = await axios.get(targetUrl, {
          headers: { 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
          maxRedirects: 5,
          validateStatus: () => true
        })
        targetUrl = res.request?.res?.responseUrl || res.headers?.location || targetUrl
      } catch {}
    }

    const pinIdMatch = targetUrl.match(/\/pin\/(\d+)/) || targetUrl.match(/pin_id=(\d+)/)
    if (pinIdMatch) {
      try {
        const pinRes = await axios.get('https://www.pinterest.com/resource/PinResource/get/', {
          params: {
            source_url: `/pin/${pinIdMatch[1]}/`,
            data: JSON.stringify({
              options: { id: pinIdMatch[1], field_set_key: 'detailed' },
              context: {}
            }),
            _: Date.now()
          },
          headers: {
            'cookie': session.cookie,
            'x-csrftoken': session.csrf,
            'x-requested-with': 'XMLHttpRequest',
            'x-pinterest-appstate': 'active',
            'x-pinterest-pws-handler': 'www/[partner]/index.js',
            'referer': `https://www.pinterest.com/pin/${pinIdMatch[1]}/`,
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          },
          timeout: 10000
        })
        const pinData = pinRes.data?.resource_response?.data
        const vid = await extractVideoFromPin(pinData)
        if (vid) return vid
      } catch {}
    }

    try {
      const pageRes = await axios.get(targetUrl, {
        headers: {
          'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        },
        maxRedirects: 5,
        timeout: 10000
      })
      const clean = pageRes.data.replaceAll('\\/', '/')
      const mp4s = clean.match(/https?:\/\/[^\s"'<>]+\.mp4[^\s"'<>]*/g) || []
      const best = mp4s.find(u => u.includes('720p') || u.includes('expMp4')) || mp4s[0]
      if (best) {
        const titleMatch = pageRes.data.match(/<meta property="og:title" content="([^"]+)"/i) || pageRes.data.match(/<title>([^<]+)<\/title>/i)
        const title = titleMatch ? titleMatch[1].replace(/ - Pinterest.*$/i, '').trim() : 'Pinterest Video'
        return { title, url: best }
      }
    } catch {}

    return null
  }

  const searchTerm = /video|edit|reels|tiktok/i.test(query) ? query : `${query} video`

  const res = await axios.get('https://www.pinterest.com/resource/BaseSearchResource/get/', {
    params: {
      source_url: `/search/pins/?q=${encodeURIComponent(searchTerm)}`,
      data: JSON.stringify({
        options: {
          isPrefetch: false,
          query: searchTerm,
          scope: 'pins',
          bookmarks: [''],
          page_size: 30,
          source_url: `/search/pins/?q=${encodeURIComponent(searchTerm)}`
        },
        context: {}
      }),
      _: Date.now()
    },
    headers: {
      'cookie': session.cookie,
      'x-csrftoken': session.csrf,
      'x-requested-with': 'XMLHttpRequest',
      'x-pinterest-appstate': 'active',
      'x-pinterest-pws-handler': 'www/[partner]/index.js',
      'referer': `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(searchTerm)}`,
      'accept': 'application/json, text/javascript, */*; q=0.01',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    },
    timeout: 12000
  })

  const results = res.data?.resource_response?.data?.results || []
  if (!results.length) return null

  const seen = new Set(recentByUser.get(userId) || [])
  const potentialPins = results.filter(p => p && (p.videos || p.story_pin_data))
  if (!potentialPins.length) return null

  const unvisited = potentialPins.filter(p => !seen.has(p.id))
  const pool = (unvisited.length ? unvisited : potentialPins).sort(() => Math.random() - 0.5)

  for (const pin of pool) {
    const vid = await extractVideoFromPin(pin)
    if (vid && vid.url) {
      remember(userId, pin.id)
      return vid
    }
  }

  return null
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return conn.reply(m.chat, `Format Penggunaan:\n${usedPrefix + command} query\n${usedPrefix + command} link\n\nContoh:\n${usedPrefix + command} anime edit\n${usedPrefix + command} aesthetic nature\n${usedPrefix + command} https://pin.it/xxxxx`, m)
  }

  await conn.reply(m.chat, '🎬 Sedang mencari dan menyiapkan video Pinterest, tunggu sebentar...', m)

  try {
    const video = await pinvidScraper(text, m.sender)

    if (!video || !video.url) {
      return conn.reply(m.chat, '❌ Tidak ada video ditemukan untuk query atau link tersebut.', m)
    }

    const caption = `📌 *Pinterest Video*\n🏷️ *Judul:* ${video.title}\n\navosky-F`

    try {
      await conn.sendFile(m.chat, video.url, 'pinvid.mp4', caption, m)
    } catch {
      const vidBuffer = await axios.get(video.url, {
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
        timeout: 40000
      })
      await conn.sendFile(m.chat, Buffer.from(vidBuffer.data), 'pinvid.mp4', caption, m)
    }
  } catch (e) {
    conn.reply(m.chat, '❌ Gagal mengambil video dari Pinterest.', m)
  }
}

handler.command = /^(pinvid|pinterestvideo|pvideo)$/i
handler.help = ['pinvid <query/url>']
handler.tags = ['downloader']
handler.register = true
handler.limit = 10

export default handler