let handler = async (m, { conn, command }) => {
  let isPublic = command === 'public'
  let self = global.opts['self']

  if (self === !isPublic) {
    await m.react('❌')
    return
  }

  global.opts['self'] = !isPublic

  await m.react('✅')
}

handler.help = ['self', 'public']
handler.tags = ['owner']
handler.rowner = true
handler.command = /^(self|public)$/i
handler.limit = 10

export default handler