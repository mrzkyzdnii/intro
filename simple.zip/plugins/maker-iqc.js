import fetch from 'node-fetch'

const randomTime = () => {
  const hour = Math.floor(Math.random() * 24)
  const minute = Math.floor(Math.random() * 60)

  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`
}

const randomBattery = () => Math.floor(Math.random() * 100) + 1

let handler = async (m, { conn, text }) => {
  if (!text) throw `Gunakan:\n.iqc pesan\n\nContoh:\n.iqc hai hai`

  const messageText = text.trim()

  if (!messageText) throw 'Pesannya tidak boleh kosong.'

  const time = randomTime()
  const battery = randomBattery()

  await m.react('⏳')

  const url =
    `https://brat.siputzx.my.id/iphone-quoted` +
    `?time=${encodeURIComponent(time)}` +
    `&batteryPercentage=${battery}` +
    `&carrierName=INDOSAT` +
    `&messageText=${encodeURIComponent(messageText)}` +
    `&emojiStyle=apple`

  try {
    const res = await fetch(url)

    if (!res.ok) throw new Error(`HTTP ${res.status}`)

    const buffer = await res.buffer()

    await conn.sendMessage(
      m.chat,
      {
        image: buffer
      },
      {
        quoted: m
      }
    )

    await m.react('✅')
  } catch (e) {
    await m.react('❌')
    throw `Gagal membuat IQC: ${e.message}`
  }
}

handler.help = ['iqc pesan']
handler.tags = ['maker']
handler.command = /^iqc$/i
handler.limit = 10

export default handler