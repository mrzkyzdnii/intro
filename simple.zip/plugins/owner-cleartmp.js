import fs from 'fs'
import path from 'path'

const handler = async (m, { isOwner }) => {
if (!isOwner) return

const tmp = path.join(process.cwd(), 'tmp')

try {
if (!fs.existsSync(tmp)) fs.mkdirSync(tmp, { recursive: true })

for (const file of fs.readdirSync(tmp)) {
const target = path.join(tmp, file)
fs.rmSync(target, { recursive: true, force: true })
}

await m.react('✅')
} catch {
await m.react('❌')
}
}

handler.help = ['cleartmp']
handler.tags = ['owner']
handler.command = /^cleartmp$/i

export default handler