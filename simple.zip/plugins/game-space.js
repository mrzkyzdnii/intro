const handler = async (m, { conn, command }) => {
conn.relayMessage(
m.chat,
{
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
botMetadata: {
messageDisclaimerText: "",
botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860",
verificationMetadata: {
proofs: [
{
version: 1,
useCase: 1,
signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
certificateChain: [
"TklYRUwuTWVzc2FnZUJ1bGRlc..." 
]
}
]
}
}
},
botForwardedMessage: {
message: {
richResponseMessage: {
messageType: 1,
submessages: [
{
messageType: 2,
messageText: "🚀 SPACE SHOOTER - GALACTIC WAR"
}
],
unifiedResponse: {
data: Buffer.from(JSON.stringify({
"response_id": "4db57b2c-8393-484d-8b9a-8e6d1a14b349",
"sections": [
{
"view_model": {
"primitive": {
"__typename": "GenAIaeacdsnwHtmlPrimitive",
"payload": `<style>
* {
  box-sizing: border-box;
  -webkit-tap-highlight-color: transparent;
  -webkit-user-select: none;
  user-select: none;
  margin: 0;
  padding: 0;
}

body {
  margin: 0;
  background: #0a0a1a;
  font-family: 'Orbitron', 'Arial', sans-serif;
  touch-action: manipulation;
  overflow: hidden;
}

.game-container {
  width: 100%;
  max-width: 420px;
  margin: 0 auto;
  background: linear-gradient(180deg, #0a0a2e 0%, #1a0a3e 50%, #0a0a1a 100%);
  border-radius: 24px;
  padding: 10px;
  position: relative;
  box-shadow: 0 0 60px rgba(100, 50, 255, 0.3);
  border: 1px solid rgba(255, 255, 255, 0.1);
}

.game-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 12px;
  background: rgba(0, 0, 0, 0.6);
  border-radius: 16px;
  margin-bottom: 8px;
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.game-title {
  font-size: 14px;
  font-weight: 900;
  background: linear-gradient(90deg, #00d4ff, #7b2ffc, #ff6b6b);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-shadow: 0 0 30px rgba(0, 212, 255, 0.3);
  letter-spacing: 2px;
}

.game-stats {
  display: flex;
  gap: 15px;
  font-size: 11px;
  color: #8899bb;
}

.stat-item {
  display: flex;
  align-items: center;
  gap: 4px;
}

.stat-icon {
  font-size: 14px;
}

.stat-value {
  font-weight: bold;
  color: #fff;
  font-size: 13px;
}

canvas {
  width: 100%;
  height: auto;
  border-radius: 16px;
  display: block;
  background: radial-gradient(ellipse at center, #0a0a2e 0%, #000 100%);
  border: 2px solid rgba(255, 255, 255, 0.05);
  box-shadow: inset 0 0 50px rgba(100, 50, 255, 0.1);
  touch-action: none;
  cursor: none;
}

.game-controls {
  display: flex;
  gap: 8px;
  padding: 8px 4px;
  margin-top: 8px;
}

.control-btn {
  flex: 1;
  border: none;
  border-radius: 12px;
  padding: 14px 8px;
  font-weight: bold;
  font-size: 13px;
  color: #fff;
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  transition: all 0.1s;
  text-transform: uppercase;
  letter-spacing: 1px;
  touch-action: none;
  position: relative;
  overflow: hidden;
}

.control-btn:active {
  transform: scale(0.95);
}

.control-btn.left {
  background: linear-gradient(135deg, rgba(0, 100, 255, 0.3), rgba(0, 50, 200, 0.2));
  border-color: rgba(0, 150, 255, 0.3);
}

.control-btn.right {
  background: linear-gradient(135deg, rgba(255, 100, 0, 0.3), rgba(200, 50, 0, 0.2));
  border-color: rgba(255, 150, 0, 0.3);
}

.control-btn.fire {
  background: linear-gradient(135deg, rgba(255, 0, 100, 0.4), rgba(200, 0, 50, 0.3));
  border-color: rgba(255, 0, 100, 0.4);
  flex: 1.5;
}

.control-btn.skill {
  background: linear-gradient(135deg, rgba(0, 255, 150, 0.2), rgba(0, 200, 100, 0.1));
  border-color: rgba(0, 255, 150, 0.2);
  flex: 0.8;
}

.control-btn .btn-icon {
  font-size: 18px;
  display: block;
  margin-bottom: 2px;
}

.control-btn .btn-label {
  font-size: 9px;
  opacity: 0.7;
}

.powerup-indicator {
  display: flex;
  gap: 6px;
  padding: 6px 12px;
  background: rgba(0, 0, 0, 0.5);
  border-radius: 10px;
  margin-top: 6px;
  border: 1px solid rgba(255, 255, 255, 0.05);
  flex-wrap: wrap;
  min-height: 30px;
  align-items: center;
}

.powerup-item {
  font-size: 11px;
  padding: 2px 10px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: #aabbdd;
}

.powerup-item.active {
  border-color: #00ff88;
  color: #00ff88;
  box-shadow: 0 0 20px rgba(0, 255, 136, 0.2);
}

.stage-indicator {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 48px;
  font-weight: 900;
  color: #fff;
  text-shadow: 0 0 60px rgba(100, 50, 255, 0.8);
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.5s;
  z-index: 10;
  text-align: center;
  line-height: 1.2;
}

.stage-indicator.show {
  opacity: 1;
}

.stage-sub {
  font-size: 20px;
  font-weight: 400;
  opacity: 0.7;
}

.boss-health {
  height: 4px;
  background: rgba(255, 0, 0, 0.2);
  border-radius: 2px;
  margin: 4px 0;
  overflow: hidden;
  display: none;
}

.boss-health .fill {
  height: 100%;
  background: linear-gradient(90deg, #ff0000, #ff6b00, #ffdd00);
  width: 100%;
  transition: width 0.3s;
  border-radius: 2px;
}

@media (max-width: 480px) {
  .game-container {
    padding: 6px;
  }
  .control-btn {
    padding: 10px 4px;
    font-size: 11px;
  }
  .game-title {
    font-size: 12px;
  }
}
</style>

<div class="game-container">
  <div class="game-header">
    <div class="game-title">🚀 SPACE SHOOTER</div>
    <div class="game-stats">
      <div class="stat-item">
        <span class="stat-icon">⭐</span>
        <span class="stat-value" id="scoreDisplay">0</span>
      </div>
      <div class="stat-item">
        <span class="stat-icon">🎯</span>
        <span class="stat-value" id="stageDisplay">1</span>
      </div>
      <div class="stat-item">
        <span class="stat-icon">❤️</span>
        <span class="stat-value" id="livesDisplay">3</span>
      </div>
    </div>
  </div>

  <div style="position:relative">
    <canvas id="gameCanvas" width="400" height="600"></canvas>
    <div class="stage-indicator" id="stageIndicator">STAGE 1</div>
    <div class="boss-health" id="bossHealth">
      <div class="fill" id="bossHealthFill"></div>
    </div>
  </div>

  <div class="game-controls">
    <button class="control-btn left" id="btnLeft">
      <span class="btn-icon">◀</span>
      <span class="btn-label">LEFT</span>
    </button>
    <button class="control-btn fire" id="btnFire">
      <span class="btn-icon">🔥</span>
      <span class="btn-label">SHOOT</span>
    </button>
    <button class="control-btn right" id="btnRight">
      <span class="btn-icon">▶</span>
      <span class="btn-label">RIGHT</span>
    </button>
    <button class="control-btn skill" id="btnSkill">
      <span class="btn-icon">✨</span>
      <span class="btn-label">ALLY</span>
    </button>
  </div>

  <div class="powerup-indicator" id="powerupDisplay">
    <span style="color:#667;font-size:10px">🔋 POWER-UPS</span>
  </div>
</div>

<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const W = 400, H = 600;

// Game state
let game = {
  player: null,
  enemies: [],
  bullets: [],
  enemyBullets: [],
  particles: [],
  powerupDrops: [],
  allies: [],
  allyBullets: [],
  score: 0,
  lives: 3,
  stage: 1,
  maxStage: 10,
  gameOver: false,
  paused: false,
  bossActive: false,
  boss: null,
  stageTimer: 0,
  maxStageTime: 180,
  combo: 0,
  maxCombo: 0,
  powerups: {
    shield: false,
    spread: false,
    rapid: false,
    ally: false,
    bomb: 0
  },
  powerupTimers: {},
  spawnTimer: 0,
  spawnInterval: 60,
  enemyCount: 0,
  maxEnemies: 5,
  difficulty: 1,
  frameCount: 0
};

// Player class
class Player {
  constructor() {
    this.x = W/2;
    this.y = H - 80;
    this.width = 30;
    this.height = 35;
    this.speed = 4;
    this.shootTimer = 0;
    this.shootInterval = 8;
    this.invincible = 0;
    this.engineParticles = [];
    this.trail = [];
  }

  update() {
    if (this.invincible > 0) this.invincible--;
    
    if (game.frameCount % 2 === 0) {
      this.engineParticles.push({
        x: this.x + (Math.random() - 0.5) * 10,
        y: this.y + 20,
        vx: (Math.random() - 0.5) * 0.5,
        vy: 2 + Math.random() * 2,
        life: 20 + Math.random() * 20,
        maxLife: 40,
        size: 2 + Math.random() * 3
      });
    }
    
    this.engineParticles = this.engineParticles.filter(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.life--;
      return p.life > 0;
    });
    
    if (game.frameCount % 3 === 0) {
      this.trail.push({x: this.x, y: this.y + 15, life: 15});
    }
    this.trail = this.trail.filter(t => {
      t.life--;
      t.y += 0.5;
      return t.life > 0;
    });
  }

  draw() {
    this.trail.forEach(t => {
      ctx.globalAlpha = t.life / 15 * 0.3;
      ctx.fillStyle = '#00aaff';
      ctx.beginPath();
      ctx.arc(t.x, t.y, 3, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    
    this.engineParticles.forEach(p => {
      ctx.globalAlpha = p.life / p.maxLife;
      const grad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
      grad.addColorStop(0, '#00ddff');
      grad.addColorStop(0.5, '#0088ff');
      grad.addColorStop(1, 'rgba(0,0,255,0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
    
    if (game.powerups.shield) {
      ctx.strokeStyle = 'rgba(0, 255, 200, 0.3)';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#00ffcc';
      ctx.shadowBlur = 20;
      ctx.beginPath();
      ctx.arc(this.x, this.y, 30, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }
    
    ctx.save();
    ctx.translate(this.x, this.y);
    
    const glow = ctx.createRadialGradient(0, 0, 5, 0, 0, 35);
    glow.addColorStop(0, 'rgba(0, 150, 255, 0.1)');
    glow.addColorStop(1, 'rgba(0, 150, 255, 0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, 35, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.shadowColor = '#00aaff';
    ctx.shadowBlur = 20;
    
    const grad = ctx.createLinearGradient(-15, -20, 15, 20);
    grad.addColorStop(0, '#00ddff');
    grad.addColorStop(0.5, '#0088ff');
    grad.addColorStop(1, '#0044aa');
    
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, -22);
    ctx.lineTo(-16, 10);
    ctx.lineTo(-10, 18);
    ctx.lineTo(0, 14);
    ctx.lineTo(10, 18);
    ctx.lineTo(16, 10);
    ctx.closePath();
    ctx.fill();
    
    ctx.shadowBlur = 10;
    ctx.fillStyle = 'rgba(100, 200, 255, 0.6)';
    ctx.beginPath();
    ctx.ellipse(0, -5, 6, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.shadowBlur = 15;
    ctx.fillStyle = '#0066cc';
    ctx.beginPath();
    ctx.moveTo(-18, 2);
    ctx.lineTo(-25, 12);
    ctx.lineTo(-18, 10);
    ctx.closePath();
    ctx.fill();
    
    ctx.beginPath();
    ctx.moveTo(18, 2);
    ctx.lineTo(25, 12);
    ctx.lineTo(18, 10);
    ctx.closePath();
    ctx.fill();
    
    ctx.shadowBlur = 0;
    ctx.restore();
    
    if (this.invincible > 0 && Math.floor(this.invincible / 5) % 2 === 0) {
      ctx.globalAlpha = 0.3;
      ctx.fillStyle = '#00ddff';
      ctx.beginPath();
      ctx.arc(this.x, this.y, 20, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  shoot() {
    if (this.shootTimer > 0) return;
    
    const bullets = [];
    if (game.powerups.spread) {
      for (let i = -2; i <= 2; i++) {
        bullets.push({
          x: this.x + i * 8,
          y: this.y - 20,
          vx: i * 1.2,
          vy: -6,
          damage: 1,
          size: 4,
          color: i === 0 ? '#00ff88' : '#44ddff'
        });
      }
    } else if (game.powerups.rapid) {
      bullets.push({
        x: this.x - 4,
        y: this.y - 20,
        vx: 0,
        vy: -8,
        damage: 1,
        size: 3,
        color: '#ff8800'
      });
      bullets.push({
        x: this.x + 4,
        y: this.y - 20,
        vx: 0,
        vy: -8,
        damage: 1,
        size: 3,
        color: '#ff8800'
      });
    } else {
      bullets.push({
        x: this.x,
        y: this.y - 20,
        vx: 0,
        vy: -7,
        damage: 1,
        size: 4,
        color: '#00ddff'
      });
    }
    
    bullets.forEach(b => {
      game.bullets.push(b);
      for (let i = 0; i < 5; i++) {
        game.particles.push({
          x: b.x,
          y: b.y,
          vx: (Math.random() - 0.5) * 3,
          vy: -Math.random() * 4 - 1,
          life: 10 + Math.random() * 10,
          maxLife: 20,
          size: 2 + Math.random() * 3,
          color: i % 2 === 0 ? '#00ddff' : '#0088ff'
        });
      }
    });
    
    this.shootTimer = game.powerups.rapid ? 4 : this.shootInterval;
  }

  updateShoot() {
    if (this.shootTimer > 0) this.shootTimer--;
  }

  getBounds() {
    return {
      x: this.x - 20,
      y: this.y - 22,
      width: 40,
      height: 44
    };
  }
}

// Enemy types
const ENEMY_TYPES = {
  SCOUT: {
    health: 1,
    speed: 1.5,
    size: 16,
    score: 10,
    color: '#44ddff',
    shootInterval: 120,
    behavior: 'straight'
  },
  FIGHTER: {
    health: 2,
    speed: 1.2,
    size: 20,
    score: 20,
    color: '#ff8844',
    shootInterval: 90,
    behavior: 'zigzag'
  },
  TANK: {
    health: 4,
    speed: 0.8,
    size: 24,
    score: 30,
    color: '#ff4444',
    shootInterval: 60,
    behavior: 'straight'
  },
  BOSS: {
    health: 50,
    speed: 0.5,
    size: 45,
    score: 100,
    color: '#ff00ff',
    shootInterval: 30,
    behavior: 'boss'
  }
};

class Enemy {
  constructor(type, x, y) {
    this.type = type;
    const data = ENEMY_TYPES[type];
    this.x = x;
    this.y = y;
    this.health = data.health + Math.floor(game.stage / 3);
    this.maxHealth = this.health;
    this.speed = data.speed + (game.stage - 1) * 0.05;
    this.size = data.size;
    this.score = data.score;
    this.color = data.color;
    this.shootTimer = Math.random() * data.shootInterval;
    this.shootInterval = Math.max(20, data.shootInterval - game.stage * 2);
    this.behavior = data.behavior;
    this.phase = 0;
    this.startX = x;
    this.startY = y;
    this.hitFlash = 0;
    this.angle = 0;
  }

  update() {
    this.phase++;
    this.hitFlash = Math.max(0, this.hitFlash - 1);
    
    if (this.type === 'BOSS') {
      this.updateBoss();
    } else {
      this.updateNormal();
    }
    
    this.shootTimer--;
    if (this.shootTimer <= 0 && this.y < H - 50) {
      this.shoot();
      this.shootTimer = this.shootInterval + (Math.random() - 0.5) * 20;
    }
  }

  updateNormal() {
    switch(this.behavior) {
      case 'straight':
        this.y += this.speed;
        break;
      case 'zigzag':
        this.y += this.speed * 0.8;
        this.x += Math.sin(this.phase * 0.05) * 1.5;
        break;
      default:
        this.y += this.speed;
    }
  }

  updateBoss() {
    this.y = Math.min(this.y + 0.3, 100);
    this.x = this.startX + Math.sin(this.phase * 0.02) * 120;
    
    if (this.phase % 60 === 0 && this.phase < 600) {
      for (let i = 0; i < 1 + Math.floor(game.stage / 3); i++) {
        const enemy = new Enemy(
          ['SCOUT', 'FIGHTER'][Math.floor(Math.random() * 2)],
          Math.random() * (W - 40) + 20,
          -20 - i * 30
        );
        game.enemies.push(enemy);
      }
    }
  }

  shoot() {
    const angle = Math.atan2(game.player.y - this.y, game.player.x - this.x);
    const speed = this.type === 'BOSS' ? 3 : 2;
    
    if (this.type === 'BOSS') {
      for (let i = -2; i <= 2; i++) {
        game.enemyBullets.push({
          x: this.x,
          y: this.y + this.size,
          vx: Math.cos(angle + i * 0.3) * speed,
          vy: Math.sin(angle + i * 0.3) * speed,
          size: i === 0 ? 8 : 5,
          color: i === 0 ? '#ff00ff' : '#ff44aa'
        });
      }
    } else {
      game.enemyBullets.push({
        x: this.x,
        y: this.y + this.size,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 5,
        color: '#ff6644'
      });
    }
  }

  draw() {
    ctx.save();
    ctx.translate(this.x, this.y);
    
    const glow = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size * 1.5);
    glow.addColorStop(0, this.color + '40');
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.beginPath();
    ctx.arc(0, 0, this.size * 1.5, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.shadowColor = this.color;
    ctx.shadowBlur = 15;
    
    if (this.hitFlash > 0) {
      ctx.fillStyle = '#ffffff';
    } else {
      const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, this.size);
      grad.addColorStop(0, this.color);
      grad.addColorStop(1, this.color + '88');
      ctx.fillStyle = grad;
    }
    
    if (this.type === 'SCOUT') {
      // Small interceptor: pointed nose, swept wings and a bright cockpit.
      ctx.beginPath();
      ctx.moveTo(0, -this.size * 1.15);
      ctx.lineTo(-this.size * 0.45, -this.size * 0.2);
      ctx.lineTo(-this.size, this.size * 0.85);
      ctx.lineTo(-this.size * 0.18, this.size * 0.55);
      ctx.lineTo(0, this.size);
      ctx.lineTo(this.size * 0.18, this.size * 0.55);
      ctx.lineTo(this.size, this.size * 0.85);
      ctx.lineTo(this.size * 0.45, -this.size * 0.2);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#d9fbff';
      ctx.beginPath();
      ctx.ellipse(0, -this.size * 0.25, this.size * 0.22, this.size * 0.35, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (this.type === 'FIGHTER') {
      // Agile fighter: broad wings and twin engine pods.
      ctx.beginPath();
      ctx.moveTo(0, -this.size * 1.1);
      ctx.lineTo(this.size * 0.35, -this.size * 0.15);
      ctx.lineTo(this.size * 1.2, this.size * 0.45);
      ctx.lineTo(this.size * 0.72, this.size * 0.7);
      ctx.lineTo(this.size * 0.3, this.size * 0.45);
      ctx.lineTo(0, this.size * 0.95);
      ctx.lineTo(-this.size * 0.3, this.size * 0.45);
      ctx.lineTo(-this.size * 0.72, this.size * 0.7);
      ctx.lineTo(-this.size * 1.2, this.size * 0.45);
      ctx.lineTo(-this.size * 0.35, -this.size * 0.15);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = '#fff0d0';
      ctx.beginPath();
      ctx.ellipse(0, -this.size * 0.35, this.size * 0.25, this.size * 0.38, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffdd66';
      ctx.fillRect(-this.size * 0.7, this.size * 0.55, this.size * 0.28, this.size * 0.22);
      ctx.fillRect(this.size * 0.42, this.size * 0.55, this.size * 0.28, this.size * 0.22);
    } else if (this.type === 'TANK') {
      // Armored tank: heavy hull, side armor and central cannon.
      ctx.fillRect(-this.size * 0.78, -this.size * 0.65, this.size * 1.56, this.size * 1.35);
      ctx.fillRect(-this.size * 1.15, -this.size * 0.28, this.size * 0.35, this.size * 0.85);
      ctx.fillRect(this.size * 0.8, -this.size * 0.28, this.size * 0.35, this.size * 0.85);
      ctx.fillStyle = '#ffcc66';
      ctx.fillRect(-this.size * 0.16, -this.size * 1.05, this.size * 0.32, this.size * 0.72);
      ctx.fillStyle = '#551122';
      ctx.fillRect(-this.size * 0.52, -this.size * 0.25, this.size * 0.3, this.size * 0.3);
      ctx.fillRect(this.size * 0.22, -this.size * 0.25, this.size * 0.3, this.size * 0.3);
    } else if (this.type === 'BOSS') {
      ctx.fillStyle = this.hitFlash > 0 ? '#ffffff' : '#ff00ff';
      for (let i = 0; i < 8; i++) {
        const spikeAngle = (i / 8) * Math.PI * 2 + this.phase * 0.02;
        const inner = this.size * 0.52;
        const outer = this.size * (1.05 + 0.12 * Math.sin(this.phase * 0.03 + i));
        ctx.beginPath();
        ctx.moveTo(Math.cos(spikeAngle - 0.16) * inner, Math.sin(spikeAngle - 0.16) * inner);
        ctx.lineTo(Math.cos(spikeAngle) * outer, Math.sin(spikeAngle) * outer);
        ctx.lineTo(Math.cos(spikeAngle + 0.16) * inner, Math.sin(spikeAngle + 0.16) * inner);
        ctx.closePath();
        ctx.fill();
      }
      ctx.shadowBlur = 30;
      ctx.fillStyle = '#ff44ff';
      ctx.beginPath();
      ctx.arc(0, 0, this.size * 0.52, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#220022';
      ctx.beginPath();
      ctx.arc(0, 0, this.size * 0.22, 0, Math.PI * 2);
      ctx.fill();
    }
    
    ctx.shadowBlur = 0;
    ctx.restore();
    
    if (this.type === 'BOSS') {
      const barWidth = 100;
      const barHeight = 6;
      const x = this.x - barWidth / 2;
      const y = this.y - this.size - 12;
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.fillRect(x, y, barWidth, barHeight);
      ctx.fillStyle = '#ff00ff';
      ctx.fillRect(x, y, barWidth * (this.health / this.maxHealth), barHeight);
    }
  }

  getBounds() {
    return {
      x: this.x - this.size,
      y: this.y - this.size,
      width: this.size * 2,
      height: this.size * 2
    };
  }
}

// Ally class
class Ally {
  constructor() {
    this.x = game.player.x + (Math.random() - 0.5) * 60;
    this.y = game.player.y + 40 + Math.random() * 30;
    this.size = 14;
    this.shootTimer = 0;
    this.shootInterval = 30;
    this.life = 600;
    this.angle = 0;
  }

  update() {
    this.life--;
    this.angle += 0.05;
    this.x += (game.player.x - this.x) * 0.03;
    this.y += (game.player.y - this.y) * 0.03 + 0.2;
    
    this.shootTimer--;
    if (this.shootTimer <= 0 && game.enemies.length > 0) {
      const target = game.enemies[Math.floor(Math.random() * game.enemies.length)];
      if (target) {
        const angle = Math.atan2(target.y - this.y, target.x - this.x);
        game.allyBullets.push({
          x: this.x,
          y: this.y - 10,
          vx: Math.cos(angle) * 4,
          vy: Math.sin(angle) * 4,
          damage: 1,
          size: 4,
          color: '#00ff88'
        });
        this.shootTimer = this.shootInterval;
      }
    }
  }

  draw() {
    ctx.save();
    ctx.translate(this.x, this.y);
    
    ctx.shadowColor = '#00ff88';
    ctx.shadowBlur = 20;
    
    const grad = ctx.createLinearGradient(-10, -12, 10, 12);
    grad.addColorStop(0, '#00ff88');
    grad.addColorStop(1, '#00aa44');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, -14);
    ctx.lineTo(-10, 8);
    ctx.lineTo(-6, 12);
    ctx.lineTo(0, 10);
    ctx.lineTo(6, 12);
    ctx.lineTo(10, 8);
    ctx.closePath();
    ctx.fill();
    
    ctx.shadowBlur = 0;
    ctx.restore();
    
    ctx.fillStyle = 'rgba(0, 255, 136, 0.3)';
    ctx.fillRect(this.x - 10, this.y + 14, 20 * (this.life / 600), 2);
  }

  getBounds() {
    return {
      x: this.x - this.size,
      y: this.y - this.size,
      width: this.size * 2,
      height: this.size * 2
    };
  }
}

// Initialize game
function initGame() {
  game.player = new Player();
  game.enemies = [];
  game.bullets = [];
  game.enemyBullets = [];
  game.particles = [];
  game.powerupDrops = [];
  game.allies = [];
  game.allyBullets = [];
  game.score = 0;
  game.lives = 3;
  game.stage = 1;
  game.gameOver = false;
  game.bossActive = false;
  game.boss = null;
  game.stageTimer = 0;
  game.combo = 0;
  game.maxCombo = 0;
  game.powerups = {
    shield: false,
    spread: false,
    rapid: false,
    ally: false,
    bomb: 0
  };
  game.powerupTimers = {};
  game.spawnTimer = 0;
  game.enemyCount = 0;
  game.difficulty = 1;
  
  updateUI();
  showStageIndicator('STAGE ' + game.stage);
  document.getElementById('bossHealth').style.display = 'none';
}

// Spawn enemies based on stage
function spawnEnemies() {
  const stage = game.stage;
  const maxEnemies = Math.min(3 + stage, 12);
  const enemyTypes = ['SCOUT'];
  
  if (stage >= 2) enemyTypes.push('FIGHTER');
  if (stage >= 3) enemyTypes.push('TANK');
  if (stage >= 5) enemyTypes.push('FIGHTER', 'TANK');
  if (stage >= 7) enemyTypes.push('TANK', 'SCOUT');
  
  if (stage % 5 === 0 && !game.bossActive && game.enemies.length === 0) {
    spawnBoss();
    return;
  }
  
  if (game.enemies.length < maxEnemies && game.frameCount % Math.max(30, 80 - stage * 3) === 0) {
    const type = enemyTypes[Math.floor(Math.random() * enemyTypes.length)];
    const x = 30 + Math.random() * (W - 60);
    const y = -20 - Math.random() * 30;
    const enemy = new Enemy(type, x, y);
    game.enemies.push(enemy);
    game.enemyCount++;
  }
}

function spawnBoss() {
  game.bossActive = true;
  const boss = new Enemy('BOSS', W/2, -60);
  boss.health = 30 + game.stage * 5;
  boss.maxHealth = boss.health;
  game.boss = boss;
  game.enemies.push(boss);
  document.getElementById('bossHealth').style.display = 'block';
  document.getElementById('bossHealthFill').style.width = '100%';
  showStageIndicator('⚠️ BOSS STAGE ⚠️');
}

// Spawn powerups
function spawnPowerup(x, y) {
  if (Math.random() > 0.15) return;
  
  const types = ['shield', 'spread', 'rapid', 'ally'];
  const type = types[Math.floor(Math.random() * types.length)];
  
  game.powerupDrops.push({
    x: x,
    y: y,
    type: type,
    size: 12,
    speed: 1.5,
    phase: 0
  });
}

// Show stage indicator
function showStageIndicator(text) {
  const el = document.getElementById('stageIndicator');
  el.textContent = text;
  el.classList.add('show');
  setTimeout(() => {
    el.classList.remove('show');
  }, 2000);
}

// Update UI
function updateUI() {
  document.getElementById('scoreDisplay').textContent = game.score;
  document.getElementById('stageDisplay').textContent = game.stage;
  document.getElementById('livesDisplay').textContent = game.lives;
  
  const display = document.getElementById('powerupDisplay');
  let html = '<span style="color:#667;font-size:10px">🔋 POWER-UPS</span>';
  if (game.powerups.shield) html += ' <span class="powerup-item active">🛡️ Shield</span>';
  if (game.powerups.spread) html += ' <span class="powerup-item active">✳️ Spread</span>';
  if (game.powerups.rapid) html += ' <span class="powerup-item active">⚡ Rapid</span>';
  if (game.powerups.bomb > 0) html += ' <span class="powerup-item active">💣 x' + game.powerups.bomb + '</span>';
  if (game.allies.length > 0) html += ' <span class="powerup-item active">👥 x' + game.allies.length + '</span>';
  display.innerHTML = html;
}

// Collision detection
function rectCollide(a, b) {
  return a.x < b.x + b.width &&
         a.x + a.width > b.x &&
         a.y < b.y + b.height &&
         a.y + a.height > b.y;
}

// Game update
function update() {
  if (game.gameOver) return;
  
  game.frameCount++;
  game.stageTimer++;
  
  if (game.stageTimer >= game.maxStageTime * 60) {
    if (!game.bossActive || (game.boss && game.boss.health <= 0)) {
      nextStage();
    }
  }
  
  game.player.update();
  game.player.updateShoot();
  
  if (game.frameCount % 3 === 0) {
    game.player.shoot();
  }
  
  game.enemies = game.enemies.filter(enemy => {
    enemy.update();
    return enemy.y < H + 50 && enemy.health > 0;
  });
  
  if (game.boss && game.boss.health > 0) {
    const fill = document.getElementById('bossHealthFill');
    fill.style.width = (game.boss.health / game.boss.maxHealth * 100) + '%';
  } else if (game.boss) {
    game.bossActive = false;
    game.boss = null;
    document.getElementById('bossHealth').style.display = 'none';
    if (game.stage % 5 === 0) {
      setTimeout(() => nextStage(), 500);
    }
  }
  
  game.bullets = game.bullets.filter(b => {
    b.x += b.vx;
    b.y += b.vy;
    return b.y > -20 && b.x > -20 && b.x < W + 20;
  });
  
  game.enemyBullets = game.enemyBullets.filter(b => {
    b.x += b.vx;
    b.y += b.vy;
    return b.y < H + 20 && b.y > -20 && b.x > -20 && b.x < W + 20;
  });
  
  game.allyBullets = game.allyBullets.filter(b => {
    b.x += b.vx;
    b.y += b.vy;
    return b.y > -20 && b.x > -20 && b.x < W + 20;
  });
  
  game.allies = game.allies.filter(ally => {
    ally.update();
    return ally.life > 0;
  });
  
  game.particles = game.particles.filter(p => {
    p.x += p.vx;
    p.y += p.vy;
    p.life--;
    p.size *= 0.98;
    return p.life > 0;
  });
  
  game.powerupDrops = game.powerupDrops.filter(p => {
    p.y += p.speed;
    p.phase += 0.05;
    return p.y < H + 20;
  });
  
  // Collision: player bullets vs enemies
  game.bullets.forEach(bullet => {
    game.enemies.forEach(enemy => {
      if (bullet.damage) {
        const bounds = enemy.getBounds();
        if (bullet.x > bounds.x && bullet.x < bounds.x + bounds.width &&
            bullet.y > bounds.y && bullet.y < bounds.y + bounds.height) {
          enemy.health -= bullet.damage;
          enemy.hitFlash = 10;
          bullet.damage = 0;
          
          for (let i = 0; i < 10; i++) {
            game.particles.push({
              x: bullet.x,
              y: bullet.y,
              vx: (Math.random() - 0.5) * 6,
              vy: (Math.random() - 0.5) * 6,
              life: 15 + Math.random() * 15,
              maxLife: 30,
              size: 2 + Math.random() * 4,
              color: enemy.color
            });
          }
          
          if (enemy.health <= 0) {
            game.score += enemy.score * (1 + game.combo * 0.1);
            game.combo++;
            game.maxCombo = Math.max(game.maxCombo, game.combo);
            
            for (let i = 0; i < 30; i++) {
              const angle = Math.random() * Math.PI * 2;
              const speed = Math.random() * 5 + 1;
              game.particles.push({
                x: enemy.x,
                y: enemy.y,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed - 1,
                life: 20 + Math.random() * 20,
                maxLife: 40,
                size: 2 + Math.random() * 5,
                color: ['#ff4444', '#ff8844', '#ffdd44', '#ffffff'][Math.floor(Math.random() * 4)]
              });
            }
            
            spawnPowerup(enemy.x, enemy.y);
            enemy.health = 0;
          }
        }
      }
    });
  });
  
  // Collision: ally bullets vs enemies
  game.allyBullets.forEach(bullet => {
    game.enemies.forEach(enemy => {
      if (bullet.damage) {
        const bounds = enemy.getBounds();
        if (bullet.x > bounds.x && bullet.x < bounds.x + bounds.width &&
            bullet.y > bounds.y && bullet.y < bounds.y + bounds.height) {
          enemy.health -= bullet.damage;
          enemy.hitFlash = 10;
          bullet.damage = 0;
          
          if (enemy.health <= 0) {
            game.score += enemy.score * 0.5;
            enemy.health = 0;
          }
        }
      }
    });
  });
  
  // Collision: enemy bullets vs player
  game.enemyBullets.forEach(bullet => {
    if (game.player.invincible > 0) return;
    const bounds = game.player.getBounds();
    if (bullet.x > bounds.x && bullet.x < bounds.x + bounds.width &&
        bullet.y > bounds.y && bullet.y < bounds.y + bounds.height) {
      if (game.powerups.shield) {
        game.powerups.shield = false;
        for (let i = 0; i < 20; i++) {
          game.particles.push({
            x: bullet.x,
            y: bullet.y,
            vx: (Math.random() - 0.5) * 8,
            vy: (Math.random() - 0.5) * 8,
            life: 20,
            maxLife: 20,
            size: 3,
            color: '#00ffcc'
          });
        }
      } else {
        playerHit();
      }
      bullet.x = -100;
    }
  });
  
  // Collision: enemies vs player
  game.enemies.forEach(enemy => {
    if (game.player.invincible > 0) return;
    const bounds = game.player.getBounds();
    const eb = enemy.getBounds();
    if (rectCollide(bounds, eb)) {
      if (game.powerups.shield) {
        game.powerups.shield = false;
        enemy.health -= 5;
      } else {
        playerHit();
      }
    }
  });
  
  // Collision: powerups vs player
  game.powerupDrops = game.powerupDrops.filter(p => {
    const bounds = game.player.getBounds();
    if (p.x > bounds.x && p.x < bounds.x + bounds.width &&
        p.y > bounds.y && p.y < bounds.y + bounds.height) {
      if (p.type === 'ally') {
        for (let i = 0; i < 2; i++) {
          game.allies.push(new Ally());
        }
      } else if (p.type === 'shield') {
        game.powerups.shield = true;
        setTimeout(() => { game.powerups.shield = false; }, 8000);
      } else if (p.type === 'spread') {
        game.powerups.spread = true;
        setTimeout(() => { game.powerups.spread = false; }, 6000);
      } else if (p.type === 'rapid') {
        game.powerups.rapid = true;
        setTimeout(() => { game.powerups.rapid = false; }, 5000);
      }
      
      for (let i = 0; i < 15; i++) {
        game.particles.push({
          x: p.x,
          y: p.y,
          vx: (Math.random() - 0.5) * 6,
          vy: (Math.random() - 0.5) * 6 - 2,
          life: 15,
          maxLife: 15,
          size: 3,
          color: '#00ff88'
        });
      }
      
      return false;
    }
    return true;
  });
  
  spawnEnemies();
  
  if (game.frameCount % 120 === 0) {
    game.combo = Math.max(0, game.combo - 1);
  }
  
  updateUI();
}

function playerHit() {
  game.lives--;
  game.player.invincible = 120;
  game.combo = 0;
  
  for (let i = 0; i < 30; i++) {
    game.particles.push({
      x: game.player.x,
      y: game.player.y,
      vx: (Math.random() - 0.5) * 10,
      vy: (Math.random() - 0.5) * 10,
      life: 20,
      maxLife: 20,
      size: 3 + Math.random() * 4,
      color: '#ff0000'
    });
  }
  
  if (game.lives <= 0) {
    gameOver();
  }
}

function nextStage() {
  if (game.stage >= game.maxStage) {
    showStageIndicator('🏆 YOU WIN! 🏆');
    game.gameOver = true;
    return;
  }
  
  game.stage++;
  game.stageTimer = 0;
  game.enemies = [];
  game.enemyBullets = [];
  game.bossActive = false;
  game.boss = null;
  game.enemyCount = 0;
  document.getElementById('bossHealth').style.display = 'none';
  
  game.lives = Math.min(game.lives + 1, 5);
  game.score += 50 * game.stage;
  
  showStageIndicator('STAGE ' + game.stage);
  updateUI();
}

function gameOver() {
  game.gameOver = true;
  showStageIndicator('💀 GAME OVER 💀\\nScore: ' + game.score);
}

// Draw function
function draw() {
  ctx.clearRect(0, 0, W, H);
  
  // Background stars
  ctx.fillStyle = '#ffffff';
  for (let i = 0; i < 50; i++) {
    const x = (i * 137.5 + game.frameCount * 0.1) % W;
    const y = (i * 97.3 + game.frameCount * 0.3) % H;
    const size = (i % 3 + 1) * 0.5;
    ctx.globalAlpha = 0.2 + (i % 5) * 0.1;
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
  
  // Draw particles
  game.particles.forEach(p => {
    ctx.globalAlpha = p.life / p.maxLife;
    ctx.fillStyle = p.color || '#00ddff';
    ctx.shadowColor = p.color || '#00ddff';
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fill();
  });
  ctx.globalAlpha = 1;
  ctx.shadowBlur = 0;
  
  // Draw powerups
  game.powerupDrops.forEach(p => {
    const float = Math.sin(p.phase) * 3;
    ctx.shadowColor = '#00ff88';
    ctx.shadowBlur = 20;
    
    ctx.strokeStyle = 'rgba(0, 255, 136, 0.3)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(p.x, p.y + float, p.size + 5, 0, Math.PI * 2);
    ctx.stroke();
    
    ctx.fillStyle = '#00ff88';
    ctx.font = '18px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowBlur = 30;
    const icons = {
      shield: '🛡️',
      spread: '✳️',
      rapid: '⚡',
      ally: '👥'
    };
    ctx.fillText(icons[p.type] || '?', p.x, p.y + float + 1);
    ctx.shadowBlur = 0;
  });
  
  // Draw enemies
  game.enemies.forEach(enemy => enemy.draw());
  
  // Draw ally bullets
  game.allyBullets.forEach(b => {
    ctx.shadowColor = b.color;
    ctx.shadowBlur = 15;
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  });
  
  // Draw enemy bullets
  game.enemyBullets.forEach(b => {
    ctx.shadowColor = b.color;
    ctx.shadowBlur = 15;
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  });
  
  // Draw allies
  game.allies.forEach(ally => ally.draw());
  
  // Draw player bullets
  game.bullets.forEach(b => {
    ctx.shadowColor = b.color;
    ctx.shadowBlur = 20;
    ctx.fillStyle = b.color;
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
  });
  
  // Draw player
  game.player.draw();
  
  // Draw UI overlay
  ctx.fillStyle = 'rgba(255,255,255,0.05)';
  ctx.font = '12px Arial';
  ctx.fillStyle = '#667';
  ctx.textAlign = 'left';
  ctx.fillText('COMBO: ' + game.combo + 'x', 10, 25);
  ctx.fillText('MAX: ' + game.maxCombo + 'x', 10, 40);
  
  const timeLeft = Math.max(0, game.maxStageTime - Math.floor(game.stageTimer / 60));
  ctx.textAlign = 'right';
  ctx.fillStyle = timeLeft < 30 ? '#ff4444' : '#667';
  ctx.fillText('⏱️ ' + timeLeft + 's', W - 10, 25);
  
  if (!game.bossActive) {
    ctx.textAlign = 'right';
    ctx.fillStyle = '#667';
    ctx.fillText('👾 ' + game.enemies.length, W - 10, 40);
  }
  
  if (game.gameOver) {
    ctx.fillStyle = 'rgba(0,0,0,0.7)';
    ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ff4444';
    ctx.font = 'bold 40px Arial';
    ctx.fillText('GAME OVER', W/2, H/2 - 30);
    ctx.fillStyle = '#fff';
    ctx.font = '24px Arial';
    ctx.fillText('Score: ' + game.score, W/2, H/2 + 30);
    ctx.fillStyle = '#889';
    ctx.font = '16px Arial';
    ctx.fillText('Tap RESET to restart', W/2, H/2 + 70);
  }
}

// Game loop
function gameLoop() {
  update();
  draw();
  requestAnimationFrame(gameLoop);
}

// Button controls
let leftPressed = false;
let rightPressed = false;

document.getElementById('btnLeft').addEventListener('touchstart', (e) => {
  e.preventDefault();
  leftPressed = true;
});
document.getElementById('btnLeft').addEventListener('touchend', (e) => {
  e.preventDefault();
  leftPressed = false;
});
document.getElementById('btnLeft').addEventListener('touchcancel', (e) => {
  leftPressed = false;
});
document.getElementById('btnLeft').addEventListener('mousedown', () => {
  leftPressed = true;
});
document.getElementById('btnLeft').addEventListener('mouseup', () => {
  leftPressed = false;
});
document.getElementById('btnLeft').addEventListener('mouseleave', () => {
  leftPressed = false;
});

document.getElementById('btnRight').addEventListener('touchstart', (e) => {
  e.preventDefault();
  rightPressed = true;
});
document.getElementById('btnRight').addEventListener('touchend', (e) => {
  e.preventDefault();
  rightPressed = false;
});
document.getElementById('btnRight').addEventListener('touchcancel', (e) => {
  rightPressed = false;
});
document.getElementById('btnRight').addEventListener('mousedown', () => {
  rightPressed = true;
});
document.getElementById('btnRight').addEventListener('mouseup', () => {
  rightPressed = false;
});
document.getElementById('btnRight').addEventListener('mouseleave', () => {
  rightPressed = false;
});

// Keyboard support
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') leftPressed = true;
  if (e.key === 'ArrowRight') rightPressed = true;
  if (e.key === ' ') {
    e.preventDefault();
    if (game.player) game.player.shoot();
  }
  if (e.key === 's' || e.key === 'S') useSkill();
});
document.addEventListener('keyup', (e) => {
  if (e.key === 'ArrowLeft') leftPressed = false;
  if (e.key === 'ArrowRight') rightPressed = false;
});

// Continuous movement
function updateMovement() {
  if (game.player && !game.gameOver) {
    if (leftPressed) game.player.x -= game.player.speed;
    if (rightPressed) game.player.x += game.player.speed;
    game.player.x = Math.max(20, Math.min(W - 20, game.player.x));
  }
  requestAnimationFrame(updateMovement);
}

// Shoot button
document.getElementById('btnFire').addEventListener('touchstart', (e) => {
  e.preventDefault();
  if (game.player) game.player.shoot();
});
document.getElementById('btnFire').addEventListener('mousedown', () => {
  if (game.player) game.player.shoot();
});

// Skill button - summon ally
document.getElementById('btnSkill').addEventListener('click', useSkill);

function useSkill() {
  if (game.gameOver || !game.player) return;
  
  for (let i = 0; i < 2; i++) {
    const ally = new Ally();
    game.allies.push(ally);
  }
  
  for (let i = 0; i < 20; i++) {
    game.particles.push({
      x: game.player.x + (Math.random() - 0.5) * 40,
      y: game.player.y + (Math.random() - 0.5) * 40,
      vx: (Math.random() - 0.5) * 8,
      vy: (Math.random() - 0.5) * 8 - 3,
      life: 20,
      maxLife: 20,
      size: 3,
      color: '#00ff88'
    });
  }
  
  updateUI();
}

// Reset function
function resetGame() {
  initGame();
  document.getElementById('bossHealth').style.display = 'none';
}

// Handle resize
function handleResize() {
  const container = document.querySelector('.game-container');
  const maxWidth = Math.min(420, window.innerWidth - 20);
  container.style.width = maxWidth + 'px';
}

// Touch controls for canvas
let touchX = null;
canvas.addEventListener('touchstart', (e) => {
  e.preventDefault();
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const touch = e.touches[0];
  touchX = (touch.clientX - rect.left) * scaleX;
});
canvas.addEventListener('touchmove', (e) => {
  e.preventDefault();
  if (!game.player || game.gameOver) return;
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const touch = e.touches[0];
  const newX = (touch.clientX - rect.left) * scaleX;
  if (touchX !== null) {
    const diff = newX - touchX;
    game.player.x += diff * 0.5;
    game.player.x = Math.max(20, Math.min(W - 20, game.player.x));
  }
  touchX = newX;
});
canvas.addEventListener('touchend', (e) => {
  touchX = null;
});

// Mouse controls for canvas
let mouseDown = false;
canvas.addEventListener('mousedown', (e) => {
  mouseDown = true;
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const x = (e.clientX - rect.left) * scaleX;
  if (game.player) {
    game.player.x = Math.max(20, Math.min(W - 20, x));
  }
});
canvas.addEventListener('mousemove', (e) => {
  if (!mouseDown || !game.player) return;
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const x = (e.clientX - rect.left) * scaleX;
  game.player.x = Math.max(20, Math.min(W - 20, x));
});
canvas.addEventListener('mouseup', () => {
  mouseDown = false;
});
canvas.addEventListener('mouseleave', () => {
  mouseDown = false;
});

// Initialize
window.onload = () => {
  initGame();
  handleResize();
  window.addEventListener('resize', handleResize);
  updateMovement();
  gameLoop();
};
</script>
`,
"trusted_sources":[
"adam.dev"
]
},
"__typename":"GenAISingleLayoutViewModel"
}
}
]
})).toString('base64')
},
contextInfo:{
forwardingScore:1,
isForwarded:true,
forwardedAiBotMessageInfo:{
botJid:"867051314767696@bot"
},
forwardOrigin:4
}
}
}
}
},
{}
)
}

handler.help=['space']
handler.tags=['game']
handler.command=/^space$/i

export default handler