const handler = async (m, { conn, text }) => {
	const q = m.quoted

	if (!q) {
		return m.reply('Reply file JavaScript hasil .crm.')
	}

	const mime = q.mimetype || ''

	if (!mime.includes('javascript') && !mime.includes('text') && !q.fileName?.endsWith('.js')) {
		return m.reply('File harus berupa JavaScript (.js).')
	}

	await m.react('⏳')

	try {
		const buffer = await q.download()
		let code = buffer.toString()

		code = code.trim()

		if (!code) {
			await m.react('❌')
			return m.reply('File JavaScript kosong.')
		}

		if (code.startsWith('=>')) {
			code = code.slice(2).trim()
		}

		const fn = new Function(
			'conn',
			'm',
			'text',
			`return (async () => { return ${code} })()`
		)

		const result = await fn(conn, m, text)

		await m.react('✅')

		if (result !== undefined && result !== null) {
			const output = typeof result === 'string'
				? result
				: JSON.stringify(result, null, 2)

			if (output) {
				return m.reply(output.slice(0, 20000))
			}
		}
	} catch (e) {
		await m.react('❌')
		return m.reply(`Execution Error:\n${e.stack || e.message}`)
	}
}

handler.help = ['crun']
handler.tags = ['owner']
handler.command = /^crun$/i
handler.owner = true

export default handler