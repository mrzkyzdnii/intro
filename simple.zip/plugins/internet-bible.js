import axios from 'axios'
import * as cheerio from 'cheerio'

const BIBLE_BOOKS = {
  1: 'Genesis', 2: 'Exodus', 3: 'Leviticus', 4: 'Numbers', 5: 'Deuteronomy',
  6: 'Joshua', 7: 'Judges', 8: 'Ruth', 9: '1 Samuel', 10: '2 Samuel',
  11: '1 Kings', 12: '2 Kings', 13: '1 Chronicles', 14: '2 Chronicles', 15: 'Ezra',
  16: 'Nehemiah', 17: 'Esther', 18: 'Job', 19: 'Psalms', 20: 'Proverbs',
  21: 'Ecclesiastes', 22: 'Song of Solomon', 23: 'Isaiah', 24: 'Jeremiah', 25: 'Lamentations',
  26: 'Ezekiel', 27: 'Daniel', 28: 'Hosea', 29: 'Joel', 30: 'Amos',
  31: 'Obadiah', 32: 'Jonah', 33: 'Micah', 34: 'Nahum', 35: 'Habakkuk',
  36: 'Zephaniah', 37: 'Haggai', 38: 'Zechariah', 39: 'Malachi',
  40: 'Matthew', 41: 'Mark', 42: 'Luke', 43: 'John', 44: 'Acts',
  45: 'Romans', 46: '1 Corinthians', 47: '2 Corinthians', 48: 'Galatians',
  49: 'Ephesians', 50: 'Philippians', 51: 'Colossians',
  52: '1 Thessalonians', 53: '2 Thessalonians',
  54: '1 Timothy', 55: '2 Timothy', 56: 'Titus',
  57: 'Philemon', 58: 'Hebrews', 59: 'James',
  60: '1 Peter', 61: '2 Peter',
  62: '1 John', 63: '2 John', 64: '3 John',
  65: 'Jude', 66: 'Revelation'
}

function cleanText(raw = '') {
  return String(raw)
    .replace(/<S>\d+<\/S>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/\s+/g, ' ')
    .trim()
}

function findVerses(obj) {
  if (!obj || typeof obj !== 'object') return null

  if (Array.isArray(obj.verses))
    return obj.verses

  for (const key of Object.keys(obj)) {
    const found = findVerses(obj[key])
    if (found) return found
  }

  return null
}

async function scrapeBibleVerses(queryInput, maxLimit = 20) {
  let query = queryInput.trim()

  if (query.includes('bible.com/')) {
    try {
      const url = new URL(query.startsWith('http') ? query : `https://${query}`)
      query =
        url.searchParams.get('query') ||
        url.searchParams.get('q') ||
        query
    } catch {}
  }

  const targetUrl = `https://www.bible.com/id/search/bible?query=${encodeURIComponent(query)}`

  try {
    const { data } = await axios.get(targetUrl, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8'
      }
    })

    const $ = cheerio.load(data)
    const nextData = $('#__NEXT_DATA__').html()

    if (nextData) {
      const parsed = JSON.parse(nextData)
      const rawVerses = findVerses(parsed)

      if (Array.isArray(rawVerses) && rawVerses.length) {
        return {
          success: true,
          query,
          source: 'bible.com',
          total: rawVerses.length,
          verses: rawVerses.slice(0, maxLimit).map((item, index) => ({
            id: index + 1,
            reference:
              item.human ||
              item.reference ||
              item.display_reference ||
              '',
            text: cleanText(
              item.content ||
              item.highlight ||
              item.text ||
              item.html ||
              ''
            ),
            translation:
              item.version_local_abbreviation ||
              item.version_abbreviation ||
              item.version ||
              'TB',
            url:
              item.version_id && item.usfm
                ? `https://www.bible.com/bible/${item.version_id}/${Array.isArray(item.usfm) ? item.usfm[0] : item.usfm}`
                : targetUrl
          }))
        }
      }
    }
  } catch {}

  try {
    const { data } = await axios.get(
      `https://bolls.life/search/KJV/?search=${encodeURIComponent(query)}`,
      { timeout: 10000 }
    )

    if (Array.isArray(data) && data.length) {
      return {
        success: true,
        query,
        source: 'bolls.life',
        total: data.length,
        verses: data.slice(0, maxLimit).map((v, index) => ({
          id: index + 1,
          reference: `${BIBLE_BOOKS[v.book] || `Book ${v.book}`} ${v.chapter}:${v.verse}`,
          text: cleanText(v.text),
          translation: v.translation || 'KJV',
          url: `https://www.bible.com/search/bible?query=${encodeURIComponent(`${BIBLE_BOOKS[v.book]} ${v.chapter}:${v.verse}`)}`
        }))
      }
    }
  } catch {}

  return {
    success: false,
    query,
    source: null,
    total: 0,
    verses: []
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text)
    throw `Contoh:\n${usedPrefix + command} kasih`

  try {
    await conn.sendMessage(m.chat, {
      react: {
        text: '📖',
        key: m.key
      }
    })

    const res = await scrapeBibleVerses(text)

    if (!res.success)
      throw 'Ayat tidak ditemukan.'

    let caption = `📖 *Bible Search*\n\n`
    caption += `🔎 Keyword: *${res.query}*\n`
    caption += `📚 Total: *${res.total}*\n`
    caption += `🌐 Source: *${res.source}*\n\n`

    for (const verse of res.verses) {
      caption += `*${verse.reference}* (${verse.translation})\n`
      caption += `${verse.text}\n`
      caption += `${verse.url}\n\n`
    }

    await conn.sendMessage(
      m.chat,
      { text: caption.trim() },
      { quoted: m }
    )
  } catch (e) {
    console.error(e)
    throw 'Gagal mencari ayat Alkitab.'
  }
}

handler.help = ['bible <keyword>']
handler.tags = ['religion']
handler.command = /^bible$/i
handler.limit = 10

export default handler