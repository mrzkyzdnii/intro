const fmt = (v) => new Intl.NumberFormat('id-ID').format(Number(v) || 0)

const get = (user, key) => Number(user?.[key]) || 0

const row = (emoji, name, value) =>
  `│ ${emoji} ${name.padEnd(20)} ${fmt(value).padStart(10)} │`

const section = (title) => `\n╭─「 ${title} 」`

let handler = async (m, { conn }) => {
  const who = m.sender
  const user = global.db?.data?.users?.[who]

  if (!user) {
    return m.reply('❌ Data pengguna tidak ditemukan di database.')
  }

  const name = user.registered
    ? user.name
    : await conn.getName(who)

  const items = {
    '⛏️ MATERIAL': [
      ['🧪', 'Potion', 'potion'],
      ['🗑️', 'Trash', 'trash'],
      ['🪵', 'Wood', 'wood'],
      ['🪨', 'Rock', 'rock'],
      ['🧵', 'String', 'string'],
      ['⛓️', 'Iron', 'iron'],
      ['🪙', 'Gold', 'gold'],
      ['💚', 'Emerald', 'emerald'],
      ['💎', 'Diamond', 'diamond']
    ],

    '⭐ RARITY': [
      ['⚪', 'Common', 'common'],
      ['🟢', 'Uncommon', 'uncommon'],
      ['🔮', 'Mythic', 'mythic'],
      ['🟡', 'Legendary', 'legendary']
    ],

    '🎣 ITEM': [
      ['🍖', 'Pet Food', 'petfood'],
      ['🐾', 'Pet', 'pet'],
      ['🪱', 'Umpan', 'umpan']
    ],

    '♻️ SAMPAH': [
      ['🍾', 'Botol', 'botol'],
      ['📦', 'Kardus', 'kardus'],
      ['🥫', 'Kaleng', 'kaleng'],
      ['🥛', 'Gelas', 'gelas'],
      ['🛍️', 'Plastik', 'plastik']
    ],

    '🌾 BAHAN': [
      ['🌾', 'Gandum', 'gandum'],
      ['🛢️', 'Minyak', 'minyak'],
      ['🧂', 'Garam', 'garam']
    ],

    '🍎 BUAH': [
      ['🍎', 'Apel', 'apel'],
      ['🍇', 'Anggur', 'anggur'],
      ['🍊', 'Jeruk', 'jeruk'],
      ['🥭', 'Mangga', 'mangga'],
      ['🍌', 'Pisang', 'pisang']
    ],

    '🌱 BIBIT': [
      ['🌱', 'Bibit Apel', 'bibitapel'],
      ['🌱', 'Bibit Anggur', 'bibitanggur'],
      ['🌱', 'Bibit Jeruk', 'bibitjeruk'],
      ['🌱', 'Bibit Mangga', 'bibitmangga'],
      ['🌱', 'Bibit Pisang', 'bibitpisang']
    ],

    '🍱 MAKANAN': [
      ['🍱', 'Makanan', 'makanan']
    ],

    '🦁 HEWAN DARAT': [
      ['🐔', 'Ayam', 'ayam'],
      ['🐖', 'Babi', 'babi'],
      ['🐗', 'Babi Hutan', 'babihutan'],
      ['🐂', 'Banteng', 'banteng'],
      ['🐊', 'Buaya', 'buaya'],
      ['🐘', 'Gajah', 'gajah'],
      ['🐅', 'Harimau', 'harimau'],
      ['🐐', 'Kambing', 'kambing'],
      ['🐃', 'Kerbau', 'kerbau'],
      ['🐒', 'Monyet', 'monyet'],
      ['🐼', 'Panda', 'panda'],
      ['🐄', 'Sapi', 'sapi']
    ],

    '🌊 HEWAN LAUT': [
      ['🐋', 'Paus', 'paus'],
      ['🦀', 'Kepiting', 'kepiting'],
      ['🐙', 'Gurita', 'gurita'],
      ['🦑', 'Cumi', 'cumi'],
      ['🐡', 'Buntal', 'buntal'],
      ['🐠', 'Dory', 'dory'],
      ['🐬', 'Lumba', 'lumba'],
      ['🦞', 'Lobster', 'lobster'],
      ['🦈', 'Hiu', 'hiu'],
      ['🦐', 'Udang', 'udang'],
      ['🐋', 'Orca', 'orca']
    ],

    '🎣 IKAN': [
      ['🐟', 'Ikan', 'ikan'],
      ['🐟', 'Lele', 'lele'],
      ['🐟', 'Nila', 'nila'],
      ['🐟', 'Bawal', 'bawal']
    ],

    '🍖 MAKANAN MASAK': [
      ['🥩', 'Steak', 'steak'],
      ['🍗', 'Ayam Goreng', 'ayam_goreng'],
      ['🍗', 'Ayam Goreng 2', 'ayamgoreng'],
      ['🍗', 'Ayam Bakar', 'ayambakar'],
      ['🥩', 'Ribs', 'ribs'],
      ['🍞', 'Roti', 'roti'],
      ['🍤', 'Udang Goreng', 'udang_goreng'],
      ['🍤', 'Udang Bakar', 'udangbakar'],
      ['🥓', 'Bacon', 'bacon']
    ],

    '🔥 MAKANAN BAKAR': [
      ['🐟', 'Ikan Bakar', 'ikanbakar'],
      ['🐟', 'Lele Bakar', 'lelebakar'],
      ['🐟', 'Nila Bakar', 'nilabakar'],
      ['🐟', 'Bawal Bakar', 'bawalbakar'],
      ['🦀', 'Kepiting Bakar', 'kepitingbakar'],
      ['🐋', 'Paus Bakar', 'pausbakar'],
      ['🐖', 'Babi Panggang', 'babipanggang'],
      ['🍗', 'Opor Ayam', 'oporayam'],
      ['🥩', 'Rendang', 'rendang'],
      ['🍛', 'Gulai', 'gulai']
    ],

    '⛏️ MINING': [
      ['💧', 'Aqua', 'aqua'],
      ['🧱', 'Clay', 'clay'],
      ['🪨', 'Coal', 'coal']
    ],

    '🚗 KENDARAAN': [
      ['🛵', 'Ojek', 'ojek'],
      ['🚓', 'Polisi', 'polisi'],
      ['🚀', 'Roket', 'roket'],
      ['🚀', 'Rokets', 'rokets'],
      ['🚕', 'Taxy', 'taxy']
    ]
  }

  const pets = [
    ['🐴', 'Horse', 'horse', 'horseexp', 'horselastfeed'],
    ['🐱', 'Cat', 'cat', 'catexp', 'catlastfeed'],
    ['🐶', 'Dog', 'dog', 'dogexp', 'doglastfeed'],
    ['🦊', 'Fox', 'fox', 'foxexp', 'foxlastfeed'],
    ['🤖', 'Robo', 'robo', 'roboexp', 'robolastfeed'],
    ['🐉', 'Dragon', 'dragon', 'dragonexp', 'dragonlastfeed'],
    ['🦁', 'Lion', 'lion', 'lionexp', 'lionlastfeed'],
    ['🦏', 'Rhinoceros', 'rhinoceros', 'rhinocerosexp', 'rhinoceroslastfeed'],
    ['🐎', 'Centaur', 'centaur', 'centaurexp', 'centaurlastfeed'],
    ['🦊', 'Kyubi', 'kyubi', 'kyubiexp', 'kyubilastfeed'],
    ['🦅', 'Griffin', 'griffin', 'griffinexp', 'griffinlastfeed'],
    ['🔥', 'Phonix', 'phonix', 'phonixexp', 'phonixlastfeed'],
    ['🐺', 'Wolf', 'wolf', 'wolfexp', 'wolflastfeed']
  ]

  let text = `
╭━━━━━━━━━━━━━━━━━━━━━━╮
│   ✦  RPG INVENTORY  │
╰━━━━━━━━━━━━━━━━━━━━━━╯

👤 *PLAYER*
│ Name  : ${name}
│ ID    : @${who.split('@')[0]}

💰 *CURRENCY*
│ 💵 Money : ${fmt(user.money)}
│ ⚡ Limit : ${fmt(user.limit)}
│ 🎟️ Chip  : ${fmt(user.chip)}
`

  for (const [title, list] of Object.entries(items)) {
    text += section(title)

    for (const [emoji, label, key] of list) {
      text += '\n' + row(emoji, label, get(user, key))
    }

    text += '\n╰' + '─'.repeat(38) + '╯'
  }

  text += `

╭─「 🐾 PET COLLECTION 」`

  for (const [emoji, label, key, expKey] of pets) {
    text += `
│ ${emoji} ${label}
│    ├─ Quantity : ${fmt(get(user, key))}
│    └─ EXP      : ${fmt(get(user, expKey))}
`
  }

  text += `╰${'─'.repeat(38)}╯`

  text += `

╭─「 🍖 PET FEED STATUS 」`

  for (const [emoji, label, key, expKey, feedKey] of pets) {
    const lastFeed = get(user, feedKey)

    text += `
│ ${emoji} ${label}
│    ├─ EXP      : ${fmt(get(user, expKey))}
│    └─ LastFeed : ${lastFeed ? new Date(lastFeed).toLocaleString('id-ID') : '-'}
`
  }

  text += `╰${'─'.repeat(38)}╯

> ✦ *RPG RPG — INVENTORY SYSTEM*
> Semua item yang tersimpan di database ditampilkan di sini.
`

  await conn.reply(
    m.chat,
    text.trim(),
    m,
    {
      mentions: [who]
    }
  )
}

handler.help = ['inv', 'inventory']
handler.tags = ['rpg']
handler.command = /^(inv|inventory)$/i
handler.rpg = true

export default handler