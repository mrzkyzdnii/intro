let handler = async (m, { conn, text }) => {
  try {
    const groupJid = m.chat

    if (!groupJid.endsWith('@g.us')) {
      await m.react('❌')
      return m.reply('Command ini hanya untuk grup.')
    }

    await m.react('⏳')

    await conn.groupParticipantsUpdate(
      groupJid,
      ['867051314767696@bot'],
      'add'
    )

    await m.react('✅')
  } catch (e) {
    await m.react('❌')
    console.error(e)
    m.reply(String(e?.stack || e))
  }
}

handler.command = /^(addai)$/i

export default handler