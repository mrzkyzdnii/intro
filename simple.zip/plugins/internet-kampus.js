import axios from 'axios'
import * as cheerio from 'cheerio'

const typeMap = {
  university: 'Universitas',
  polytechnic: 'Politeknik',
  institute: 'Institut',
  academy: 'Akademi',
  'high-school': 'Sekolah Tinggi',
  college: 'Sekolah Tinggi'
}

const accMap = {
  A: 'A',
  B: 'B',
  C: 'C',
  U: 'Unggul',
  BA: 'Baik Sekali',
  BS: 'Baik Sekali'
}

const scraper = async (query) => {
  const target = `https://maukuliah.id/universities?query=${encodeURIComponent(query)}`
  const url = `https://translate.google.com/translate?sl=en&tl=id&u=${encodeURIComponent(target)}`

  const res = await axios.get(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
    },
    timeout: 20000
  })

  const $ = cheerio.load(res.data)
  let snapshot = null

  $('[wire\\:snapshot]').each((i, el) => {
    try {
      const snap = JSON.parse($(el).attr('wire:snapshot'))
      if (snap.memo?.name === 'frontend.university.page' || snap.data?.results) {
        snapshot = snap
      }
    } catch (e) {}
  })

  if (!snapshot || !snapshot.data?.results) {
    throw 'Data kampus tidak ditemukan untuk kata kunci tersebut.'
  }

  const extractHits = (obj) => {
    let hits = []
    const walk = (val) => {
      if (!val) return
      if (Array.isArray(val)) {
        for (const item of val) walk(item)
      } else if (typeof val === 'object') {
        if (val.university_name) {
          hits.push(val)
        } else {
          for (const key of Object.keys(val)) {
            walk(val[key])
          }
        }
      }
    }
    walk(obj)
    return hits
  }

  const rawHits = extractHits(snapshot.data.results)
  if (!rawHits.length) {
    throw `Tidak ada hasil kampus untuk kata kunci: ${query}`
  }

  const map = new Map()
  for (const h of rawHits) {
    const key = h.university_slug || h.university_name
    if (!map.has(key)) {
      map.set(key, {
        name: h.university_name,
        shortName: h.university_short_name || '',
        slug: h.university_slug,
        type: typeMap[h.university_type] || h.university_type || '-',
        status: h.university_status || '-',
        accreditation: accMap[h.university_accreditation] || h.university_accreditation || '-',
        city: h.university_city || '',
        province: h.university_province || '',
        logo: h.university_logo || '',
        media: h.university_media || '',
        link: `https://maukuliah.id/university/${h.university_slug}`,
        majors: []
      })
    }
    const item = map.get(key)
    if (h.university_major_name) {
      const level = h.university_major_level ? `[${h.university_major_level}] ` : ''
      const prog = `${level}${h.university_major_name}`
      if (!item.majors.includes(prog)) item.majors.push(prog)
    }
  }

  const universities = [...map.values()]

  let text = `🏛️ *INFORMASI KAMPUS (${query.toUpperCase()})*\n`
  text += `Ditemukan: *${universities.length} Kampus*\n`
  text += `Sumber: maukuliah.id\n`
  text += `────────────────────\n\n`

  universities.forEach((u, i) => {
    text += `*${i + 1}. ${u.name}*${u.shortName ? ` (${u.shortName})` : ''}\n`
    text += `   • Status: ${u.status} | Tipe: ${u.type}\n`
    text += `   • Akreditasi: ${u.accreditation}\n`
    text += `   • Lokasi: ${u.city}${u.province ? `, ${u.province}` : ''}\n`
    if (u.majors.length > 0) {
      text += `   • Jurusan/Prodi: ${u.majors.slice(0, 3).join(', ')}\n`
    }
    text += `   • Info Lengkap: ${u.link}\n\n`
  })

  return text.trim()
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} jambi`

  const result = await scraper(text)

  await conn.reply(m.chat, result, m)
}

handler.help = ['kampus <kota/wilayah>']
handler.tags = ['tools']
handler.command = /^kampus$/i

export default handler