import axios from 'axios'
import * as cheerio from 'cheerio'

const scraper = async (query) => {
    try {
        // 1. Ambil daftar sumber berita/referensi
        const { data: sources } = await axios.post(
            'https://www.turboseek.io/api/getSources',
            { question: query },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
            }
        )

        // 2. Ambil jawaban AI berdasarkan sumber yang didapat
        const { data: rawAnswer } = await axios.post(
            'https://www.turboseek.io/api/getAnswer',
            {
                question: query,
                sources: sources || []
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                }
            }
        )

        // Parsing HTML response dari jawaban
        let cleanAnswer = ''
        if (typeof rawAnswer === 'string') {
            const $ = cheerio.load(rawAnswer)
            cleanAnswer = $.text().trim()
        } else {
            cleanAnswer = JSON.stringify(rawAnswer)
        }

        // Format daftar sumber
        const formattedSources = (sources || [])
            .map((s, i) => `${i + 1}. ${s.title}\n   🔗 ${s.url}`)
            .join('\n\n')

        return `*Jawaban:*\n${cleanAnswer}\n\n*Sumber:*\n${formattedSources || '-'}`
    } catch (err) {
        throw new Error(`Gagal mengambil data dari TurboSeek: ${err.message}`)
    }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Example:\n${usedPrefix + command} siapa presiden indonesia 2024`

    const result = await scraper(text)

    await conn.reply(m.chat, result, m)
}

handler.help = ['turboseek']
handler.tags = ['tools']
handler.command = /^turboseek$/i

handler.limit = 10
export default handler