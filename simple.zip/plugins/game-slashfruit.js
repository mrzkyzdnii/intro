const handler = async (m, { conn, command }) => {
conn.relayMessage(
m.chat,
{
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
botMetadata: {
messageDisclaimerText: "",
botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860",
verificationMetadata: {
proofs: [
{
version: 1,
useCase: 1,
signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
certificateChain: [
"TklYRUwuTWVzc2FnZUJ1bGRlc..." 
]
}
]
}
}
},
botForwardedMessage: {
message: {
richResponseMessage: {
messageType: 1,
submessages: [
{
messageType: 2,
messageText: "🍉 SLASH FRUIT"
}
],
unifiedResponse: {
data: Buffer.from(JSON.stringify({
"response_id": "4db57b2c-8393-484d-8b9a-8e6d1a14b349",
"sections": [
{
"view_model": {
"primitive": {
"__typename": "GenAIaeacdsnwHtmlPrimitive",
"payload": `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
body{margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee;touch-action:manipulation}
.wrap{width:100%;max-width:620px;margin:auto;padding:14px}
.card{background:linear-gradient(145deg,rgba(255,255,255,.09),rgba(255,255,255,.035));border:1px solid rgba(255,255,255,.14);border-radius:22px;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4);backdrop-filter:blur(18px)}
.head{padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.1);display:flex;justify-content:space-between;align-items:center}
.logo{font-size:10px;letter-spacing:2px;color:#888;text-transform:uppercase}
.title{font-size:23px;font-weight:800;margin-top:3px;background:linear-gradient(135deg,#f7971e,#ffd200);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.status{font-size:13px;font-weight:bold;text-align:right}
.lives{color:#ff4757;font-size:18px;letter-spacing:2px}
.gameArea{padding:20px}
.emojiDisplay{font-size:120px;text-align:center;padding:30px 0;background:rgba(255,255,255,.05);border-radius:18px;margin-bottom:20px;border:2px dashed rgba(255,255,255,.1);min-height:200px;display:flex;align-items:center;justify-content:center;transition:all .3s}
.emojiDisplay.hit{transform:scale(1.1);border-color:#2ed573}
.emojiDisplay.miss{transform:scale(.9);border-color:#ff4757}
.emojiDisplay.boom{animation:shake .5s}
@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-20px)}75%{transform:translateX(20px)}}
.options{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:15px}
.optBtn{background:rgba(255,255,255,.08);border:2px solid rgba(255,255,255,.1);border-radius:14px;padding:15px;color:#fff;font-size:16px;font-weight:bold;transition:all .2s}
.optBtn:active{transform:scale(.95)}
.optBtn.correct{background:rgba(46,213,115,.3);border-color:#2ed573}
.optBtn.wrong{background:rgba(255,71,87,.3);border-color:#ff4757}
.optBtn.disabled{opacity:.5;pointer-events:none}
.info{display:flex;justify-content:space-between;padding:12px 0;color:#888;font-size:14px}
.score{color:#ffd700;font-weight:bold;font-size:18px}
.combo{color:#ff6b81;font-weight:bold}
.progress{width:100%;height:6px;background:rgba(255,255,255,.1);border-radius:3px;overflow:hidden;margin:10px 0}
.progressBar{height:100%;background:linear-gradient(90deg,#f7971e,#ffd200);width:100%;transition:width .5s}
.btn{width:100%;border:0;border-radius:14px;padding:14px;background:linear-gradient(135deg,#f7971e,#ffd200);color:#222;font-size:16px;font-weight:bold;margin-top:10px}
.btn:active{transform:scale(.97)}
</style>

<body>
<div class="wrap">
<div class="card">
<div class="head">
<div>
<div class="logo">⚔️ SLASH FRUIT</div>
<div class="title">🍉 Tebak Buah</div>
</div>
<div class="status">
<div class="lives" id="lives">❤️❤️❤️</div>
<div id="roundDisplay">1/10</div>
</div>
</div>

<div class="gameArea">
<div class="emojiDisplay" id="emojiDisplay">🍎</div>
<div id="optionsContainer" class="options"></div>
<div class="info">
<span class="score">⭐ <span id="score">0</span></span>
<span class="combo">🔥 Combo: <span id="combo">0</span>x</span>
<span>⏱️ <span id="timer">10</span>s</span>
</div>
<div class="progress"><div class="progressBar" id="progressBar"></div></div>
<button class="btn" id="resetBtn">🔄 MULAI LAGI</button>
</div>
</div>
</div>

<script>
const emojiDisplay = document.getElementById('emojiDisplay');
const optionsContainer = document.getElementById('optionsContainer');
const livesDisplay = document.getElementById('lives');
const scoreDisplay = document.getElementById('score');
const comboDisplay = document.getElementById('combo');
const timerDisplay = document.getElementById('timer');
const roundDisplay = document.getElementById('roundDisplay');
const progressBar = document.getElementById('progressBar');
const resetBtn = document.getElementById('resetBtn');

const fruitData = [
{ name: 'Apel', emoji: '🍎' },
{ name: 'Pisang', emoji: '🍌' },
{ name: 'Jeruk', emoji: '🍊' },
{ name: 'Anggur', emoji: '🍇' },
{ name: 'Stroberi', emoji: '🍓' },
{ name: 'Semangka', emoji: '🍉' },
{ name: 'Pir', emoji: '🍐' },
{ name: 'Persik', emoji: '🍑' },
{ name: 'Ceri', emoji: '🍒' },
{ name: 'Leci', emoji: '🍈' },
{ name: 'Mangga', emoji: '🥭' },
{ name: 'Nanas', emoji: '🍍' },
{ name: 'Kiwi', emoji: '🥝' },
{ name: 'Alpukat', emoji: '🥑' },
{ name: 'Kelapa', emoji: '🥥' }
];

let currentFruit = null;
let options = [];
let score = 0;
let combo = 0;
let lives = 3;
let round = 0;
const maxRounds = 10;
let timer = 10;
let timerInterval = null;
let isPlaying = false;
let isAnswered = false;

function shuffle(arr) {
for(let i = arr.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[arr[i], arr[j]] = [arr[j], arr[i]];
}
return arr;
}

function getRandomFruit() {
return fruitData[Math.floor(Math.random() * fruitData.length)];
}

function getWrongOptions(correct, count = 3) {
const wrong = fruitData.filter(f => f.name !== correct.name);
shuffle(wrong);
return wrong.slice(0, count).map(f => f.name);
}

function updateLives() {
livesDisplay.textContent = '❤️'.repeat(lives) + '🖤'.repeat(3 - lives);
if(lives <= 1) livesDisplay.style.color = '#ff4757';
else livesDisplay.style.color = '#ff4757';
}

function updateUI() {
scoreDisplay.textContent = score;
comboDisplay.textContent = combo;
roundDisplay.textContent = round + '/' + maxRounds;
progressBar.style.width = (round / maxRounds * 100) + '%';
}

function showNewRound() {
if(round >= maxRounds || lives <= 0) {
endGame();
return;
}

isAnswered = false;
currentFruit = getRandomFruit();
const wrongNames = getWrongOptions(currentFruit);
options = shuffle([currentFruit.name, ...wrongNames]);

emojiDisplay.textContent = currentFruit.emoji;
emojiDisplay.className = 'emojiDisplay';

optionsContainer.innerHTML = '';
options.forEach(opt => {
const btn = document.createElement('button');
btn.className = 'optBtn';
btn.textContent = opt;
btn.dataset.name = opt;
btn.onclick = () => handleAnswer(btn, opt);
optionsContainer.appendChild(btn);
});

timer = 10;
timerDisplay.textContent = timer;
clearInterval(timerInterval);
timerInterval = setInterval(() => {
timer--;
timerDisplay.textContent = timer;
if(timer <= 0) {
clearInterval(timerInterval);
if(!isAnswered) {
handleTimeout();
}
}
}, 1000);

updateUI();
}

function handleAnswer(btn, selected) {
if(isAnswered || !isPlaying) return;
isAnswered = true;
clearInterval(timerInterval);

const correct = selected === currentFruit.name;

if(correct) {
emojiDisplay.className = 'emojiDisplay hit';
btn.classList.add('correct');
combo++;
const bonus = combo >= 3 ? 3 : combo >= 2 ? 2 : 1;
const points = 10 * bonus;
score += points;
} else {
emojiDisplay.className = 'emojiDisplay miss';
btn.classList.add('wrong');
lives--;
combo = 0;
updateLives();

optionsContainer.querySelectorAll('.optBtn').forEach(b => {
if(b.dataset.name === currentFruit.name) {
b.classList.add('correct');
}
});
}

optionsContainer.querySelectorAll('.optBtn').forEach(b => b.classList.add('disabled'));
updateUI();

setTimeout(() => {
round++;
if(round < maxRounds && lives > 0) {
showNewRound();
} else {
endGame();
}
}, correct ? 800 : 1500);
}

function handleTimeout() {
if(isAnswered || !isPlaying) return;
isAnswered = true;
emojiDisplay.className = 'emojiDisplay miss';
lives--;
combo = 0;
updateLives();

optionsContainer.querySelectorAll('.optBtn').forEach(b => {
b.classList.add('disabled');
if(b.dataset.name === currentFruit.name) {
b.classList.add('correct');
}
});

updateUI();

setTimeout(() => {
round++;
if(round < maxRounds && lives > 0) {
showNewRound();
} else {
endGame();
}
}, 1500);
}

function endGame() {
clearInterval(timerInterval);
isPlaying = false;
emojiDisplay.className = 'emojiDisplay boom';

let message = '';
if(lives <= 0) {
message = '💀 GAME OVER!';
} else if(round >= maxRounds) {
message = '🎉 SELESAI!';
}

const total = score + (lives * 20);
emojiDisplay.innerHTML = \`
<div style="flex-direction:column;display:flex;gap:10px;font-size:30px">
<div>\${message}</div>
<div style="font-size:24px">⭐ Skor: \${score}</div>
<div style="font-size:18px;color:#ff6b81">🔥 Combo tertinggi: \${comboDisplay.textContent}x</div>
<div style="font-size:20px;color:#ffd700">🏆 Total: \${total}</div>
</div>
\`;

optionsContainer.innerHTML = '';
timerDisplay.textContent = '0';
}

function resetGame() {
clearInterval(timerInterval);
score = 0;
combo = 0;
lives = 3;
round = 0;
isPlaying = true;
isAnswered = false;
updateLives();
updateUI();
showNewRound();
}

resetBtn.addEventListener('click', resetGame);

// Start game
resetGame();
</script>`,
"trusted_sources":[
"adam.dev"
]
},
"__typename":"GenAISingleLayoutViewModel"
}
}
]
})).toString('base64')
},
contextInfo:{
forwardingScore:1,
isForwarded:true,
forwardedAiBotMessageInfo:{
botJid:"867051314767696@bot"
},
forwardOrigin:4
}
}
}
}
},
{}
)
}

handler.help=['slashfruit']
handler.tags=['game']
handler.command=/^slashfruit$/i

export default handler