import crypto from 'node:crypto'

const bdd = [1, 2, 2, 4, 8, 32, 5, 160]
const aMX = [123, 47, 145, 68, 232, 60, 165, 105]
const aKq = [210, 23, 142, 243, 86, 186, 13, 193]
const regions = ['Zy3', 'A7x', 'Lp2', 'Hj4', 'K9m', 'Qw8', 'Xs1', 'Nv7']

const bsH = (a) => {
  const h = []
  for (let q = 0; q < 8; ++q) {
    const p = ((a >>> (q * 4)) & 15) + 1
    const str = regions[q]
    for (let o = 0; o < str.length; ++o) {
      h.push((((str.charCodeAt(o) ^ 90) >>> 0) * p) & 255)
    }
  }
  const m = []
  for (let q = 7; q >= 0; --q) {
    const shift = q * 8
    m.push(shift > 31 ? 0 : (a >>> shift) & 255)
  }
  const s = Buffer.concat([Buffer.from(h), Buffer.from(m)])
  const l = crypto.createHash('sha256').update(s).digest()
  const k = []
  for (let q = 0; q < l.length; ++q) {
    const sq = l[q]
    const r = q % 8
    const o = bdd[r]
    const n = aMX[r]
    k.push(((((sq ^ o) >>> 0) + (o & n) - (sq | n)) & 255) ^ aKq[r])
  }
  return k
}

const bsI = (bytes, g) => {
  let q = (1095977805 ^ (g & 0xffff)) >>> 0
  for (let r = 0; r < bytes.length; ++r) {
    const shift = (r * 3) % 32
    const factor = ((g >>> shift) & 7) + 1
    q = ((q << 5 >>> 0) + Math.imul(q, factor) + bytes[r]) >>> 0
  }
  return (q ^ 1161906481 ^ ((g >>> 16) & 0xffff)) >>> 0
}

const bqD = (a, b) => {
  const q = []
  let s = b
  for (let r = 0; r < a.length; ++r) {
    switch (r % 4) {
      case 0:
        q.push((a[r] ^ ((r * 7 + 13) & 255) ^ (s & 255)) >>> 0)
        break
      case 1:
        q.push((a[r] + ((r * 11 + 17) & 255) - (s & 63)) & 255)
        break
      case 2:
        q.push((a[r] ^ ((r * 13 + 23) & 255) ^ ((s >>> 2) & 15)) >>> 0)
        break
      case 3:
        q.push((a[r] - ((r * 17 + 31) & 127) + ((s >>> 4) & 31)) & 255)
        break
    }
    s = (Math.imul(s, 1103515245) + 12345) >>> 16 & 32767
  }
  return q
}

const generateToken = (deviceId) => {
  const h = Date.now()
  const g = Math.floor(h / 300000)
  const e = []
  const rand = crypto.randomBytes(16)
  for (let idx = 0; idx < 16; ++idx) {
    const r = rand[idx]
    if (idx % 4 === 0) {
      const hours = Math.floor(h / 3600000) % 24
      const minutes = Math.floor(h / 60000) % 60
      const s = (r ^ (((hours * 60 + minutes) ^ 43981) & 255)) >>> 0
      e.push(s)
    } else {
      e.push(r)
    }
  }

  const d = Buffer.from(deviceId, 'utf8')
  const b = []
  for (let s = 7; s >= 0; --s) {
    const shift = s * 8
    b.push(shift > 31 ? 0 : (g >>> shift) & 255)
  }
  b.push(d.length & 255)
  for (const byte of d) b.push(byte)
  for (const byte of e) b.push(byte)

  const r = bsI(b, g)
  for (let s = 3; s >= 0; --s) b.push((r >>> (s * 8)) & 255)

  const q = bsH(g)
  const p = Buffer.alloc(64)
  const o = q.length > 64 ? crypto.createHash('sha256').update(Buffer.from(q)).digest() : Buffer.from(q)
  o.copy(p)

  const n = crypto.createHmac('sha256', p).update(Buffer.from(b)).digest()
  const pe = e[0]
  const m = (g & 65535) ^ pe
  const l = ((g >>> 16) & 65535) ^ (pe >>> 8)
  const p2 = Buffer.concat([n, Buffer.from([(m >>> 8) & 255, m & 255, (l >>> 8) & 255, l & 255])])
  const k = crypto.createHash('sha256').update(p2).digest()

  const j = []
  for (let s = 0; s < 32; ++s) j.push(s % 2 === 0 ? n[s] : k[s])

  const f = [...b, ...j]
  const i = bqD(f, (g * 31337) & 2147483647)
  return Buffer.from(i).toString('base64').replace(/\+/g, '-').replace(/\//g, '_')
}

const scraper = async (query) => {
  const deviceId = crypto.randomUUID()
  const token = generateToken(deviceId)

  const response = await fetch('https://www.ask-me-ai.app/api/chat/stream', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Accept': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'X-App-Token': token,
      'X-App-Version': '1.0.0',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
      'Origin': 'https://www.ask-me-ai.app',
      'Referer': 'https://www.ask-me-ai.app/'
    },
    body: JSON.stringify({ message: query, deviceId })
  })

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`HTTP ${response.status}: ${errorText}`)
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let text = ''
  let imageBuffer = null
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop()

    for (const line of lines) {
      const trimmed = line.trim()
      if (!trimmed.startsWith('data:')) continue
      const raw = trimmed.slice(5).trim()
      if (!raw) continue
      try {
        const json = JSON.parse(raw)
        if (json.type === 'text' && json.content) {
          text += json.content
        } else if (json.type === 'image' && json.base64) {
          imageBuffer = Buffer.from(json.base64, 'base64')
        }
      } catch {}
    }
  }

  const cleanText = text.replace(/!\[.*?\]\(.*?\)/g, '').trim()

  return {
    isImage: !!imageBuffer,
    image: imageBuffer,
    text: cleanText || text.trim()
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} siapa presiden pertama indonesia?\natau\n${usedPrefix + command} gambar kucing lucu pakai kacamata`

  const result = await scraper(text)

  if (result.isImage && result.image) {
    await conn.sendFile(m.chat, result.image, 'askme.jpg', result.text || 'Hasil Gambar', m)
  } else {
    await conn.reply(m.chat, result.text, m)
  }
}

handler.help = ['askai']
handler.tags = ['ai']
handler.command = /^(askai)$/i
handler.limit = 10

export default handler