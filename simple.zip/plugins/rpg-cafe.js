let handler = async (m, { conn, text, usedPrefix, command }) => {
  const user = global.db.data.users[m.sender]

  if (!user) {
    return m.reply('Data pengguna belum siap. Coba lagi sebentar.')
  }

  const toSafeNumber = (value, fallback = 0) => {
    const number = Number(value)
    return Number.isFinite(number) ? number : fallback
  }

  const integer = (value) =>
    Number.isInteger(Number(value)) ? Number(value) : null

  const rupiah = (value) =>
    `Rp${toSafeNumber(value).toLocaleString('id-ID')}`

  if (!Number.isFinite(Number(user.money))) {
    user.money = 0
  }

  user.money = Number(user.money)

  if (!user.cafe || typeof user.cafe !== 'object') {
    user.cafe = {
      name: 'Kafe Lezat',
      level: 1,
      capacity: 10,
      stock: 50,
      maxStock: 50,
      customers: 0,
      revenue: 0,
      popularity: 5,
      upgradeCost: 1000000,
      menu: [
        {
          item: 'Kopi Hitam',
          price: 30000
        }
      ],
      facilities: ['Meja Kayu'],
      openHours: {
        start: 8,
        end: 22
      },
      rating: 4.2
    }
  }

  const cafe = user.cafe

  cafe.name = String(cafe.name || 'Kafe Lezat')

  cafe.level = Math.max(
    1,
    toSafeNumber(cafe.level, 1)
  )

  cafe.capacity = Math.max(
    1,
    toSafeNumber(cafe.capacity, 10)
  )

  cafe.maxStock = Math.max(
    1,
    toSafeNumber(cafe.maxStock, 50)
  )

  cafe.stock = Math.max(
    0,
    Math.min(
      toSafeNumber(cafe.stock, 0),
      cafe.maxStock
    )
  )

  cafe.customers = Math.max(
    0,
    toSafeNumber(cafe.customers)
  )

  cafe.revenue = Math.max(
    0,
    toSafeNumber(cafe.revenue)
  )

  cafe.popularity = Math.max(
    0,
    Math.min(
      100,
      toSafeNumber(cafe.popularity, 5)
    )
  )

  cafe.rating = Math.max(
    0,
    Math.min(
      5,
      toSafeNumber(cafe.rating, 4.2)
    )
  )

  cafe.upgradeCost = Math.max(
    1,
    toSafeNumber(cafe.upgradeCost, 1000000)
  )

  cafe.menu = Array.isArray(cafe.menu)
    ? cafe.menu
        .filter(item =>
          item &&
          String(item.item || '').trim() &&
          Number.isFinite(Number(item.price)) &&
          Number(item.price) > 0
        )
        .map(item => ({
          item: String(item.item).trim(),
          price: Number(item.price)
        }))
    : []

  if (!cafe.menu.length) {
    cafe.menu = [
      {
        item: 'Kopi Hitam',
        price: 30000
      }
    ]
  }

  const usage = {
    cafeopen:
      `Format: ${usedPrefix}cafeopen\n` +
      `Contoh: ${usedPrefix}cafeopen`,

    cafestock:
      `Format: ${usedPrefix}cafestock <jumlah>\n` +
      `Contoh: ${usedPrefix}cafestock 10`,

    cafeadd:
      `Format: ${usedPrefix}cafeadd <nama> <harga>\n` +
      `Contoh: ${usedPrefix}cafeadd pisang 1000`,

    caferename:
      `Format: ${usedPrefix}caferename <nama>\n` +
      `Contoh: ${usedPrefix}caferename Kafe Mantap`
  }

  const cafeStatus = () => `
☕ *Status Kafe - ${cafe.name}*

📈 Level: ${cafe.level}
👥 Kapasitas: ${cafe.capacity}
📦 Stok: ${cafe.stock}/${cafe.maxStock}
✨ Popularitas: ${cafe.popularity}%
⭐ Rating: ${cafe.rating.toFixed(1)}/5
👨‍🍳 Pelanggan: ${cafe.customers}
💰 Pendapatan: ${rupiah(cafe.revenue)}
💵 Uang Anda: ${rupiah(user.money)}

*Perintah Kafe*
• ${usedPrefix}cafemenu
• ${usedPrefix}cafeupgrade
• ${usedPrefix}cafeopen
• ${usedPrefix}cafestock <jumlah>
• ${usedPrefix}cafeadd <nama> <harga>
• ${usedPrefix}caferename <nama>
• ${usedPrefix}cafelist
`

  /*
   * ============================================================
   * PELUANG MENU TERJUAL
   * ============================================================
   *
   * Harga murah  = lebih mudah laku
   * Harga mahal  = jauh lebih sulit laku
   *
   * KHUSUS HARGA 100K KE ATAS:
   *
   * 100K        = maksimal 5%
   * 150K        = maksimal 3%
   * 250K        = maksimal 2%
   * 500K        = maksimal 1%
   * 1JT         = maksimal 0.5%
   * >1JT        = maksimal 0.1%
   *
   * Popularitas dan rating hanya memberikan bonus
   * untuk harga di bawah 100K.
   *
   * Jadi harga 100K+ benar-benar tetap sulit laku.
   */

  const getBuyChance = (price) => {
    price = Number(price)

    if (!Number.isFinite(price) || price <= 0) {
      return 0
    }

    /*
     * ==========================================================
     * HARGA DI BAWAH 100K
     * ==========================================================
     */

    if (price < 100000) {
      let chance

      if (price <= 5000) {
        chance = 0.98
      } else if (price <= 10000) {
        chance = 0.93
      } else if (price <= 20000) {
        chance = 0.85
      } else if (price <= 30000) {
        chance = 0.75
      } else if (price <= 50000) {
        chance = 0.60
      } else if (price <= 75000) {
        chance = 0.45
      } else {
        chance = 0.20
      }

      /*
       * Bonus popularitas.
       */
      const popularityBonus =
        (cafe.popularity / 100) * 0.10

      /*
       * Bonus rating.
       */
      const ratingBonus =
        (cafe.rating / 5) * 0.05

      chance += popularityBonus
      chance += ratingBonus

      return Math.max(
        0.001,
        Math.min(0.99, chance)
      )
    }

    /*
     * ==========================================================
     * HARGA 100K+
     * ==========================================================
     *
     * Tidak menggunakan bonus popularitas/rating besar.
     * Ada batas maksimum berdasarkan harga.
     */

    let maxChance

    if (price <= 100000) {
      /*
       * Tepat 100K:
       * maksimal 5%.
       */
      maxChance = 0.05

    } else if (price <= 150000) {
      /*
       * 100K - 150K:
       * sekitar 5% -> 3%.
       */
      const progress =
        (price - 100000) / 50000

      maxChance =
        0.05 -
        (0.05 - 0.03) * progress

    } else if (price <= 250000) {
      /*
       * 150K - 250K:
       * 3% -> 2%.
       */
      const progress =
        (price - 150000) / 100000

      maxChance =
        0.03 -
        (0.03 - 0.02) * progress

    } else if (price <= 500000) {
      /*
       * 250K - 500K:
       * 2% -> 1%.
       */
      const progress =
        (price - 250000) / 250000

      maxChance =
        0.02 -
        (0.02 - 0.01) * progress

    } else if (price <= 1000000) {
      /*
       * 500K - 1JT:
       * 1% -> 0.5%.
       */
      const progress =
        (price - 500000) / 500000

      maxChance =
        0.01 -
        (0.01 - 0.005) * progress

    } else {
      /*
       * Di atas 1JT:
       * maksimal 0.1%.
       */
      maxChance = 0.001
    }

    /*
     * Bonus kecil sekali dari popularitas/rating.
     *
     * Bonus ini tidak boleh melewati maxChance.
     */
    const popularityBonus =
      (cafe.popularity / 100) * 0.005

    const ratingBonus =
      (cafe.rating / 5) * 0.003

    const chance =
      maxChance +
      popularityBonus +
      ratingBonus

    /*
     * Tetap dikunci berdasarkan maxChance.
     */
    return Math.max(
      0.0001,
      Math.min(maxChance, chance)
    )
  }

  const serveCustomers = () => {
    if (String(text || '').trim()) {
      return m.reply(usage.cafeopen)
    }

    if (cafe.stock < 1) {
      return m.reply(
        `📦 Stok habis.\n\n` +
        `Beli stok terlebih dahulu dengan *${usedPrefix}cafestock 10*.`
      )
    }

    /*
     * Jumlah pelanggan yang datang.
     */
    const baseCustomers = Math.floor(
      cafe.popularity / 10
    )

    const randomCustomers =
      Math.floor(Math.random() * 5) + 1

    const maxCustomers = Math.min(
      cafe.capacity,
      cafe.stock,
      Math.max(
        1,
        baseCustomers + randomCustomers
      )
    )

    let totalIncome = 0
    let servedCustomers = 0
    let failedCustomers = 0

    const soldMenus = {}

    for (let i = 0; i < maxCustomers; i++) {
      if (!cafe.menu.length) break

      const menuItem =
        cafe.menu[
          Math.floor(
            Math.random() * cafe.menu.length
          )
        ]

      const price = Number(menuItem.price)

      const chance = getBuyChance(price)

      /*
       * Pelanggan menentukan apakah membeli.
       */
      const bought =
        Math.random() < chance

      if (!bought) {
        failedCustomers++
        continue
      }

      /*
       * Bonus rating terhadap pendapatan.
       */
      const ratingMultiplier =
        0.85 +
        (cafe.rating / 5) * 0.15

      /*
       * Random pendapatan.
       */
      const randomMultiplier =
        0.90 +
        Math.random() * 0.20

      const income = Math.floor(
        price *
        ratingMultiplier *
        randomMultiplier
      )

      if (
        !Number.isFinite(income) ||
        income <= 0
      ) {
        continue
      }

      totalIncome += income
      servedCustomers++

      soldMenus[menuItem.item] =
        (soldMenus[menuItem.item] || 0) + 1
    }

    /*
     * Stok hanya berkurang jika benar-benar terjual.
     */
    cafe.stock -= servedCustomers

    cafe.customers += servedCustomers
    cafe.revenue += totalIncome
    user.money += totalIncome

    /*
     * Popularitas naik jika ada penjualan.
     */
    if (servedCustomers > 0) {
      const popularityIncrease =
        Math.min(
          3,
          Math.floor(servedCustomers / 3) + 1
        )

      cafe.popularity = Math.min(
        100,
        cafe.popularity + popularityIncrease
      )
    }

    /*
     * Jika banyak pelanggan gagal membeli,
     * popularitas bisa turun.
     */
    if (
      failedCustomers >= 5 &&
      servedCustomers === 0
    ) {
      cafe.popularity = Math.max(
        0,
        cafe.popularity - 1
      )
    }

    const soldList =
      Object.entries(soldMenus)
        .map(
          ([item, amount]) =>
            `• ${item} ×${amount}`
        )
        .join('\n') ||
      '• Tidak ada menu yang terjual'

    return m.reply(`
☕ *Kafe Dibuka!*

👥 Pelanggan datang: ${maxCustomers}
🍽️ Berhasil membeli: ${servedCustomers}
🚶 Tidak jadi membeli: ${failedCustomers}

*Menu Terjual*
${soldList}

💰 Pendapatan: ${rupiah(totalIncome)}
📦 Sisa stok: ${cafe.stock}/${cafe.maxStock}
✨ Popularitas: ${cafe.popularity}%

${servedCustomers === 0
  ? '😔 Tidak ada pelanggan yang membeli. Coba turunkan harga menu.'
  : '🎉 Kafe berhasil mendapatkan pelanggan!'}
`)
  }

  const upgradeCafe = () => {
    if (String(text || '').trim()) {
      return m.reply(
        'Format: ' +
        usedPrefix +
        'cafeupgrade'
      )
    }

    if (user.money < cafe.upgradeCost) {
      return m.reply(
        `💸 Uang tidak cukup.\n` +
        `Anda membutuhkan ${rupiah(cafe.upgradeCost)}.`
      )
    }

    user.money -= cafe.upgradeCost

    cafe.level += 1
    cafe.capacity += 10

    cafe.maxStock *= 2

    cafe.stock = Math.min(
      cafe.stock * 2,
      cafe.maxStock
    )

    cafe.popularity = Math.min(
      100,
      cafe.popularity + 5
    )

    cafe.upgradeCost = Math.floor(
      cafe.upgradeCost * 1.8
    )

    return m.reply(`
☕ *Kafe Berhasil Diupgrade!*

📈 Level: ${cafe.level}
👥 Kapasitas: ${cafe.capacity}
📦 Max Stok: ${cafe.maxStock}
✨ Popularitas: ${cafe.popularity}%

💵 Sisa uang:
${rupiah(user.money)}

💰 Upgrade berikutnya:
${rupiah(cafe.upgradeCost)}
`)
  }

  const buyStock = () => {
    const raw =
      String(text || '').trim()

    if (!/^\d+$/.test(raw)) {
      return m.reply(usage.cafestock)
    }

    const requested = integer(raw)

    if (
      requested === null ||
      requested <= 0
    ) {
      return m.reply(
        `Jumlah stok harus bilangan bulat lebih dari 0.\n\n` +
        usage.cafestock
      )
    }

    const maxBuy =
      cafe.maxStock - cafe.stock

    if (maxBuy <= 0) {
      return m.reply(
        '📦 Stok kafe sudah penuh.\n' +
        'Upgrade kafe untuk menambah kapasitas.'
      )
    }

    const amount = Math.min(
      requested,
      maxBuy
    )

    const cost =
      amount * 15000

    if (user.money < cost) {
      return m.reply(
        `💸 Uang tidak cukup.\n\n` +
        `Harga ${amount} stok: ${rupiah(cost)}`
      )
    }

    user.money -= cost
    cafe.stock += amount

    return m.reply(`
📦 *Stok Berhasil Dibeli!*

Jumlah: ${amount}
Harga: ${rupiah(cost)}

📦 Stok:
${cafe.stock}/${cafe.maxStock}

💵 Uang:
${rupiah(user.money)}
`)
  }

  const addMenu = () => {
    const args =
      String(text || '')
        .trim()
        .split(/\s+/)
        .filter(Boolean)

    if (args.length < 2) {
      return m.reply(usage.cafeadd)
    }

    const rawPrice = args.pop()

    if (!/^\d+$/.test(rawPrice)) {
      return m.reply(usage.cafeadd)
    }

    const price = integer(rawPrice)

    const item =
      args.join(' ').trim()

    if (
      !item ||
      price === null ||
      price <= 0
    ) {
      return m.reply(usage.cafeadd)
    }

    const chance =
      Math.round(
        getBuyChance(price) * 100
      )

    cafe.menu.push({
      item,
      price
    })

    let warning

    if (price >= 1000000) {
      warning =
        '🔴 Harga ekstrem. Menu ini hampir tidak akan dibeli pelanggan.'

    } else if (price >= 500000) {
      warning =
        '🔴 Harga sangat mahal. Peluang terjual sangat kecil.'

    } else if (price >= 250000) {
      warning =
        '🟠 Harga sangat tinggi. Menu akan sulit sekali terjual.'

    } else if (price >= 100000) {
      warning =
        '🔴 Harga 100K+. Peluang pelanggan membeli maksimal sekitar 5%.'

    } else if (price <= 10000) {
      warning =
        '🔥 Harga murah, menu ini lebih mudah terjual.'

    } else {
      warning =
        '👍 Harga menu masih tergolong normal.'
    }

    return m.reply(`
✅ *Menu Berhasil Ditambahkan!*

🍽️ Menu: ${item}
💰 Harga: ${rupiah(price)}

📊 Perkiraan peluang terjual:
${chance}%

${warning}
`)
  }

  const renameCafe = () => {
    const name =
      String(text || '').trim()

    if (!name) {
      return m.reply(usage.caferename)
    }

    if (name.length > 40) {
      return m.reply(
        'Nama kafe maksimal 40 karakter.'
      )
    }

    cafe.name = name

    return m.reply(
      `✅ Nama kafe berhasil diganti menjadi *${cafe.name}*.`
    )
  }

  const showMenu = () => {
    const list =
      cafe.menu
        .map((item, index) => {
          const chance =
            Math.round(
              getBuyChance(item.price) * 100
            )

          let difficulty

          if (chance >= 80) {
            difficulty = '🔥 Sangat mudah'
          } else if (chance >= 60) {
            difficulty = '🟢 Mudah'
          } else if (chance >= 40) {
            difficulty = '🟡 Normal'
          } else if (chance >= 20) {
            difficulty = '🟠 Sulit'
          } else if (chance >= 5) {
            difficulty = '🔴 Sangat sulit'
          } else {
            difficulty = '💀 Ekstrem'
          }

          return (
            `${index + 1}. *${item.item}*\n` +
            `   💰 ${rupiah(item.price)}\n` +
            `   📊 Peluang: ${chance}% ${difficulty}`
          )
        })
        .join('\n\n')

    return m.reply(`
☕ *Daftar Menu ${cafe.name}*

${list}

💡 *Tips:*
Semakin mahal harga menu,
semakin kecil kemungkinan pelanggan membelinya.

🔴 *Rp100K+ sangat sulit laku*
💰 Harga tinggi = keuntungan besar jika berhasil terjual.
`)
  }

  switch (
    String(command).toLowerCase()
  ) {
    case 'cafemenu':
      if (String(text || '').trim()) {
        return m.reply(
          'Format: ' +
          usedPrefix +
          'cafemenu'
        )
      }

      return m.reply(cafeStatus())

    case 'cafeopen':
      return serveCustomers()

    case 'cafeupgrade':
      return upgradeCafe()

    case 'cafestock':
      return buyStock()

    case 'cafeadd':
      return addMenu()

    case 'caferename':
      return renameCafe()

    case 'cafelist':
      if (String(text || '').trim()) {
        return m.reply(
          'Format: ' +
          usedPrefix +
          'cafelist'
        )
      }

      return showMenu()
  }
}

handler.help = [
  'cafemenu',
  'cafeopen',
  'cafeupgrade',
  'cafestock',
  'cafeadd',
  'caferename',
  'cafelist'
]

handler.tags = ['rpg']

handler.command =
  /^(cafemenu|cafeopen|cafeupgrade|cafestock|cafeadd|caferename|cafelist)$/i

handler.register = true

export default handler