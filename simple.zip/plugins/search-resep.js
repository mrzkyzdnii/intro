import axios from 'axios'
import * as cheerio from 'cheerio'

const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
  'Referer': 'https://cookpad.com/id'
}

async function searchRecipes(query) {
  const url = `https://cookpad.com/id/cari/${encodeURIComponent(query)}`
  const { data } = await axios.get(url, {
    headers: HEADERS,
    timeout: 10000
  })

  const $ = cheerio.load(data)
  const recipeMap = new Map()

  $('a[href*="/resep/"]').each((_, el) => {
    const href = $(el).attr('href')
    if (!href || !href.match(/\/resep\/\d+/)) return

    const fullUrl = href.startsWith('http')
      ? href
      : `https://cookpad.com${href}`

    const cleanUrl = fullUrl.split('?')[0]

    if (recipeMap.has(cleanUrl)) return

    const card = $(el).closest('li, div')
    const title =
      card.find('h2, h3, span[dir="auto"]').first().text().trim() ||
      $(el).text().trim()

    if (
      title &&
      title.length > 2 &&
      !title.toLowerCase().includes('resep terpilih')
    ) {
      recipeMap.set(cleanUrl, {
        title: title.replace(/\s+/g, ' '),
        url: cleanUrl
      })
    }
  })

  return [...recipeMap.values()]
}

async function scrapeRecipeDetail(recipeUrl) {
  const { data } = await axios.get(recipeUrl, {
    headers: HEADERS,
    timeout: 10000
  })

  const $ = cheerio.load(data)

  let jsonLd = null

  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const parsed = JSON.parse($(el).html() || '{}')

      if (parsed['@type'] === 'Recipe') {
        jsonLd = parsed
      } else if (Array.isArray(parsed)) {
        const found = parsed.find(v => v['@type'] === 'Recipe')
        if (found) jsonLd = found
      }
    } catch {}
  })

  if (jsonLd) {
    let image = jsonLd.image

    if (Array.isArray(image)) image = image[0]
    if (typeof image === 'object' && image?.url) image = image.url
    if (!image) image = $('meta[property="og:image"]').attr('content') || ''

    let author = 'Komunitas Cookpad'

    if (typeof jsonLd.author === 'string')
      author = jsonLd.author
    else if (jsonLd.author?.name)
      author = jsonLd.author.name

    return {
      title: jsonLd.name || $('h1').first().text().trim(),
      description: jsonLd.description || '-',
      image,
      author,
      servings: jsonLd.recipeYield || '-',
      ingredients: Array.isArray(jsonLd.recipeIngredient)
        ? jsonLd.recipeIngredient.map(v => v.trim()).filter(Boolean)
        : [],
      steps: Array.isArray(jsonLd.recipeInstructions)
        ? jsonLd.recipeInstructions.map(v =>
            typeof v === 'string'
              ? v.trim()
              : (v.text || '').trim()
          ).filter(Boolean)
        : [],
      sourceUrl: recipeUrl
    }
  }

  return {
    title: $('h1').first().text().trim(),
    description: $('meta[name="description"]').attr('content') || '-',
    image: $('meta[property="og:image"]').attr('content') || '',
    author:
      $('a[href*="/pengguna/"]').first().text().trim() ||
      'Pengguna Cookpad',
    servings: '-',
    ingredients: [],
    steps: [],
    sourceUrl: recipeUrl
  }
}

async function cookpad(query) {
  const results = await searchRecipes(query)

  if (!results.length) return null

  const random =
    results[Math.floor(Math.random() * results.length)]

  return await scrapeRecipeDetail(random.url)
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text)
    throw `Masukkan nama makanan.\n\nContoh:\n${usedPrefix + command} nasi goreng`

  try {
    await conn.sendMessage(
      m.chat,
      { react: { text: "🍳", key: m.key } }
    )

    const res = await cookpad(text)

    if (!res)
      throw 'Resep tidak ditemukan.'

    let caption = `🍽️ *${res.title}*\n\n`

    if (res.description)
      caption += `📝 ${res.description}\n\n`

    caption += `👨‍🍳 *Author:* ${res.author}\n`
    caption += `🍛 *Porsi:* ${res.servings}\n\n`

    if (res.ingredients.length) {
      caption += `🥕 *Bahan-bahan:*\n`
      caption += res.ingredients
        .map(v => `• ${v}`)
        .join('\n')
      caption += '\n\n'
    }

    if (res.steps.length) {
      caption += `👨‍🍳 *Langkah-langkah:*\n`
      caption += res.steps
        .map((v, i) => `${i + 1}. ${v}`)
        .join('\n')
      caption += '\n\n'
    }

    caption += `🔗 *Sumber:*\n${res.sourceUrl}`

    await conn.sendMessage(
      m.chat,
      {
        image: { url: res.image },
        caption
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    throw 'Gagal mengambil resep Cookpad.'
  }
}

handler.help = ['resep <makanan>']
handler.tags = ['internet']
handler.command = /^resep$/i
handler.limit = 10

export default handler