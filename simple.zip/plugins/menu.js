import moment from 'moment-timezone'

moment.locale('id')

const smallCaps = {
  a:'ᴀ', b:'ʙ', c:'ᴄ', d:'ᴅ', e:'ᴇ', f:'ꜰ', g:'ɢ', h:'ʜ',
  i:'ɪ', j:'ᴊ', k:'ᴋ', l:'ʟ', m:'ᴍ', n:'ɴ', o:'ᴏ', p:'ᴘ',
  q:'q', r:'ʀ', s:'ꜱ', t:'ᴛ', u:'ᴜ', v:'ᴠ', w:'ᴡ', x:'x',
  y:'ʏ', z:'ᴢ',
  0:'0', 1:'1', 2:'2', 3:'3', 4:'4', 5:'5', 6:'6', 7:'7',
  8:'8', 9:'9'
}

const aestheticMap = {
  a:'𝘢', b:'𝘣', c:'𝘤', d:'𝘥', e:'𝘦', f:'𝘧', g:'𝘨', h:'𝘩',
  i:'𝘪', j:'𝘫', k:'𝘬', l:'𝘭', m:'𝘮', n:'𝘯', o:'𝘰', p:'𝘱',
  q:'𝘲', r:'𝘳', s:'𝘴', t:'𝘵', u:'𝘶', v:'𝘷', w:'𝘸', x:'𝘹',
  y:'𝘺', z:'𝘻',
  A:'𝘈', B:'𝘉', C:'𝘊', D:'𝘋', E:'𝘌', F:'𝘍', G:'𝘎', H:'𝘏',
  I:'𝘐', J:'𝘑', K:'𝘒', L:'𝘓', M:'𝘔', N:'𝘕', O:'𝘖', P:'𝘗',
  Q:'𝘘', R:'𝘙', S:'𝘚', T:'𝘛', U:'𝘜', V:'𝘝', W:'𝘞', X:'𝘟',
  Y:'𝘠', Z:'𝘡'
}

function toSmallCaps(text = '') {
  return text
    .toLowerCase()
    .split('')
    .map(c => smallCaps[c] || c)
    .join('')
}

function toAesthetic(text = '') {
  return text
    .split('')
    .map(c => aestheticMap[c] || c)
    .join('')
}

function formatTag(tag) {
  return tag
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, c => c.toUpperCase())
}

function getInfo(item) {
  const info = []
  if (item.premium) info.push('Ⓟ')
  if (item.limit) info.push('Ⓛ')
  if (item.owner) info.push('Ⓞ')
  if (item.admin) info.push('Ⓐ')
  return info.length ? `  ${info.join(' ')}` : ''
}

function createTree(tag, items, usedPrefix) {
  const lines = []

  lines.push(`╭─〔 ⟡ ${toAesthetic(formatTag(tag))} 〕`)
  lines.push(`│`)
  lines.push(`│  ◇ ${toSmallCaps('available commands')}`)
  lines.push(`│`)

  const commands = []

  for (const item of items) {
    for (const cmd of item.helps) {
      commands.push({
        cmd,
        prefix: item.prefix ? usedPrefix : '',
        info: getInfo(item)
      })
    }
  }

  commands.forEach((item, index) => {
    const last = index === commands.length - 1
    const branch = last ? '╰─' : '├─'

    lines.push(
      `│  ${branch} ◇ ${toAesthetic(item.prefix + item.cmd)}${item.info}`
    )
  })

  lines.push(`│`)
  lines.push(`╰────────────────────────`)

  return lines.join('\n')
}

function createAllTree(categories, arrayMenu, usedPrefix) {
  const lines = []

  lines.push(`╭─〔 ⟡ ${toAesthetic('ALL COMMANDS')} 〕`)
  lines.push(`│`)
  lines.push(`│  ◇ ${arrayMenu.length} ${toSmallCaps('categories')}`)
  lines.push(`│`)

  arrayMenu.forEach((tag, tagIndex) => {
    const lastCategory = tagIndex === arrayMenu.length - 1
    const categoryBranch = lastCategory ? '╰─' : '├─'
    const childPrefix = lastCategory ? '   ' : '│  '

    lines.push(
      `│  ${categoryBranch} ◇ ${toAesthetic(formatTag(tag))}`
    )

    const commands = []

    for (const item of categories[tag]) {
      for (const cmd of item.helps) {
        commands.push({
          cmd,
          prefix: item.prefix ? usedPrefix : '',
          info: getInfo(item)
        })
      }
    }

    commands.forEach((item, index) => {
      const last = index === commands.length - 1
      const branch = last ? '╰─' : '├─'

      lines.push(
        `│  ${childPrefix}${branch} ${toAesthetic(item.prefix + item.cmd)}${item.info}`
      )
    })

    if (!lastCategory) {
      lines.push(`│`)
    }
  })

  lines.push(`│`)
  lines.push(`╰────────────────────────`)

  return lines.join('\n')
}

function createInformation() {
  return [
    `╭─〔 ⟡ ${toSmallCaps('information')} 〕`,
    `│  » ${toSmallCaps('premium')}  Ⓟ`,
    `│  » ${toSmallCaps('limit')}    Ⓛ`,
    `│  » ${toSmallCaps('owner')}    Ⓞ`,
    `│  » ${toSmallCaps('admin')}    Ⓐ`,
    `╰────────────────────────`
  ].join('\n')
}

async function sendInteractiveMenu(conn, m, opts = {}) {
  const {
    title = '',
    subtitle = '',
    bodyText = '',
    footerText = '',
    url = 'https://intro-three-eosin.vercel.app/',
    buttonText = 'Press Me'
  } = opts

  return conn.relayMessage(m.chat, {
    interactiveMessage: {
      header: {
        title,
        subtitle,
        hasMediaAttachment: false
      },
      body: {
        text: bodyText
      },
      footer: {
        text: footerText
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: buttonText,
              icon: 'Promotion',
              url,
              webview_interaction: true
            })
          }
        ],
        messageParamsJson: '{}',
        messageVersion: 1
      },
      contextInfo: {
        participant: m.sender,
        stanzaId: m.key?.id || '',
        quotedMessage: {
          extendedTextMessage: {
            text: 'hai',
            previewType: 0,
            inviteLinkGroupTypeV2: 0
          }
        }
      }
    }
  }, {
    additionalNodes: [
      {
        tag: 'biz',
        attrs: {},
        content: [
          {
            tag: 'interactive',
            attrs: {
              type: 'native_flow',
              v: '1'
            },
            content: [
              {
                tag: 'native_flow',
                attrs: {
                  v: '9',
                  name: 'mixed'
                }
              }
            ]
          }
        ]
      }
    ]
  })
}

let handler = async (m, { conn, usedPrefix, command, text, isOwner }) => {
  try {
    const THUMB = global.thumb || './data/media/ky.jpg'

    const who = m.sender
    const user = global.db.data.users[who] || {}

    const botname = global.namebot || conn.user?.name || 'avosky-F'
    const owner = global.nameown || 'Owner'

    const limit =
      (isOwner || user.premiumTime >= 1)
        ? '∞ Unlimited'
        : (user.limit ?? 0)

    const role = isOwner
      ? 'Owner'
      : (user.role || 'Newbie')

    const totalexp = user.totalexp || user.exp || 0

    const plugins = Object.values(global.plugins || {})
      .filter(p => !p.disabled)

    const categories = {}

    for (const p of plugins) {
      const helps = Array.isArray(p.help)
        ? p.help
        : [p.help]

      const tags = Array.isArray(p.tags)
        ? p.tags
        : [p.tags]

      for (let tag of tags) {
        if (!tag) continue

        tag = tag.toLowerCase().trim()

        if (!categories[tag]) {
          categories[tag] = []
        }

        categories[tag].push({
          helps,
          limit: p.limit,
          premium: p.premium,
          owner: p.owner,
          admin: p.admin,
          prefix: !p.customPrefix
        })
      }
    }

    const menuType = (text || '')
      .toLowerCase()
      .trim()

    const arrayMenu = Object.keys(categories).sort()

    const style = global.menuStyle || 1

    if (style === 2) {
      if (
        menuType &&
        (categories[menuType] || menuType === 'all')
      ) {
        let menuText = []

        const targets =
          menuType === 'all'
            ? arrayMenu
            : [menuType]

        for (const tag of targets) {
          menuText.push(
            createTree(
              tag,
              categories[tag],
              usedPrefix
            )
          )
          menuText.push('')
        }

        menuText.push(createInformation())

        return await sendInteractiveMenu(conn, m, {
          title: '',
          subtitle: '',
          bodyText: '',
          footerText: menuText.join('\n'),
          url: 'https://intro-three-eosin.vercel.app/',
          buttonText: 'Press Me'
        })
      }

      const caption = [
        `╭─〔 ⟡ ${toAesthetic(botname.toUpperCase())} 〕`,
        `│`,
        `│  ◇ ${toSmallCaps('selamat datang')},`,
        `│  ${toSmallCaps(who.split('@')[0])}`,
        `│`,
        `├─〔 USER INFORMATION 〕`,
        `│`,
        `│  ◆ Role   › ${toSmallCaps(role)}`,
        `│  ◆ Limit  › ${limit}`,
        `│  ◆ EXP    › ${totalexp}`,
        `│`,
        `├─〔 MENU CATEGORIES 〕`,
        `│`,
        ...arrayMenu.map((tag, i) => {
          const last = i === arrayMenu.length - 1
          return `│  ${last ? '╰─' : '├─'} ◇ ${toAesthetic(formatTag(tag))}`
        }),
        `│`,
        `╰─〔 » ${toSmallCaps('ketik')} ${usedPrefix}menu <kategori> 〕`
      ].join('\n')

      return await conn.sendMessage(
        m.chat,
        {
          image: typeof THUMB === 'string'
            ? { url: THUMB }
            : THUMB,
          caption
        },
        { quoted: m }
      )
    }

    if (
      !menuType ||
      (!categories[menuType] && menuType !== 'all')
    ) {
      return await conn.sendMessage(
        m.chat,
        {
          image: typeof THUMB === 'string'
            ? { url: THUMB }
            : THUMB,

          caption: '',

          footer: [
            `╭─〔 ⟡ ${toAesthetic('WELCOME')} 〕`,
            `│`,
            `│  ${toSmallCaps('halo')}, ${toAesthetic(who.split('@')[0])}`,
            `│`,
            `├─〔 USER INFORMATION 〕`,
            `│`,
            `│  ◆ Bot    › ${toAesthetic(botname)}`,
            `│  ◆ Owner  › ${toAesthetic(owner)}`,
            `│  ◆ Role   › ${toAesthetic(role)}`,
            `│  ◆ Limit  › ${limit}`,
            `│  ◆ EXP    › ${totalexp}`,
            `│`,
            `├─〔 LEGEND 〕`,
            `│`,
            `│  Ⓟ  ${toSmallCaps('premium')}`,
            `│  Ⓛ  ${toSmallCaps('limit')}`,
            `│  Ⓞ  ${toSmallCaps('owner')}`,
            `│  Ⓐ  ${toSmallCaps('admin')}`,
            `│`,
            `╰────────────────────────`
          ].join('\n'),

          optionText: ` ${toAesthetic('Buka Menu')}`,

          optionTitle:
            ` ${toAesthetic('Kategori Tersedia')}`,

          offerText: botname,

          offerCode: 'avosky this bot',

          offerUrl:
            'https://whatsapp.com/channel/',

          offerExpiration:
            Date.now() + 86400000,

          nativeFlow: [
            {
              text: ` ${toAesthetic('Pilih Kategori')}`,

              sections: [
                {
                  title:
                    ` ⟡ ${toAesthetic('MENU CATEGORIES')} (${arrayMenu.length})`,

                  rows: arrayMenu.map(v => ({
                    header: '◇',

                    title:
                      `⌁  ${toAesthetic(formatTag(v))}`,

                    description:
                      `» ${toSmallCaps('buka menu')} ${formatTag(v).toLowerCase()}`,

                    id:
                      `${usedPrefix}${command} ${v}`
                  }))
                }
              ]
            },

            {
              text:
                ` ⟡ ${toAesthetic('Open All Menu')}`,

              id:
                `${usedPrefix}${command} all`
            }
          ]
        },
        { quoted: m }
      )
    }

    let menuText = []

    if (menuType === 'all') {
      menuText.push(
        createAllTree(
          categories,
          arrayMenu,
          usedPrefix
        )
      )
    } else {
      menuText.push(
        createTree(
          menuType,
          categories[menuType],
          usedPrefix
        )
      )
    }

    menuText.push('')
    menuText.push(createInformation())

    await sendInteractiveMenu(conn, m, {
      title: '',
      subtitle: '',
      bodyText: '',
      footerText: menuText.join('\n'),
      url: 'https://intro-three-eosin.vercel.app/',
      buttonText: 'Press Me'
    })

  } catch (e) {
    console.error(e)
    m.reply('Menu error.')
  }
}

handler.command = /^(menu|help)$/i
handler.tags = ['main']
handler.help = ['menu']

export default handler