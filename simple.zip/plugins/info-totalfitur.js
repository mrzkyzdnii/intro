import { createCanvas } from '@napi-rs/canvas'
import { Sticker } from 'wa-sticker-formatter'

const handler = async (m, { conn }) => {
  try {
    const totalPlugin = Object.keys(global.plugins).length
    const totalFitur = Object.values(global.plugins)
      .filter(v => v.help && v.tags && !v.disabled)
      .flatMap(v => v.help)
      .length

    const text = `${totalPlugin} | ${totalFitur}`
    const canvas = createCanvas(800, 300)
    const ctx = canvas.getContext('2d')

    ctx.fillStyle = '#000'
    ctx.fillRect(0, 0, 800, 300)

    ctx.fillStyle = '#fff'
    ctx.font = 'bold 100px monospace'
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.fillText(text, 400, 150)

    const sticker = new Sticker(await canvas.encode('png'), {
      type: 'full',
      pack: 'TOTAL PLUGIN',
      author: 'FITURNYA',
      quality: 100
    })

    await conn.sendFile(m.chat, await sticker.toBuffer(), 'total.webp', '', m, {
      asSticker: true
    })
  } catch (e) {
    console.error(e)
    m.reply('Terjadi error.')
  }
}

handler.help = ['totalfitur']
handler.tags = ['info']
handler.command = ['totalfitur']
handler.limit = 10

export default handler