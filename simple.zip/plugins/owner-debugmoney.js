let handler = async (m, { conn }) => {
    const users = global.db?.data?.users || {}

    let result = []

    for (const [jid, user] of Object.entries(users)) {
        if (!user || typeof user !== 'object') continue

        if (typeof user.money === 'number' && user.money >= 10000000000) {
            result.push({
                jid,
                money: user.money,
                name: await conn.getName(
                    jid.includes('@') ? jid : `${jid}@s.whatsapp.net`
                )
            })
        }
    }

    if (!result.length) {
        return conn.reply(m.chat, '❌ Tidak ditemukan user dengan money besar.', m)
    }

    let teks = `╭━━〔 🔍 DEBUG MONEY 〕━━╮\n┃\n`

    for (const [i, user] of result.entries()) {
        teks += `┃ ${i + 1}. ${user.name}
┃ 👤 JID: ${user.jid}
┃ 💰 Money: ${Number(user.money).toLocaleString('id-ID')}
┃
`
    }

    teks += `╰━━━━━━━━━━━━━━━━━━━━╯`

    await conn.reply(m.chat, teks, m)
}

handler.help = ['debugmoney']
handler.tags = ['owner']
handler.command = /^debugmoney$/i

export default handler