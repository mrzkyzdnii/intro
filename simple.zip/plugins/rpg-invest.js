let handler = async (m, { conn, usedPrefix, text }) => {

    let user = global.db.data.users[m.sender]

    if (!user) return m.reply('❌ Data pengguna belum tersedia.')

    const formatMoney = value =>
        Number(value || 0).toLocaleString('id-ID')

    const BANKRUPTCY_CHANCE = 0.30

    const companies = {

        techcore: {
            name: 'TechCore',
            icon: '💻',
            sector: 'Technology',
            risk: 'EXTREME',
            volatility: 1.35,
            profitChance: 0.34
        },

        nexafin: {
            name: 'NexaFin',
            icon: '🏦',
            sector: 'Finance',
            risk: 'HIGH',
            volatility: 0.95,
            profitChance: 0.37
        },

        agrimax: {
            name: 'AgriMax',
            icon: '🌾',
            sector: 'Agriculture',
            risk: 'LOW',
            volatility: 0.55,
            profitChance: 0.42
        },

        voltaris: {
            name: 'Voltaris',
            icon: '⚡',
            sector: 'Energy',
            risk: 'EXTREME',
            volatility: 1.50,
            profitChance: 0.31
        },

        medinova: {
            name: 'MediNova',
            icon: '🧬',
            sector: 'Healthcare',
            risk: 'HIGH',
            volatility: 0.90,
            profitChance: 0.38
        },

        skylogix: {
            name: 'SkyLogix',
            icon: '🚀',
            sector: 'Aerospace',
            risk: 'EXTREME',
            volatility: 1.65,
            profitChance: 0.28
        },

        ecozen: {
            name: 'EcoZen',
            icon: '🌱',
            sector: 'Green Energy',
            risk: 'HIGH',
            volatility: 1.05,
            profitChance: 0.36
        },

        cybernova: {
            name: 'CyberNova',
            icon: '🛡️',
            sector: 'Cyber Security',
            risk: 'EXTREME',
            volatility: 1.45,
            profitChance: 0.32
        },

        foodverse: {
            name: 'FoodVerse',
            icon: '🍔',
            sector: 'Consumer',
            risk: 'LOW',
            volatility: 0.50,
            profitChance: 0.43
        },

        megabuild: {
            name: 'MegaBuild',
            icon: '🏗️',
            sector: 'Construction',
            risk: 'MEDIUM',
            volatility: 0.75,
            profitChance: 0.40
        }
    }

    const events = [
        {
            name: 'MARKET STABLE',
            icon: '🟢',
            weight: 42,
            min: -8,
            max: 8
        },
        {
            name: 'MARKET VOLATILE',
            icon: '🟡',
            weight: 26,
            min: -15,
            max: 12
        },
        {
            name: 'MARKET PANIC',
            icon: '🔴',
            weight: 15,
            min: -28,
            max: -5
        },
        {
            name: 'MARKET RECOVERY',
            icon: '🔵',
            weight: 9,
            min: -4,
            max: 18
        },
        {
            name: 'MARKET BOOM',
            icon: '🟣',
            weight: 6,
            min: 8,
            max: 28
        },
        {
            name: 'BLACK SWAN',
            icon: '⚫',
            weight: 2,
            min: -45,
            max: 35
        }
    ]

    const random = (min, max) =>
        Math.random() * (max - min) + min

    const pickWeighted = list => {

        let total = list.reduce(
            (sum, item) => sum + item.weight,
            0
        )

        let randomValue = Math.random() * total

        for (let item of list) {

            randomValue -= item.weight

            if (randomValue <= 0)
                return item
        }

        return list[list.length - 1]
    }

    const generateResult = company => {

        let event = pickWeighted(events)

        // Setiap investasi memiliki peluang 30% perusahaan bangkrut.
        // Jika bangkrut, seluruh modal dianggap hilang.
        let isBankrupt = Math.random() < BANKRUPTCY_CHANCE

        if (isBankrupt) {
            return {
                event,
                movement: -100,
                bankrupt: true
            }
        }

        let isProfit =
            Math.random() < company.profitChance

        let movement

        if (event.name === 'BLACK SWAN') {

            movement = random(
                event.min,
                event.max
            )

        } else if (isProfit) {

            movement = random(
                1,
                event.max
            )

            movement *= company.volatility

        } else {

            movement = random(
                event.min,
                -0.5
            )

            movement *= company.volatility
        }

        movement = Math.max(-55, movement)
        movement = Math.min(45, movement)

        return {
            event,
            movement,
            bankrupt: false
        }
    }

    /*
     * ==========================================
     * MENU
     * ==========================================
     */

    if (!text) {

        let list = Object.entries(companies)
            .map(([id, c], i) => {

                let chance =
                    Math.round(c.profitChance * 100)

                return `
${i + 1}. ${c.icon} *${c.name}*
   ├─ 🏷️ ${id}
   ├─ 🏢 ${c.sector}
   ├─ ⚠️ Risiko: ${c.risk}
   └─ 🎯 Profit rate: ~${chance}%`
            })
            .join('\n')

        return conn.reply(m.chat, `
╭━━━〔 📈 INVESTMENT EXCHANGE 〕━━━╮
┃
┃ 💰 *GLOBAL STOCK MARKET*
┃
┃ Pilih perusahaan dan pertaruhkan
┃ uangmu pada market.
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

${list}

╭━━━〔 🎮 CARA BERMAIN 〕━━━╮
┃
┃ ${usedPrefix}invest jumlah perusahaan
┃
┃ Contoh:
┃ ${usedPrefix}invest 1000000 techcore
┃
┃ 💰 Modal    : Rp1.000.000
┃ 🏢 Company  : TechCore
┃ ⏱️ Durasi   : 20 detik
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

⚠️ *MARKET TIDAK RAMAH.*

Profit tidak dijamin.
Kerugian tetap sangat mungkin terjadi.

🍀 Menang bukan mustahil,
tapi jangan berharap market selalu berpihak.
`, m)
    }

    /*
     * ==========================================
     * CEK INVESTASI AKTIF
     * ==========================================
     */

    if (user.investment) {

        let inv = user.investment

        let remaining =
            inv.endAt - Date.now()

        if (remaining > 0) {

            let company =
                companies[inv.company]

            return conn.reply(m.chat, `
╭━━━〔 🔒 INVESTMENT ACTIVE 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃
┃ 💰 Modal
┃ Rp${formatMoney(inv.amount)}
┃
┃ ⏳ Sisa
┃ *${Math.ceil(remaining / 1000)} detik*
┃
┃ 📡 Market
┃ 🟢 RUNNING
┃
┃ 🔐 Position
┃ LOCKED
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

⚠️ Selesaikan investasi ini terlebih dahulu.
`, m)
        }

        /*
         * Kalau investasi sudah selesai
         */

        let company =
            companies[inv.company]

        let movement =
            inv.movement

        let isBankrupt = inv.bankrupt === true

        let profit = isBankrupt
            ? -inv.amount
            : Math.floor(
                inv.amount *
                movement /
                100
            )

        let finalAmount = isBankrupt
            ? 0
            : Math.max(
                0,
                inv.amount + profit
            )

        user.money += finalAmount

        delete user.investment

        return conn.reply(m.chat, `
╭━━━〔 🏁 INVESTMENT CLOSED 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃
┃ 📊 Result
┃ ${movement >= 0 ? '📈' : '📉'} *${movement >= 0 ? '+' : ''}${movement.toFixed(2)}%*
┃
┃ 💰 Modal
┃ Rp${formatMoney(inv.amount)}
┃
┃ ${isBankrupt ? '💥 BANKRUPT' : profit >= 0 ? '🤑 Profit' : '💀 Loss'}
┃ Rp${formatMoney(Math.abs(profit))}
┃
┃ 💎 Final
┃ *Rp${formatMoney(finalAmount)}*
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`, m)
    }

    /*
     * ==========================================
     * ARGUMENT
     * ==========================================
     */

    let args =
        text.trim().split(/\s+/)

    if (args.length < 2) {

        return conn.reply(m.chat, `
╭━━━〔 ❌ INVALID ORDER 〕━━━╮
┃
┃ Format:
┃
┃ ${usedPrefix}invest jumlah perusahaan
┃
┃ Contoh:
┃ ${usedPrefix}invest 1000000 techcore
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`, m)
    }

    let amount =
        Number(args[0])

    let companyId =
        args[1].toLowerCase()

    /*
     * ==========================================
     * VALIDASI
     * ==========================================
     */

    if (
        !Number.isFinite(amount) ||
        amount <= 0
    ) {

        return conn.reply(
            m.chat,
            '❌ Jumlah investasi tidak valid.',
            m
        )
    }

    if (!Number.isInteger(amount)) {

        return conn.reply(
            m.chat,
            '❌ Jumlah investasi harus berupa angka bulat.',
            m
        )
    }

    if (!companies[companyId]) {

        return conn.reply(m.chat, `
❌ Perusahaan *${companyId}* tidak ditemukan.

Gunakan:
*${usedPrefix}invest*
untuk melihat daftar perusahaan.
`, m)
    }

    if (
        amount >
        Number(user.money || 0)
    ) {

        return conn.reply(m.chat, `
╭━━━〔 💸 INSUFFICIENT FUNDS 〕━━━╮
┃
┃ 💰 Order
┃ Rp${formatMoney(amount)}
┃
┃ 💳 Balance
┃ Rp${formatMoney(user.money)}
┃
┃ ❌ Kurang
┃ Rp${formatMoney(
    amount - Number(user.money || 0)
)}
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯
`, m)
    }

    let company =
        companies[companyId]

    /*
     * ==========================================
     * HASIL MARKET DIKUNCI
     * ==========================================
     */

    let market =
        generateResult(company)

    /*
     * ==========================================
     * DURASI FIX 20 DETIK
     * ==========================================
     */

    const durationMs = 20 * 1000

    /*
     * ==========================================
     * POTONG MONEY
     * ==========================================
     */

    user.money -= amount

    let startAt =
        Date.now()

    let endAt =
        startAt + durationMs

    user.investment = {

        company: companyId,

        amount,

        duration: durationMs,

        startAt,

        endAt,

        movement:
            market.movement,

        event:
            market.event.name
    }

    /*
     * ==========================================
     * PESAN UTAMA
     * ==========================================
     */

    let sent =
        await conn.sendMessage(
            m.chat,
            {
                text: `
╭━━━〔 🏦 INVESTMENT ORDER 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃ 🏢 ${company.sector}
┃
┃ 💰 Capital
┃ Rp${formatMoney(amount)}
┃
┃ ⏱️ Duration
┃ *20 seconds*
┃
┃ ⚠️ Risk
┃ ${company.risk}
┃
┃ 📡 Market
┃ 🟡 CONNECTING
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

🔐 Mengunci modal...
📡 Menghubungkan exchange...
🧠 Menyiapkan market engine...
`
            },
            {
                quoted: m
            }
        )

    /*
     * ==========================================
     * KEY PESAN UNTUK EDIT
     * ==========================================
     */

    let key = sent.key

    /*
     * ==========================================
     * HELPER EDIT
     * ==========================================
     */

    const edit = async text => {

        try {

            await conn.sendMessage(
                m.chat,
                {
                    text,
                    edit: key
                }
            )

        } catch (e) {

            console.error(
                'Investment edit error:',
                e
            )
        }
    }

    /*
     * ==========================================
     * 2 DETIK
     * ==========================================
     */

    setTimeout(() => {

        edit(`
╭━━━〔 📡 EXCHANGE CONNECTED 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃ 🏢 ${company.sector}
┃
┃ 💰 Capital
┃ Rp${formatMoney(amount)}
┃
┃ ⏱️ Remaining
┃ *18 seconds*
┃
┃ 📡 Exchange
┃ 🟢 ONLINE
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

🔎 Menganalisa perusahaan...
📊 Mengambil market data...
🛰️ Menunggu pergerakan harga...
`)

    }, 2000)

    /*
     * ==========================================
     * 5 DETIK
     * ==========================================
     */

    setTimeout(() => {

        edit(`
╭━━━〔 📊 MARKET ANALYSIS 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃
┃ 🏢 Sector
┃ ${company.sector}
┃
┃ 📈 Volatility
┃ *${(company.volatility * 100).toFixed(0)}%*
┃
┃ ⚠️ Risk
┃ *${company.risk}*
┃
┃ 💰 Locked Capital
┃ Rp${formatMoney(amount)}
┃
┃ ⏳ Remaining
┃ *15 seconds*
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

📊 Market mulai bergerak...
📉 Harga sedang berfluktuasi...
🧠 Algoritma membaca sentimen...
`)

    }, 5000)

    /*
     * ==========================================
     * 8 DETIK
     * ==========================================
     */

    setTimeout(() => {

        let fake =
            random(-9, 7)

        edit(`
╭━━━〔 📈 LIVE MARKET 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃
┃ 📊 Current Movement
┃ ${fake >= 0 ? '📈 +' : '📉 '}${fake.toFixed(2)}%
┃
┃ 💰 Investment
┃ Rp${formatMoney(amount)}
┃
┃ ⏳ Remaining
┃ *12 seconds*
┃
┃ 🔐 Position
┃ LOCKED
┃
┃ 🟡 Market
┃ VOLATILE
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

⚡ Harga saham sedang berubah...
📡 Investor lain mulai bergerak...
🌐 Global market sedang aktif...
`)

    }, 8000)

    /*
     * ==========================================
     * 12 DETIK
     * ==========================================
     */

    setTimeout(() => {

        let fake =
            random(-14, 10)

        edit(`
╭━━━〔 🛰️ MARKET MONITOR 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃
┃ 📊 Market Pulse
┃ ${fake >= 0 ? '🟢 +' : '🔴 '}${fake.toFixed(2)}%
┃
┃ 💰 Capital
┃ Rp${formatMoney(amount)}
┃
┃ ⏳ Remaining
┃ *8 seconds*
┃
┃ 📡 Exchange
┃ 🟢 ONLINE
┃
┃ 🔐 Position
┃ OPEN
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

⚠️ Market belum menentukan hasil akhir.

📈 Pergerakan sementara bukan hasil final.
💀 Market masih bisa berubah drastis.
`)

    }, 12000)

    /*
     * ==========================================
     * 16 DETIK
     * ==========================================
     */

    setTimeout(() => {

        edit(`
╭━━━〔 ⚠️ FINAL MARKET PHASE 〕━━━╮
┃
┃ ${company.icon} *${company.name}*
┃
┃ 💰 Capital
┃ Rp${formatMoney(amount)}
┃
┃ ⏳ Remaining
┃ *4 seconds*
┃
┃ 📡 Market
┃ 🔴 FINALIZING
┃
┃ 🔐 Position
┃ CLOSING
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

⚡ Harga final sedang ditentukan...
📊 Mengunci market price...
🔐 Menutup posisi...
🎲 Menunggu hasil akhir...
`)

    }, 16000)

    /*
     * ==========================================
     * 20 DETIK
     * HASIL AKHIR
     * ==========================================
     */

    setTimeout(() => {

        if (!user.investment)
            return

        let inv =
            user.investment

        let finalCompany =
            companies[inv.company]

        let movement =
            inv.movement

        let isBankrupt = inv.bankrupt === true

        let profit = isBankrupt
            ? -inv.amount
            : Math.floor(
                inv.amount *
                movement /
                100
            )

        let finalAmount = isBankrupt
            ? 0
            : Math.max(
                0,
                inv.amount + profit
            )

        user.money += finalAmount

        delete user.investment

        let isProfit =
            !isBankrupt && profit > 0

        let isBreakEven =
            !isBankrupt && profit === 0

        let resultIcon =
            isBankrupt
                ? '💥'
                : isProfit
                ? '🟢'
                : isBreakEven
                    ? '🟡'
                    : '🔴'

        let chart =
            isBankrupt
                ? '💣'
                : isProfit
                ? '📈'
                : isBreakEven
                    ? '➖'
                    : '📉'

        edit(`
╭━━━〔 ${resultIcon} INVESTMENT CLOSED 〕━━━╮
┃
┃ ${finalCompany.icon} *${finalCompany.name}*
┃ 🏢 ${finalCompany.sector}
┃
┃ ${chart} MARKET RESULT
┃
┃ 📡 Event
┃ *${inv.event}*
┃
┃ 📊 Movement
┃ *${movement >= 0 ? '+' : ''}${movement.toFixed(2)}%*
┃
┃ ─────────────────────────
┃
┃ 💰 Initial Capital
┃ Rp${formatMoney(inv.amount)}
┃
        ┃ ${isBankrupt
            ? '💥 BANKRUPT — LOSE ALL'
            : isProfit
                ? '🤑 Profit'
                : isBreakEven
                    ? '➖ Return'
                    : '💀 Loss'}
┃ Rp${formatMoney(Math.abs(profit))}
┃
┃ 💎 Final Value
┃ *Rp${formatMoney(finalAmount)}*
┃
┃ ─────────────────────────
┃
┃ 💳 Current Balance
┃ *Rp${formatMoney(user.money)}*
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

${isBankrupt
    ? '💥 Perusahaan bangkrut! Seluruh modal investasi kamu hilang.'
    : isProfit
        ? '🎉 Market berhasil kamu kalahkan!'
        : isBreakEven
        ? '😐 Tidak untung, tidak rugi.'
        : '💀 Market menghancurkan posisi kamu.'}

📌 Position automatically closed.
`)

    }, durationMs)
}

handler.help = ['invest']
handler.tags = ['rpg']
handler.command = /^(invest|investasi)$/i

export default handler