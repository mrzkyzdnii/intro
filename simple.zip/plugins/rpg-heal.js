const MAX_HEALTH = 100
const BASE_HEAL = 40
const CAT_BONUS = 4

const fmt = (value) =>
    Number(value || 0).toLocaleString('id-ID')

const safeNumber = (value, fallback = 0) => {
    const n = Number(value)
    return Number.isFinite(n) ? n : fallback
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    const user = global.db?.data?.users?.[m.sender]

    if (!user) {
        return m.reply(
            '❌ Data pengguna tidak ditemukan di database.'
        )
    }

    /*
     * =========================
     * NORMALISASI DATA
     * =========================
     */

    user.health = Math.max(
        0,
        Math.min(
            MAX_HEALTH,
            safeNumber(user.health)
        )
    )

    user.potion = Math.max(
        0,
        safeNumber(user.potion)
    )

    user.cat = Math.max(
        0,
        safeNumber(user.cat)
    )

    /*
     * =========================
     * HEALTH PENUH
     * =========================
     */

    if (user.health >= MAX_HEALTH) {
        return conn.reply(
            m.chat,
            `
╭━━━━━━━━━━━━━━━━━━━━━━╮
│     ❤️ *HEALTH FULL*     │
╰━━━━━━━━━━━━━━━━━━━━━━╯

❤️ Health kamu sudah penuh!

│ Health : *${fmt(user.health)}/${MAX_HEALTH}*
│ Potion : 🧪 *${fmt(user.potion)}*

✨ Tidak perlu menggunakan potion.
`.trim(),
            m
        )
    }

    /*
     * =========================
     * JUMLAH HEAL
     * =========================
     */

    const healPerPotion =
        BASE_HEAL +
        (user.cat * CAT_BONUS)

    const healthNeeded =
        MAX_HEALTH -
        user.health

    const maxPotionNeeded =
        Math.ceil(
            healthNeeded /
            healPerPotion
        )

    let count

    if (args[0] === undefined) {
        count = maxPotionNeeded
    } else {
        const raw = String(args[0]).trim()

        if (!/^\d+$/.test(raw)) {
            return m.reply(
                `
❌ *JUMLAH TIDAK VALID*

Gunakan angka positif.

Contoh:
➜ ${usedPrefix + command} 1
➜ ${usedPrefix + command} 5
`.trim()
            )
        }

        count = Number(raw)
    }

    /*
     * =========================
     * VALIDASI JUMLAH
     * =========================
     */

    if (
        !Number.isSafeInteger(count) ||
        count < 1
    ) {
        return m.reply(
            '❌ Jumlah potion harus minimal 1.'
        )
    }

    /*
     * =========================
     * CEK POTION
     * =========================
     */

    if (user.potion < count) {
        return conn.reply(
            m.chat,
            `
╭━━━━━━━━━━━━━━━━━━━━━━╮
│    🧪 *POTION KURANG*    │
╰━━━━━━━━━━━━━━━━━━━━━━╯

🧪 Potion kamu:
*${fmt(user.potion)}*

🧪 Potion dibutuhkan:
*${fmt(count)}*

❌ Potion tidak cukup.

💡 Contoh:
${usedPrefix + command} 1
`.trim(),
            m
        )
    }

    /*
     * =========================
     * HITUNG HEAL
     * =========================
     */

    const oldHealth = user.health

    const totalHeal =
        healPerPotion *
        count

    user.potion -= count

    user.health = Math.min(
        MAX_HEALTH,
        user.health + totalHeal
    )

    const actualHeal =
        user.health -
        oldHealth

    /*
     * =========================
     * HASIL
     * =========================
     */

    return conn.reply(
        m.chat,
        `
╭━━━━━━━━━━━━━━━━━━━━━━╮
│     ❤️ *HEAL SUCCESS*     │
╰━━━━━━━━━━━━━━━━━━━━━━╯

🧪 Potion digunakan
│ ${fmt(count)} potion

❤️ Health
│ ${fmt(oldHealth)} ➜ *${fmt(user.health)} / ${MAX_HEALTH}*

💚 Health dipulihkan
│ +${fmt(actualHeal)}

🧪 Sisa potion
│ ${fmt(user.potion)}

${user.cat > 0
    ? `🐱 Cat bonus
│ +${fmt(user.cat * CAT_BONUS)} HP / potion`
    : ''}

╰──────────────────────╯
✨ Health berhasil dipulihkan!
`.trim(),
        m
    )
}

handler.help = ['heal', 'heal <jumlah>']
handler.tags = ['rpg']
handler.command = /^(heal)$/i
handler.register = true
handler.rpg = true

export default handler