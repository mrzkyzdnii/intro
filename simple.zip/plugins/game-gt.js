import crypto from 'crypto'

if (!global.gtWsUrl) global.gtWsUrl = ''

const handler = async (m, { conn, text, usedPrefix, command }) => {
    const input = text?.trim() || ''

    if (input.startsWith('--set')) {
        const wsUrl = input.replace(/^--set\s+/, '').trim()

        if (!wsUrl || !wsUrl.startsWith('ws')) {
            return m.reply(`❌ URL tidak valid\n\n> \`${usedPrefix + command} --set wss://\``)
        }

        global.gtWsUrl = wsUrl

        await m.react('✅')
        return m.reply(`✅ Game WS URL diset: \`${wsUrl}\``)
    }

    if (!global.gtWsUrl) {
        return m.reply(
            `⛏️ *8BIT MINER*\n\n` +
            `> Set WS URL dulu:\n` +
            `> \`${usedPrefix + command} --set wss:\`\n\n`
        )
    }

    await m.react('⛏️')

    try {
        const responseId = crypto.randomUUID()
        const wsUrl = global.gtWsUrl
        const roomId = m.chat
        const playerName = (m.pushName || 'Player').slice(0, 20)

        const html = `<style>
*{-webkit-tap-highlight-color:transparent;user-select:none;box-sizing:border-box;margin:0;padding:0}
body{margin:0;background:transparent;font-family:'Segoe UI',Arial,sans-serif;color:#fff;touch-action:manipulation}
.p{background:#1a2540;border:1px solid rgba(120,180,255,.35);border-radius:18px;padding:12px;max-width:820px;margin:auto;position:relative;box-shadow:0 8px 30px rgba(0,0,0,.4)}
.h{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.logo{width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,#3a8ef6,#2dd4bf);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;box-shadow:0 2px 6px rgba(0,0,0,.3)}
.hinfo{flex:1;min-width:0}
.t{font-size:14px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;letter-spacing:.5px}
.s{font-size:9px;color:#7dd3fc;margin-top:1px;letter-spacing:.5px}
.stage{width:100%;border-radius:12px;overflow:hidden;background:#5fb8e8;margin:6px 0;position:relative;box-shadow:inset 0 0 0 2px rgba(0,0,0,.2)}
canvas{width:100%;display:block;image-rendering:pixelated;image-rendering:crisp-edges;cursor:pointer}
.hud{position:absolute;top:8px;right:8px;background:rgba(10,20,35,.8);border:1px solid rgba(255,255,255,.2);border-radius:8px;padding:5px 9px;font-size:11px;font-weight:700;display:flex;align-items:center;gap:5px;backdrop-filter:blur(4px)}
.hud .plus{background:#22c55e;color:#fff;border-radius:5px;width:18px;height:18px;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:800;margin-left:4px;cursor:pointer}
.chatlog{position:absolute;top:8px;left:8px;max-width:55%;background:rgba(10,25,50,.78);border:1px solid rgba(120,180,255,.25);border-radius:8px;padding:6px 8px;font-size:9px;line-height:1.55;max-height:78px;overflow:hidden;backdrop-filter:blur(4px)}
.chatlog div{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.chatlog .nm{font-weight:800}
.chatlog .sysline{color:#7CFC9A;font-style:italic}
.chatlog .cl{color:#7dd3fc}
.startScreen{position:absolute;inset:0;background:linear-gradient(180deg,rgba(15,25,45,.95),rgba(10,20,40,.95));border-radius:12px;z-index:50;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:20px}
.startScreen .sIcon{font-size:42px}
.startScreen .sTitle{font-size:15px;font-weight:800;letter-spacing:1.5px;color:#7dd3fc}
.startScreen .sSub{font-size:9px;color:#9bb0d0;text-align:center;letter-spacing:.5px}
.startScreen input{width:100%;max-width:240px;background:rgba(255,255,255,.08);border:1px solid rgba(125,211,252,.4);border-radius:8px;color:#fff;font-size:13px;padding:9px;text-align:center;font-family:inherit;outline:none}
.startScreen input:focus{border-color:#7dd3fc;background:rgba(125,211,252,.12)}
.startScreen button{width:100%;max-width:240px;background:linear-gradient(135deg,#3a8ef6,#2dd4bf);border:none;border-radius:8px;color:#fff;font-size:13px;font-weight:800;padding:10px;letter-spacing:1.5px;cursor:pointer;box-shadow:0 4px 12px rgba(58,142,246,.4)}
.startScreen .sWarn{font-size:9px;color:#ff6b6b;min-height:11px}
.hidden{display:none!important}
.hint{font-size:8px;color:#9bb0d0;text-align:center;margin-top:6px;letter-spacing:.3px}
.bottomBar{display:flex;align-items:center;justify-content:space-between;gap:6px;margin-top:8px}
.dgroup{display:flex;gap:5px;flex-shrink:0}
.cbtn{width:42px;height:42px;background:rgba(58,142,246,.22);border:1px solid rgba(58,142,246,.5);border-radius:10px;color:#fff;font-size:18px;display:flex;align-items:center;justify-content:center;cursor:pointer;font-weight:800;backdrop-filter:blur(4px)}
.cbtn:active{background:rgba(58,142,246,.6);transform:scale(.94)}
.inv{display:flex;gap:5px;flex:1;justify-content:center;flex-wrap:wrap}
.ibtn{position:relative;width:42px;height:42px;background:rgba(255,255,255,.06);border:2px solid rgba(255,255,255,.18);border-radius:8px;display:flex;align-items:center;justify-content:center;cursor:pointer;backdrop-filter:blur(4px)}
.ibtn.active{border-color:#29e0ff;box-shadow:0 0 10px rgba(41,224,255,.7);background:rgba(41,224,255,.12)}
.ibtn .sw{width:22px;height:22px;border-radius:4px}
.ibtn .badge{position:absolute;bottom:-4px;right:-4px;background:#0e1420;border:1px solid rgba(255,255,255,.3);border-radius:6px;font-size:8px;padding:1px 4px;font-weight:700;min-width:14px;text-align:center}
.emojiRow{display:flex;gap:4px;margin-top:6px;justify-content:center;flex-wrap:wrap}
.ebtn{width:32px;height:32px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.15);border-radius:8px;font-size:16px;display:flex;align-items:center;justify-content:center;cursor:pointer}
.ebtn:active{background:rgba(255,255,255,.2);transform:scale(.92)}
.chatbox{margin-top:8px;background:rgba(0,0,0,.4);border:1px solid rgba(125,211,252,.2);border-radius:10px;padding:7px;display:flex;flex-direction:column}
.log{height:58px;overflow-y:auto;font-size:10px;line-height:1.45;margin-bottom:6px}
.log::-webkit-scrollbar{width:4px}
.log::-webkit-scrollbar-thumb{background:rgba(125,211,252,.3);border-radius:2px}
.log .sys{color:#7CFC9A;font-style:italic}
.log .name{font-weight:bold}
.inrow{display:flex;gap:5px}
.inrow input{flex:1;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);border-radius:7px;color:#fff;font-size:11px;padding:7px;font-family:inherit;outline:none}
.inrow input:focus{border-color:#7dd3fc}
.inrow button{background:linear-gradient(135deg,#3a8ef6,#2dd4bf);border:none;border-radius:7px;color:#fff;font-size:11px;font-weight:700;padding:7px 12px;cursor:pointer}
.st{text-align:center;margin-top:6px;font-size:9px;color:#9bb0d0;letter-spacing:1.2px;font-weight:600}
.credit{text-align:center;margin-top:6px;font-size:7px;color:#4a6080;letter-spacing:.5px}
.credit a{color:#7dd3fc;text-decoration:none}
</style>
<body>
<div class="p">
<div class="h"><div class="logo">🌍</div><div class="hinfo"><div class="t">PIXEL WORLD</div><div class="s">Room: ${playerName} • Realtime Multiplayer</div></div></div>
<div class="stage">
<canvas id="cv" width="800" height="450"></canvas>
<div class="hud">💎 <span id="scoreTxt">0</span><div class="plus" id="plusBtn">+</div></div>
<div class="chatlog" id="chatlog"></div>
<div class="startScreen" id="startScreen">
<div class="sIcon">🕹️</div>
<div class="sTitle">MASUKKAN NAMA</div>
<div class="sSub">Pilih nama unik biar nggak nabrak sama pemain lain</div>
<input id="nameInput" type="text" placeholder="Nama kamu" maxlength="20" value="${playerName.replace(/"/g, '&quot;')}">
<button id="btnStart">MULAI MAIN</button>
<div class="sWarn" id="sWarn"></div>
</div>
</div>
<div class="hint" id="hint">Klik blok 3x buat hancurin • klik kosong buat lompat • <span id="playerCount">0 pemain</span></div>
<div class="bottomBar">
<div class="dgroup">
<div class="cbtn" id="btnLeft">◀</div>
<div class="cbtn" id="btnRight">▶</div>
</div>
<div class="inv hidden" id="inv">
<div class="ibtn" id="invDirt" data-type="dirt"><div class="sw" style="background:linear-gradient(180deg,#8b5a2b,#6b4423)"></div><span class="badge">0</span></div>
<div class="ibtn" id="invGrass" data-type="grass"><div class="sw" style="background:linear-gradient(180deg,#5fe05a,#3cb33a)"></div><span class="badge">0</span></div>
<div class="ibtn" id="invStone" data-type="stone"><div class="sw" style="background:linear-gradient(180deg,#c8c8d2,#98989e)"></div><span class="badge">0</span></div>
<div class="ibtn" id="invMore" data-type="more"><div class="sw" style="background:linear-gradient(135deg,#f4c542,#e89b1a);display:flex;align-items:center;justify-content:center;font-size:14px;color:#fff;font-weight:800">…</div><span class="badge">∞</span></div>
</div>
<div class="dgroup">
<div class="cbtn" id="btnJump">▲</div>
</div>
</div>
<div class="emojiRow hidden" id="emojiRow">
<div class="ebtn" data-e="😀">😀</div>
<div class="ebtn" data-e="😂">😂</div>
<div class="ebtn" data-e="😍">😍</div>
<div class="ebtn" data-e="👍">👍</div>
<div class="ebtn" data-e="😢">😢</div>
<div class="ebtn" data-e="😡">😡</div>
<div class="ebtn" data-e="🎉">🎉</div>
<div class="ebtn" data-e="❤️">❤️</div>
<div class="ebtn" data-e="🔥">🔥</div>
<div class="ebtn" data-e="💎">💎</div>
</div>
<div class="chatbox hidden" id="chatbox">
<div class="log" id="log"></div>
<div class="inrow">
<input id="chatInput" type="text" placeholder="Ketik pesan..." maxlength="200">
<button id="btnSend">Kirim</button>
</div>
</div>
<div class="st" id="st">MENUNGGU NAMA</div>
<div class="credit">Shared by <a href="https://whatsapp.com/channel/0029Vb7ho1XInlqVcTQ6Oc25">Mrzkyzdnii</a></div>
</div>
<script>
const WS_URL='${wsUrl}',ROOM='${roomId}';
const cv=document.getElementById('cv'),ctx=cv.getContext('2d');
const st=document.getElementById('st'),logEl=document.getElementById('log'),chatInput=document.getElementById('chatInput'),btnSend=document.getElementById('btnSend'),scoreTxt=document.getElementById('scoreTxt'),playerCount=document.getElementById('playerCount'),chatlog=document.getElementById('chatlog');
const startScreen=document.getElementById('startScreen'),nameInput=document.getElementById('nameInput'),btnStart=document.getElementById('btnStart'),sWarn=document.getElementById('sWarn');
const inv=document.getElementById('inv'),chatbox=document.getElementById('chatbox'),emojiRow=document.getElementById('emojiRow'),plusBtn=document.getElementById('plusBtn');
const invDirt=document.getElementById('invDirt'),invGrass=document.getElementById('invGrass'),invStone=document.getElementById('invStone'),invMore=document.getElementById('invMore');
let ws,myId=null,grid={w:20,h:14},players=[],world=[],breaking={},myName='',selectedBlock=null;
let bubbles={};
let chatLines=[];
let renderPos={};
const TILE = Math.floor(cv.width / 20);
const H_TILE = Math.floor(cv.height / 14);
const COLORS={dirt:'#8b5a2b',grass:'#5fe05a',stone:'#a8a8b2',bedrock:'#3a4050'};

function hash(x,y){return Math.abs(Math.sin(x*127.1+y*311.7)*43758.5453)%1}
function fmtTime(t){const d=new Date(t);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}

function pushChatLine(html){
chatLines.push(html);
if(chatLines.length>6)chatLines.shift();
chatlog.innerHTML=chatLines.map(function(l){return '<div>'+l+'</div>'}).join('');
}

function addLog(html){const d=document.createElement('div');d.innerHTML=html;logEl.appendChild(d);logEl.scrollTop=logEl.scrollHeight}

function drawSky(){
const g=ctx.createLinearGradient(0,0,0,cv.height);
g.addColorStop(0,'#4aa8e0');
g.addColorStop(0.5,'#7cc5ed');
g.addColorStop(1,'#bce5f5');
ctx.fillStyle=g;
ctx.fillRect(0,0,cv.width,cv.height);

const sunX=cv.width-90,sunY=80,sunR=30;
ctx.fillStyle='rgba(255,235,120,.35)';
ctx.beginPath();ctx.arc(sunX,sunY,sunR+14,0,7);ctx.fill();
ctx.fillStyle='rgba(255,240,160,.55)';
ctx.beginPath();ctx.arc(sunX,sunY,sunR+6,0,7);ctx.fill();
ctx.fillStyle='#ffe98a';
ctx.beginPath();ctx.arc(sunX,sunY,sunR,0,7);ctx.fill();
ctx.fillStyle='#fff5b8';
ctx.beginPath();ctx.arc(sunX-8,sunY-8,sunR*0.5,0,7);ctx.fill();

function cloud(cx,cy,scale){
ctx.fillStyle='rgba(255,255,255,.95)';
const p=[[0,0,32,14],[10,-8,22,12],[26,-4,22,10],[-12,2,16,10],[24,6,12,8]];
p.forEach(function(r){
ctx.fillRect(cx+r[0]*scale,cy+r[1]*scale,r[2]*scale,r[3]*scale);
});
// shadow under
ctx.fillStyle='rgba(180,210,235,.6)';
ctx.fillRect(cx+4*scale,cy+10*scale,28*scale,3*scale);
}
const t=Date.now()/1000;
cloud(80+Math.sin(t*0.3)*10, 50, 1);
cloud(220+Math.sin(t*0.25+1)*8, 80, 1.2);
cloud(420+Math.sin(t*0.35+2)*12, 40, 0.9);
cloud(580+Math.sin(t*0.28+3)*10, 90, 1.1);

// distant mountains (parallax, 2 layers)
function mountain(cx,w,h,col,snowColor){
ctx.fillStyle=col;
ctx.beginPath();
ctx.moveTo(cx-w/2,cv.height*0.6);
ctx.lineTo(cx,cv.height*0.6-h);
ctx.lineTo(cx+w/2,cv.height*0.6);
ctx.closePath();
ctx.fill();
// snow cap
ctx.fillStyle=snowColor;
ctx.beginPath();
ctx.moveTo(cx-w*0.14,cv.height*0.6-h*0.55);
ctx.lineTo(cx,cv.height*0.6-h);
ctx.lineTo(cx+w*0.14,cv.height*0.6-h*0.55);
ctx.lineTo(cx+w*0.06,cv.height*0.6-h*0.42);
ctx.lineTo(cx-w*0.06,cv.height*0.6-h*0.42);
ctx.closePath();
ctx.fill();
}
// far layer
mountain(120, 200, 110, '#5a7fa8', 'rgba(220,235,250,.75)');
mountain(340, 240, 140, '#6a8fb8', 'rgba(230,240,250,.85)');
mountain(560, 220, 120, '#5a7fa8', 'rgba(220,235,250,.75)');
mountain(740, 200, 105, '#6a8fb8', 'rgba(230,240,250,.85)');
// near layer
mountain(220, 180, 80, '#3d6890', 'rgba(200,225,250,.9)');
mountain(480, 200, 90, '#3a5a7a', 'rgba(200,225,250,.9)');
mountain(700, 160, 70, '#3d6890', 'rgba(200,225,250,.9)');

// green rolling hills
function hillLayer(yBase,amp,col,detail){
ctx.fillStyle=col;
ctx.beginPath();
ctx.moveTo(0,yBase);
for(let x=0;x<=cv.width;x+=detail){
const y=yBase+Math.sin(x*0.02)*amp+Math.sin(x*0.07)*amp*0.4;
ctx.lineTo(x,y);
}
ctx.lineTo(cv.width,yBase);
ctx.closePath();
ctx.fill();
}
hillLayer(cv.height*0.6, 18, '#6ab84a', 24);
hillLayer(cv.height*0.64, 12, '#5fa640', 18);
}

function drawDirt(x,y){
const px=x*TILE,py=y*H_TILE;
const w=TILE,h=H_TILE;
// layered dirt (darker bottom, lighter top to suggest strata)
const grad=ctx.createLinearGradient(px,py,px,py+h);
grad.addColorStop(0,'#7a4a25');
grad.addColorStop(.5,'#5e3a1d');
grad.addColorStop(1,'#3e2410');
ctx.fillStyle=grad;ctx.fillRect(px,py,w,h);
// dark top border
ctx.fillStyle='rgba(0,0,0,.35)';
ctx.fillRect(px,py,w,2);
ctx.fillRect(px,py+h-2,w,2);
// pebbles
ctx.fillStyle='rgba(0,0,0,.35)';
if(hash(x,y)>0.4)ctx.fillRect(px+5,py+7,3,3);
if(hash(x+2,y+3)>0.5)ctx.fillRect(px+15,py+12,2,2);
if(hash(x+5,y+1)>0.6)ctx.fillRect(px+25,py+20,3,2);
if(hash(x+7,y+4)>0.5)ctx.fillRect(px+30,py+6,2,3);
// little light speck
ctx.fillStyle='rgba(255,220,160,.18)';
if(hash(x+3,y+5)>0.6)ctx.fillRect(px+10,py+18,2,1);
if(hash(x+6,y+2)>0.6)ctx.fillRect(px+22,py+5,3,1);
}

function drawGrass(x,y){
const px=x*TILE,py=y*H_TILE;
const w=TILE,h=H_TILE;
// dirt body underneath
const grad=ctx.createLinearGradient(px,py,px,py+h);
grad.addColorStop(0,'#7a4a25');
grad.addColorStop(1,'#3e2410');
ctx.fillStyle=grad;ctx.fillRect(px,py,w,h);
ctx.fillStyle='rgba(0,0,0,.3)';
ctx.fillRect(px,py+h-2,w,2);
ctx.fillStyle='rgba(0,0,0,.3)';
if(hash(x,y)>0.4)ctx.fillRect(px+5,py+12,3,3);
if(hash(x+2,y+3)>0.5)ctx.fillRect(px+18,py+17,2,2);
// grass top band (vibrant growtopia green)
ctx.fillStyle='#5dca3a';
ctx.fillRect(px,py,w,8);
ctx.fillStyle='#7ee35a';
ctx.fillRect(px,py,w,2);
ctx.fillStyle='#3a9c2a';
ctx.fillRect(px,py+7,w,2);
// little grass blades sticking up
const h1=hash(x,y);
if(h1>0.3){ctx.fillStyle='#5dca3a';ctx.fillRect(px+5,py-3,2,4);}
if(h1>0.6){ctx.fillStyle='#5dca3a';ctx.fillRect(px+20,py-4,2,5);}
if(h1>0.5){ctx.fillStyle='#7ee35a';ctx.fillRect(px+32,py-2,2,3);}
if(h1>0.8){ctx.fillStyle='#3a9c2a';ctx.fillRect(px+12,py-2,2,3);}
}

function drawStone(x,y){
const px=x*TILE,py=y*H_TILE;
const w=TILE,h=H_TILE;
const grad=ctx.createLinearGradient(px,py,px,py+h);
grad.addColorStop(0,'#c0c0cc');
grad.addColorStop(1,'#7a7a86');
ctx.fillStyle=grad;ctx.fillRect(px,py,w,h);
ctx.fillStyle='rgba(0,0,0,.25)';
ctx.fillRect(px,py,w,2);
ctx.fillStyle='rgba(255,255,255,.25)';
if(hash(x,y)>0.4)ctx.fillRect(px+6,py+8,4,3);
if(hash(x+2,y+3)>0.5)ctx.fillRect(px+20,py+16,5,3);
if(hash(x+5,y+1)>0.6)ctx.fillRect(px+28,py+24,3,2);
ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=1;
if(hash(x+1,y+2)>0.7){ctx.beginPath();ctx.moveTo(px+10,py+5);ctx.lineTo(px+14,py+18);ctx.stroke();}
if(hash(x+4,y+3)>0.7){ctx.beginPath();ctx.moveTo(px+22,py+10);ctx.lineTo(px+30,py+20);ctx.stroke();}
}

function drawBedrock(x,y){
const px=x*TILE,py=y*H_TILE;
const w=TILE,h=H_TILE;
ctx.fillStyle='#3a4050';
ctx.fillRect(px,py,w,h);
ctx.fillStyle='rgba(0,0,0,.3)';
if(hash(x,y)>0.4)ctx.fillRect(px+5,py+6,8,6);
if(hash(x+2,y+3)>0.5)ctx.fillRect(px+18,py+12,9,7);
if(hash(x+5,y+1)>0.6)ctx.fillRect(px+30,py+22,6,5);
ctx.fillStyle='rgba(255,255,255,.08)';
if(hash(x+1,y+4)>0.5)ctx.fillRect(px+8,py+18,4,3);
if(hash(x+3,y+2)>0.5)ctx.fillRect(px+24,py+4,5,3);
}

function drawTile(t,x,y){
if(t==='dirt')drawDirt(x,y);
else if(t==='grass')drawGrass(x,y);
else if(t==='stone')drawStone(x,y);
else if(t==='bedrock')drawBedrock(x,y);
else {
ctx.fillStyle=COLORS[t]||'#555';
ctx.fillRect(x*TILE,y*H_TILE,TILE,H_TILE);
}
}

function easeLerp(cur,target,amt){return cur+(target-cur)*amt}

function updateRenderPos(){
const ids={};
players.forEach(function(p){
ids[p.id]=true;
const tx=p.x*TILE,ty=p.y*H_TILE;
if(!renderPos[p.id]){renderPos[p.id]={x:tx,y:ty,facing:1}}
const r=renderPos[p.id];
if(tx>r.x+0.5)r.facing=1; else if(tx<r.x-0.5)r.facing=-1;
r.x=easeLerp(r.x,tx,0.22);
r.y=easeLerp(r.y,ty,0.22);
r.moving=Math.abs(tx-r.x)>0.6||Math.abs(ty-r.y)>0.6;
});
Object.keys(renderPos).forEach(function(id){if(!ids[id])delete renderPos[id]});
}

function drawPlayer(p){
const r=renderPos[p.id]||{x:p.x*TILE,y:p.y*H_TILE,facing:1,moving:false};
const px=r.x,py=r.y;
const cx=px+TILE/2;
const bob=r.moving?Math.sin(Date.now()/90)*1.5:0;

ctx.fillStyle='rgba(0,0,0,.28)';
ctx.beginPath();ctx.ellipse(cx,py+H_TILE-2,TILE*0.32,3,0,0,7);ctx.fill();

ctx.fillStyle='#3a3a4a';
ctx.fillRect(cx-7,py+H_TILE-10+(r.moving?bob*0.5:0),5,8);
ctx.fillRect(cx+2,py+H_TILE-10-(r.moving?bob*0.5:0),5,8);

const bodyY=py+H_TILE*0.55+bob*0.3;
ctx.fillStyle=p.color;
ctx.fillRect(cx-9,bodyY,18,14);
ctx.fillStyle='rgba(0,0,0,.2)';
ctx.fillRect(cx-9,bodyY+10,18,4);
ctx.fillStyle='rgba(255,255,255,.18)';
ctx.fillRect(cx-9,bodyY,18,2);

ctx.fillStyle=p.color;
ctx.fillRect(cx-12,bodyY+2,4,8);
ctx.fillRect(cx+8,bodyY+2,4,8);
ctx.fillStyle='#ffd9a0';
ctx.fillRect(cx-12,bodyY+9,4,3);
ctx.fillRect(cx+8,bodyY+9,4,3);

const headY=py+H_TILE*0.15+bob;
const headR=TILE*0.32;
ctx.fillStyle=p.hair||'#3a2a1a';
ctx.beginPath();
ctx.arc(cx,headY-2,headR+1,Math.PI,0);
ctx.fill();
ctx.fillStyle='#ffd9a0';
ctx.beginPath();ctx.arc(cx,headY,headR,0,7);ctx.fill();
ctx.strokeStyle='rgba(0,0,0,.3)';ctx.lineWidth=1;ctx.stroke();
ctx.fillStyle=p.hair||'#3a2a1a';
ctx.fillRect(cx-headR+1,headY-headR*0.4,3,headR*0.7);
ctx.fillRect(cx+headR-4,headY-headR*0.4,3,headR*0.7);
ctx.fillRect(cx-6,headY-headR*0.6,12,3);

ctx.fillStyle='rgba(255,140,140,.6)';
ctx.beginPath();ctx.arc(cx-headR*0.55,headY+headR*0.15,headR*0.18,0,7);ctx.fill();
ctx.beginPath();ctx.arc(cx+headR*0.55,headY+headR*0.15,headR*0.18,0,7);ctx.fill();

ctx.fillStyle='#222';
const eyeDx=2*r.facing;
const eyeY=headY-1;
ctx.fillRect(cx-5+eyeDx,eyeY,2,3);
ctx.fillRect(cx+3+eyeDx,eyeY,2,3);
ctx.fillStyle='#fff';
ctx.fillRect(cx-4+eyeDx,eyeY,1,1);
ctx.fillRect(cx+4+eyeDx,eyeY,1,1);

ctx.fillStyle='#7a4a2a';
ctx.fillRect(cx-2,headY+headR*0.3,4,2);

if(p.id===myId){
ctx.strokeStyle='#7dd3fc';ctx.lineWidth=1.6;
ctx.beginPath();ctx.arc(cx,headY,headR+2,0,7);ctx.stroke();
}

const label=p.name;
ctx.font='bold 9px Arial';
const tw=ctx.measureText(label).width;
const tagX=cx-tw/2-5,tagY=py-14,tagW=tw+18,tagH=11;
// flag swatch (red/white like ID flag)
ctx.fillStyle='rgba(255,80,80,.95)';
ctx.fillRect(tagX+2,tagY+2,5,tagH-4);
ctx.fillStyle='rgba(255,255,255,.95)';
ctx.fillRect(tagX+2,tagY+5,5,2);
// name pill
ctx.fillStyle='rgba(10,15,25,.85)';
ctx.beginPath();
if(ctx.roundRect){ctx.roundRect(tagX+9,tagY,tagW-9,tagH,3);}
else{ctx.rect(tagX+9,tagY,tagW-9,tagH);}
ctx.fill();
ctx.fillStyle='#fff';
ctx.font='bold 8px Arial';
ctx.fillText(label,tagX+12,tagY+8);

const bub=bubbles[p.name];
if(bub&&bub.expire>Date.now()){
ctx.font='10px Arial';
const bw=Math.min(140,ctx.measureText(bub.text).width+14);
const bx=Math.max(4,Math.min(cv.width-bw-4,cx-bw/2)),by=py-38;
ctx.fillStyle='rgba(255,255,255,.96)';
ctx.beginPath();
ctx.moveTo(bx+5,by);ctx.lineTo(bx+bw-5,by);ctx.quadraticCurveTo(bx+bw,by,bx+bw,by+5);
ctx.lineTo(bx+bw,by+18);ctx.quadraticCurveTo(bx+bw,by+23,bx+bw-5,by+23);
ctx.lineTo(cx-3,by+23);ctx.lineTo(cx,by+28);ctx.lineTo(cx+3,by+23);
ctx.lineTo(bx+5,by+23);ctx.quadraticCurveTo(bx,by+23,bx,by+18);
ctx.lineTo(bx,by+5);ctx.quadraticCurveTo(bx,by,bx+5,by);
ctx.fill();
ctx.strokeStyle='rgba(0,0,0,.2)';ctx.lineWidth=1;ctx.stroke();
ctx.fillStyle='#222';
ctx.font='10px Arial';
ctx.fillText(bub.text.slice(0,28),bx+7,by+15);
}
}

function draw(){
drawSky();
for(let y=0;y<grid.h;y++)for(let x=0;x<grid.w;x++){
const t=world[y]&&world[y][x];
if(t)drawTile(t,x,y);
const key=x+','+y;
if(breaking[key]){
const hits=breaking[key].hits;
const cx0=x*TILE,cy0=y*H_TILE;
ctx.strokeStyle='rgba(0,0,0,.7)';ctx.lineWidth=2;
ctx.beginPath();
if(hits>=1){ctx.moveTo(cx0+3,cy0+3);ctx.lineTo(cx0+TILE-3,cy0+H_TILE-3)}
if(hits>=2){ctx.moveTo(cx0+TILE-3,cy0+3);ctx.lineTo(cx0+3,cy0+H_TILE-3)}
if(hits>=3){ctx.moveTo(cx0+TILE/2,cy0+2);ctx.lineTo(cx0+TILE/2,cy0+H_TILE-2)}
ctx.stroke();
}
}
players.sort(function(a,b){return (a.y)-(b.y)});
players.forEach(drawPlayer);
}

function loop(){
updateRenderPos();
draw();
requestAnimationFrame(loop);
}

function updateInv(){
const me=players.find(function(p){return p.id===myId});
const invData=me?me.inventory:{dirt:0,grass:0,stone:0};
invDirt.querySelector('.badge').textContent=invData.dirt||0;
invGrass.querySelector('.badge').textContent=invData.grass||0;
invStone.querySelector('.badge').textContent=invData.stone||0;
[invDirt,invGrass,invStone].forEach(function(b){b.classList.toggle('active',b.dataset.type===selectedBlock)});
}

function connect(){
ws=new WebSocket(WS_URL);
ws.onopen=function(){st.textContent='MENGIRIM NAMA...';st.style.color='#7dd3fc';ws.send(JSON.stringify({type:'join',room:ROOM,name:myName}))};
ws.onclose=function(){st.textContent='TERPUTUS';st.style.color='#ff6b6b'};
ws.onerror=function(){st.textContent='ERROR';st.style.color='#ff6b6b'};
ws.onmessage=function(e){
try{
const m=JSON.parse(e.data);
if(m.type==='join_error'){
sWarn.textContent=m.data.message;
startScreen.classList.remove('hidden');
btnStart.disabled=false;
btnStart.textContent='MULAI MAIN';
try{ws.close()}catch(err){}
return;
}
if(m.type==='joined'){
myId=m.data.id;grid=m.data.grid;
startScreen.classList.add('hidden');
inv.classList.remove('hidden');
emojiRow.classList.remove('hidden');
chatbox.classList.remove('hidden');
st.textContent='ONLINE';st.style.color='#22c55e';
}
if(m.type==='state'){
players=m.data.players;world=m.data.world;breaking=m.data.breaking;grid=m.data.grid;
const me=players.find(function(p){return p.id===myId});
scoreTxt.textContent=me?me.score:0;
playerCount.textContent=players.length+' pemain online';
updateInv();
}
if(m.type==='chat'){
addLog('<span class="name" style="color:'+m.data.color+'">'+m.data.from+':</span> '+m.data.text);
pushChatLine('<span class="nm" style="color:'+m.data.color+'">['+fmtTime(m.data.time)+'] '+m.data.from+':</span> '+m.data.text);
bubbles[m.data.from]={text:m.data.text,expire:Date.now()+4000};
}
if(m.type==='system'){
addLog('<span class="sys">'+m.data.text+'</span>');
pushChatLine('<span class="sysline">'+m.data.text+'</span>');
}
}catch(err){}
};
}

cv.addEventListener('click',function(e){
if(!myId)return;
const rect=cv.getBoundingClientRect();
const scaleX=cv.width/rect.width,scaleY=cv.height/rect.height;
const px=(e.clientX-rect.left)*scaleX,py=(e.clientY-rect.top)*scaleY;
const tx=Math.floor(px/TILE),ty=Math.floor(py/H_TILE);
if(tx<0||tx>=grid.w||ty<0||ty>=grid.h)return;
const cellType=world[ty]?world[ty][tx]:null;

if(selectedBlock==='more'){
ws.send(JSON.stringify({type:'place',x:tx,y:ty,blockType:'grass'}));
selectedBlock=null;updateInv();
return;
}
if(selectedBlock){
if(!cellType)ws.send(JSON.stringify({type:'place',x:tx,y:ty,blockType:selectedBlock}));
selectedBlock=null;updateInv();
return;
}
if(cellType&&cellType!=='bedrock'){
ws.send(JSON.stringify({type:'break',x:tx,y:ty}));
}else if(!cellType){
ws.send(JSON.stringify({type:'jump'}));
}
});

[invDirt,invGrass,invStone,invMore].forEach(function(btn){
btn.addEventListener('click',function(){
const type=btn.dataset.type;
if(type==='more'){selectedBlock='more';}
else selectedBlock=(selectedBlock===type)?null:type;
updateInv();
});
});

document.getElementById('btnLeft').addEventListener('click',function(){if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'move',dir:'left'}))});
document.getElementById('btnRight').addEventListener('click',function(){if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'move',dir:'right'}))});
document.getElementById('btnJump').addEventListener('click',function(){if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'jump'}))});
plusBtn.addEventListener('click',function(){if(ws&&ws.readyState===1)ws.send(JSON.stringify({type:'jump'}))});

function sendChat(){
const text=chatInput.value.trim();
if(!text||!ws||ws.readyState!==1)return;
ws.send(JSON.stringify({type:'chat',text:text}));
chatInput.value='';
}
btnSend.onclick=sendChat;
chatInput.addEventListener('keydown',function(e){if(e.key==='Enter')sendChat()});

document.querySelectorAll('.ebtn').forEach(function(btn){
btn.addEventListener('click',function(){
if(!ws||ws.readyState!==1)return;
ws.send(JSON.stringify({type:'chat',text:btn.dataset.e}));
});
});

function startGame(){
const name=nameInput.value.trim();
if(!name){sWarn.textContent='Nama tidak boleh kosong';return}
sWarn.textContent='';
myName=name;
btnStart.disabled=true;
btnStart.textContent='MENGHUBUNGKAN...';
connect();
}
btnStart.onclick=startGame;
nameInput.addEventListener('keydown',function(e){if(e.key==='Enter')startGame()});

loop();
</script></body>`;

        const payload = {
            response_id: responseId,
            sections: [{
                view_model: {
                    primitive: {
                        __typename: "GenAIaeacdsnwHtmlPrimitive",
                        payload: html,
                        trusted_sources: []
                    },
                    __typename: "GenAISingleLayoutViewModel"
                }
            }]
        }

        await conn.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: responseId
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [
                                {
                                    messageType: 2,
                                    messageText: `PixelWorld - ${playerName}`
                                }
                            ],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify(payload)).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {
                messageId: responseId
            }
        )

        await m.react('✅')

    } catch (e) {
        console.error('[gt]', e)
        await m.react('❌')
        await m.reply(`❌ Error: ${e?.message || e}`)
    }
}

handler.help = ['gt']
handler.tags = ['tools']
handler.command = /^gt$/i

export default handler