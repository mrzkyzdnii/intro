const INVENTORY_KEYS = [
    'potion',
    'trash',
    'wood',
    'rock',
    'string',
    'iron',
    'gold',
    'emerald',
    'diamond',

    'common',
    'uncommon',
    'mythic',
    'legendary',

    'petfood',
    'pet',
    'umpan',

    'botol',
    'kardus',
    'kaleng',
    'gelas',
    'plastik',

    'gandum',
    'minyak',
    'garam',

    'apel',
    'anggur',
    'jeruk',
    'mangga',
    'pisang',

    'bibitapel',
    'bibitanggur',
    'bibitjeruk',
    'bibitmangga',
    'bibitpisang',

    'makanan',

    'ayam',
    'babi',
    'babihutan',
    'banteng',
    'buaya',
    'gajah',
    'harimau',
    'kambing',
    'kerbau',
    'monyet',
    'panda',
    'sapi',

    'paus',
    'kepiting',
    'gurita',
    'cumi',
    'buntal',
    'dory',
    'lumba',
    'lobster',
    'hiu',
    'udang',
    'orca',

    'ikan',
    'lele',
    'nila',
    'bawal',

    'steak',
    'ayam_goreng',
    'ayamgoreng',
    'ayambakar',
    'ribs',
    'roti',
    'udang_goreng',
    'udangbakar',
    'bacon',

    'ikanbakar',
    'lelebakar',
    'nilabakar',
    'bawalbakar',
    'kepitingbakar',
    'pausbakar',
    'babipanggang',
    'oporayam',
    'rendang',
    'gulai',

    'aqua',
    'clay',
    'coal',

    'ojek',
    'polisi',
    'roket',
    'rokets',
    'taxy',

    'horse',
    'horseexp',

    'cat',
    'catexp',

    'dog',
    'dogexp',

    'fox',
    'foxexp',

    'robo',
    'roboexp',

    'dragon',
    'dragonexp',

    'lion',
    'lionexp',

    'rhinoceros',
    'rhinocerosexp',

    'centaur',
    'centaurexp',

    'kyubi',
    'kyubiexp',

    'griffin',
    'griffinexp',

    'phonix',
    'phonixexp',

    'wolf',
    'wolfexp',

    'horselastfeed',
    'catlastfeed',
    'doglastfeed',
    'foxlastfeed',
    'robolastfeed',
    'dragonlastfeed',
    'lionlastfeed',
    'rhinoceroslastfeed',
    'centaurlastfeed',
    'kyubilastfeed',
    'griffinlastfeed',
    'phonixlastfeed',
    'wolflastfeed'
]

const fmt = (num) => {
    return new Intl.NumberFormat('id-ID').format(
        Number(num) || 0
    )
}

const getAmount = (value) => {
    const amount = Number(value)

    if (!Number.isFinite(amount)) return null
    if (amount < 1) return null

    return Math.floor(amount)
}

const isOwner = (m) => {
    const sender = m.sender
    const owners = global.owner || []

    return owners.some(owner => {
        const number = String(
            Array.isArray(owner) ? owner[0] : owner
        ).replace(/\D/g, '')

        return number && sender.includes(number)
    })
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    /*
     * OWNER ONLY
     */
    if (!isOwner(m)) {
        return m.reply(
            '❌ *Akses ditolak!*\n\n' +
            'Command cheat hanya bisa digunakan oleh owner bot.'
        )
    }

    const user = global.db?.data?.users?.[m.sender]

    if (!user) {
        return m.reply(
            '❌ Data user kamu belum tersedia di database.'
        )
    }

    const args = text?.trim().split(/\s+/).filter(Boolean) || []

    /*
     * HELP
     */
    if (!args.length) {
        return m.reply(
`╭━━━〔 ⚡ CHEAT SYSTEM 〕━━━╮
┃
┃ • ${usedPrefix + command} all
┃   └─ Semua item +999999
┃
┃ • ${usedPrefix + command} money 999999
┃   └─ Money +999999
┃
┃ • ${usedPrefix + command} limit 9999
┃   └─ Limit +9999
┃
┃ • ${usedPrefix + command} chip 999999
┃   └─ Chip +999999
┃
┃ • ${usedPrefix + command} diamond 999999
┃   └─ Diamond +999999
┃
┃ • ${usedPrefix + command} wood 999999
┃   └─ Wood +999999
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
        )
    }

    const target = args[0].toLowerCase()

    /*
     * CHEAT ALL
     */
    if (target === 'all') {
        const amount = 999999

        let success = 0
        let skipped = 0

        /*
         * Semua inventory
         */
        for (const key of INVENTORY_KEYS) {
            /*
             * lastfeed bukan quantity.
             */
            if (key.endsWith('lastfeed')) {
                skipped++
                continue
            }

            const current = Number(user[key])

            if (!Number.isFinite(current)) {
                user[key] = amount
            } else {
                user[key] += amount
            }

            success++
        }

        /*
         * Currency
         * money + limit + chip
         */
        for (const key of [
            'money',
            'limit',
            'chip'
        ]) {
            const current = Number(user[key])

            if (!Number.isFinite(current)) {
                user[key] = amount
            } else {
                user[key] += amount
            }
        }

        return m.reply(
`╭━━━〔 ⚡ CHEAT ALL 〕━━━╮
┃
┃ 👤 Player
┃ ${await conn.getName(m.sender)}
┃
┃ 💰 Money
┃ +${fmt(amount)}
┃
┃ ⚡ Limit
┃ +${fmt(amount)}
┃
┃ 🎟️ Chip
┃ +${fmt(amount)}
┃
┃ 📦 Inventory
┃ +${fmt(amount)}
┃
┃ ✅ Berhasil : ${success} objek
┃ ⏭️ Dilewati  : ${skipped} field
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

🔥 *Semua inventory & currency berhasil ditambahkan!*`
        )
    }

    /*
     * Alias
     */
    let key = target

    if (key === 'uang') key = 'money'
    if (key === 'duit') key = 'money'
    if (key === 'koin') key = 'chip'

    /*
     * Jangan izinkan lastfeed.
     */
    if (key.endsWith('lastfeed')) {
        return m.reply(
            '❌ Field `lastfeed` tidak bisa digunakan sebagai objek cheat.'
        )
    }

    /*
     * Semua objek yang boleh di-cheat.
     */
    const allowed = [
        ...INVENTORY_KEYS.filter(
            key => !key.endsWith('lastfeed')
        ),

        'money',
        'limit',
        'chip'
    ]

    /*
     * Object tidak ditemukan.
     */
    if (!allowed.includes(key)) {
        return m.reply(
`❌ Objek *${target}* tidak ditemukan.

Gunakan:
${usedPrefix + command} all

Atau:
${usedPrefix + command} <objek> <jumlah>

Contoh:
${usedPrefix + command} money 999999
${usedPrefix + command} limit 9999
${usedPrefix + command} chip 999999
${usedPrefix + command} diamond 999999`
        )
    }

    /*
     * Validasi jumlah.
     */
    const amount = getAmount(args[1])

    if (!amount) {
        return m.reply(
`❌ Jumlah tidak valid.

Contoh:
${usedPrefix + command} ${key} 999999`
        )
    }

    const before = Number(user[key]) || 0

    /*
     * Tambahkan jumlah.
     */
    user[key] = before + amount

    return m.reply(
`╭━━━〔 ⚡ CHEAT SUCCESS 〕━━━╮
┃
┃ 📦 Object
┃ ${key}
┃
┃ ➕ Ditambahkan
┃ +${fmt(amount)}
┃
┃ 📊 Sebelum
┃ ${fmt(before)}
┃
┃ 💎 Sekarang
┃ ${fmt(user[key])}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
    )
}

handler.help = ['cheat']
handler.tags = ['owner']
handler.command = /^cheat$/i
handler.owner = true

export default handler