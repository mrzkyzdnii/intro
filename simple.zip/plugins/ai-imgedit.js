import axios from 'axios'
import crypto from 'crypto'
import { addExif } from '../lib/sticker.js'
import { Sticker } from 'wa-sticker-formatter'

const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwlO+boC6cwRo3UfXVBadaYwcX0zKS2fuVNY2qZ0dgwb1NJ+/Q9FeAosL4ONiosD71on3PVYqRUlL5045mvH2K9i8bAFVMEip7E6RMK6tKAAif7xzZrXnP1GZ5Rijtqdgwh+YmzTo39cuBCsZqK9oEoeQ3r/myG9S+9cR5huTuFQIDAQAB
-----END PUBLIC KEY-----`

const randomString = (len = 16) => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let res = ''
  for (let i = 0; i < len; i++) {
    res += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return res
}

const aesEncrypt = (data, key, iv) => {
  const cipher = crypto.createCipheriv('aes-128-cbc', Buffer.from(key, 'utf8'), Buffer.from(iv, 'utf8'))
  let encrypted = cipher.update(data, 'utf8', 'base64')
  encrypted += cipher.final('base64')
  return encrypted
}

const rsaEncrypt = (text) => {
  const buffer = Buffer.from(text, 'utf8')
  const encrypted = crypto.publicEncrypt(
    {
      key: PUBLIC_KEY,
      padding: crypto.constants.RSA_PKCS1_PADDING
    },
    buffer
  )
  return encrypted.toString('base64')
}

const signux = (brand = 'aifaceswap') => {
  const nonce = crypto.randomUUID()
  const aesSecret = randomString(16)
  const secretKey = rsaEncrypt(aesSecret)
  const rawSign = `${brand}:${nonce}:${secretKey}`
  const sign = aesEncrypt(rawSign, aesSecret, aesSecret)
  return { secret_key: secretKey, sign, nonce, aesSecret }
}

const signx = () => {
  const nonce = crypto.randomUUID()
  const aesSecret = randomString(16)
  const secretKey = rsaEncrypt(aesSecret)
  return { secret_key: secretKey, aesSecret, nonce }
}

const uploadImage = async (imageBuffer, filename = 'input.png') => {
  const sig = signux('aifaceswap')
  const boundary = `----WebKitFormBoundary${randomString(16)}`
  const originFrom = crypto.createHash('md5').update('ezmaker.ai').digest('hex').substring(8, 24)

  const bodyHeader = Buffer.from(
    `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: image/png\r\n\r\n`
  )
  const bodyFooter = Buffer.from(
    `\r\n--${boundary}\r\nContent-Disposition: form-data; name="request_from"\r\n\r\n37\r\n--${boundary}\r\nContent-Disposition: form-data; name="origin_from"\r\n\r\n${originFrom}\r\n--${boundary}--\r\n`
  )
  const fullBody = Buffer.concat([bodyHeader, imageBuffer, bodyFooter])

  const { data } = await axios.post('https://api-v1.ezmaker.ai/aitools/upload-img-cdn', fullBody, {
    headers: {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': `multipart/form-data; boundary=${boundary}`,
      'Origin': 'https://ezmaker.ai',
      'Referer': 'https://ezmaker.ai/image-to-image/',
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      'x-guide': sig.secret_key,
      'x-sign': sig.sign,
      'theme-version': '83EmcUoQTUv50LhNx0VrdcK8rcGexcP35FcZDcpgWsAXEyO4xqL5shCY6sFIWB2Q',
      'X-code': Date.now().toString()
    }
  })

  if (data?.code !== 200 || !data?.data?.url) {
    throw new Error(data?.message || 'Gagal mengupload gambar ke CDN.')
  }
  return data.data.url
}

const ezmakerImageEdit = async (imageBuffer, prompt, aspectRatio = 'auto') => {
  const imgUrlPath = await uploadImage(imageBuffer)

  const originFrom = crypto.createHash('md5').update('ezmaker.ai').digest('hex').substring(8, 24)
  const fp32 = crypto.createHash('md5').update(`user-fp-${Date.now()}-${Math.random()}`).digest('hex')
  const taskSig = signx()
  const fp1 = aesEncrypt(`aifaceswap:${fp32}`, taskSig.aesSecret, taskSig.aesSecret)

  const payload = {
    fn_name: 'demo-qwen-image-editor',
    call_type: 3,
    input: {
      mode: 'Single Edit',
      source_images: [`https://temp.ezmaker.ai/${imgUrlPath}`],
      prompt: prompt,
      aspect_ratio: aspectRatio,
      request_from: 37
    },
    request_from: 37,
    origin_from: originFrom
  }

  const { data: createData } = await axios.post('https://api-v1.ezmaker.ai/aitools/of/create', payload, {
    headers: {
      'Accept': 'application/json, text/plain, */*',
      'Content-Type': 'application/json',
      'Origin': 'https://ezmaker.ai',
      'Referer': 'https://ezmaker.ai/image-to-image/',
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
      'fp': fp32,
      'fp1': fp1,
      'x-guide': taskSig.secret_key,
      'theme-version': '83EmcUoQTUv50LhNx0VrdcK8rcGexcP35FcZDcpgWsAXEyO4xqL5shCY6sFIWB2Q',
      'X-code': Date.now().toString()
    }
  })

  if (createData?.code !== 200 || !createData?.data?.task_id) {
    throw new Error(createData?.message || 'Gagal membuat task editing di server.')
  }

  const taskId = createData.data.task_id

  let attempts = 0
  const maxAttempts = 25
  while (attempts < maxAttempts) {
    attempts++
    await new Promise((r) => setTimeout(r, 3000))

    const pollSig = signx()
    const pollFp1 = aesEncrypt(`aifaceswap:${fp32}`, pollSig.aesSecret, pollSig.aesSecret)

    const { data: statusData } = await axios.post(
      'https://api-v1.ezmaker.ai/aitools/of/check-status',
      {
        task_id: taskId,
        fn_name: 'demo-qwen-image-editor',
        call_type: 3,
        consume_type: 0,
        request_from: 37,
        origin_from: originFrom
      },
      {
        headers: {
          'Accept': 'application/json, text/plain, */*',
          'Content-Type': 'application/json',
          'Origin': 'https://ezmaker.ai',
          'Referer': 'https://ezmaker.ai/image-to-image/',
          'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
          'fp': fp32,
          'fp1': pollFp1,
          'x-guide': pollSig.secret_key,
          'theme-version': '83EmcUoQTUv50LhNx0VrdcK8rcGexcP35FcZDcpgWsAXEyO4xqL5shCY6sFIWB2Q',
          'X-code': Date.now().toString()
        }
      }
    )

    if (statusData?.code === 200) {
      if (statusData.data?.status === 2 && statusData.data?.result_image) {
        const fullUrl = `https://temp.ezmaker.ai/${statusData.data.result_image}`
        const { data: imgBuffer } = await axios.get(fullUrl, { responseType: 'arraybuffer' })
        return {
          url: fullUrl,
          buffer: Buffer.from(imgBuffer)
        }
      }

      if (statusData.data?.status === 3 || statusData.data?.status === -1) {
        throw new Error(statusData.data?.error || 'Proses gagal digenerate oleh server.')
      }
    }
  }

  throw new Error('Timeout: Antrean server terlalu lama, coba lagi beberapa saat lagi.')
}

// ==========================================
// FUNGSI BUAT STICKER YANG BENAR
// ==========================================

const createWebPSticker = async (imageBuffer, packname = 'AI Edit', author = 'Bot') => {
  try {
    // Method 1: Pakai addExif dari lib/sticker.js (sesuai plugin sticker bot)
    const stickerWithExif = await addExif(imageBuffer, packname, author)
    if (stickerWithExif && Buffer.isBuffer(stickerWithExif) && stickerWithExif.length > 0) {
      return stickerWithExif
    }
  } catch (err) {
    console.error('[addExif error]', err)
  }

  try {
    // Method 2: Fallback pakai wa-sticker-formatter
    const sticker = new Sticker(imageBuffer, {
      type: 'full',
      pack: packname,
      author: author,
      quality: 70
    })
    const buffer = await sticker.toBuffer()
    return buffer
  } catch (err) {
    console.error('[Sticker fallback error]', err)
    throw new Error('Gagal membuat sticker: ' + err.message)
  }
}

// ==========================================
// HANDLER UTAMA
// ==========================================

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || q.mediaType || ''

  // Validasi gambar
  if (!mime.startsWith('image/')) {
    throw `📸 *Kirim atau reply gambar*\n\n` +
          `Cara pakai:\n` +
          `• ${usedPrefix + command} [prompt] --sticker\n` +
          `• ${usedPrefix + command} [prompt]\n\n` +
          `Contoh:\n` +
          `${usedPrefix + command} tambah kacamata --sticker`
  }

  if (!text) {
    throw `✏️ *Masukkan prompt deskripsinya!*\n\n` +
          `Contoh:\n` +
          `${usedPrefix + command} tambah kacamata --sticker`
  }

  // Deteksi flag --sticker
  const isSticker = /(?:^|\s)--sticker(?:\s|$)/i.test(text)

  // Hapus flag dari prompt
  const prompt = text
    .replace(/(?:^|\s)--sticker(?=\s|$)/gi, ' ')
    .trim()

  if (!prompt) {
    throw `✏️ *Masukkan prompt deskripsinya!*\n\n` +
          `Contoh:\n` +
          `${usedPrefix + command} tambah kacamata --sticker`
  }

  // React proses
  try {
    await m.react('⏳')
  } catch {}

  try {
    // Download image
    let media = null

    if (typeof q.download === 'function') {
      media = await q.download()
    } else if (conn.downloadMediaMessage) {
      media = await conn.downloadMediaMessage(q)
    } else if (typeof m.download === 'function') {
      media = await m.download()
    }

    if (!media || !Buffer.isBuffer(media) || media.length === 0) {
      throw new Error('Gagal mendownload media gambar.')
    }

    // Proses AI
    const result = await ezmakerImageEdit(media, prompt)

    if (!result?.buffer || !Buffer.isBuffer(result.buffer) || result.buffer.length === 0) {
      throw new Error('Gambar hasil AI kosong.')
    }

    // ==========================================
    // KIRIM HASIL
    // ==========================================

    if (isSticker) {
      // --- MODE STICKER ---
      const packname = global.stickpack || 'AI Edit'
      const author = global.stickauth || 'Bot'
      
      let stickerBuffer = null
      
      try {
        stickerBuffer = await createWebPSticker(result.buffer, packname, author)
      } catch (err) {
        console.error('[createWebPSticker]', err)
        // Jika gagal, kirim sebagai image biasa
        await conn.sendMessage(m.chat, {
          image: result.buffer,
          caption: `⚠️ *Gagal buat sticker, dikirim sebagai gambar*\n\n✨ Prompt: ${prompt}`
        }, { quoted: m })
        await m.react('✅')
        return
      }

      if (!stickerBuffer || !Buffer.isBuffer(stickerBuffer) || stickerBuffer.length === 0) {
        throw new Error('Buffer sticker kosong.')
      }

      // Kirim sticker
      await conn.sendMessage(m.chat, {
        sticker: stickerBuffer
      }, { quoted: m })

    } else {
      // --- MODE IMAGE ---
      await conn.sendMessage(m.chat, {
        image: result.buffer,
        caption: `✨ *Image Edit Complete*\n\n` +
                 `📝 Prompt: ${prompt}\n` +
                 `🖼️ Format: Image`
      }, { quoted: m })
    }

    // React sukses
    try {
      await m.react('✅')
    } catch {}

  } catch (err) {
    console.error('[imagedit error]', err)

    try {
      await m.react('❌')
    } catch {}

    await conn.reply(m.chat, 
      `❌ *Gagal memproses gambar*\n\n` +
      `> ${err.message || err}`, 
      m
    )
  }
}

handler.help = ['imagedit']
handler.tags = ['ai']
handler.command = /^imagedit$/i
handler.limit = 50
handler.premium = true

export default handler