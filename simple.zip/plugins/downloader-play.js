import yts from 'yt-search'
import { execFile } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'
import os from 'os'
import path from 'path'

const execFileAsync = promisify(execFile)

const YTDLP = './yt-dlp'
const DENO = '/root/.deno/bin/deno'
const COOKIES = './proxy.txt'

const formatViews = views => {
  const num = Number(views || 0)

  if (!Number.isFinite(num) || num <= 0)
    return 'N/A'

  if (num >= 1_000_000_000)
    return `${(num / 1_000_000_000).toFixed(1)}B`

  if (num >= 1_000_000)
    return `${(num / 1_000_000).toFixed(1)}M`

  if (num >= 1_000)
    return `${(num / 1_000).toFixed(1)}K`

  return num.toLocaleString('id-ID')
}

const cleanTitle = title =>
  String(title || '')
    .replace(/\s+/g, ' ')
    .trim()

const normalizeVideo = video => ({
  title: cleanTitle(video.title),
  url: video.url,
  thumbnail: video.thumbnail || '',
  views: video.views || 0,
  duration: video.timestamp || ''
})

const downloadAudio = async (url, dir) => {
  const output = path.join(dir, 'audio.%(ext)s')

  const args = [
    '--js-runtimes',
    `deno:${DENO}`,
    '--remote-components',
    'ejs:github',
    '--cookies',
    COOKIES,
    '--no-playlist',
    '--no-update',
    '--no-warnings',
    '-f',
    '140/251/250/249/bestaudio',
    '-o',
    output,
    url
  ]

  console.log('[PLAY]', url)

  try {
    const { stdout, stderr } =
      await execFileAsync(
        YTDLP,
        args,
        {
          env: {
            ...process.env,
            PATH:
              `/root/.deno/bin:${process.env.PATH || ''}`
          },
          maxBuffer:
            100 * 1024 * 1024
        }
      )

    if (stdout)
      console.log('[YTDLP]', stdout)

    if (stderr)
      console.log('[YTDLP STDERR]', stderr)
  } catch (error) {
    console.error(
      '[YTDLP ERROR]',
      error?.stderr ||
      error?.stdout ||
      error
    )

    throw new Error(
      error?.stderr ||
      error?.stdout ||
      error?.message ||
      'yt-dlp gagal mengunduh audio.'
    )
  }

  const files = fs.readdirSync(dir).map(f => path.join(dir, f))
  const file = files.find(f => /\.(m4a|webm|mp3|opus)$/i.test(f) && fs.existsSync(f))

  if (!file)
    throw new Error(
      'Audio tidak ditemukan setelah download.'
    )

  return file
}

const sendAudio = async (
  conn,
  m,
  video
) => {
  let tempDir = null

  try {
    tempDir = fs.mkdtempSync(
      path.join(os.tmpdir(), 'yt_play-')
    )

    await conn.reply(
      m.chat,
      `🎧 *${video.title}*\n` +
      `⏱️ ${video.duration || '-'}\n` +
      `👁️ ${formatViews(video.views)} views\n\n` +
      `⏳ Sedang mengunduh audio...`,
      m
    )

    const audio =
      await downloadAudio(
        video.url,
        tempDir
      )

    const buffer =
      fs.readFileSync(audio)

    const ext =
      audio
        .split('.')
        .pop()
        .toLowerCase()

    const mimetype =
      ext === 'm4a'
        ? 'audio/mp4'
        : ext === 'mp3'
          ? 'audio/mpeg'
          : ext === 'opus'
            ? 'audio/ogg; codecs=opus'
            : 'audio/webm'

    await conn.sendMessage(
      m.chat,
      {
        audio: buffer,
        mimetype,
        fileName:
          `${video.title}.${ext}`,
        ptt: false
      },
      {
        quoted: m
      }
    )
  } finally {
    if (tempDir) {
      try {
        fs.rmSync(tempDir, {
          recursive: true,
          force: true
        })
      } catch {}
    }
  }
}

const handler = async (
  m,
  {
    conn,
    text,
    usedPrefix,
    command
  }
) => {
  if (!text) {
    throw (
      `Contoh:\n` +
      `${usedPrefix + command} beautiful in white\n\n` +
      `List:\n` +
      `${usedPrefix + command} beautiful in white --list 5`
    )
  }

  conn.playLists =
    conn.playLists || new Map()

  const input =
    text.trim()

  const listMatch =
    input.match(
      /\s+--list(?:\s+(\d+))?\s*$/i
    )

  if (listMatch) {
    const count =
      Number(
        listMatch[1] || 5
      )

    const query =
      input
        .replace(
          /\s+--list(?:\s+\d+)?\s*$/i,
          ''
        )
        .trim()

    if (!query) {
      throw (
        `Masukkan judul lagu.\n\n` +
        `Contoh:\n` +
        `${usedPrefix + command} beautiful in white --list 5`
      )
    }

    if (
      !Number.isInteger(count) ||
      count < 1 ||
      count > 20
    ) {
      throw (
        'Jumlah list harus antara 1–20.'
      )
    }

    await conn.reply(
      m.chat,
      `🔎 Mencari ${count} hasil YouTube...`,
      m
    )

    let results

    try {
      const search =
        await yts(query)

      results =
        search.videos
          .slice(0, count)
          .map(normalizeVideo)
    } catch (error) {
      console.error(
        '[YTS ERROR]',
        error
      )

      throw (
        '❌ Gagal mencari video YouTube.'
      )
    }

    if (!results.length)
      throw (
        '❌ Video tidak ditemukan.'
      )

    let listText =
      `╭─〔 🎧 YOUTUBE SEARCH 〕\n` +
      `│ 🔎 Query : ${query}\n` +
      `│ 📋 Total : ${results.length} hasil\n` +
      `│\n`

    results.forEach(
      (video, index) => {
        listText +=
          `│ *${index + 1}.* ${video.title}\n` +
          `│    ├ ⏱️ ${video.duration || '-'}\n` +
          `│    └ 👁️ ${formatViews(video.views)} views\n` +
          `│\n`
      }
    )

    listText +=
      `│ Reply pesan ini dengan angka *1–${results.length}*\n` +
      `│ untuk memilih lagu.\n` +
      `│\n` +
      `│ ⏳ Berlaku selama 60 detik.\n` +
      `╰────────────`

    const sent =
      await conn.sendMessage(
        m.chat,
        {
          text: listText
        },
        {
          quoted: m
        }
      )

    const messageId =
      sent?.key?.id ||
      sent?.id ||
      sent?.stanzaId ||
      null

    const old =
      conn.playLists.get(
        m.sender
      )

    if (old?.timer)
      clearTimeout(
        old.timer
      )

    const pending = {
      sender: m.sender,
      chat: m.chat,
      messageId,
      results,
      createdAt: Date.now(),
      timer: null
    }

    conn.playLists.set(
      m.sender,
      pending
    )

    pending.timer =
      setTimeout(() => {
        const current =
          conn.playLists.get(
            m.sender
          )

        if (current === pending) {
          conn.playLists.delete(
            m.sender
          )

          console.log(
            `[PLAY LIST] Expired: ${m.sender}`
          )
        }
      }, 60000)

    return
  }

  const query =
    input

  if (/^\d+$/.test(query))
    return

  let video

  try {
    if (
      /youtu\.be|youtube\.com/i.test(
        query
      )
    ) {
      video = {
        title: 'YouTube Audio',
        url: query,
        thumbnail: '',
        views: 0,
        duration: ''
      }

      try {
        const search =
          await yts(query)

        if (
          search.videos?.length
        ) {
          video =
            normalizeVideo(
              search.videos[0]
            )
        }
      } catch {}
    } else {
      const search =
        await yts(query)

      if (
        !search.videos?.length
      ) {
        throw new Error(
          'Video tidak ditemukan.'
        )
      }

      video =
        normalizeVideo(
          search.videos[0]
        )
    }

    await sendAudio(
      conn,
      m,
      video
    )
  } catch (error) {
    console.error(
      '[PLAY ERROR]',
      error
    )

    await conn.reply(
      m.chat,
      `❌ ${
        error?.message ||
        error ||
        'Terjadi kesalahan.'
      }`,
      m
    )
  }
}

handler.before = async (
  m,
  { conn }
) => {
  conn.playLists =
    conn.playLists || new Map()

  const answer =
    String(
      m.text || ''
    ).trim()

  if (
    !/^(?:[1-9]|1\d|20)$/.test(
      answer
    )
  )
    return

  const pending =
    conn.playLists.get(
      m.sender
    )

  if (!pending)
    return

  if (!m.quoted)
    return

  const quotedId =
    m.quoted?.key?.id ||
    m.quoted?.id ||
    m.quoted?.stanzaId ||
    null

  if (
    !quotedId ||
    quotedId !== pending.messageId
  )
    return

  if (
    pending.chat !== m.chat
  )
    return

  conn.playLists.delete(
    m.sender
  )

  if (pending.timer)
    clearTimeout(
      pending.timer
    )

  const index =
    Number(answer) - 1

  const video =
    pending.results[index]

  if (!video) {
    return conn.reply(
      m.chat,
      `❌ Pilihan hanya tersedia 1–${pending.results.length}.`,
      m
    )
  }

  try {
    await sendAudio(
      conn,
      m,
      video
    )
  } catch (error) {
    console.error(
      '[PLAY LIST ERROR]',
      error
    )

    await conn.reply(
      m.chat,
      `❌ Gagal mengunduh audio.\n\n${
        error?.message ||
        error ||
        'Unknown error'
      }`,
      m
    )
  }
}

handler.help = ['play']
handler.tags = ['downloader']
handler.command = /^(play)$/i
handler.limit = 10
handler.register = true

export default handler