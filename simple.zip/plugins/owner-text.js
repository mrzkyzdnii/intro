const handler = async (m, { conn, text }) => {
    if (!text) throw 'apa'

    if (m.isGroup) {
        await conn.sendMessage(m.chat, {
            text: '@' + m.chat,
            contextInfo: {
                groupMentions: [
                    {
                        groupSubject: text,
                        groupJid: m.chat
                    }
                ]
            }
        }, { quoted: m })
    } else {
        await conn.reply(m.chat, text, m)
    }
}

handler.help = ['text']
handler.tags = ['tools']
handler.command = /^text$/i
handler.owner = true

handler.limit = 10
export default handler