import axios from 'axios'
import * as cheerio from 'cheerio'

const BASE_URL = 'https://wuthering.gg'

const getHeaders = () => ({
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.9'
})

const getCharacterList = async () => {
  const { data } = await axios.get(`${BASE_URL}/characters`, { headers: getHeaders() })
  const $ = cheerio.load(data)
  const list = []

  $('a[href^="/characters/"]').each((_, el) => {
    const href = $(el).attr('href') || ''
    const slug = href.replace('/characters/', '').replace(/\//g, '').trim().toLowerCase()
    if (!slug) return

    const fullText = $(el).text().trim()
    const name = fullText.replace(/[★\d]/g, '').trim() || slug
    const rarity = fullText.includes('★★★★★') ? 5 : fullText.includes('★★★★') ? 4 : null
    const element = $(el).find('img[src*="iconelement"], img[alt*="Element"], img[alt]').filter((__, img) => {
      const alt = $(img).attr('alt') || ''
      return ['Glacio', 'Fusion', 'Electro', 'Aero', 'Spectro', 'Havoc'].includes(alt)
    }).attr('alt') || ''

    if (!list.some(c => c.slug === slug)) {
      list.push({ name, slug, rarity, element })
    }
  })

  return list.sort((a, b) => a.name.localeCompare(b.name))
}

const getCharacterDetail = async (query) => {
  const cleanQuery = query.toLowerCase().replace(/[^a-z0-9]/g, '')
  const charList = await getCharacterList()
  const matched = charList.find(c =>
    c.slug.replace(/[^a-z0-9]/g, '') === cleanQuery ||
    c.name.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanQuery ||
    c.slug.replace(/[^a-z0-9]/g, '').includes(cleanQuery)
  )

  const slug = matched ? matched.slug : cleanQuery
  const url = `${BASE_URL}/characters/${slug}`

  const { data } = await axios.get(url, { headers: getHeaders() })
  const $ = cheerio.load(data)

  const name = matched?.name || $('title').text().replace(/Build.*/i, '').trim() || slug
  
  let avatar = $('img[src*="iconrolepile"], img[src*="T_IconRole_Pile"]').first().attr('src') || ''
  if (avatar && avatar.startsWith('/')) avatar = `${BASE_URL}${avatar}`

  let element = matched?.element || ''
  let weapon = ''
  const rarity = matched?.rarity ? (matched.rarity === 5 ? '★★★★★ (5 Star)' : '★★★★ (4 Star)') : '-'

  $('img[src*="iconelement"]').each((_, img) => {
    if (!element) element = $(img).attr('alt') || ''
  })

  $('img[src*="SP_IconNor"], img[src*="SP_Icon"]').each((_, img) => {
    const alt = $(img).attr('alt')
    if (['Rectifier', 'Broadblade', 'Sword', 'Pistols', 'Gauntlets'].includes(alt)) {
      weapon = alt
    }
  })

  if (!weapon) {
    const textMatch = $('body').text().match(/(Rectifier|Broadblade|Sword|Pistols|Gauntlets)/i)
    if (textMatch) weapon = textMatch[1]
  }

  const ascensionMaterials = []
  $('h2:contains("Ascension Materials")').parent().parent().find('li.consume, .consume').each((_, el) => {
    const matText = $(el).text().replace(/\s+/g, ' ').trim()
    if (matText) {
      ascensionMaterials.push(matText)
    }
  })

  let bestWeapon = null
  const weaponSec = $('.character-weapon')
  if (weaponSec.length) {
    const wName = weaponSec.find('.weapon-info h1.name, .weapon-info .name').first().text().trim()
    const wLevel = weaponSec.find('.level .value').first().text().trim()
    const wRank = weaponSec.find('.weapon-ability .level .value').text().trim()
    const wStats = weaponSec.find('.weapon-stats .item').map((_, el) => {
      return `${$(el).find('.text').text().trim()}: ${$(el).find('.value').text().trim()}`
    }).get().join(' | ')
    const wDesc = weaponSec.find('.weapon-ability .container p, .weapon-ability p').text().replace(/\s+/g, ' ').trim()
    if (wName) {
      bestWeapon = { name: wName, level: wLevel, rank: wRank, stats: wStats, desc: wDesc }
    }
  }

  let bestEcho = null
  const echoSec = $('.character-echoes')
  if (echoSec.length) {
    const echoSlots = []
    echoSec.find('.echo-choice').each((_, el) => {
      const cost = $(el).find('.cost').text().trim()
      const eName = $(el).find('.echo-name').text().trim() || $(el).find('img').first().attr('alt')
      const sonata = $(el).find('.fet img').attr('alt') || ''
      if (eName) echoSlots.push(`[Cost ${cost}] ${eName}${sonata ? ` (${sonata})` : ''}`)
    })

    const sonataEffects = []
    echoSec.find('p, span, div').each((_, el) => {
      const text = $(el).text().replace(/\s+/g, ' ').trim()
      if (text.startsWith('•') && !sonataEffects.includes(text)) {
        sonataEffects.push(text)
      }
    })

    if (echoSlots.length) {
      bestEcho = {
        slots: echoSlots,
        effects: sonataEffects
      }
    }
  }

  const buildStats = []
  $('h3:contains("Stats"), h2:contains("Stats")').parent().find('.character-stats .item, .weapon-stats .item, .stats .item').each((_, el) => {
    const label = $(el).find('.text').text().trim()
    const val = $(el).find('.value').text().trim()
    if (label && val && !buildStats.some(s => s.startsWith(label))) {
      buildStats.push(`${label}: ${val}`)
    }
  })

  const skills = []
  $('h2:contains("Skills")').parent().find('.ability').each((_, el) => {
    const sName = $(el).find('.header h3, .header .name, h3').first().clone().children().remove().end().text().trim() || $(el).find('.header h3, .header .name, h3').first().text().trim()
    const sType = $(el).find('.header p, p').first().text().replace(/—/g, '').trim()
    const sDesc = $(el).find('.container p, p.desc, .description').map((__, p) => $(p).text().replace(/\s+/g, ' ').trim()).get().filter(Boolean).join('\n')
    if (sName && !skills.some(s => s.name === sName)) {
      skills.push({ name: sName, type: sType, desc: sDesc })
    }
  })

  const introOutro = []
  $('h2:contains("Intro/Outro")').parent().find('.ability').each((_, el) => {
    const sName = $(el).find('.header h3, .header .name, h3').first().clone().children().remove().end().text().trim() || $(el).find('.header h3, .header .name, h3').first().text().trim()
    const sType = $(el).find('.header p, p').first().text().replace(/—/g, '').trim()
    const sDesc = $(el).find('.container p, p.desc, .description').map((__, p) => $(p).text().replace(/\s+/g, ' ').trim()).get().filter(Boolean).join('\n')
    if (sName && !introOutro.some(s => s.name === sName)) {
      introOutro.push({ name: sName, type: sType, desc: sDesc })
    }
  })

  const passives = []
  $('h2:contains("Passive Skills")').parent().find('.ability').each((_, el) => {
    const sName = $(el).find('.header h3, .header .name, h3').first().clone().children().remove().end().text().trim() || $(el).find('.header h3, .header .name, h3').first().text().trim()
    const sDesc = $(el).find('p').text().replace(/\s+/g, ' ').trim()
    if (sName && !passives.some(p => p.name === sName)) {
      passives.push({ name: sName, desc: sDesc })
    }
  })

  const resonanceChain = []
  $('h2:contains("Resonance Chain")').parent().find('.sequence').each((i, el) => {
    const cName = $(el).find('h3').text().trim() || `Node ${i + 1}`
    const cDesc = $(el).find('.description, p').text().replace(/\s+/g, ' ').trim()
    if (cName) {
      resonanceChain.push({ node: i + 1, name: cName, desc: cDesc })
    }
  })

  return {
    name,
    rarity,
    element,
    weapon,
    avatar,
    ascensionMaterials,
    bestWeapon,
    bestEcho,
    buildStats,
    skills,
    introOutro,
    passives,
    resonanceChain
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    throw `Contoh Penggunaan:\n• ${usedPrefix + command} jinhsi\n• ${usedPrefix + command} --list`
  }

  const query = text.trim()

  if (query === '--list') {
    const charList = await getCharacterList()
    if (!charList.length) throw 'Gagal mengambil daftar karakter.'

    const star5 = charList.filter(c => c.rarity === 5).map(c => `${c.name} (${c.element || 'Unknown'})`)
    const star4 = charList.filter(c => c.rarity === 4).map(c => `${c.name} (${c.element || 'Unknown'})`)
    const others = charList.filter(c => !c.rarity).map(c => `${c.name} (${c.element || 'Unknown'})`)

    let caption = `乂 *WUTHERING WAVES CHARACTER LIST* 乂\n`
    caption += `Total: ${charList.length} Karakter\n\n`

    if (star5.length) {
      caption += `*★ 5-Star Resonators:*\n`
      caption += star5.map(name => `• ${name}`).join('\n') + '\n\n'
    }

    if (star4.length) {
      caption += `*★ 4-Star Resonators:*\n`
      caption += star4.map(name => `• ${name}`).join('\n') + '\n\n'
    }

    if (others.length) {
      caption += `*★ Others:*\n`
      caption += others.map(name => `• ${name}`).join('\n') + '\n\n'
    }

    caption += `Ketik *${usedPrefix + command} <nama karakter>* untuk melihat detail build.`

    return conn.reply(m.chat, caption.trim(), m)
  }

  try {
    const data = await getCharacterDetail(query)

    let caption = `乂 *WUTHERING WAVES - ${data.name.toUpperCase()}* 乂\n\n`
    caption += `• *Rarity:* ${data.rarity}\n`
    caption += `• *Element:* ${data.element}\n`
    caption += `• *Weapon Type:* ${data.weapon}\n\n`

    if (data.ascensionMaterials.length) {
      caption += `┌─「 *ASCENSION MATERIALS* 」\n`
      caption += data.ascensionMaterials.map(m => `│ • ${m}`).join('\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.bestWeapon) {
      caption += `┌─「 *BEST WEAPON* 」\n`
      caption += `│ • *${data.bestWeapon.name}* (Lvl ${data.bestWeapon.level || '90'})\n`
      if (data.bestWeapon.stats) caption += `│   Stats: ${data.bestWeapon.stats}\n`
      if (data.bestWeapon.desc) caption += `│   Effect: ${data.bestWeapon.desc}\n`
      caption += `└────\n\n`
    }

    if (data.bestEcho) {
      caption += `┌─「 *BEST ECHO BUILD* 」\n`
      if (data.bestEcho.slots.length) {
        caption += `│ • *Echo Setup:*\n`
        caption += data.bestEcho.slots.map(s => `│   - ${s}`).join('\n') + '\n'
      }
      if (data.bestEcho.effects.length) {
        caption += `│ • *Sonata Effects:*\n`
        caption += data.bestEcho.effects.map(e => `│   ${e}`).join('\n') + '\n'
      }
      caption += `└────\n\n`
    }

    if (data.buildStats.length) {
      caption += `┌─「 *BUILD STATS (LVL 90)* 」\n`
      caption += data.buildStats.map(s => `│ • ${s}`).join('\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.skills.length) {
      caption += `┌─「 *RESONANCE SKILLS* 」\n`
      caption += data.skills.map(s => `│ • *${s.type}:* ${s.name}\n│   ${s.desc}`).join('\n│\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.introOutro.length) {
      caption += `┌─「 *CONCERTO SKILLS* 」\n`
      caption += data.introOutro.map(s => `│ • *${s.type}:* ${s.name}\n│   ${s.desc}`).join('\n│\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.passives.length) {
      caption += `┌─「 *PASSIVE SKILLS (INHERENT SKILLS)* 」\n`
      caption += data.passives.map(p => `│ • *${p.name}:*\n│   ${p.desc}`).join('\n│\n') + '\n'
      caption += `└────\n\n`
    }

    if (data.resonanceChain.length) {
      caption += `┌─「 *RESONANCE CHAIN (SEQUENCES)* 」\n`
      caption += data.resonanceChain.map(c => `│ • *S${c.node}. ${c.name}*\n│   ${c.desc}`).join('\n│\n') + '\n'
      caption += `└────`
    }

    if (data.avatar && conn.sendFile) {
      return conn.sendFile(m.chat, data.avatar, `${data.name}.png`, caption.trim(), m)
    }

    return conn.reply(m.chat, caption.trim(), m)
  } catch (err) {
    throw `Karakter "${query}" tidak ditemukan atau terjadi kesalahan saat mengambil data.`
  }
}

handler.help = ['wuwa <character>', 'wuwa --list']
handler.tags = ['anime']
handler.command = /^wuwa$/i

export default handler