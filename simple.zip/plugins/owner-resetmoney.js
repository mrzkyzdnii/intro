const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Contoh:\n${usedPrefix + command} 628123456789`

    let number = text.replace(/[^0-9]/g, '')
    if (!number) throw 'Nomor tidak valid!'

    if (number.startsWith('0'))
        number = '62' + number.slice(1)

    const jid = number + '@s.whatsapp.net'

    if (!global.db.data.users[jid])
        throw 'User tersebut belum terdaftar di database bot.'

    const user = global.db.data.users[jid]
    const oldMoney = user.money || 0

    user.money = 0

    await conn.reply(
        m.chat,
        `╭━━〔 💰 RESET MONEY 〕━━╮
┃
┃ 👤 User   : @${number}
┃ 💵 Sebelum : ${oldMoney.toLocaleString('id-ID')}
┃ 💵 Sesudah : 0
┃
╰━━━━━━━━━━━━━━━━━━╯
> Money user berhasil direset.`,
        m,
        { mentions: [jid] }
    )
}

handler.help = ['resetmoney']
handler.tags = ['owner']
handler.command = /^resetmoney$/i
handler.owner = true

export default handler