import fs from 'fs'

let timeout = 60000 // 60 detik
let poin = 0 // opsional untuk skor

let handler = async (m, { conn, command, isAdmin, isOwner }) => {
  global.tebakgame = global.tebakgame || {}
  const chat = m.chat
  const room = global.tebakgame[chat] || {}

  if (command === "tebakgame" || command === "tgame") {
    if (room.answer) 
      return conn.reply(chat, "❌ Masih ada soal belum terjawab di chat ini.", m)

    // Ambil data dari JSON
    let src = JSON.parse(fs.readFileSync('./data/json/tebakgame.json', 'utf-8'))
    let json = src[Math.floor(Math.random() * src.length)]

    // Kirim gambar game
    await conn.sendMessage(
      chat,
      {
        image: { url: json.img },
        caption: `🎮 *TEBAK GAME*\n\n🖼️ Tebak nama game dari gambar di atas!\n⏳ Waktu: *60 detik*\n💡 Ketik jawaban langsung.\n🔑 Ketik *.whogame* untuk klu (Admin saja).`,
      },
      { quoted: m }
    )

    global.tebakgame[chat] = {
      answer: json.jawaban.toLowerCase(),
      player: m.sender,
      timer: setTimeout(() => {
        conn.reply(chat, `❌ Waktu habis!\nJawaban: *${json.jawaban}*`)
        delete global.tebakgame[chat]
      }, timeout),
    }
  }

  // Fitur clue (hanya admin/owner)
  if (command === "whogame") {
    if (!room.answer) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    if (!isAdmin && !isOwner)
      return conn.reply(chat, "❌ Klu hanya untuk admin/owner.", m)

    const ans = room.answer
    const words = ans.split(' ')
    let hint = words.map(word => {
      if (word.length <= 2) return word
      return word[0] + "_".repeat(word.length - 2) + word.slice(-1)
    }).join(' ')
    
    return conn.reply(chat, `🧩 *KLU:* ${hint}`, m)
  }

  // Fitur cek player
  if (command === "whoplayergame") {
    if (!room.player) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    return conn.reply(
      chat,
      `👤 Player: @${room.player.split("@")[0]}`,
      m,
      { mentions: [room.player] }
    )
  }

  // Fitur tambahan: hint langsung (tanpa admin)
  if (command === "hintgame") {
    if (!room.answer) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    
    const ans = room.answer
    const hint = ans[0] + "_".repeat(Math.max(ans.length - 2, 1)) + ans.slice(-1)
    return conn.reply(chat, `🧩 *HINT:* ${hint}`, m)
  }
}

handler.all = async function (m) {
  const room = global.tebakgame?.[m.chat]
  if (!room?.answer) return

  const text = (m.text || "").trim().toLowerCase()
  if (!text) return

  // Cek jawaban (case insensitive)
  if (text === room.answer) {
    clearTimeout(room.timer)
    await this.reply(m.chat, `✅ *Benar!* 🎉\nJawaban: *${room.answer}*`, m)
    delete global.tebakgame[m.chat]
  }
}

handler.help = ["tebakgame"]
handler.tags = ["game"]
handler.command = /^(tebakgame|tgame|whogame|whoplayergame|hintgame)$/i
handler.limit = 10

export default handler