import axios from 'axios'
import * as cheerio from 'cheerio'

// Function helper translate ke Bahasa Indonesia
const translateText = async (text) => {
  if (!text) return ''
  try {
    const chunks = []
    for (let i = 0; i < text.length; i += 1000) {
      chunks.push(text.slice(i, i + 1000))
    }
    const translatedChunks = []
    for (const chunk of chunks) {
      const tUrl = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=id&dt=t&q=' + encodeURIComponent(chunk)
      const { data } = await axios.get(tUrl)
      if (Array.isArray(data) && Array.isArray(data[0])) {
        translatedChunks.push(data[0].map((x) => x[0]).join(''))
      } else {
        translatedChunks.push(chunk)
      }
    }
    return translatedChunks.join('')
  } catch (err) {
    return text
  }
}

const scraper = async (query) => {
  if (!query) throw 'Masukkan kata kunci atau link pencarian!'

  let searchQuery = query.trim()
  if (searchQuery.includes('q=')) {
    const match = searchQuery.match(/q=([^&]+)/)
    if (match) searchQuery = decodeURIComponent(match[1])
  }

  // 1. Cari hasil di Temple of Zeus
  const searchUrl = 'https://templeofzeus.org/search.php?q=' + encodeURIComponent(searchQuery)
  const { data: searchHtml } = await axios.get(searchUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
  })

  const $search = cheerio.load(searchHtml)
  const results = []

  $search('.result-item').each((_, el) => {
    const title = $search(el).find('h3 a').text().trim()
    let href = $search(el).find('h3 a').attr('href')
    const snippet = $search(el).find('.result-snippet').text().trim()

    if (href) {
      if (!href.startsWith('http')) {
        href = 'https://templeofzeus.org' + (href.startsWith('/') ? '' : '/') + href
      }
      results.push({ title, href, snippet })
    }
  })

  if (!results.length) {
    throw `Tidak ada hasil pencarian ditemukan untuk: *${searchQuery}*`
  }

  // 2. Ambil 1 link artikel secara ACAK
  const randomItem = results[Math.floor(Math.random() * results.length)]

  // 3. KLIK & FETCH LINK ARTIKEL TERSEBUT (Buka Halaman Detail Asli)
  const { data: pageHtml } = await axios.get(randomItem.href, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }
  })

  const $page = cheerio.load(pageHtml)
  // Bersihkan tag non-konten
  $page('header, nav, footer, script, style, form, iframe, noscript, .top-pane, #nav-menu, .credits').remove()

  const titleEn = $page('h1').first().text().trim() || randomItem.title
  const paragraphTexts = []
  $page('p').each((_, el) => {
    const txt = $page(el).text().trim()
    if (txt && !txt.toLowerCase().includes('author:') && !txt.toLowerCase().includes('updated by:')) {
      paragraphTexts.push(txt)
    }
  })

  let articleText = paragraphTexts.join('\n\n')
  if (!articleText) {
    articleText = $page('body').text().replace(/\s+/g, ' ').trim()
  }

  // Batasi panjang respons pesan chat (~2500 karakter)
  if (articleText.length > 2500) {
    articleText = articleText.substring(0, 2500) + '...'
  }

  // 4. Terjemahkan judul & seluruh isi artikel ke Bahasa Indonesia
  const titleId = await translateText(titleEn)
  const articleId = await translateText(articleText)

  return `🏛️ *TEMPLE OF ZEUS - RANDOM ARTICLE RESULT*

🔍 *Query:* ${searchQuery}
🎲 *Total Hasil:* ${results.length} artikel (Terpilih 1 Secara Acak)

📌 *Judul Asli:* ${titleEn}
🇮🇩 *Judul (ID):* ${titleId}
🔗 *URL Detail:* ${randomItem.href}

📖 *Arti / Isi Artikel (Terjemahan Bahasa Indonesia):*
${articleId}`
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} blood\natau\n${usedPrefix + command} https://templeofzeus.org/search.php?q=blood`

  await conn.reply(m.chat, '⏳ *Sedang membuka link artikel acak & menerjemahkan isinya...*', m)

  const result = await scraper(text)

  await conn.reply(m.chat, result, m)
}

handler.help = ['satanist']
handler.tags = ['search']
handler.command = /^(satanist)$/i

handler.limit = 10
export default handler