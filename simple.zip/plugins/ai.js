import crypto from 'crypto'
class RizkyAI {
static endpoint = 'https://app.unlimitedai.chat/api/chat'
static prompt = `Kamu adalah Rizky AI yang baik hati, ramah, tidak sombong, suka memakai kaomoji, dan suka makan mie instan 🍜. Selalu perkenalkan dirimu sebagai Rizky AI. Jangan pernah mengaku sebagai UnlimitedAI atau model AI lain.\n\n`
static createId() {
return crypto.randomUUID()
}
static createMessage(text) {
const content = this.prompt + text
return {
role: 'user',
content,
parts: [{ type: 'text', text: content }]
}
}
static createPayload(text) {
return {
chatId: this.createId(),
messages: [this.createMessage(text)],
selectedChatModel: 'chat-model-reasoning',
selectedCharacter: null,
selectedStory: null,
deviceId: this.createId(),
locale: 'id'
}
}
static async request(text) {
const response = await fetch(this.endpoint, {
method: 'POST',
headers: {
'Content-Type': 'application/json',
'x-next-intl-locale': 'id'
},
body: JSON.stringify(this.createPayload(text))
})
return response.text()
}
static parse(response) {
let output = ''
for (const line of response.split('\n')) {
const value = line.trim()
if (!value) continue
try {
const data = JSON.parse(value)
if (data?.delta) output += data.delta
else if (data?.content) output += data.content
} catch {}
}
return output || 'Tidak ada respon.'
}
static async generate(text) {
return this.parse(await this.request(text))
}
}
const handler = async (m, { text, usedPrefix, command }) => {
if (!text) {
await m.react('✨')
return m.reply(`Masukkan teks.\n\nContoh:\n${usedPrefix}${command} lagi ngapain?`, null, { quoted: global.fvn })
}
try {
await m.react('✨')
const answer = await RizkyAI.generate(text)
await m.reply(answer, null, { quoted: global.fvn })
} catch (error) {
console.error(error)
await m.reply('Lagi error. Nanti aja.', null, { quoted: global.fvn })
}
}
handler.help = ['ai']
handler.tags = ['ai']
handler.command = /^ai$/i
handler.limit = 10
handler.register = true
export default handler