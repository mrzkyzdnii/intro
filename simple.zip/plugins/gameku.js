import crypto from 'node:crypto'
import { Buffer } from 'buffer'

const META_AI_BOT_JID = '867051314767696@bot'
const FORWARD_ORIGIN_META_AI = 4

const makeBotMessage = data => ({
botForwardedMessage:{
message:{
richResponseMessage:{
submessages:[],
messageType:1,
unifiedResponse:{
data:Buffer.from(JSON.stringify(data)).toString('base64')
},
contextInfo:{
mentionedJid:[],
groupMentions:[],
statusAttributions:[],
forwardingScore:1,
isForwarded:true,
forwardedAiBotMessageInfo:{
botJid:META_AI_BOT_JID
},
forwardOrigin:FORWARD_ORIGIN_META_AI
}
}
}
}
})

const buildHtmlUnifiedData = ({ html, responseId, trustedSources }) => ({
response_id:responseId || crypto.randomUUID(),
sections:[
{
view_model:{
primitive:{
__typename:'GenAIaeacdsnwHtmlPrimitive',
payload:html,
trusted_sources:trustedSources
},
__typename:'GenAISingleLayoutViewModel'
}
}
]
})

const editBotMessage = async (conn,jid,messageId,data) => {
return conn.relayMessage(jid,{
botForwardedMessage:{
message:{
protocolMessage:{
key:{
remoteJid:jid,
fromMe:true,
id:messageId
},
type:14,
editedMessage:makeBotMessage(data)
}
}
}
},{
messageId
})
}

const sendHtmlViaEditGlitch = async (conn,jid,{ html, trustedSources = ['nixel.dev','whatsapp.com'] },sendOpts = {}) => {
const responseId=crypto.randomUUID()
const shellHtml='<div style="padding:16px;font-family:system-ui;color:#fff;background:#121212;border-radius:12px">Menyiapkan…</div>'

const shellData=buildHtmlUnifiedData({
html:shellHtml,
responseId,
trustedSources
})

const finalData=buildHtmlUnifiedData({
html,
responseId,
trustedSources
})

const messageId=sendOpts.messageId || crypto.randomBytes(10).toString('hex')

await conn.relayMessage(
jid,
makeBotMessage(shellData),
{
messageId
}
)

await new Promise(resolve=>setTimeout(resolve,250))

try {
await editBotMessage(
conn,
jid,
messageId,
shellData
)
} catch(e) {
console.log('[GAMEKU EDIT SHELL]',e?.message||e)
}

await new Promise(resolve=>setTimeout(resolve,250))

await editBotMessage(
conn,
jid,
messageId,
finalData
)

return {
originalMessageId:messageId,
responseId
}
}

const tictactoeHtml = `<style>
*,:before,:after{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
body{margin:0;background:transparent;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#eee;touch-action:manipulation;cursor:pointer}
.wrap{width:100%;max-width:480px;margin:0 auto;padding:14px}
.card{background:rgba(255,255,255,.06);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1px solid rgba(255,255,255,.15);border-radius:18px;overflow:hidden;box-shadow:0 8px 32px rgba(0,0,0,.4);padding:18px}
.header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,.12);padding-bottom:12px;margin-bottom:14px}
.brand{font-size:11px;letter-spacing:1.5px;color:rgba(255,255,255,.45);font-weight:700}
.title{font-size:18px;font-weight:800;color:#fff}
.scores{display:flex;gap:10px}
.badge{padding:4px 10px;border-radius:8px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);font-size:10px;font-weight:700;color:#aaa}
.badge span{color:#fff}
.status{text-align:center;font-size:13px;font-weight:600;margin-bottom:14px;color:#00d2d3;min-height:20px;letter-spacing:.3px}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:16px}
.cell{aspect-ratio:1;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.12);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:38px;font-weight:900;cursor:pointer;transition:all .15s ease}
.cell:active{transform:scale(.95);background:rgba(255,255,255,.09)}
.cell.x{color:#ff6b6b;text-shadow:0 0 14px rgba(255,107,107,.5)}
.cell.o{color:#48dbfb;text-shadow:0 0 14px rgba(72,219,251,.5)}
.cell.win{background:rgba(0,210,211,.18);border-color:#00d2d3}
.controls{display:flex;gap:10px}
.btn{flex:1;padding:12px;border:none;border-radius:12px;background:#fff;color:#0c0d12;font-weight:800;font-size:12px;cursor:pointer;letter-spacing:.5px;transition:transform .1s}
.btn:active{transform:scale(.97)}
</style>
<body>
<div class="wrap">
<div class="card">
<div class="header">
<div>
<div class="brand">DANS ARCADE</div>
<div class="title">Tic Tac Toe</div>
</div>
<div class="scores">
<div class="badge">KAMU (X): <span id="pScore">0</span></div>
<div class="badge">BOT (O): <span id="bScore">0</span></div>
</div>
</div>
<div class="status" id="status">GILIRANMU (X)</div>
<div class="grid" id="board">
<div class="cell" data-i="0"></div>
<div class="cell" data-i="1"></div>
<div class="cell" data-i="2"></div>
<div class="cell" data-i="3"></div>
<div class="cell" data-i="4"></div>
<div class="cell" data-i="5"></div>
<div class="cell" data-i="6"></div>
<div class="cell" data-i="7"></div>
<div class="cell" data-i="8"></div>
</div>
<div class="controls">
<button class="btn" id="resetBtn" type="button">MAIN LAGI</button>
</div>
</div>
</div>
<script>
(function(){
let board=Array(9).fill(null)
let pWins=0
let bWins=0
let isGameOver=false
let playerTurn=true

const cells=document.querySelectorAll('.cell')
const statusEl=document.getElementById('status')
const pScoreEl=document.getElementById('pScore')
const bScoreEl=document.getElementById('bScore')
const resetBtn=document.getElementById('resetBtn')
const aCtx=new(window.AudioContext||window.webkitAudioContext)()

function sfx(type){
if(aCtx.state==='suspended')aCtx.resume()
const osc=aCtx.createOscillator()
const gain=aCtx.createGain()
const t=aCtx.currentTime
osc.connect(gain)
gain.connect(aCtx.destination)

if(type==='tap'){
osc.type='sine'
osc.frequency.setValueAtTime(450,t)
osc.frequency.exponentialRampToValueAtTime(800,t+.05)
gain.gain.setValueAtTime(.08,t)
gain.gain.exponentialRampToValueAtTime(.001,t+.05)
osc.start(t)
osc.stop(t+.05)
}else if(type==='win'){
osc.type='triangle'
osc.frequency.setValueAtTime(523.25,t)
osc.frequency.setValueAtTime(659.25,t+.08)
osc.frequency.setValueAtTime(783.99,t+.16)
gain.gain.setValueAtTime(.12,t)
gain.gain.linearRampToValueAtTime(0,t+.3)
osc.start(t)
osc.stop(t+.3)
}else if(type==='lose'){
osc.type='sawtooth'
osc.frequency.setValueAtTime(300,t)
osc.frequency.exponentialRampToValueAtTime(100,t+.25)
gain.gain.setValueAtTime(.1,t)
gain.gain.exponentialRampToValueAtTime(.001,t+.25)
osc.start(t)
osc.stop(t+.25)
}
}

const winLines=[
[0,1,2],
[3,4,5],
[6,7,8],
[0,3,6],
[1,4,7],
[2,5,8],
[0,4,8],
[2,4,6]
]

function checkWinner(b){
for(const[x,y,z]of winLines){
if(b[x]&&b[x]===b[y]&&b[x]===b[z]){
return{winner:b[x],combo:[x,y,z]}
}
}

if(b.every(c=>c!==null)){
return{winner:'tie',combo:[]}
}

return null
}

function render(){
cells.forEach((cell,i)=>{
cell.textContent=board[i]||''
cell.className='cell'+(board[i]?' '+board[i].toLowerCase():'')
})
}

function handleMove(idx){
if(board[idx]||isGameOver||!playerTurn)return

board[idx]='X'
sfx('tap')
render()

const res=checkWinner(board)

if(res){
finishGame(res)
return
}

playerTurn=false
statusEl.textContent='BOT SEDANG BERPIKIR...'
statusEl.style.color='#fbc531'

setTimeout(botMove,380)
}

function botMove(){
if(isGameOver)return

for(const[x,y,z]of winLines){
const combo=[x,y,z]
const oCount=combo.filter(i=>board[i]==='O').length
const empty=combo.find(i=>board[i]===null)

if(oCount===2&&empty!==undefined){
applyBot(empty)
return
}
}

for(const[x,y,z]of winLines){
const combo=[x,y,z]
const xCount=combo.filter(i=>board[i]==='X').length
const empty=combo.find(i=>board[i]===null)

if(xCount===2&&empty!==undefined){
applyBot(empty)
return
}
}

if(board[4]===null){
applyBot(4)
return
}

const corners=[0,2,6,8].filter(i=>board[i]===null)

if(corners.length){
applyBot(corners[Math.floor(Math.random()*corners.length)])
return
}

const available=board.map((v,i)=>v===null?i:null).filter(v=>v!==null)

if(available.length){
applyBot(available[Math.floor(Math.random()*available.length)])
}
}

function applyBot(i){
board[i]='O'
sfx('tap')
render()

const res=checkWinner(board)

if(res){
finishGame(res)
return
}

playerTurn=true
statusEl.textContent='GILIRANMU (X)'
statusEl.style.color='#00d2d3'
}

function finishGame(res){
isGameOver=true

if(res.winner==='X'){
pWins++
pScoreEl.textContent=pWins
statusEl.textContent='KAMU MENANG! 🎉'
statusEl.style.color='#2ed573'
sfx('win')

res.combo.forEach(i=>{
cells[i].classList.add('win')
})

}else if(res.winner==='O'){
bWins++
bScoreEl.textContent=bWins
statusEl.textContent='BOT MENANG! 🤖'
statusEl.style.color='#ff4757'
sfx('lose')

res.combo.forEach(i=>{
cells[i].classList.add('win')
})

}else{
statusEl.textContent='PERMAINAN SERI! 🤝'
statusEl.style.color='#70a1ff'
sfx('tap')
}
}

function reset(){
board=Array(9).fill(null)
isGameOver=false
playerTurn=true
statusEl.textContent='GILIRANMU (X)'
statusEl.style.color='#00d2d3'
render()
}

cells.forEach(c=>{
c.addEventListener('pointerdown',e=>{
e.preventDefault()
handleMove(parseInt(c.dataset.i,10))
})
})

resetBtn.addEventListener('pointerdown',e=>{
e.preventDefault()
reset()
})

reset()
})()
</script>
</body>`

const handler = async (m,{ conn }) => {
if(m.react) await m.react('⏳')

try {
await sendHtmlViaEditGlitch(conn,m.chat,{
html:tictactoeHtml,
trustedSources:['nixel.dev','whatsapp.com']
})

if(m.react) await m.react('✅')
} catch(e) {
console.error('[GAMEKU ERROR]',e)

if(m.react) await m.react('❌')

await conn.reply(
m.chat,
`❌ Gagal membuka game.\n\n${e.message||e}`,
m
)
}
}

handler.help=['gameku']
handler.tags=['game']
handler.command=/^gameku$/i

export default handler