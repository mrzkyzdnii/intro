import { canLevelUp, xpRange } from '../lib/levelling.js'

const formatNumber = value =>
    Math.max(0, Number(value) || 0)
        .toLocaleString('id-ID')

const handler = async (m, { conn }) => {
    const who = m.sender
    const user = global.db?.data?.users?.[who]

    if (!user) {
        throw 'Data user kamu belum tersedia di database.'
    }

    /*
     * Normalisasi wajib dilakukan sebelum memanggil canLevelUp.
     * Data database kadang tersimpan sebagai string atau kosong.
     */
    const currentMultiplier =
        Number.isFinite(Number(global.multiplier)) &&
        Number(global.multiplier) > 0
            ? Number(global.multiplier)
            : 1

    user.level = Math.max(
        0,
        Math.floor(Number(user.level) || 0)
    )

    user.exp = Math.max(
        0,
        Math.floor(Number(user.exp) || 0)
    )

    const beforeLevel = user.level

    /*
     * Jangan hanya menaikkan satu level. Dengan while,
     * EXP besar dapat langsung menaikkan beberapa level.
     */
    while (
        canLevelUp(
            user.level,
            user.exp,
            currentMultiplier
        )
    ) {
        user.level += 1
    }

    const afterLevel = user.level

    if (beforeLevel !== afterLevel) {
        const levelCount = afterLevel - beforeLevel

        return conn.reply(
            m.chat,
            `╭━━〔 ✦ LEVEL UP 〕━━╮
┃
┃  ✨ Selamat, @${who.split('@')[0]}!
┃
┃  🎖️ Level
┃  └─ ${beforeLevel} ➜ *${afterLevel}*
┃
┃  🚀 Naik
┃  └─ +${levelCount} Level
┃
┃  💫 EXP
┃  └─ ${formatNumber(user.exp)} EXP
┃
╰━━━━━━━━━━━━━━━━━━╯`,
            m,
            {
                mentions: [who]
            }
        )
    }

    /*
     * Ambil range setelah level dinormalisasi agar progress
     * selalu mengikuti level yang sedang aktif.
     */
    const { min, max, xp } = xpRange(
        user.level,
        currentMultiplier
    )

    const currentExp = Math.max(
        0,
        user.exp - min
    )

    const neededExp = Math.max(
        0,
        max - user.exp
    )

    const progressExp = Math.max(
        0,
        xp
    )

    return conn.reply(
        m.chat,
        `╭━━〔 ✦ LEVEL PROGRESS 〕━━╮
┃
┃  👤 @${who.split('@')[0]}
┃
┃  🎖️ Level
┃  └─ *${user.level}*
┃
┃  💫 EXP Level
┃  └─ ${formatNumber(currentExp)} / ${formatNumber(progressExp)}
┃
┃  📊 Progress
┃  └─ ${formatNumber(neededExp)} EXP lagi
┃
┃  ${neededExp > 0
        ? '🔥 Terus aktif untuk naik level!'
        : '✨ Siap untuk naik level!'}
┃
╰━━━━━━━━━━━━━━━━━━╯`,
        m,
        {
            mentions: [who]
        }
    )
}

handler.help = ['levelup']
handler.tags = ['xp']
handler.command = /^levelup$/i
handler.limit = 10

export default handler