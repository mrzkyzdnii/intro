import { createCanvas } from '@napi-rs/canvas'

const rupiah = new Intl.NumberFormat('id-ID', {
  style: 'currency',
  currency: 'IDR',
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
})

const roundedRect = (ctx, x, y, w, h, r) => {
  const radius = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.arcTo(x + w, y, x + w, y + h, radius)
  ctx.arcTo(x + w, y + h, x, y + h, radius)
  ctx.arcTo(x, y + h, x, y, radius)
  ctx.arcTo(x, y, x + w, y, radius)
  ctx.closePath()
}

const fitText = (ctx, text, maxWidth, startSize, weight = '700') => {
  let size = startSize
  while (size > 20) {
    ctx.font = `${weight} ${size}px Sans`
    if (ctx.measureText(text).width <= maxWidth) return size
    size -= 2
  }
  return size
}

const drawWalletIcon = (ctx, x, y, scale = 1) => {
  ctx.save()
  ctx.translate(x, y)
  ctx.scale(scale, scale)
  ctx.strokeStyle = '#e9e7ff'
  ctx.fillStyle = 'rgba(255,255,255,0.13)'
  ctx.lineWidth = 4

  roundedRect(ctx, 0, 10, 88, 58, 16)
  ctx.fill()
  ctx.stroke()

  ctx.beginPath()
  ctx.moveTo(16, 10)
  ctx.lineTo(16, 2)
  ctx.quadraticCurveTo(16, -5, 25, -5)
  ctx.lineTo(75, -5)
  ctx.quadraticCurveTo(84, -5, 84, 4)
  ctx.lineTo(84, 10)
  ctx.stroke()

  roundedRect(ctx, 52, 27, 42, 28, 10)
  ctx.fillStyle = '#ffffff'
  ctx.fill()
  ctx.strokeStyle = 'rgba(94, 71, 255, 0.55)'
  ctx.stroke()
  ctx.fillStyle = '#6758e8'
  ctx.beginPath()
  ctx.arc(69, 41, 4, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()
}

const drawMiniQr = (ctx, x, y, size) => {
  const pattern = [
    '111101001111',
    '100101101001',
    '101101001101',
    '111101111111',
    '000010100010',
    '110111011010',
    '001001110111',
    '111110010100',
    '101011111011',
    '100010001001',
    '111011101111',
    '001101010101'
  ]
  const cell = size / pattern.length
  ctx.save()
  ctx.fillStyle = '#ffffff'
  roundedRect(ctx, x - 10, y - 10, size + 20, size + 20, 12)
  ctx.fill()
  ctx.fillStyle = '#211f4e'
  pattern.forEach((row, rowIndex) => {
    [...row].forEach((value, colIndex) => {
      if (value === '1') ctx.fillRect(x + colIndex * cell, y + rowIndex * cell, cell + 0.5, cell + 0.5)
    })
  })
  ctx.restore()
}

let handler = async (m, { conn }) => {
  let who

  if (m.isGroup) {
    who = m.mentionedJid?.[0] || m.sender
  } else {
    who = m.sender
  }

  const user = global.db.data.users[who]

  if (!user) {
    return m.reply('Pengguna tidak ditemukan di database.')
  }

  const name = user.registered ? user.name : await conn.getName(who)
  const balance = Number(user.money ?? user.balance ?? user.saldo ?? 0)
  const safeBalance = Number.isFinite(balance) ? balance : 0
  const balanceText = rupiah.format(safeBalance)
  const shortName = name.length > 22 ? `${name.slice(0, 21)}…` : name
  const userTag = `@${who.split('@')[0]}`

  const width = 1200
  const height = 720
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  // Background: dark fintech canvas dengan aksen violet dan cyan.
  const background = ctx.createLinearGradient(0, 0, width, height)
  background.addColorStop(0, '#0c0b1f')
  background.addColorStop(0.52, '#161438')
  background.addColorStop(1, '#082d42')
  ctx.fillStyle = background
  ctx.fillRect(0, 0, width, height)

  const glow = (x, y, radius, color) => {
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius)
    gradient.addColorStop(0, color)
    gradient.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)
  }

  glow(1060, 90, 420, 'rgba(107, 85, 255, 0.32)')
  glow(70, 700, 430, 'rgba(0, 213, 214, 0.18)')

  // Grid halus memberi kesan dashboard finansial digital.
  ctx.strokeStyle = 'rgba(255,255,255,0.045)'
  ctx.lineWidth = 1
  for (let x = 0; x <= width; x += 60) {
    ctx.beginPath()
    ctx.moveTo(x, 0)
    ctx.lineTo(x, height)
    ctx.stroke()
  }
  for (let y = 0; y <= height; y += 60) {
    ctx.beginPath()
    ctx.moveTo(0, y)
    ctx.lineTo(width, y)
    ctx.stroke()
  }

  const cardX = 60
  const cardY = 52
  const cardW = 1080
  const cardH = 616

  // Bayangan kartu.
  ctx.save()
  ctx.shadowColor = 'rgba(0,0,0,0.48)'
  ctx.shadowBlur = 44
  ctx.shadowOffsetY = 22
  roundedRect(ctx, cardX, cardY, cardW, cardH, 40)
  const cardGradient = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH)
  cardGradient.addColorStop(0, '#30246d')
  cardGradient.addColorStop(0.48, '#4b3eb1')
  cardGradient.addColorStop(1, '#087f99')
  ctx.fillStyle = cardGradient
  ctx.fill()
  ctx.restore()

  // Lapisan glossy dan bentuk abstrak.
  ctx.save()
  roundedRect(ctx, cardX, cardY, cardW, cardH, 40)
  ctx.clip()
  const shine = ctx.createLinearGradient(100, 30, 980, 660)
  shine.addColorStop(0, 'rgba(255,255,255,0.18)')
  shine.addColorStop(0.3, 'rgba(255,255,255,0.02)')
  shine.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = shine
  ctx.fillRect(cardX, cardY, cardW, cardH)

  ctx.fillStyle = 'rgba(255,255,255,0.08)'
  ctx.beginPath()
  ctx.arc(990, 82, 250, 0, Math.PI * 2)
  ctx.fill()
  ctx.beginPath()
  ctx.arc(1080, 590, 270, 0, Math.PI * 2)
  ctx.fill()

  ctx.strokeStyle = 'rgba(255,255,255,0.10)'
  ctx.lineWidth = 3
  for (let i = -250; i < 1250; i += 92) {
    ctx.beginPath()
    ctx.moveTo(i, 650)
    ctx.lineTo(i + 420, 50)
    ctx.stroke()
  }
  ctx.restore()

  // Header bergaya aplikasi dompet digital.
  ctx.fillStyle = '#ffffff'
  ctx.font = '800 30px Sans'
  ctx.fillText('DOMPETKU', 118, 128)
  ctx.fillStyle = 'rgba(255,255,255,0.66)'
  ctx.font = '500 18px Sans'
  ctx.fillText('DIGITAL WALLET • PERSONAL FINANCE', 120, 157)
  drawWalletIcon(ctx, 1010, 98, 0.8)

  // Badge status akun.
  roundedRect(ctx, 120, 202, 168, 42, 21)
  ctx.fillStyle = 'rgba(255,255,255,0.13)'
  ctx.fill()
  ctx.fillStyle = '#96ffe1'
  ctx.beginPath()
  ctx.arc(145, 223, 7, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillStyle = '#e9fff9'
  ctx.font = '700 17px Sans'
  ctx.fillText('AKUN AKTIF', 163, 229)

  // Saldo menjadi fokus utama kartu.
  ctx.fillStyle = 'rgba(240,238,255,0.73)'
  ctx.font = '500 23px Sans'
  ctx.fillText('SALDO TERSEDIA', 120, 294)

  const balanceSize = fitText(ctx, balanceText, 760, 82, '800')
  ctx.font = `800 ${balanceSize}px Sans`
  ctx.fillStyle = '#ffffff'
  ctx.fillText(balanceText, 115, 390)

  ctx.fillStyle = 'rgba(255,255,255,0.57)'
  ctx.font = '500 16px Sans'
  ctx.fillText('Saldo dapat digunakan untuk transaksi digital', 122, 423)

  // Panel informasi pemilik.
  ctx.strokeStyle = 'rgba(255,255,255,0.20)'
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(120, 458)
  ctx.lineTo(820, 458)
  ctx.stroke()

  ctx.fillStyle = 'rgba(240,238,255,0.62)'
  ctx.font = '500 17px Sans'
  ctx.fillText('PEMILIK DOMPET', 120, 495)
  ctx.fillStyle = '#ffffff'
  ctx.font = '700 27px Sans'
  ctx.fillText(shortName, 120, 532)

  ctx.fillStyle = 'rgba(240,238,255,0.62)'
  ctx.font = '500 17px Sans'
  ctx.fillText('ID PENGGUNA', 505, 495)
  ctx.fillStyle = '#ffffff'
  ctx.font = '600 22px Sans'
  ctx.fillText(userTag, 505, 532)

  // QR dekoratif sebagai penanda identitas digital.
  drawMiniQr(ctx, 930, 442, 112)
  ctx.fillStyle = 'rgba(255,255,255,0.7)'
  ctx.font = '500 15px Sans'
  ctx.textAlign = 'center'
  ctx.fillText('SCAN TO PAY', 986, 592)
  ctx.textAlign = 'left'

  // Footer dengan keamanan dan branding.
  ctx.fillStyle = 'rgba(255,255,255,0.60)'
  ctx.font = '600 16px Sans'
  ctx.fillText('TERLINDUNGI • CEPAT • PRAKTIS', 120, 620)
  ctx.fillStyle = '#a7fff0'
  ctx.font = '800 16px Sans'
  ctx.textAlign = 'right'
  ctx.fillText('MRZKYZDNI', 1075, 640)
  ctx.textAlign = 'left'

  const buffer = canvas.toBuffer('image/png')

  return conn.sendMessage(m.chat, {
    image: buffer,
    caption: `Dompet digital milik ${name}\nSaldo tersedia: ${balanceText}`,
    mentions: [who]
  }, {
    quoted: m
  })
}

handler.help = ['money']
handler.tags = ['xp']
handler.command = /^(money|saldo)$/i
handler.register = false

export default handler