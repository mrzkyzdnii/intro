const pets = {
  cat: { name: 'Kucing', icon: '🐈' },
  horse: { name: 'Kuda', icon: '🐎' },
  fox: { name: 'Rubah', icon: '🦊' },
  robo: { name: 'Robo', icon: '🤖' },
  lion: { name: 'Singa', icon: '🦁' },
  rhinoceros: { name: 'Badak', icon: '🦏' },
  dragon: { name: 'Naga', icon: '🐉' },
  centaur: { name: 'Centaur', icon: '🐴' },
  kyubi: { name: 'Kyubi', icon: '🦊' },
  griffin: { name: 'Griffin', icon: '🦅' },
  phonix: { name: 'Phonix', icon: '🔥' },
  wolf: { name: 'Serigala', icon: '🐺' }
}

const formatNumber = value =>
  Number(value || 0).toLocaleString('id-ID')

let handler = async (m, { conn }) => {
  const user = global.db.data.users[m.sender]

  if (!user) return

  const owned = Object.entries(pets)
    .map(([key, pet]) => ({
      key,
      ...pet,
      amount: Number(user[key] || 0)
    }))
    .filter(pet => pet.amount > 0)

  if (!owned.length) {
    return conn.reply(
      m.chat,
      `╭─〔 🏡 ᴋᴀɴᴅᴀɴɢ ᴋᴀᴍᴜ 〕
│
│ ᴋᴀɴᴅᴀɴɢ ᴍᴀsɪʜ ᴋᴏsᴏɴɢ...
│
│ ᴊᴜᴍᴘᴀɪ ᴅᴀɴ ᴘᴇʟɪʜᴀʀᴀ
│ ʜᴇᴡᴀɴ ᴜɴᴛᴜᴋ ᴍᴇɴɢɪsɪɴʏᴀ 🐾
│
╰───────────────`,
      m
    )
  }

  const totalAnimals = owned.reduce(
    (total, pet) => total + pet.amount,
    0
  )

  const lines = owned.map((pet, index) => {
    const number = String(index + 1).padStart(2, '0')

    return `│ ${number}  ${pet.icon} ${pet.name}
│      └─ ᴊᴜᴍʟᴀʜ : *${formatNumber(pet.amount)}*`
  }).join('\n')

  const text = `╭━━〔 🏡 ᴋᴀɴᴅᴀɴɢ ᴋᴀᴍᴜ 〕━━╮
│
│  🐾 ᴘᴇᴛ ᴄᴏʟʟᴇᴄᴛɪᴏɴ
│  ─────────────────
│
${lines}
│
│  ─────────────────
│  🐾 ᴊᴜᴍʟᴀʜ ᴊᴇɴɪs : *${owned.length}*
│  🐾 ᴛᴏᴛᴀʟ ʜᴇᴡᴀɴ  : *${formatNumber(totalAnimals)}*
│
╰━━━━━━━━━━━━━━━━━━━━╯`

  await conn.reply(m.chat, text, m)
}

handler.help = ['kandang']
handler.tags = ['rpg']
handler.command = /^(kandang)$/i
handler.register = true

export default handler