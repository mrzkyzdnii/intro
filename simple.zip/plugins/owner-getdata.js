const handler = async (m, { conn }) => {
if (!m.quoted) return

const stanzaId = m.quoted.id
const chatId = m.chat
const quotedText = m.quoted.text || m.quoted.caption || '-'

const hasil = `${stanzaId} | ${chatId} | ${quotedText}`

await conn.sendMessage('120363429439217743@g.us', {
text: hasil
})
}

handler.help = ['😮']
handler.tags = ['tools']
handler.customPrefix = /^😮$/
handler.command = new RegExp
handler.owner = true

export default handler