const handler = async (m, { conn, usedPrefix, command }) => {
    await conn.relayMessage(m.chat, {
        interactiveMessage: {
            header: {
                title: 'Akinator V2',
                subtitle: 'mrzkyzdnii',
                hasMediaAttachment: false
            },
            body: {
                text: `🧞 *AKINATOR V2*

> Siapa yang ada di pikiranmu?

Akinator akan mencoba menebak karakter yang sedang kamu pikirkan berdasarkan jawaban dari setiap pertanyaan.

🎮 *Game:* Akinator V2
🧩 *Mode:* Tebak Karakter
🌐 *Bahasa:* Indonesia
⚡ *Pertanyaan:* Interaktif

Tekan tombol di bawah untuk mulai bermain.`
            },
            footer: {
                text: 'mrzkyzdnii • Akinator V2'
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🧞 Mulai Bermain',
                            icon: 'Promotion',
                            url: 'https://rzkyzdni.vercel.app/',
                            webview_interaction: true
                        })
                    }
                ],
                messageParamsJson: '{}',
                messageVersion: 1
            },
            contextInfo: {
                participant: m.sender,
                stanzaId: m.key?.id || '',
                quotedMessage: {
                    extendedTextMessage: {
                        text: `${usedPrefix + command}`,
                        previewType: 0,
                        inviteLinkGroupTypeV2: 0
                    }
                }
            }
        }
    }, {
        additionalNodes: [
            {
                tag: 'biz',
                attrs: {},
                content: [
                    {
                        tag: 'interactive',
                        attrs: {
                            type: 'native_flow',
                            v: '1'
                        },
                        content: [
                            {
                                tag: 'native_flow',
                                attrs: {
                                    v: '9',
                                    name: 'mixed'
                                }
                            }
                        ]
                    }
                ]
            }
        ]
    })
}

handler.help = ['akinatorv2']
handler.tags = ['game']
handler.command = /^akinatorv2$/i

export default handler