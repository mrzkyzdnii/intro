import { jidNormalizedUser } from '@mrzkyzdnii/baileys'

let handler = async (m, { conn }) => {
    const users = global.db?.data?.users

    if (!users) {
        throw '❌ Database users tidak ditemukan.'
    }

    const isPN = jid =>
        typeof jid === 'string' &&
        jid.endsWith('@s.whatsapp.net')

    const isLid = jid =>
        typeof jid === 'string' &&
        jid.endsWith('@lid')

    // ==========================================
    // CARI LID DARI PN VIA SIGNAL REPOSITORY
    // ==========================================

    const getLidFromPN = async (pn) => {
        try {
            const mapping = conn?.signalRepository?.lidMapping
            if (mapping?.getLIDForPN) {
                const lid = await mapping.getLIDForPN(pn)
                if (lid && isLid(lid)) {
                    return lid
                }
            }
        } catch {}

        // Coba tanpa @s.whatsapp.net
        try {
            const mapping = conn?.signalRepository?.lidMapping
            if (mapping?.getLIDForPN) {
                const lid = await mapping.getLIDForPN(
                    pn.replace('@s.whatsapp.net', '')
                )
                if (lid && isLid(lid)) {
                    return lid
                }
            }
        } catch {}

        return null
    }

    // ==========================================
    // AMBIL SEMUA PN
    // ==========================================

    const pnList = Object.keys(users).filter(isPN)

    if (!pnList.length) {
        return m.reply(
            `╭─〔 🛠️ FIX DATABASE 〕\n` +
            `│\n` +
            `│ ✅ Tidak ada key @s.whatsapp.net\n` +
            `│ Database sudah menggunakan @lid\n` +
            `╰───────────────`
        )
    }

    let scanned = 0
    let converted = 0
    let skipped = 0
    let conflict = 0
    const results = []

    // ==========================================
    // PROCESS
    // ==========================================

    for (const originalPN of pnList) {
        scanned++
        const pn = originalPN

        // Cari LID dari signal repository
        const lid = await getLidFromPN(pn)

        // Jika tidak ditemukan LID, skip
        if (!lid || !isLid(lid)) {
            skipped++
            results.push({
                status: 'skip',
                pn: pn.replace('@s.whatsapp.net', '')
            })
            continue
        }

        // ==========================================
        // CEK APAKAH LID SUDAH ADA DI DATABASE
        // ==========================================

        if (users[lid]) {
            // LID sudah ada, jangan timpa!
            conflict++
            results.push({
                status: 'conflict',
                pn: pn.replace('@s.whatsapp.net', ''),
                lid: lid.replace('@lid', '')
            })
            continue
        }

        // ==========================================
        // RENAME KEY: PN -> LID
        // ==========================================

        // Pindahkan data ke LID
        users[lid] = users[pn]

        // Hapus PN
        delete users[pn]

        converted++
        results.push({
            status: 'converted',
            pn: pn.replace('@s.whatsapp.net', ''),
            lid: lid.replace('@lid', '')
        })
    }

    // ==========================================
    // SAVE DATABASE
    // ==========================================

    try {
        if (typeof global.db.write === 'function') {
            await global.db.write()
        }
    } catch (error) {
        throw `❌ Gagal menyimpan database.\n\nError: ${error?.message || error}`
    }

    // ==========================================
    // RESULT
    // ==========================================

    let caption =
        `╭─〔 🛠️ FIX DATABASE 〕\n` +
        `│\n` +
        `│ 🔍 Scan PN       : ${scanned}\n` +
        `│ 🔄 Diubah ke LID : ${converted}\n` +
        `│ ⚠️ Konflik       : ${conflict}\n` +
        `│ ⏭️ Skip          : ${skipped}\n` +
        `│\n`

    const success = results.filter(x => x.status === 'converted')

    if (success.length) {
        caption += `│ ── HASIL ──\n`
        success.forEach((item, index) => {
            caption +=
                `│ 🔄 ${index + 1}. ` +
                `${item.pn}\n` +
                `│    ↓\n` +
                `│    ${item.lid}\n`
        })
        caption += `│\n`
    }

    if (conflict > 0) {
        caption +=
            `│ ⚠️ ${conflict} data tidak diubah\n` +
            `│ karena key @lid sudah ada.\n` +
            `│\n`
    }

    if (skipped > 0) {
        caption +=
            `│ ⏭️ ${skipped} data tidak ditemukan LID-nya\n` +
            `│\n`
    }

    caption +=
        `╰───────────────\n` +
        `💾 Database berhasil disimpan.\n` +
        `📊 Total user: ${Object.keys(users).length}`

    await conn.reply(m.chat, caption, m)
}

handler.help = ['fixdb']
handler.tags = ['owner']
handler.command = /^fixdb$/i
handler.owner = true

export default handler