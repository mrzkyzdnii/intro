import { generateWAMessageFromContent, proto } from '@mrzkyzdnii/baileys'

const handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya bisa dipakai di grup.')
  try {
    await m.react('🆔')
    const id = m.chat
    const teks = `╭─〔 𝐆𝐑𝐎𝐔𝐏 𝐈𝐍𝐅𝐎 〕
│
│  ◈ 𝐆𝐑𝐎𝐔𝐏 𝐈𝐃
│  ${id}
│
│  ◈ 𝐒𝐓𝐀𝐓𝐔𝐒
│  ● Active
│
╰──────────────────
      𝐈𝐃 𝐆𝐑𝐎𝐔𝐏 𝐒𝐘𝐒𝐓𝐄𝐌`

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({
              title: '𝐆𝐑𝐎𝐔𝐏 𝐈𝐃',
              subtitle: 'Group identification system',
              hasMediaAttachment: false
            }),
            body: proto.Message.InteractiveMessage.Body.create({
              text: teks
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: 'ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴍʀᴢᴋʏᴢᴅɴɪɪ'
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: '⧉  Copy Group ID',
                    copy_code: id
                  })
                }
              ]
            })
          })
        }
      }
    }, {})
    await conn.relayMessage(m.chat, msg.message, {
      messageId: msg.key.id
    })
  } catch (e) {
    console.log(e)
    m.reply('❌ Gagal mengambil ID grup.')
  }
}

handler.help = ['cekidgc']
handler.tags = ['tools']
handler.command = /^cekid(gc|grup)?$/i
handler.owner = true
handler.limit = 10

export default handler