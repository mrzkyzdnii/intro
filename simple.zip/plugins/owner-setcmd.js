let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
  global.db.data.sticker = global.db.data.sticker || {}

  switch (command) {
    case 'setcmd':
    case 'addcmd':
    case 'cmdset': {
      if (!m.quoted) throw `Reply media (stiker, gambar, video, audio, dokumen) yang ingin diset command!\n\nContoh:\n*${usedPrefix + command} .menu*`
      if (!text) throw `Masukkan command yang ingin dijalankan saat media ini dikirim!\n\nContoh:\n*${usedPrefix + command} .menu*`

      const qMsg = m.quoted.msg || m.quoted.mediaMessage?.[m.quoted.mediaType] || m.quoted
      const fileSha256 = qMsg?.fileSha256 || m.quoted.fileSha256

      if (!fileSha256) throw 'Media yang di-reply tidak memiliki hash/SHA256 valid. Pastikan me-reply stiker, gambar, video, audio, atau dokumen.'

      const hashKey = Buffer.isBuffer(fileSha256)
        ? fileSha256.toString('base64')
        : Buffer.from(fileSha256).toString('base64')

      const mediaType = m.quoted.mediaType || m.quoted.mtype || 'media'

      global.db.data.sticker[hashKey] = {
        text: text.trim(),
        mentionedJid: m.mentionedJid || [],
        creator: m.sender,
        at: +new Date(),
        mediaType: mediaType.replace(/message/i, '')
      }

      m.reply(`✅ *Berhasil Menyimpan Media Command!*\n\n• *Command:* \`${text.trim()}\`\n• *Tipe Media:* ${mediaType.replace(/message/i, '')}\n• *Hash:* \`${hashKey.slice(0, 16)}...\``)
      break
    }

    case 'delcmd':
    case 'deletecmd': {
      let hashKey = null
      const qMsg = m.quoted?.msg || m.quoted?.mediaMessage?.[m.quoted?.mediaType] || m.quoted
      const fileSha256 = qMsg?.fileSha256 || m.quoted?.fileSha256

      if (fileSha256) {
        hashKey = Buffer.isBuffer(fileSha256)
          ? fileSha256.toString('base64')
          : Buffer.from(fileSha256).toString('base64')
      } else if (text) {
        let cleanText = text.trim()
        if (cleanText in global.db.data.sticker) {
          hashKey = cleanText
        } else {
          for (let key in global.db.data.sticker) {
            if (global.db.data.sticker[key]?.text?.toLowerCase() === cleanText.toLowerCase()) {
              hashKey = key
              break
            }
          }
        }
      } else {
        throw `Reply media yang ingin dihapus command-nya, atau masukkan command/hash yang ingin dihapus!\n\nContoh:\n*${usedPrefix + command} .menu*`
      }

      if (!hashKey || !(hashKey in global.db.data.sticker)) {
        throw '❌ Media command tidak ditemukan dalam database.'
      }

      const deletedCmd = global.db.data.sticker[hashKey]?.text || ''
      delete global.db.data.sticker[hashKey]

      m.reply(`✅ *Berhasil Menghapus Media Command!*\n\n• *Command:* \`${deletedCmd}\``)
      break
    }

    case 'listcmd':
    case 'listcommand': {
      const keys = Object.keys(global.db.data.sticker || {})
      if (!keys.length) throw 'Belum ada media command yang tersimpan.'

      let caption = `📋 *DAFTAR MEDIA COMMAND*\n`
      caption += `Total: *${keys.length}* command\n\n`

      let i = 1
      for (let key of keys) {
        const item = global.db.data.sticker[key]
        caption += `${i++}. *Command:* \`${item.text}\`\n`
        caption += `   • *Tipe:* ${item.mediaType || 'media'}\n`
        caption += `   • *Hash:* \`${key.slice(0, 16)}...\`\n\n`
      }

      m.reply(caption.trim())
      break
    }
  }
}

handler.help = ['setcmd', 'delcmd', 'listcmd']
handler.tags = ['owner']
handler.command = /^(setcmd|addcmd|cmdset|delcmd|deletecmd|listcmd|listcommand)$/i
handler.owner = true

export default handler
