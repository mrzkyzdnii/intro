import axios from 'axios'

const scraper = async (query) => {
    try {
        const headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9'
        }

        // Ambil halaman DuckDuckGo untuk mendapatkan VQD
        const initRes = await axios.get(
            `https://duckduckgo.com/?q=${encodeURIComponent(query)}&iax=images&ia=images`,
            {
                headers: {
                    ...headers,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                }
            }
        )

        const vqdMatch =
            initRes.data.match(/vqd=["']([^"']+)["']/i) ||
            initRes.data.match(/vqd=([\d-]+)/i)

        if (!vqdMatch) {
            throw new Error('Gagal mendapatkan token pencarian')
        }

        const vqd = vqdMatch[1]

        // Request image API DuckDuckGo
        const apiRes = await axios.get(
            `https://duckduckgo.com/i.js?l=wt-wt&o=json&q=${encodeURIComponent(query)}&vqd=${vqd}&f=,,,;&p=1`,
            {
                headers: {
                    ...headers,
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Referer': `https://duckduckgo.com/?q=${encodeURIComponent(query)}&iax=images&ia=images`,
                    'X-Requested-With': 'XMLHttpRequest'
                }
            }
        )

        const results = apiRes.data?.results

        if (!Array.isArray(results) || !results.length) {
            throw new Error('Gambar tidak ditemukan')
        }

        // Filter hasil yang memiliki URL gambar
        const validResults = results.filter(x =>
            x?.image &&
            /^https?:\/\//i.test(x.image)
        )

        if (!validResults.length) {
            throw new Error('Gambar tidak ditemukan')
        }

        // Pilih gambar secara random
        const randomItem =
            validResults[Math.floor(Math.random() * validResults.length)]

        return {
            title: randomItem.title || query,
            image: randomItem.image,
            thumbnail: randomItem.thumbnail
        }

    } catch (err) {
        throw new Error(
            err?.response?.data?.message ||
            err?.message ||
            'Gagal mengambil gambar'
        )
    }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) {
        throw `Example:\n${usedPrefix + command} meme indo`
    }

    try {
        const result = await scraper(text)

        await conn.sendFile(
            m.chat,
            result.image,
            'image.jpg',
            `*${result.title}*`,
            m
        )
    } catch (e) {
        throw e.message
    }
}

handler.help = [
    'duckduckimage',
    'ddgimage',
    'ddgimg',
    'googleimage',
    'gimg'
]

handler.tags = ['tools']

handler.command = /^(duckduckimage|ddgimage|ddgimg|googleimage|gimg)$/i

handler.limit = 10

export default handler