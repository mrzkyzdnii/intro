let handler = async (m, { usedPrefix }) => {
  let text = `
╭━━〔 📚 TUTORIAL BOT 〕━━╮
┃
┃ 👋 Hai! Bingung cara mendapatkan
┃ money atau limit? Santai, gampang
┃ banget gais! 😎
┃
┣━━〔 💰 CARA DAPAT UANG 〕━━
┃
┃ 🎮 Main game yang tersedia di
┃ menu RPG atau menu FUN.
┃
┃ Setiap bermain beberapa game,
┃ kamu bisa mendapatkan 💰 Money
┃ dan hadiah lainnya.
┃
┃ 📌 Coba ketik:
┃ ${usedPrefix}menu rpg
┃ ${usedPrefix}menu fun
┃
┣━━〔 💎 CARA DAPAT LIMIT 〕━━
┃
┃ Limit bisa kamu dapatkan dari
┃ beberapa fitur atau membelinya
┃ menggunakan Money.
┃
┃ 🛒 Contoh membeli limit:
┃ ${usedPrefix}buy limit 5
┃
┃ Artinya kamu membeli 5 Limit.
┃
┣━━〔 🛒 BUY 〕━━
┃
┃ Gunakan ${usedPrefix}buy untuk membeli
┃ item atau kebutuhan tertentu.
┃
┃ Contoh:
┃ ${usedPrefix}buy limit 5
┃
┃ Untuk melihat barang yang tersedia,
┃ gunakan:
┃ ${usedPrefix}buy
┃
┣━━〔 💸 SELL 〕━━
┃
┃ Gunakan ${usedPrefix}sell untuk menjual
┃ item yang memang tersedia di sistem.
┃
┃ Contoh:
┃ ${usedPrefix}sell <item> <jumlah>
┃
┃ 📌 Ketik ${usedPrefix}sell untuk melihat
┃ daftar item yang bisa dijual.
┃
┣━━〔 🛍️ JUAL BARANG 〕━━
┃
┃ Punya banyak isi di dalam 🎒 Karung?
┃ Barang tersebut bisa dijual untuk
┃ mendapatkan Money 💰.
┃
┃ 📦 Lihat isi karung:
┃ ${usedPrefix}karung
┃
┃ 🛒 Lihat barang yang bisa dijual:
┃ ${usedPrefix}jual
┃
┃ Contoh:
┃ ${usedPrefix}jual botol 10
┃
┃ Kamu akan mendapatkan Money sesuai
┃ harga jual barang tersebut.
┃
┣━━〔 🎮 TIPS 〕━━
┃
┃ ✦ Rajin main menu RPG
┃ ✦ Coba game di menu FUN
┃ ✦ Kumpulkan item di 🎒 Karung
┃ ✦ Jual item yang tidak diperlukan
┃ ✦ Gunakan Money untuk membeli Limit
┃
╰━━━━━━━━━━━━━━━━━━━━╯
`

  await conn.reply(m.chat, text.trim(), m)
}

handler.help = ['tutorial']
handler.tags = ['main']
handler.command = /^tutorial$/i

export default handler