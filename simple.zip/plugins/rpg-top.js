import { jidNormalizedUser } from '@mrzkyzdnii/baileys'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const users = global.db?.data?.users || {}

    if (!text) {
        return m.reply(
            `╭─〔 🏆 TOP DATABASE 〕\n` +
            `│\n` +
            `│ Contoh:\n` +
            `│ ${usedPrefix + command} money\n` +
            `│ ${usedPrefix + command} limit\n` +
            `│ ${usedPrefix + command} wood\n` +
            `│ ${usedPrefix + command} rock\n` +
            `│ ${usedPrefix + command} iron\n` +
            `│\n` +
            `│ Support semua object\n` +
            `│ yang ada di database.\n` +
            `╰───────────────`
        )
    }

    const object = text.trim().toLowerCase()

    // ==========================================
    // BIG NUMBER FORMAT
    // ==========================================

    const suffixes = [
        '',
        'K',
        'M',
        'B',
        'T',
        'Qa',
        'Qi',
        'Sx',
        'Sp',
        'Oc',
        'No',
        'Dc',
        'Ud',
        'Dd',
        'Td',
        'Qad',
        'Qid',
        'Sxd',
        'Spd',
        'Ocd',
        'Nod',
        'Vg',
        'Uvg',
        'Dvg',
        'Tvg',
        'Qavg',
        'Qivg',
        'Sxvg',
        'Spvg',
        'Ocvg',
        'Novg',
        'Tg',
        'Utg',
        'Dtg',
        'Ttg',
        'Qatg',
        'Qitg',
        'Sxtg',
        'Sptg',
        'Octg',
        'Notg',
        'Qag',
        'Qig',
        'Sxg',
        'Spg',
        'Ocg',
        'Nog',
        'C',
        'Uc',
        'Dc',
        'Tc',
        'Qac',
        'Qic',
        'Sxc',
        'Spc',
        'Occ',
        'Noc'
    ]

    const formatBigNumber = value => {
        let num = Number(value)

        if (!Number.isFinite(num)) return '∞'
        if (num === 0) return '0'

        const negative = num < 0
        num = Math.abs(num)

        let index = 0

        while (
            num >= 1000 &&
            index < suffixes.length - 1
        ) {
            num /= 1000
            index++
        }

        if (index === 0) {
            return `${negative ? '-' : ''}${Math.floor(num).toLocaleString('id-ID')}`
        }

        let result

        if (num >= 100) {
            result = num.toFixed(1)
        } else if (num >= 10) {
            result = num.toFixed(2)
        } else {
            result = num.toFixed(2)
        }

        result = result
            .replace(/\.00$/, '')
            .replace(/(\.\d)0$/, '')

        return `${negative ? '-' : ''}${result}${suffixes[index]}`
    }

    // ==========================================
    // GET VALUE
    // ==========================================

    const getValue = (user, key) => {
        const value = user?.[key]

        if (value === undefined || value === null) {
            return 0
        }

        if (typeof value === 'number') {
            return Number.isFinite(value) ? value : 0
        }

        if (typeof value === 'bigint') {
            return Number(value)
        }

        if (typeof value === 'string') {
            const num = Number(
                value.replace(/,/g, '')
            )

            return Number.isFinite(num) ? num : 0
        }

        if (Array.isArray(value)) {
            return value.length
        }

        if (typeof value === 'object') {
            return Object.keys(value).length
        }

        return 0
    }

    // ==========================================
    // NORMALIZE JID
    // ==========================================

    const normalizeJid = jid => {
        try {
            return jidNormalizedUser(jid)
        } catch {
            return jid
        }
    }

    // ==========================================
    // LID -> PN
    // ==========================================

    const resolveLid = async jid => {
        const normalized = normalizeJid(jid)

        if (!normalized.endsWith('@lid')) {
            return normalized
        }

        try {
            const mapping =
                conn?.signalRepository?.lidMapping

            if (mapping?.getPNForLID) {
                const pn = await mapping.getPNForLID(normalized)

                if (pn) {
                    return normalizeJid(pn)
                }
            }
        } catch {}

        return normalized
    }

    // ==========================================
    // CEK APAKAH STRING ADALAH NOMOR
    // ==========================================

    const looksLikePhone = name => {
        if (!name) return true

        const value = String(name)
            .replace(/[+\-\s().]/g, '')

        return /^\d+$/.test(value)
    }

    // ==========================================
    // CARI CONTACT
    // ==========================================

    const findContact = jid => {
        const contacts = conn?.contacts || {}

        const normalized = normalizeJid(jid)

        const keys = [
            jid,
            normalized
        ]

        // LID
        if (normalized.endsWith('@lid')) {
            keys.push(
                normalized,
                normalized.replace('@lid', '')
            )
        }

        // PN
        if (normalized.endsWith('@s.whatsapp.net')) {
            keys.push(
                normalized,
                normalized.replace('@s.whatsapp.net', '')
            )
        }

        for (const key of keys) {
            try {
                const contact = contacts[key]

                if (contact) {
                    return contact
                }
            } catch {}
        }

        // Cari berdasarkan key jika format berbeda
        try {
            for (const [key, contact] of Object.entries(contacts)) {
                if (
                    key === jid ||
                    key === normalized ||
                    contact?.id === jid ||
                    contact?.id === normalized
                ) {
                    return contact
                }
            }
        } catch {}

        return null
    }

    // ==========================================
    // CARI NAMA DARI CONTACT
    // ==========================================

    const getContactName = contact => {
        if (!contact) return null

        const names = [
            contact.name,
            contact.notify,
            contact.pushName,
            contact.verifiedName,
            contact.subject,
            contact.shortName
        ]

        for (const name of names) {
            if (
                typeof name === 'string' &&
                name.trim() &&
                !looksLikePhone(name)
            ) {
                return name.trim()
            }
        }

        return null
    }

    // ==========================================
    // GET NAME
    // ==========================================

    const getUserName = async (jid, userData) => {
        const originalJid = jid
        const normalizedJid = normalizeJid(jid)

        /*
         * ======================================
         * 1. CEK DATABASE USER
         * ======================================
         *
         * Kalau plugin lain sudah pernah menyimpan
         * nama user, ini adalah sumber terbaik.
         */

        if (userData) {
            const databaseNames = [
                userData.name,
                userData.pushName,
                userData.notify,
                userData.displayName
            ]

            for (const name of databaseNames) {
                if (
                    typeof name === 'string' &&
                    name.trim() &&
                    !looksLikePhone(name)
                ) {
                    return name.trim()
                }
            }
        }

        /*
         * ======================================
         * 2. CEK CONTACT MENGGUNAKAN LID
         * ======================================
         */

        let contact = findContact(originalJid)

        let name = getContactName(contact)

        if (name) {
            return name
        }

        /*
         * ======================================
         * 3. RESOLVE LID -> PN
         * ======================================
         */

        const resolvedJid = await resolveLid(originalJid)

        /*
         * ======================================
         * 4. CEK CONTACT PN
         * ======================================
         */

        contact = findContact(resolvedJid)

        name = getContactName(contact)

        if (name) {
            return name
        }

        /*
         * ======================================
         * 5. getName() PAKAI LID
         * ======================================
         */

        try {
            const result = await conn.getName(normalizedJid)

            if (
                result &&
                typeof result === 'string' &&
                result.trim() &&
                !looksLikePhone(result)
            ) {
                return result.trim()
            }
        } catch {}

        /*
         * ======================================
         * 6. getName() PAKAI PN
         * ======================================
         */

        if (resolvedJid !== normalizedJid) {
            try {
                const result = await conn.getName(resolvedJid)

                if (
                    result &&
                    typeof result === 'string' &&
                    result.trim() &&
                    !looksLikePhone(result)
                ) {
                    return result.trim()
                }
            } catch {}
        }

        /*
         * ======================================
         * 7. CEK CONTACT LAGI
         * ======================================
         */

        try {
            const contact2 =
                findContact(normalizedJid) ||
                findContact(resolvedJid)

            const name2 = getContactName(contact2)

            if (name2) {
                return name2
            }
        } catch {}

        /*
         * ======================================
         * 8. FALLBACK
         * ======================================
         *
         * Jangan format nomor jadi +62.
         */

        if (
            resolvedJid &&
            resolvedJid.endsWith('@s.whatsapp.net')
        ) {
            return resolvedJid
                .replace('@s.whatsapp.net', '')
        }

        return originalJid
            .replace('@lid', '')
            .replace('@s.whatsapp.net', '')
    }

    // ==========================================
    // TOP 10
    // ==========================================

    const data = Object.entries(users)
        .map(([jid, user]) => ({
            jid,
            user,
            value: getValue(user, object)
        }))
        .filter(item => item.value > 0)
        .sort((a, b) => b.value - a.value)
        .slice(0, 10)

    if (!data.length) {
        return m.reply(
            `╭─〔 🏆 TOP ${object.toUpperCase()} 〕\n` +
            `│\n` +
            `│ ❌ Tidak ada data untuk\n` +
            `│ object *${object}*.\n` +
            `╰───────────────`
        )
    }

    // ==========================================
    // GET NAMES
    // ==========================================

    const names = await Promise.all(
        data.map(item =>
            getUserName(item.jid, item.user)
        )
    )

    // ==========================================
    // DESIGN
    // ==========================================

    let caption =
        `╭─〔 🏆 TOP ${object.toUpperCase()} 〕\n` +
        `│\n`

    data.forEach((item, index) => {
        const medal =
            index === 0
                ? '🥇'
                : index === 1
                ? '🥈'
                : index === 2
                ? '🥉'
                : '🏅'

        caption +=
            `│ ${medal} *${index + 1}. ${names[index]}*\n` +
            `│    💰 ${formatBigNumber(item.value)}\n`

        if (index < data.length - 1) {
            caption += `│\n`
        }
    })

    caption +=
        `│\n` +
        `╰───────────────\n` +
        `📊 Total: *${data.length} pemain*`

    await conn.reply(m.chat, caption, m)
}

handler.help = ['top']
handler.tags = ['rpg']
handler.command = /^top$/i

export default handler