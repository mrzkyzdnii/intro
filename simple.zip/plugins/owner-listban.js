let listban = async (m, { conn }) => {
    const users = global.db.data.users

    if (!users) {
        throw 'Database users tidak ditemukan.'
    }

    const banned = Object.entries(users)
        .filter(([jid, user]) => user?.banned === true)

    if (!banned.length) {
        return conn.reply(
            m.chat,
            `╭─「 🚫 *BANNED USER LIST* 」
│
│ Tidak ada user yang sedang di-ban.
│
╰─────────────`,
            m
        )
    }

    const list = banned.map(([jid, user]) => {
        const name =
            user.name ||
            user.pushName ||
            user.notify ||
            jid.split('@')[0]

        const reason =
            user.banReason ||
            'Tidak ada alasan'

        return `${name}\n> ${reason}`
    }).join('\n\n')

    return conn.reply(
        m.chat,
        `╭─「 🚫 *BANNED USER LIST* 」
│
│ ${list.replace(/\n/g, '\n│ ')}
│
╰─────────────`,
        m
    )
}

listban.help = ['listban']
listban.tags = ['owner']
listban.command = /^listban$/i
listban.rowner = true

export default listban