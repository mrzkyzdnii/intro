let handler = async (m, { conn, args, usedPrefix, command }) => {

  let who

  // =========================
  // ADD PREMIUM
  // =========================
  if (/^(add|tambah|\+)p(rem)?$/i.test(command)) {

    if (!args[0]) {
      throw `Contoh:
${usedPrefix + command} 30 628xxxxx
${usedPrefix + command} 30 @628xxxxx
${usedPrefix + command} permanen 628xxxxx

Atau reply:
${usedPrefix + command} 30
${usedPrefix + command} permanen`
    }

    // Durasi
    let hari = args[0].toString().trim()

    // =========================
    // TARGET USER
    // =========================

    // Kalau reply pesan
    if (m.quoted) {
      who =
        m.quoted.sender ||
        m.quoted.participant ||
        m.quoted.key?.participant
    }

    // Kalau tidak reply, ambil nomor dari args[1]
    if (!who && args[1]) {
      let number = args[1].replace(/[^0-9]/g, '')

      if (!number) {
        throw '❌ Nomor tidak valid!'
      }

      who = number + '@s.whatsapp.net'
    }

    // Kalau mention
    if (!who && m.mentionedJid?.[0]) {
      who = m.mentionedJid[0]
    }

    if (!who) {
      throw `❌ User tidak ditemukan!

Contoh:
${usedPrefix + command} 30 628xxxxx

Atau reply pesan user:
${usedPrefix + command} 30`
    }

    // =========================
    // DATABASE USER
    // =========================

    if (!global.db.data.users[who]) {
      global.db.data.users[who] = {
        name: await conn.getName(who).catch(() => 'Unknown'),
        limit: 10,
        exp: 0,
        level: 0,
        register: false,
        premium: false,
        premiumTime: 0
      }
    }

    let user = global.db.data.users[who]
    let now = Date.now()

    // =========================
    // PREMIUM PERMANEN
    // =========================

    if (hari.toLowerCase() === 'permanen') {

      user.premium = true
      user.premiumTime = Infinity

      return conn.reply(
        m.chat,
        `🪄 *Success*

👤 User : @${who.split('@')[0]}
💜 Status : Premium Permanen
🌙 Tanggal : ${new Date().toLocaleDateString('id-ID')}`,
        m,
        {
          mentions: [who]
        }
      )
    }

    // =========================
    // PREMIUM HARIAN
    // =========================

    if (isNaN(hari)) {
      throw '❌ Durasi harus berupa angka atau "permanen"!'
    }

    let jumlahHari = parseInt(hari)

    if (jumlahHari <= 0) {
      throw '❌ Durasi harus lebih dari 0 hari!'
    }

    let ms = 86400000 * jumlahHari

    // Jika premium masih aktif, tambahkan durasi
    if (user.premiumTime && user.premiumTime > now) {
      user.premiumTime += ms
    } else {
      user.premiumTime = now + ms
    }

    user.premium = true

    let expired = new Date(user.premiumTime)
      .toLocaleDateString('id-ID')

    return conn.reply(
      m.chat,
      `✨ *Premium Aktif*

👤 User : @${who.split('@')[0]}
⏳ Durasi : ${jumlahHari} Hari
🌙 Berakhir : ${expired}`,
      m,
      {
        mentions: [who]
      }
    )
  }

  // =========================
  // DELETE PREMIUM
  // =========================

  if (/^(del|hapus|-)p(rem)?$/i.test(command)) {

    // Target dari reply
    if (m.quoted) {
      who =
        m.quoted.sender ||
        m.quoted.participant ||
        m.quoted.key?.participant
    }

    // Target dari nomor
    if (!who && args[0]) {
      let number = args[0].replace(/[^0-9]/g, '')

      if (!number) {
        throw '❌ Nomor tidak valid!'
      }

      who = number + '@s.whatsapp.net'
    }

    // Target dari mention
    if (!who && m.mentionedJid?.[0]) {
      who = m.mentionedJid[0]
    }

    if (!who) {
      throw `❌ User tidak ditemukan!

Contoh:
${usedPrefix + command} 628xxxxx

Atau reply pesan user:
${usedPrefix + command}`
    }

    // =========================
    // CEK DATABASE
    // =========================

    if (!global.db.data.users[who]) {
      throw '❌ User tidak ada di database'
    }

    let user = global.db.data.users[who]

    user.premium = false
    user.premiumTime = 0

    return conn.reply(
      m.chat,
      `⚠️ *Premium Dihapus*

👤 User : @${who.split('@')[0]}
🌙 Status sudah nonaktif`,
      m,
      {
        mentions: [who]
      }
    )
  }
}

handler.help = ['addprem', 'delprem']
handler.tags = ['owner']
handler.command = /^(add|tambah|\+|del|hapus|-)p(rem)?$/i
handler.owner = true

handler.limit = 10

export default handler