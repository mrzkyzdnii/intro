let handler = async (m, { conn, usedPrefix }) => {

    let user = global.db.data.users[m.sender]

    if (!user) return m.reply('❌ Data pengguna belum tersedia.')

    let name = await conn.getName(m.sender)

    /*
     * ==========================================
     * COOLDOWN
     * ==========================================
     */

    let lastgrab = Number(user.lastgrab || 0)
    let elapsed = Date.now() - lastgrab
    let cooldown = 10800000
    let remaining = cooldown - elapsed

    let timers = clockString(remaining)

    /*
     * ==========================================
     * STAMINA
     * ==========================================
     */

    if (Number(user.stamina || 0) < 20) {
        return m.reply(
`╭━━━〔 ⚡ STAMINA LOW 〕━━━╮
┃
┃ 👤 Explorer
┃ ${name}
┃
┃ ⚡ Stamina
┃ ${user.stamina || 0}/100
┃
┃ 🔋 Required
┃ 20
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

💡 Isi stamina kamu dengan:
*${usedPrefix}eat8*`
        )
    }

    /*
     * ==========================================
     * COOLDOWN CHECK
     * ==========================================
     */

    if (lastgrab && remaining > 0) {
        return m.reply(
`╭━━━〔 ⏳ EXPEDITION LOCKED 〕━━━╮
┃
┃ 👤 Explorer
┃ ${name}
┃
┃ 💤 Status
┃ RECOVERING
┃
┃ ⏰ Cooldown
┃ ${timers}
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

🧭 Expedition berikutnya belum tersedia.

⚡ Istirahat dulu sebelum kembali
ke area eksplorasi.`
        )
    }

    /*
     * ==========================================
     * LOCATION DATABASE
     * ==========================================
     */

    const locations = [
        {
            name: 'Mystic Forest',
            icon: '🌲',
            danger: 'LOW',
            rarity: 'COMMON',
            description: 'Hutan tua dengan banyak sumber daya tersembunyi.'
        },
        {
            name: 'Iron Valley',
            icon: '⛰️',
            danger: 'MEDIUM',
            rarity: 'UNCOMMON',
            description: 'Lembah berbatu dengan kandungan mineral tinggi.'
        },
        {
            name: 'Crystal Cavern',
            icon: '💎',
            danger: 'HIGH',
            rarity: 'RARE',
            description: 'Gua dalam yang dipenuhi kristal bercahaya.'
        },
        {
            name: 'Ancient Ruins',
            icon: '🏛️',
            danger: 'HIGH',
            rarity: 'RARE',
            description: 'Reruntuhan misterius dari peradaban kuno.'
        },
        {
            name: 'Dead Quarry',
            icon: '🪨',
            danger: 'MEDIUM',
            rarity: 'UNCOMMON',
            description: 'Tambang tua yang menyimpan berbagai material.'
        },
        {
            name: 'Shadow Valley',
            icon: '🌑',
            danger: 'EXTREME',
            rarity: 'LEGENDARY',
            description: 'Wilayah gelap yang sangat jarang dijelajahi.'
        }
    ]

    let location =
        locations[
            Math.floor(Math.random() * locations.length)
        ]

    /*
     * ==========================================
     * RANDOM EVENT
     * ==========================================
     */

    const events = [
        {
            title: 'Quiet Expedition',
            icon: '🍃',
            text: 'Perjalanan berlangsung dengan tenang.',
            rarity: 'COMMON'
        },
        {
            title: 'Lucky Spot',
            icon: '🍀',
            text: 'Scanner menemukan area dengan sumber daya tinggi.',
            rarity: 'UNCOMMON'
        },
        {
            title: 'Abandoned Chest',
            icon: '📦',
            text: 'Sebuah peti tua ditemukan di balik reruntuhan.',
            rarity: 'RARE'
        },
        {
            title: 'Ancient Discovery',
            icon: '🏺',
            text: 'Sisa peradaban kuno berhasil ditemukan.',
            rarity: 'EPIC'
        },
        {
            title: 'Hidden Mineral Vein',
            icon: '✨',
            text: 'Scanner mendeteksi sumber mineral tersembunyi.',
            rarity: 'EPIC'
        },
        {
            title: 'Treasure Signal',
            icon: '🗺️',
            text: 'Sinyal loot langka terdeteksi oleh perangkat.',
            rarity: 'LEGENDARY'
        }
    ]

    let event =
        events[
            Math.floor(Math.random() * events.length)
        ]

    /*
     * ==========================================
     * RANDOM LOOT
     * ==========================================
     */

    let rndm1 = Math.floor(Math.random() * 5)
    let rndm2 = Math.floor(Math.random() * 10)
    let rndm3 = Math.floor(Math.random() * 7)
    let rndm4 = Math.floor(Math.random() * 4)
    let rndm5 = Math.floor(Math.random() * 200)
    let rndm6 = Math.floor(Math.random() * 200)
    let rndm7 = Math.floor(Math.random() * 20)
    let rndm8 = Math.floor(Math.random() * 100)
    let rndm9 = Math.floor(Math.random() * 100)

    let hmsil1 = rndm1 * 10
    let hmsil2 = rndm2 * 10
    let hmsil3 = rndm3 * 10
    let hmsil4 = rndm4 * 10
    let hmsil5 = rndm5 * 10
    let hmsil6 = rndm6 * 10
    let hmsil7 = rndm7 * 10
    let hmsil8 = rndm8 * 10
    let hmsil9 = rndm9 * 10

    /*
     * ==========================================
     * RATING
     * ==========================================
     */

    let totalLoot =
        hmsil1 +
        hmsil2 +
        hmsil3 +
        hmsil4 +
        hmsil5 +
        hmsil6 +
        hmsil7 +
        hmsil8

    let rating

    if (totalLoot >= 3000) {
        rating = 'S+'
    } else if (totalLoot >= 2200) {
        rating = 'S'
    } else if (totalLoot >= 1500) {
        rating = 'A'
    } else if (totalLoot >= 900) {
        rating = 'B'
    } else if (totalLoot >= 400) {
        rating = 'C'
    } else {
        rating = 'D'
    }

    /*
     * ==========================================
     * MAP
     * ==========================================
     */

    const maps = [
        [
            '⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛',
            '⬛🌲🌲⬛⬛🌲🌲🌲⬛⬛',
            '⬛🌲⬛⬛🚶⬛⬛🌲⬛⬛',
            '⬛⬛⬛🌲🌲🌲⬛⬛⬛⬛'
        ],
        [
            '⬛⬛⛰️⛰️⬛⬛⬛⬛⬛⬛',
            '⬛⛰️⛰️⬛⬛🪨⬛⬛⬛⬛',
            '⬛⬛⬛⬛🚶⬛⬛💎⬛⬛',
            '⬛🪨🪨⬛⬛⬛⬛⬛⬛⬛'
        ],
        [
            '⬛🏛️🏛️⬛⬛⬛🏺⬛⬛⬛',
            '⬛⬛⬛⬛🚶⬛⬛⬛⬛⬛',
            '⬛⬛🏺⬛⬛⬛⬛🏛️⬛⬛',
            '⬛⬛⬛⬛⬛⬛⬛⬛⬛⬛'
        ],
        [
            '⬛🌑🌑⬛⬛🌑🌑🌑⬛⬛',
            '⬛🌑⬛⬛🚶⬛⬛🌑⬛⬛',
            '⬛⬛⬛✨⬛⬛⬛⬛⬛⬛',
            '⬛🌑🌑⬛⬛⬛🌑🌑⬛⬛'
        ]
    ]

    let map =
        maps[
            Math.floor(Math.random() * maps.length)
        ]

    /*
     * ==========================================
     * APPLY REWARD
     * ==========================================
     */

    user.diamond += hmsil1
    user.iron += hmsil2
    user.gold += hmsil3
    user.emerald += hmsil4
    user.rock += hmsil5
    user.clay += hmsil6
    user.coal += hmsil7
    user.sand += hmsil8
    user.exp += hmsil9

    user.stamina -= 20
    user.lastgrab = Date.now()

    /*
     * ==========================================
     * FRAME 1
     * ==========================================
     */

    let frame1 = `
╭━━━〔 🧭 EXPEDITION SYSTEM 〕━━━╮
┃
┃ 👤 Explorer
┃ *${name}*
┃
┃ 📡 System
┃ ONLINE
┃
┃ ⚡ Stamina
┃ ${user.stamina}/100
┃
┃ 🎒 Equipment
┃ READY
┃
┃ 🛰️ Satellite
┃ CONNECTED
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

🔍 Scanning unexplored territory...
🧭 Searching for expedition route...
📡 Connecting to field scanner...
`

    /*
     * ==========================================
     * FRAME 2
     * ==========================================
     */

    let frame2 = `
╭━━━〔 🗺️ LOCATION DISCOVERED 〕━━━╮
┃
┃ ${location.icon} *${location.name}*
┃
┃ 🏷️ Rarity
┃ ${location.rarity}
┃
┃ ☠️ Danger
┃ ${location.danger}
┃
┃ 📡 Signal
┃ 🟢 STABLE
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

${location.description}

🧭 Route calculated.
🎒 Equipment secured.
🚶 Expedition commencing...
`

    /*
     * ==========================================
     * FRAME 3
     * ==========================================
     */

    let frame3 = `
╭━━━〔 🚶 FIELD EXPEDITION 〕━━━╮
┃
┃ 👤 *${name}*
┃
┃ 📍 ${location.name}
┃
┃ 🧭 Progress
┃ ███████░░░ 70%
┃
┃ ☠️ Danger
┃ ${location.danger}
┃
┃ 🎒 Scanner
┃ 🟢 ACTIVE
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

${map.join('\n')}

📡 Movement detected...
🔎 Searching for resources...
⛏️ Scanner analyzing terrain...
`

    /*
     * ==========================================
     * FRAME 4
     * ==========================================
     */

    let frame4 = `
╭━━━〔 🔎 LOOT DETECTED 〕━━━╮
┃
┃ ${event.icon} *${event.title}*
┃
┃ 🏷️ Rarity
┃ ${event.rarity}
┃
┃ 📍 Location
┃ ${location.name}
┃
┃ 📡 Scanner
┃ 🟢 TARGET LOCKED
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

${event.text}

💎 Resource signal detected.
⛏️ Extracting materials...
🎒 Securing discovered loot...
`

    /*
     * ==========================================
     * FRAME 5
     * ==========================================
     */

    let frame5 = `
╭━━━〔 📦 EXTRACTION COMPLETE 〕━━━╮
┃
┃ 👤 *${name}*
┃
┃ ${location.icon} ${location.name}
┃
┃ ${event.icon} ${event.title}
┃
┃ 🏆 Expedition Rating
┃ *${rating}*
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

🎒 LOOT SECURED

💎 Diamond   × ${hmsil1}
⛓️ Iron      × ${hmsil2}
🪙 Gold      × ${hmsil3}
💚 Emerald   × ${hmsil4}
🪨 Rock      × ${hmsil5}
🌕 Clay      × ${hmsil6}
🕳️ Coal      × ${hmsil7}
🌑 Sand      × ${hmsil8}
✉️ EXP       × ${hmsil9}

💾 Synchronizing inventory...
📡 Returning to base...
`

    /*
     * ==========================================
     * FINAL
     * ==========================================
     */

    let final = `
╭━━━〔 🏆 EXPEDITION REPORT 〕━━━╮
┃
┃ 👤 Explorer
┃ *${name}*
┃
┃ 📍 ${location.name}
┃ ${event.icon} ${event.title}
┃
┃ ☠️ Danger
┃ ${location.danger}
┃
┃ 🏆 Rating
┃ *${rating}*
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 🎒 LOOT SECURED 〕━━━╮
┃
┃ 💎 Diamond  × ${hmsil1}
┃ ⛓️ Iron     × ${hmsil2}
┃ 🪙 Gold     × ${hmsil3}
┃ 💚 Emerald  × ${hmsil4}
┃ 🪨 Rock     × ${hmsil5}
┃ 🌕 Clay     × ${hmsil6}
┃ 🕳️ Coal     × ${hmsil7}
┃ 🌑 Sand     × ${hmsil8}
┃ ✉️ EXP      × ${hmsil9}
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

╭━━━〔 ⚡ CONDITION 〕━━━╮
┃
┃ ⚡ Stamina Used
┃ -20
┃
┃ 🔋 Remaining
┃ *${user.stamina}/100*
┃
┃ 🎒 Inventory
┃ UPDATED
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

✨ Expedition successfully completed.

📡 All resources have been secured.
💾 Expedition data synchronized.
`

    /*
     * ==========================================
     * KIRIM PESAN AWAL
     * ==========================================
     */

    let sent = await conn.sendMessage(m.chat, {
        text: frame1
    }, {
        quoted: m
    })

    /*
     * ==========================================
     * AMBIL KEY
     * ==========================================
     */

    let key = sent.key

    /*
     * ==========================================
     * EDIT PESAN YANG SAMA
     * ==========================================
     *
     * PENTING:
     * edit HARUS berada di object pesan.
     *
     * {
     *     text: frame,
     *     edit: key
     * }
     *
     */

    setTimeout(() => {

        conn.sendMessage(m.chat, {
            text: frame2,
            edit: key
        })

    }, 3000)

    setTimeout(() => {

        conn.sendMessage(m.chat, {
            text: frame3,
            edit: key
        })

    }, 7000)

    setTimeout(() => {

        conn.sendMessage(m.chat, {
            text: frame4,
            edit: key
        })

    }, 11000)

    setTimeout(() => {

        conn.sendMessage(m.chat, {
            text: frame5,
            edit: key
        })

    }, 15000)

    setTimeout(() => {

        conn.sendMessage(m.chat, {
            text: final,
            edit: key
        })

    }, 20000)
}

handler.help = ['grab']
handler.tags = ['rpg']
handler.command = /^(taksi|taxy|grab|megrab)$/i

export default handler


function clockString(ms) {

    if (isNaN(ms) || ms <= 0)
        return 'READY'

    let d =
        Math.floor(ms / 86400000)

    let h =
        Math.floor(ms / 3600000) % 24

    let m =
        Math.floor(ms / 60000) % 60

    let s =
        Math.floor(ms / 1000) % 60

    return [
        d > 0 ? `${d}d` : '',
        h > 0 ? `${h}h` : '',
        m > 0 ? `${m}m` : '',
        `${s}s`
    ]
        .filter(Boolean)
        .join(' ')
}