const handler = async (m, { conn, text, usedPrefix, command }) => {
    const CONFIG = Object.freeze({
        endpoint: 'https://savetwitter.net/api/ajaxSearch',
        origin: 'https://savetwitter.net',
        referer: 'https://savetwitter.net/id3',
        language: 'id',
        timeout: 30000,
        userAgent: [
            'Mozilla/5.0',
            '(Windows NT 10.0; Win64; x64)',
            'AppleWebKit/537.36',
            '(KHTML, like Gecko)',
            'Chrome/131.0.0.0',
            'Safari/537.36'
        ].join(' ')
    })

    const STATE = {
        startedAt: Date.now(),
        reacted: false,
        sent: false
    }

    const sleep = ms =>
        new Promise(resolve => setTimeout(resolve, ms))

    const react = async emoji => {
        try {
            await conn.sendMessage(m.chat, {
                react: {
                    text: emoji,
                    key: m.key
                }
            })

            STATE.reacted = Boolean(emoji)
        } catch {}
    }

    const clean = value => {
        if (value === undefined || value === null) return ''
        return String(value)
            .replace(/&amp;/gi, '&')
            .replace(/&quot;/gi, '"')
            .replace(/&#39;/gi, "'")
            .replace(/&lt;/gi, '<')
            .replace(/&gt;/gi, '>')
            .replace(/\s+/g, ' ')
            .trim()
    }

    const normalizeInput = input => {
        let value = String(input || '').trim()

        if (!/^https?:\/\//i.test(value)) {
            value = `https://${value}`
        }

        try {
            const url = new URL(value)
            const host = url.hostname.toLowerCase()

            const allowed = [
                'twitter.com',
                'www.twitter.com',
                'x.com',
                'www.x.com',
                'mobile.twitter.com'
            ]

            if (!allowed.includes(host)) {
                throw new Error('URL Twitter/X tidak valid.')
            }

            return url.toString()
        } catch {
            throw new Error('Masukkan URL Twitter/X yang valid.')
        }
    }

    const request = async url => {
        const controller = new AbortController()
        const timer = setTimeout(() => controller.abort(), CONFIG.timeout)

        try {
            const payload = new URLSearchParams()

            ;[
                ['q', url],
                ['lang', CONFIG.language],
                ['cftoken', '']
            ].forEach(([key, value]) => {
                payload.append(key, value)
            })

            const response = await fetch(CONFIG.endpoint, {
                method: 'POST',
                headers: {
                    'User-Agent': CONFIG.userAgent,
                    'Accept': '*/*',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Origin': CONFIG.origin,
                    'Referer': CONFIG.referer
                },
                body: payload,
                signal: controller.signal
            })

            if (!response.ok) {
                throw new Error(
                    `Server downloader mengembalikan HTTP ${response.status}.`
                )
            }

            const contentType =
                response.headers.get('content-type') || ''

            if (!contentType.includes('json')) {
                const raw = await response.text()

                try {
                    return JSON.parse(raw)
                } catch {
                    throw new Error('Response server tidak berbentuk JSON.')
                }
            }

            return await response.json()
        } finally {
            clearTimeout(timer)
        }
    }

    const extract = html => {
        const source = String(html || '')

        const title =
            clean(
                source.match(
                    /<h3[^>]*>([\s\S]*?)<\/h3>/i
                )?.[1]
            ) || 'Twitter Video'

        const duration =
            clean(
                source.match(
                    /<p[^>]*>\s*(\d{1,3}:\d{2}(?::\d{2})?)\s*<\/p>/i
                )?.[1]
            ) || '-'

        const thumbnail =
            source.match(
                /<img[^>]+src=["']([^"']+)["']/i
            )?.[1] || null

        const results = []

        const patterns = [
            /href=["'](https:\/\/dl\.snapcdn\.app\/get\?token=[^"']+)["'][^>]*>[\s\S]*?MP4\s*\(([^)]+)\)/gi,
            /href=["'](https:\/\/dl\.snapcdn\.app\/get\?token=[^"']+)["'][^>]*>[\s\S]*?MP4[\s\S]*?\(([^)]+)\)/gi
        ]

        for (const pattern of patterns) {
            for (const match of source.matchAll(pattern)) {
                const url = match?.[1]
                const quality = clean(match?.[2])

                if (!url) continue

                results.push({
                    url,
                    quality: quality || 'Unknown',
                    score: getQualityScore(quality)
                })
            }
        }

        const unique = new Map()

        for (const item of results) {
            if (!unique.has(item.url)) {
                unique.set(item.url, item)
            }
        }

        return {
            title,
            duration,
            thumbnail,
            videos: [...unique.values()]
        }
    }

    const getQualityScore = quality => {
        const value = String(quality || '').toLowerCase()

        const match = value.match(
            /(\d{3,4})p/
        )

        if (match) {
            return Number(match[1])
        }

        if (value.includes('full hd')) return 1080
        if (value.includes('hd')) return 720
        if (value.includes('sd')) return 480

        return 0
    }

    const chooseBest = videos => {
        if (!Array.isArray(videos) || !videos.length) {
            return null
        }

        return [...videos]
            .sort((a, b) => {
                if (b.score !== a.score) {
                    return b.score - a.score
                }

                return String(b.quality)
                    .length - String(a.quality).length
            })[0]
    }

    const getThumbnail = async url => {
        if (!url) return null

        try {
            const controller = new AbortController()
            const timer = setTimeout(
                () => controller.abort(),
                10000
            )

            try {
                const response = await fetch(url, {
                    headers: {
                        'User-Agent': CONFIG.userAgent,
                        'Referer': CONFIG.origin
                    },
                    signal: controller.signal
                })

                if (!response.ok) return null

                const buffer = Buffer.from(
                    await response.arrayBuffer()
                )

                return buffer.length
                    ? buffer
                    : null
            } finally {
                clearTimeout(timer)
            }
        } catch {
            return null
        }
    }

    const formatCaption = data => {
        const elapsed =
            ((Date.now() - STATE.startedAt) / 1000)
                .toFixed(1)

        return [
            '*🐦 TWITTER / X DOWNLOADER*',
            '',
            `*📌 Judul:* ${data.title}`,
            `*⏱️ Durasi:* ${data.duration}`,
            `*🎞️ Kualitas:* ${data.video.quality}`,
            `*⚡ Response:* ${elapsed}s`,
            '',
            '_Downloaded by bot_'
        ].join('\n')
    }

    const errorMessage = error => {
        const message = String(
            error?.message || error || 'Unknown error'
        )

        if (/abort|timeout/i.test(message)) {
            return '*⏱️ Request timeout.*\nCoba lagi beberapa saat.'
        }

        if (/valid|twitter|x\.com/i.test(message)) {
            return `*❌ URL tidak valid.*\n\nContoh:\n${usedPrefix + command} https://x.com/...`
        }

        if (/HTTP 4\d\d|HTTP 5\d\d/i.test(message)) {
            return '*❌ Server downloader sedang bermasalah.*\nCoba lagi nanti.'
        }

        return `*❌ Terjadi kesalahan.*\n\n${message}`
    }

    try {
        if (!text?.trim()) {
            throw new Error(
                `Masukkan URL Twitter/X.\n\nContoh:\n${usedPrefix + command} https://x.com/...`
            )
        }

        await react('⏳')

        const target = normalizeInput(text)

        const response = await request(target)

        const html =
            typeof response?.data === 'string'
                ? response.data
                : typeof response?.html === 'string'
                    ? response.html
                    : null

        if (!html) {
            throw new Error(
                'Data video tidak ditemukan dari server.'
            )
        }

        const parsed = extract(html)

        if (!parsed.videos.length) {
            throw new Error(
                'Tidak ada video MP4 yang tersedia.'
            )
        }

        const best = chooseBest(parsed.videos)

        if (!best?.url) {
            throw new Error(
                'Link video tidak dapat ditemukan.'
            )
        }

        const thumbnail =
            await getThumbnail(parsed.thumbnail)

        const caption = formatCaption({
            ...parsed,
            video: best
        })

        const message = {
            video: {
                url: best.url
            },
            caption,
            mimetype: 'video/mp4'
        }

        if (thumbnail) {
            message.jpegThumbnail = thumbnail
        }

        await conn.sendMessage(
            m.chat,
            message,
            {
                quoted: m
            }
        )

        STATE.sent = true

        await sleep(300)
    } catch (error) {
        await conn.reply(
            m.chat,
            errorMessage(error),
            m
        )
    } finally {
        try {
            await react('')
        } catch {}
    }
}

handler.help = ['twitter']
handler.tags = ['downloader']
handler.command = /^(twitter|tw|xdl)$/i
handler.limit = 10
handler.register = true

export default handler