const formatMoney = value => Number(value || 0).toLocaleString('id-ID')

const getRandomNumber = () => Math.floor(Math.random() * 10) + 1

const editMessage = async (conn, chat, key, text, mentions = []) => {
  if (!key) return null

  return conn.sendMessage(
    chat,
    {
      text,
      mentions
    },
    {
      edit: key
    }
  )
}

const cleanExpiredGames = (conn) => {
  const now = Date.now()

  for (const key in conn.numberGuess) {
    const game = conn.numberGuess[key]

    if (
      game &&
      game.createdAt &&
      now - game.createdAt > 30000 &&
      !game.answered
    ) {
      if (game.timer) clearTimeout(game.timer)
      delete conn.numberGuess[key]
    }
  }
}

let handler = async (m, { conn, args, usedPrefix }) => {
  conn.numberGuess = conn.numberGuess || {}

  cleanExpiredGames(conn)

  const amount = Number(args?.[0])

  if (!Number.isInteger(amount) || amount <= 0) {
    return m.reply(
      `╭─〔 ❌ CARA PAKAI 〕
│ ${usedPrefix}numberguess 1000
│
│ 💰 Taruhan bebas tanpa batas!
│
│ Contoh:
│ ${usedPrefix}numberguess 1000
│ ${usedPrefix}numberguess 100000
│ ${usedPrefix}numberguess 10000000
╰────────────`
    )
  }

  if (conn.numberGuess[m.sender]) {
    return m.reply(
      `╭─〔 ⏳ GAME AKTIF 〕
│ Kamu masih memiliki game berjalan!
│
│ 🎯 Balas pesan game dengan angka 1-10
│ ❌ Atau ketik "batal"
╰────────────`
    )
  }

  const user = global.db.data.users[m.sender]

  if (!user) {
    return m.reply('❌ Data pengguna tidak ditemukan di database.')
  }

  const userMoney = Number(user.money || 0)

  if (userMoney < amount) {
    return m.reply(
      `╭─〔 ❌ SALDO TIDAK CUKUP 〕
│ 💳 Saldo kamu : Rp${formatMoney(userMoney)}
│ 🎯 Taruhan    : Rp${formatMoney(amount)}
│
│ 📉 Kekurangan : Rp${formatMoney(amount - userMoney)}
╰────────────`
    )
  }

  const secretNumber = getRandomNumber()

  user.money = userMoney - amount

  const gameData = {
    chat: m.chat,
    sender: m.sender,
    amount,
    secretNumber,
    createdAt: Date.now(),
    answered: false,
    timer: null,
    key: null
  }

  conn.numberGuess[m.sender] = gameData

  const gameMessage = await conn.sendMessage(
    m.chat,
    {
      text: `╭─〔 🎯 NUMBER GUESS 〕
│ @${m.sender.split('@')[0]}
│
│ 💰 Taruhan : Rp${formatMoney(amount)}
│
│ 🎲 Tebak angka 1 - 10!
│
│ ↳ Balas pesan ini dengan angka
│ ↳ Ketik "batal" untuk membatalkan
│
│ ⏰ Waktu  : 30 detik
│ 🎁 Hadiah : x5
│ 💵 Menang : Rp${formatMoney(amount * 5)}
│
│ 💳 Saldo setelah taruhan:
│ Rp${formatMoney(user.money)}
╰────────────`,
      mentions: [m.sender]
    },
    {
      quoted: m
    }
  )

  gameData.key = gameMessage?.key || null

  if (!gameData.key) {
    user.money += amount
    delete conn.numberGuess[m.sender]

    return m.reply(
      '❌ Gagal membuat game. Taruhan kamu sudah dikembalikan.'
    )
  }

  gameData.timer = setTimeout(async () => {
    const game = conn.numberGuess[m.sender]

    if (!game) return
    if (game.answered) return

    game.answered = true

    const userData = global.db.data.users[m.sender]

    if (userData) {
      userData.money = Number(userData.money || 0) + game.amount
    }

    try {
      await editMessage(
        conn,
        game.chat,
        game.key,
        `╭─〔 ⏰ WAKTU HABIS 〕
│ @${m.sender.split('@')[0]}
│
│ Kamu tidak menjawab dalam
│ waktu 30 detik.
│
│ 🔐 Angka rahasia : ${game.secretNumber}
│ 💰 Taruhan       : Rp${formatMoney(game.amount)}
│
│ ↩️ Taruhan dikembalikan
│ 💳 Saldo baru    : Rp${formatMoney(userData?.money || 0)}
╰────────────`,
        [m.sender]
      )
    } catch (e) {
      console.error('NumberGuess timeout edit:', e)
    }

    delete conn.numberGuess[m.sender]
  }, 30000)
}

handler.before = async (m, { conn }) => {
  conn.numberGuess = conn.numberGuess || {}

  cleanExpiredGames(conn)

  const game = conn.numberGuess[m.sender]

  if (!game) return
  if (game.answered) return

  if (m.chat !== game.chat) return

  if (
    m.text &&
    m.text.trim().toLowerCase() === 'batal'
  ) {
    game.answered = true

    if (game.timer) {
      clearTimeout(game.timer)
      game.timer = null
    }

    const user = global.db.data.users[m.sender]

    if (user) {
      user.money = Number(user.money || 0) + game.amount
    }

    try {
      await editMessage(
        conn,
        game.chat,
        game.key,
        `╭─〔 ❌ GAME DIBATALKAN 〕
│ @${m.sender.split('@')[0]}
│
│ Permainan telah dibatalkan.
│
│ 💰 Taruhan dikembalikan
│ 💵 Refund : Rp${formatMoney(game.amount)}
│
│ 💳 Saldo baru:
│ Rp${formatMoney(user?.money || 0)}
╰────────────`,
        [m.sender]
      )
    } catch (e) {
      console.error('NumberGuess cancel edit:', e)
    }

    delete conn.numberGuess[m.sender]
    return
  }

  if (!m.quoted) return

  const quotedId =
    m.quoted?.key?.id ||
    m.quoted?.id ||
    m.quoted?.stanzaId ||
    null

  const gameMessageId = game.key?.id || null

  if (!quotedId || !gameMessageId) return
  if (quotedId !== gameMessageId) return

  const guess = Number(m.text)

  if (
    !Number.isInteger(guess) ||
    guess < 1 ||
    guess > 10
  ) {
    try {
      await editMessage(
        conn,
        game.chat,
        game.key,
        `╭─〔 ❌ INPUT TIDAK VALID 〕
│ @${m.sender.split('@')[0]}
│
│ Masukkan angka 1 - 10!
│
│ Contoh:
│ ➜ 7
│
│ ⏰ Waktu masih berjalan...
╰────────────`,
        [m.sender]
      )
    } catch (e) {
      console.error('NumberGuess invalid edit:', e)
    }

    return
  }

  game.answered = true

  if (game.timer) {
    clearTimeout(game.timer)
    game.timer = null
  }

  const user = global.db.data.users[m.sender]

  if (!user) {
    delete conn.numberGuess[m.sender]
    return
  }

  const isWin = guess === game.secretNumber

  if (isWin) {
    const winAmount = game.amount * 5

    user.money = Number(user.money || 0) + winAmount

    try {
      await editMessage(
        conn,
        game.chat,
        game.key,
        `╭─〔 🎉 MENANG! 〕
│ @${m.sender.split('@')[0]}
│
│ 🎯 Tebakan : ${guess}
│ 🔐 Angka   : ${game.secretNumber}
│
│ 💰 Taruhan : Rp${formatMoney(game.amount)}
│ 🎁 Hadiah  : Rp${formatMoney(winAmount)}
│ ✖️ Multiplier : x5
│
│ 💳 Saldo baru:
│ Rp${formatMoney(user.money)}
│
│ 🏆 Tebakan kamu benar!
╰────────────`,
        [m.sender]
      )
    } catch (e) {
      console.error('NumberGuess win edit:', e)
    }
  } else {
    try {
      await editMessage(
        conn,
        game.chat,
        game.key,
        `╭─〔 😢 KALAH 〕
│ @${m.sender.split('@')[0]}
│
│ 🎯 Tebakan : ${guess}
│ 🔐 Angka   : ${game.secretNumber}
│
│ 💰 Taruhan : Rp${formatMoney(game.amount)}
│
│ 💳 Saldo baru:
│ Rp${formatMoney(user.money)}
│
│ ❌ Tebakan kamu salah!
│ 🍀 Coba lagi lain kali.
╰────────────`,
        [m.sender]
      )
    } catch (e) {
      console.error('NumberGuess lose edit:', e)
    }
  }

  delete conn.numberGuess[m.sender]
}

handler.help = ['numberguess']
handler.tags = ['rpg']
handler.command = /^(numberguess)$/i
handler.register = true
handler.group = true
handler.rpg = true
handler.limit = 10

export default handler