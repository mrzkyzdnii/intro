const PETS = {
    cat: {
        name: 'Cat',
        emoji: '🐱',
        power: 1.05,
        ability: 'Claw Rush'
    },
    dog: {
        name: 'Dog',
        emoji: '🐶',
        power: 1.10,
        ability: 'Feral Bite'
    },
    fox: {
        name: 'Fox',
        emoji: '🦊',
        power: 1.15,
        ability: 'Flame Illusion'
    },
    robo: {
        name: 'Robo',
        emoji: '🤖',
        power: 1.20,
        ability: 'Plasma Cannon'
    },
    dragon: {
        name: 'Dragon',
        emoji: '🐉',
        power: 1.35,
        ability: 'Dragon Breath'
    },
    lion: {
        name: 'Lion',
        emoji: '🦁',
        power: 1.25,
        ability: 'Royal Roar'
    },
    rhinoceros: {
        name: 'Rhinoceros',
        emoji: '🦏',
        power: 1.30,
        ability: 'Iron Charge'
    },
    centaur: {
        name: 'Centaur',
        emoji: '🐎',
        power: 1.22,
        ability: 'Storm Arrow'
    },
    kyubi: {
        name: 'Kyubi',
        emoji: '🦊',
        power: 1.45,
        ability: 'Nine Flame Orbs'
    },
    griffin: {
        name: 'Griffin',
        emoji: '🦅',
        power: 1.40,
        ability: 'Sky Dive'
    },
    phonix: {
        name: 'Phonix',
        emoji: '🔥',
        power: 1.50,
        ability: 'Phoenix Inferno'
    },
    wolf: {
        name: 'Wolf',
        emoji: '🐺',
        power: 1.18,
        ability: 'Pack Assault'
    }
}

const MAX_LEVEL = 500

/*
 * Boss mempunyai power 3SX
 */
const BOSS_POWER = 3e21

const random = (min, max) => {
    min = Math.ceil(min)
    max = Math.floor(max)

    return Math.floor(
        Math.random() * (max - min + 1)
    ) + min
}

const formatNumber = number => {
    return Number(number || 0)
        .toLocaleString('id-ID')
}

const formatPower = number => {
    number = Number(number || 0)

    if (number >= 1e21) {
        return `${(number / 1e21)
            .toFixed(2)
            .replace(/\.00$/, '')}SX`
    }

    if (number >= 1e18) {
        return `${(number / 1e18)
            .toFixed(2)
            .replace(/\.00$/, '')}Qi`
    }

    if (number >= 1e15) {
        return `${(number / 1e15)
            .toFixed(2)
            .replace(/\.00$/, '')}Qa`
    }

    if (number >= 1e12) {
        return `${(number / 1e12)
            .toFixed(2)
            .replace(/\.00$/, '')}T`
    }

    if (number >= 1e9) {
        return `${(number / 1e9)
            .toFixed(2)
            .replace(/\.00$/, '')}B`
    }

    if (number >= 1e6) {
        return `${(number / 1e6)
            .toFixed(2)
            .replace(/\.00$/, '')}M`
    }

    if (number >= 1e3) {
        return `${(number / 1e3)
            .toFixed(2)
            .replace(/\.00$/, '')}K`
    }

    return formatNumber(number)
}

/*
 * ==========================================
 * EXP REQUIREMENT
 * ==========================================
 */

const expRequired = level => {

    if (level <= 1)
        return 0

    return Math.floor(
        1000 *
        Math.pow(level - 1, 2.25)
    )
}

const getLevel = exp => {

    exp = Number(exp || 0)

    let level = 1

    for (
        let i = 2;
        i <= MAX_LEVEL;
        i++
    ) {

        if (
            exp >= expRequired(i)
        ) {
            level = i
        } else {
            break
        }
    }

    return level
}

/*
 * ==========================================
 * SYNC PET
 * ==========================================
 */

const syncPet = (user, pet) => {

    const expKey = `${pet}exp`
    const exp = Number(user[expKey])

    user[expKey] = Number.isFinite(exp) && exp > 0
        ? exp
        : 0

    user[pet] = user[expKey] > 0
        ? getLevel(user[expKey])
        : 0

    return user[pet]
}

/*
 * ==========================================
 * NORMALIZE PET OWNERSHIP
 * ==========================================
 *
 * `.petshop` dan versi lama menyimpan jumlah/level pada
 * user[pet], sedangkan sistem EXP memakai user[pet]exp.
 * Nilai positif dari user[pet], termasuk 1, dimigrasikan
 * menjadi EXP positif agar petshop, feed, sell, stat, dan
 * battle membaca status kepemilikan yang sama.
 */
const normalizePet = (user, pet) => {

    const expKey = `${pet}exp`
    const storedExp = Number(user[expKey])
    const storedLevel = Number(user[pet])

    if (
        (!Number.isFinite(storedExp) || storedExp <= 0) &&
        Number.isFinite(storedLevel) &&
        storedLevel > 0
    ) {
        const level = Math.min(
            MAX_LEVEL,
            Math.max(1, Math.floor(storedLevel))
        )

        // Level 1 tetap harus memiliki EXP positif agar terdeteksi.
        user[expKey] = Math.max(1, expRequired(level))
    } else {
        user[expKey] = Number.isFinite(storedExp) && storedExp > 0
            ? storedExp
            : 0
    }

    return syncPet(user, pet)
}

const hasPet = (user, pet) =>
    Number(user[`${pet}exp`]) > 0

const clearPet = (user, pet) => {
    user[`${pet}exp`] = 0
    user[pet] = 0
}

/*
 * ==========================================
 * RANDOM PET
 * ==========================================
 */

const randomPet = () => {

    const pets =
        Object.keys(PETS)

    return pets[
        random(
            0,
            pets.length - 1
        )
    ]
}

/*
 * ==========================================
 * RANDOM ENEMY
 * ==========================================
 */

const createEnemy = level => {

    const pet =
        randomPet()

    const required =
        expRequired(level)

    let power

    if (level === 1) {

        power =
            random(
                1000,
                5000
            )

    } else {

        const min =
            Math.max(
                1,
                Math.floor(
                    required * 0.85
                )
            )

        const max =
            Math.max(
                min,
                Math.floor(
                    required * 1.25
                )
            )

        power =
            random(
                min,
                max
            )
    }

    return {
        pet,
        level,
        power,
        boss: false
    }
}

/*
 * ==========================================
 * BOSS
 * ==========================================
 */

const createBoss = () => {

    return {
        pet: randomPet(),
        level: 100,
        power: BOSS_POWER,
        boss: true
    }
}

/*
 * ==========================================
 * BATTLE POWER
 * ==========================================
 */

const UNLIMITED_PET_FOOD = false

const ATTACK_STYLES = {
    cat: 'menerkam dengan cakaran kilat',
    dog: 'menerjang dengan gigitan brutal',
    fox: 'melepaskan ilusi api',
    robo: 'menembakkan meriam plasma',
    dragon: 'menyemburkan naga api',
    lion: 'menghantam dengan raungan singa',
    rhinoceros: 'menyeruduk dengan tanduk baja',
    centaur: 'melepaskan hujan anak panah',
    kyubi: 'memanggil sembilan bola api',
    griffin: 'menukik dengan badai angin',
    phonix: 'menyerang menggunakan API PHOENIX',
    wolf: 'menerkam dalam mode kawanan'
}

const getAttackStyle = pet =>
    ATTACK_STYLES[pet] || 'melancarkan serangan spesial'

const getPetPower = (exp, pet) =>
    Number(exp || 0) * (PETS[pet]?.power || 1)

const wait = milliseconds =>
    new Promise(resolve => setTimeout(resolve, milliseconds))

const battlePower = (
    power,
    level,
    boss = false
) => {

    /*
     * Power tetap menjadi faktor utama.
     */

    let result =
        Number(power) *
        (
            0.85 +
            Math.random() * 0.30
        )

    /*
     * Level memberikan sedikit bonus.
     */

    result *=
        1 +
        (
            Math.max(
                0,
                level - 1
            ) * 0.002
        )

    /*
     * Boss dibuat sangat kuat
     * tapi tetap mengikuti power.
     */

    if (boss) {

        result *=
            0.98 +
            Math.random() * 0.04
    }

    return result
}

/*
 * ==========================================
 * BAR
 * ==========================================
 */

const battleBar = (
    player,
    enemy
) => {

    const total =
        player + enemy

    if (!total)
        return '░░░░░░░░░░'

    const percentage =
        player / total

    const filled =
        Math.round(
            percentage * 10
        )

    return (
        '█'.repeat(
            Math.max(
                0,
                Math.min(
                    10,
                    filled
                )
            )
        ) +
        '░'.repeat(
            10 -
            Math.max(
                0,
                Math.min(
                    10,
                    filled
                )
            )
        )
    )
}

/*
 * ==========================================
 * LOOT
 * ==========================================
 *
 * MENANG SELALU DAPAT LOOT.
 */

const getPetSellPrice = (level, pet) => {
    const data = PETS[pet]
    const levelValue = Math.max(1, Number(level) || 1)
    const basePrice =
        10000 +
        levelValue * 5000 +
        Math.pow(levelValue, 2) * 2500

    // Pet dengan power khusus lebih tinggi memiliki nilai jual sedikit lebih besar.
    const rarityMultiplier =
        0.9 + (data?.power || 1) * 0.1

    return Math.floor(basePrice * rarityMultiplier)
}

const getLoot = level => {

    const money =
        random(
            1000,
            Math.min(
                1000000,
                Math.max(
                    1000,
                    Math.floor(
                        10000 +
                        Math.pow(
                            level,
                            2
                        ) * 100
                    )
                )
            )
        )

    const loot = {
        money,
        emerald: 0,
        diamond: 0
    }

    /*
     * Minimal salah satu
     * selalu didapat.
     */

    if (
        Math.random() < 0.5
    ) {

        loot.emerald =
            random(1, 5)

    } else {

        loot.diamond =
            random(1, 5)
    }

    /*
     * 25% kemungkinan
     * mendapat loot kedua.
     */

    if (
        Math.random() < 0.25
    ) {

        if (
            loot.emerald > 0
        ) {

            loot.diamond =
                random(1, 5)

        } else {

            loot.emerald =
                random(1, 5)
        }
    }

    return loot
}


const getMessageId = message => message?.key?.id || message?.id || message?.stanzaId || null
const getQuotedId = quoted => quoted?.key?.id || quoted?.id || quoted?.stanzaId || null
const sendMention = (conn, chat, text, mentions, quoted) => conn.sendMessage(chat, { text, mentions }, { quoted })

const getOwnedPets = user => Object.keys(PETS).filter(pet => {
    normalizePet(user, pet)
    return hasPet(user, pet)
})

const formatPetChoices = (user, pets) => pets.map((pet, index) => {
    const data = PETS[pet]
    const exp = Number(user[`${pet}exp`] || 0)
    const level = syncPet(user, pet)
    return `${index + 1}) ${data.emoji} ${data.name}\n   Level: ${level}\n   Power: ${formatPower(getPetPower(exp, pet))}\n   Skill: ${data.ability}`
}).join('\n\n')

const stopPetDuelTimer = pending => {
    if (pending.timer) clearTimeout(pending.timer)
    pending.timer = null
    // Membatalkan callback timer yang mungkin sudah masuk antrean event loop.
    pending.timerToken = (pending.timerToken || 0) + 1
}

const armPetDuelTimer = (conn, pending, callback) => {
    stopPetDuelTimer(pending)
    const token = pending.timerToken

    pending.timer = setTimeout(async () => {
        // Cek object, token, dan fase agar timer lama tidak mengirim pesan
        // setelah jawaban sudah diproses.
        if (
            conn.petDuel?.[pending.target] !== pending ||
            pending.timerToken !== token
        ) return

        pending.timer = null
        pending.timerToken++
        await callback()
    }, 20000)
}

const finishPetDuel = (conn, pending) => {
    stopPetDuelTimer(pending)
    pending.phase = 'done'
    if (conn.petDuel?.[pending.target] === pending) delete conn.petDuel[pending.target]
}

const runBotBattle = async (conn, battle, quoted) => {
    const player = global.db.data.users[battle.player]
    normalizePet(player, battle.playerPet)
    const playerExp = Number(player[`${battle.playerPet}exp`] || 0)
    const playerLevel = syncPet(player, battle.playerPet)
    const playerPower = getPetPower(playerExp, battle.playerPet)
    const enemy = createEnemy(battle.enemyLevel)
    const playerData = PETS[battle.playerPet]
    const enemyData = PETS[enemy.pet]
    const playerScore = battlePower(playerPower, playerLevel)
    const enemyScore = battlePower(enemy.power, enemy.level)
    const playerDamage = Math.max(1, Math.floor(playerScore * 0.15))
    const enemyDamage = Math.max(1, Math.floor(enemyScore * 0.15))
    const hpBar = (value, max) => battleBar(Math.max(0, max - value), max)
    const frame = (title, extra = '') => `╭━━━〔 ${title} 〕━━━╮\n┃\n┃ 👤 @${battle.player.split('@')[0]}\n┃ ${playerData.emoji} *${playerData.name}*  •  LVL ${playerLevel}\n┃ ⚡ Power : ${formatPower(playerPower)}\n┃ ✦ Skill : ${playerData.ability}\n┃\n┃ ${battleBar(playerPower, enemy.power)}\n┃\n┃ 🤖 *BOT LVL ${enemy.level}*\n┃ ${enemyData.emoji} *${enemyData.name}*\n┃ ⚡ Power : ${formatPower(enemy.power)}\n┃ ✦ Skill : ${enemyData.ability}\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n${extra}`
    const mentions = [battle.player]
    const sent = await conn.sendMessage(battle.chat, { text: frame('⚔️ PET BATTLE', '\n╔══════════════════╗\n║  ARENA ONLINE...  ║\n╚══════════════════╝\n\n⏳ Kedua pet memasuki arena.'), mentions }, { quoted })
    const key = sent.key
    const edit = (title, extra) => conn.sendMessage(battle.chat, { text: frame(title, extra), mentions, edit: key })
    await wait(3000)
    await edit('🔥 ROUND 1 • OPENING', `\n┌─〔 ${playerData.emoji} SERANGAN PEMBUKA 〕─┐\n│ ${playerData.name} ${getAttackStyle(battle.playerPet)}!\n│\n│        ╭──────╮\n│   >>>  │ ⚡⚡⚡ │  >>>\n│        ╰──────╯\n└────────────────────\n\n💨 Serangan melesat menuju ${enemyData.name}!`)
    await wait(3000)
    await edit('💥 HIT CONFIRMED', `\n┌─〔 DAMAGE DEALT 〕─┐\n│ ${enemyData.emoji} ${enemyData.name} terkena damage!\n│\n│ -${formatPower(playerDamage)} HP\n│ ${hpBar(playerDamage, enemy.power)}\n└──────────────────\n\n✦ ${playerData.ability} aktif!\n╰─「 KRAK 💥 BOOM ⚡ 」─╯`)
    await wait(3000)
    await edit('⚡ COUNTER ATTACK', `\n┌─〔 BOT MEMBALAS 〕─┐\n│ ${enemyData.emoji} ${enemyData.name} ${getAttackStyle(enemy.pet)}!\n│\n│   ⚡ <====[ 💢 ]====> ⚡\n│\n│ @${battle.player.split('@')[0]} menerima\n│ damage sebesar -${formatPower(enemyDamage)} HP\n└──────────────────\n\n🔥 Arena bergetar! Serangan terakhir menentukan hasil.`)
    await wait(3000)
    await edit(playerScore >= enemyScore ? '🏆 VICTORY • FINISH' : '💀 DEFEAT • FINISH', `\n╔══════════════════╗\n║  ${playerScore >= enemyScore ? 'YOU WIN' : 'BOT WINS'}  ║\n╚══════════════════╝\n\n${playerData.emoji} ${formatPower(playerScore)}   VS   ${formatPower(enemyScore)} ${enemyData.emoji}\n\n${playerScore >= enemyScore ? `🏆 @${battle.player.split('@')[0]} menumbangkan BOT LVL ${enemy.level}!` : `💀 BOT LVL ${enemy.level} mengalahkan ${playerData.name}.`}\n\n✦ Skill: ${playerData.ability}\n✦ Skill bot: ${enemyData.ability}`)
    if (conn.petbattle?.[battle.player] === battle) delete conn.petbattle[battle.player]
}

const runPetDuel = async (conn, pending, targetPet, quoted) => {
    const challengerUser = global.db.data.users[pending.challenger]
    const targetUser = global.db.data.users[pending.target]
    if (!challengerUser || !targetUser) return

    normalizePet(challengerUser, pending.challengerPet)
    normalizePet(targetUser, targetPet)
    const cExp = Number(challengerUser[`${pending.challengerPet}exp`] || 0)
    const tExp = Number(targetUser[`${targetPet}exp`] || 0)
    const cLevel = syncPet(challengerUser, pending.challengerPet)
    const tLevel = syncPet(targetUser, targetPet)
    const cPower = getPetPower(cExp, pending.challengerPet)
    const tPower = getPetPower(tExp, targetPet)
    const cScore = battlePower(cPower, cLevel)
    const tScore = battlePower(tPower, tLevel)
    const cData = PETS[pending.challengerPet]
    const tData = PETS[targetPet]
    const winner = cScore === tScore ? null : (cScore > tScore ? pending.challenger : pending.target)
    const winnerPet = winner === pending.challenger ? cData : tData
    const result = winner ? `🏆 Pemenang: @${winner.split('@')[0]} dengan ${winnerPet.emoji} ${winnerPet.name}.` : '🤝 Hasil seri.'

    const text = (title, extra = '') => `╭━━━〔 ${title} 〕━━━╮\n┃\n┃ @${pending.challenger.split('@')[0]}\n┃ ${cData.emoji} *${cData.name}*  •  LVL ${cLevel}\n┃ ⚡ Power : ${formatPower(cPower)}\n┃ ✦ Skill : ${cData.ability}\n┃\n┃ ${battleBar(cPower, tPower)}\n┃        ⚔️ VS ⚔️\n┃\n┃ @${pending.target.split('@')[0]}\n┃ ${tData.emoji} *${tData.name}*  •  LVL ${tLevel}\n┃ ⚡ Power : ${formatPower(tPower)}\n┃ ✦ Skill : ${tData.ability}\n┃\n╰━━━━━━━━━━━━━━━━━━━━━━╯\n${extra}`
    const mentions = [pending.challenger, pending.target, ...(winner ? [winner] : [])]
    const cDamage = Math.max(1, Math.floor(cScore * 0.15))
    const tDamage = Math.max(1, Math.floor(tScore * 0.15))
    const sent = await conn.sendMessage(pending.chat, { text: text('⚔️ PET DUEL', '\n╔══════════════════╗\n║  PVP ARENA ONLINE  ║\n╚══════════════════╝\n\n🔥 Kedua trainer siap bertarung.'), mentions }, { quoted })
    const key = sent.key
    const edit = (title, extra) => conn.sendMessage(pending.chat, { text: text(title, extra), mentions, edit: key })
    await wait(3000)
    await edit('🔥 ROUND 1 • CHALLENGER', `\n┌─〔 @${pending.challenger.split('@')[0]} MENYERANG 〕─┐\n│ ${cData.emoji} ${cData.name} ${getAttackStyle(pending.challengerPet)}!\n│\n│        ╭──────╮\n│   >>>  │ ⚡⚡⚡ │  >>>\n│        ╰──────╯\n└────────────────────\n\n💨 Serangan mengarah ke ${tData.name}!`)
    await wait(3000)
    await edit('💥 DAMAGE CONFIRMED', `\n┌─〔 TARGET TERKENA 〕─┐\n│ ${tData.emoji} ${tData.name} terkena damage!\n│\n│ -${formatPower(cDamage)} HP\n│ ${battleBar(Math.max(1, tPower - cDamage), tPower)}\n└──────────────────\n\n✦ ${cData.ability} menembus pertahanan!\n╰─「 KRAK 💥 BOOM ⚡ 」─╯`)
    await wait(3000)
    await edit('⚡ ROUND 2 • COUNTER', `\n┌─〔 @${pending.target.split('@')[0]} MEMBALAS 〕─┐\n│ ${tData.emoji} ${tData.name} ${getAttackStyle(targetPet)}!\n│\n│   ⚡ <====[ 💢 ]====> ⚡\n│\n│ @${pending.challenger.split('@')[0]} menerima\n│ damage sebesar -${formatPower(tDamage)} HP\n└──────────────────\n\n🔥 Arena bergetar! Serangan penentu dilepaskan.`)
    await wait(3000)
    await edit(winner ? '🏆 DUEL SELESAI' : '🤝 DRAW', `\n╔══════════════════╗\n║  ${winner ? 'FINAL RESULT' : 'PERFECT DRAW'}  ║\n╚══════════════════╝\n\n${cData.emoji} ${formatPower(cScore)}   VS   ${formatPower(tScore)} ${tData.emoji}\n\n${result}\n\n✦ ${cData.name}: ${cData.ability}\n✦ ${tData.name}: ${tData.ability}`)
    finishPetDuel(conn, pending)
}

/*
 * ==========================================
 * HANDLER
 * ==========================================
 */

let handler = async (
    m,
    {
        conn
    }
) => {

    const user =
        global.db.data.users[
            m.sender
        ]

    if (!user) {

        return m.reply(
            '❌ Data pengguna belum tersedia.'
        )
    }

    /*
     * Pastikan object penting ada.
     */

    user.money =
        Number(user.money || 0)

    user.petfood =
        Number(user.petfood || 0)

    user.emerald =
        Number(user.emerald || 0)

    user.diamond =
        Number(user.diamond || 0)

    for (
        const pet of Object.keys(PETS)
    ) {

        user[pet] =
            Number(user[pet] || 0)

        normalizePet(
            user,
            pet
        )
    }

    /*
     * ==========================================
     * ARGUMENT
     * ==========================================
     */

    const args =
        String(m.text || '')
            .trim()
            .split(/\s+/)
            .slice(1)

    /*
     * ==========================================
     * .PET
     * ==========================================
     */

    if (!args.length) {

        return m.reply(`
╭━━━〔 🐾 PET SYSTEM 〕━━━╮
┃
┃ 📊 *Stat Pet*
┃ └─ .pet stat
┃
┃ ⚔️ *Battle Pet*
┃ ├─ .pet battle robo lvl1
┃ ├─ .pet battle phonix lvl500
┃ └─ .pet battle robo @user
┃
┃ 🍖 *Feed Pet*
┃ ├─ .pet feed phonix 1
┃ └─ .pet feed phonix 5
┃
┃ 💰 *Sell Pet*
┃ └─ .pet sell robo
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

🐾 Battle bot tersedia dari *lvl1 sampai lvl500*.
Power dan EXP pet menentukan kekuatan
pertarungan.

🤖 Gunakan *lvl1/lvl500* untuk melawan bot.
⚔️ Mention *@user* untuk duel pemain lain.
`.trim())
    }

    /*
     * ==========================================
     * STAT
     * ==========================================
     */

    if (
        args[0].toLowerCase() === 'stat'
    ) {

        let text = `
╭━━━〔 📊 PET STATISTICS 〕━━━╮
┃
`

        let ownedPets = 0

        for (
            const [id, data]
            of Object.entries(PETS)
        ) {

            const exp =
                Number(
                    user[`${id}exp`] || 0
                )

            // EXP 0 berarti pet belum dimiliki atau sudah dijual.
            if (exp <= 0) {
                continue
            }

            ownedPets++

            const level =
                getLevel(exp)

            text +=
`┃ ${data.emoji} *${data.name}*
┃    Level : ${level}/${MAX_LEVEL}
┃    EXP   : ${formatPower(exp)}
┃    Power : ${formatPower(getPetPower(exp, id))}
┃    Ability: ${data.ability} (+${Math.round((data.power - 1) * 100)}%)
┃
`
        }

        if (!ownedPets) {
            return m.reply(`
╭━━━〔 📊 PET STATISTICS 〕━━━╮
┃
┃ Kamu belum memiliki pet.
┃
┃ Gunakan:
┃ .pet feed robo 1
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`.trim())
        }

        text +=
`╰━━━━━━━━━━━━━━━━━━━━━━╯`

        return m.reply(
            text.trim()
        )
    }

    /*
     * ==========================================
     * FEED
     * ==========================================
     */

    if (
        args[0].toLowerCase() === 'feed'
    ) {

        const pet =
            args[1]?.toLowerCase()

        const amount =
            Number(args[2])

        if (
            !PETS[pet]
        ) {

            return m.reply(
`❌ Pet tidak ditemukan.

Contoh:
.pet feed phonix 5`
            )
        }

        if (
            !Number.isInteger(amount) ||
            amount < 1
        ) {

            return m.reply(
`❌ Jumlah food tidak valid.

Contoh:
.pet feed phonix 5`
            )
        }

        const petExp =
            Number(user[`${pet}exp`])

        if (!hasPet(user, pet) || !Number.isFinite(petExp)) {

            return m.reply(
`❌ Kamu belum memiliki ${PETS[pet].name}.`
            )
        }

        // Pet Food dibuat tanpa batas. Nilai lama tetap dibiarkan di database
        // agar kompatibel dengan data pengguna yang sudah tersimpan.
        if (!UNLIMITED_PET_FOOD && user.petfood < amount) {

            return m.reply(
`❌ Pet Food tidak cukup.

🍖 Food kamu : ${formatNumber(user.petfood)}
🍖 Dibutuhkan : ${formatNumber(amount)}`
            )
        }

        const expKey =
            `${pet}exp`

        const oldExp =
            Number(
                user[expKey]
            )

        const oldLevel =
            getLevel(oldExp)

        let gainedExp = 0

        for (
            let i = 0;
            i < amount;
            i++
        ) {

            gainedExp +=
                random(
                    1000,
                    2000
                )
        }

        if (!UNLIMITED_PET_FOOD) {
            user.petfood -= amount
        }

        user[expKey] +=
            gainedExp

        const newLevel =
            syncPet(
                user,
                pet
            )

        const data =
            PETS[pet]

        let text = `
╭━━━〔 🍖 PET FEED 〕━━━╮
┃
┃ ${data.emoji} *${data.name}*
┃
┃ 🍖 Food Used
┃ ${formatNumber(amount)} (unlimited)
┃
┃ ✨ EXP Gained
┃ +${formatNumber(gainedExp)}
┃
┃ 📊 Level
┃ ${oldLevel} → ${newLevel}
┃
┃ ⚡ Power
┃ ${formatPower(
    user[expKey]
)}
┃
┃ 🍖 Remaining Food
┃ ∞ (tanpa batas)
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯
`.trim()

        if (
            newLevel > oldLevel
        ) {

            text +=
`

🎉 *LEVEL UP!*

${data.emoji} ${data.name}
sekarang mencapai *Level ${newLevel}*!`
        }

        return m.reply(text)
    }

    /*
     * ==========================================
     * SELL PET
     * ==========================================
     */

    if (
        args[0].toLowerCase() === 'sell'
    ) {
        const pet = args[1]?.toLowerCase()

        if (!PETS[pet]) {
            return m.reply(`❌ Pet tidak ditemukan.

Contoh:
.pet sell robo`)
        }

        const expKey = `${pet}exp`
        const petExp = Number(user[expKey])

        if (!hasPet(user, pet) || !Number.isFinite(petExp)) {
            return m.reply(`❌ Kamu belum memiliki ${PETS[pet].name}.

Berikan food terlebih dahulu:
.pet feed ${pet} 1`)
        }

        const level = syncPet(user, pet)
        const price = getPetSellPrice(level, pet)
        const data = PETS[pet]

        user.money += price
        clearPet(user, pet)

        return m.reply(`
╭━━━〔 💰 PET SOLD 〕━━━╮
┃
┃ ${data.emoji} *${data.name}*
┃ Level : ${level}
┃ Ability: ${data.ability}
┃
┃ 💵 Harga Jual
┃ +Rp. ${formatNumber(price)}
┃
┃ 💰 Total Money
┃ Rp. ${formatNumber(user.money)}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

${data.emoji} ${data.name} telah dijual.
EXP pet direset ke 0 dan dapat dibangun kembali kapan saja.`.trim())
    }

    /*
     * ==========================================
     * BATTLE
     * ==========================================
     */

    if (
        args[0].toLowerCase() === 'battle'
    ) {
        const pet = args[1]?.toLowerCase()
        const target = m.mentionedJid?.[0]
        const levelArg = args[2]?.toLowerCase()

        if (!PETS[pet]) return m.reply('❌ Pet tidak ditemukan. Contoh: .pet battle robo lvl1 atau .pet battle robo @user')

        if (!target) {
            if (!/^lvl\d+$/.test(levelArg || '')) return m.reply('❌ Gunakan lvl1 sampai lvl500 untuk melawan bot, atau mention @user untuk duel PvP.')
            const level = Number(levelArg.slice(3))
            if (level < 1 || level > 500) return m.reply('❌ Level bot hanya tersedia dari lvl1 sampai lvl500.')
            conn.petbattle = conn.petbattle || {}
            if (conn.petbattle[m.sender]) return m.reply('⚔️ Battle pet kamu sebelumnya masih berlangsung.')
            const battle = { chat: m.chat, player: m.sender, playerPet: pet, enemyLevel: level }
            conn.petbattle[m.sender] = battle
            try {
                await runBotBattle(conn, battle, m)
            } catch (error) {
                console.error('[PET BATTLE]', error)
                delete conn.petbattle[m.sender]
            }
            return
        }
        if (target === m.sender) return m.reply('❌ Kamu tidak dapat menantang diri sendiri.')

        conn.petDuel = conn.petDuel || {}
        if (conn.petDuel[target]) return m.reply('⚔️ Pengguna tersebut masih memiliki tantangan pet yang belum selesai.')
        if (Object.values(conn.petDuel).some(item => item.challenger === m.sender)) return m.reply('⚔️ Kamu masih memiliki tantangan pet yang belum selesai.')

        const challengerUser = global.db.data.users[m.sender]
        const targetUser = global.db.data.users[target]
        if (!challengerUser || !targetUser) return m.reply('❌ Data salah satu pengguna tidak ditemukan.')

        normalizePet(challengerUser, pet)
        const challengerExp = Number(challengerUser[`${pet}exp`] || 0)
        if (challengerExp <= 0) return m.reply(`${PETS[pet].emoji} *${PETS[pet].name}* belum kamu miliki atau belum mempunyai EXP.`)
        if (!getOwnedPets(targetUser).length) return sendMention(conn, m.chat, `❌ @${target.split('@')[0]} belum memiliki pet untuk bertarung.`, [target], m)

        const challenge = await sendMention(conn, m.chat, `╭─〔 ⚔️ TANTANGAN PET 〕
│ @${m.sender.split('@')[0]} menantang
│ @${target.split('@')[0]} untuk adu pet.
│
│ Pet penantang: ${PETS[pet].emoji} ${PETS[pet].name}
│ Power: ${formatPower(getPetPower(challengerExp, pet))}
│ Skill: ${PETS[pet].ability}
│
│ @${target.split('@')[0]}, apakah kamu menerima?
│
│ Balas pesan ini dengan:
│ 1 untuk menerima
│ 2 untuk menolak
│
│ Batas waktu: 20 detik
╰────────────`, [m.sender, target], m)

        const pending = { chat: m.chat, challenger: m.sender, target, challengerPet: pet, messageId: getMessageId(challenge), phase: 'accept', timer: null, timerToken: 0 }
        conn.petDuel[target] = pending
        armPetDuelTimer(conn, pending, async () => {
            if (pending.phase !== 'accept') return
            finishPetDuel(conn, pending)
            await sendMention(conn, pending.chat, `⏱️ Tantangan dari @${pending.challenger.split('@')[0]} dibatalkan karena @${pending.target.split('@')[0]} tidak merespons.`, [pending.challenger, pending.target], m)
        })
        return
    }

    /*
     * ==========================================
     * UNKNOWN COMMAND
     * ==========================================
     */

    return m.reply(`
❌ Command pet tidak ditemukan.

Ketik *.pet* untuk melihat menu.
`.trim())
}


handler.before = async (m, { conn }) => {
    conn.petDuel = conn.petDuel || {}
    const answer = String(m.text || '').trim()
    const pending = conn.petDuel[m.sender]
    if (!pending || pending.chat !== m.chat || !m.quoted) return

    if (pending.phase === 'accept') {
        if (!/^(1|2)$/.test(answer)) return
        if (getQuotedId(m.quoted) !== pending.messageId) return
        if (answer === '2') {
            finishPetDuel(conn, pending)
            return sendMention(conn, m.chat, `❌ @${pending.target.split('@')[0]} menolak tantangan pet.`, [pending.challenger, pending.target], m)
        }

        // Jawaban "1" sudah diterima; hentikan timer accept SEBELUM
        // operasi async agar timer lama tidak balapan dengan proses ini.
        stopPetDuelTimer(pending)
        pending.phase = 'select'

        const targetUser = global.db.data.users[pending.target]
        const pets = targetUser ? getOwnedPets(targetUser) : []
        if (!pets.length) {
            finishPetDuel(conn, pending)
            return m.reply('❌ Kamu tidak memiliki pet yang dapat dipertarungkan.')
        }
        pending.targetPets = pets
        const selection = await sendMention(conn, m.chat, `╭─〔 🐾 PILIH PET 〕
│ @${pending.target.split('@')[0]}, pilih pet untuk bertarung:
│
${formatPetChoices(targetUser, pets).split('\n').map(line => `│ ${line}`).join('\n')}
│
│ Balas pesan ini dengan nomor pet.
│ Batas waktu: 20 detik
╰────────────`, [pending.target], m)
        pending.selectionMessageId = getMessageId(selection)
        armPetDuelTimer(conn, pending, async () => {
            if (pending.phase !== 'select') return
            finishPetDuel(conn, pending)
            await conn.sendMessage(pending.chat, { text: '⏱️ Waktu pemilihan pet habis.' }, { quoted: m })
        })
        return
    }

    if (pending.phase === 'select') {
        if (!/^\d+$/.test(answer)) return
        if (getQuotedId(m.quoted) !== pending.selectionMessageId) return
        const targetPet = pending.targetPets?.[Number(answer) - 1]
        if (!targetPet) return m.reply('❌ Nomor pet tidak valid. Balas daftar pet dengan nomor yang tersedia.')
        const targetUser = global.db.data.users[pending.target]
        if (!targetUser || !hasPet(targetUser, targetPet)) {
            finishPetDuel(conn, pending)
            return m.reply('❌ Pet tersebut sudah tidak tersedia.')
        }
        // Konsumsi jawaban secara atomik sebelum battle async dimulai.
        stopPetDuelTimer(pending)
        pending.phase = 'battle'
        await runPetDuel(conn, pending, targetPet, m)
    }
}

handler.help = [
    'pet'
]

handler.tags = [
    'rpg'
]

handler.command =
    /^pet$/i

handler.group = true

export default handler