import axios from 'axios'

const IG_COOKIE = ''

const shortcodeToId = (shortcode) => {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_'
  let id = BigInt(0)
  for (let i = 0; i < shortcode.length; i++) {
    id = id * BigInt(64) + BigInt(alphabet.indexOf(shortcode[i]))
  }
  return id.toString()
}

const scraper = async (igUrl, customCookie = IG_COOKIE) => {
  const codeMatch = igUrl.match(/\/(?:reel|reels|p)\/([A-Za-z0-9_-]+)/)
  if (!codeMatch) throw 'Link Instagram tidak valid.'

  const shortcode = codeMatch[1]
  const mediaId = shortcodeToId(shortcode)

  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none'
  }

  if (customCookie) headers['Cookie'] = customCookie

  const res = await axios.get(`https://www.instagram.com/reel/${shortcode}/`, {
    headers,
    maxRedirects: 5
  })

  const html = typeof res.data === 'string' ? res.data : ''

  let videoData = null
  let gating = null
  let user = null

  const scriptRegex = new RegExp('<script[^>]*>([\\s\\S]*?)<\\/script>', 'gi')
  let match

  while ((match = scriptRegex.exec(html)) !== null) {
    const content = match[1]

    if (content.includes('xig_polaris_media')) {
      try {
        const json = JSON.parse(content)

        const findMedia = (obj) => {
          if (!obj || typeof obj !== 'object' || videoData) return

          if (obj.xig_polaris_media) {
            const m = obj.xig_polaris_media
            gating = m.gating_ruling

            if (m.if_not_gated_logged_out) {
              videoData = m.if_not_gated_logged_out
            }

            return
          }

          for (const k of Object.keys(obj)) {
            findMedia(obj[k])
          }
        }

        findMedia(json)
      } catch (e) {}
    }

    if (content.includes('xig_logged_out_dynamic_dialog_info')) {
      try {
        const json = JSON.parse(content)

        const findUser = (obj) => {
          if (!obj || typeof obj !== 'object' || user) return

          if (obj.xig_logged_out_dynamic_dialog_info?.user) {
            user = obj.xig_logged_out_dynamic_dialog_info.user
            return
          }

          for (const k of Object.keys(obj)) {
            findUser(obj[k])
          }
        }

        findUser(json)
      } catch (e) {}
    }
  }

  const directMp4 =
    html.match(/"video_url":"([^"]+)"/)?.[1]?.replace(/\\u0026/g, '&')?.replace(/\\/g, '') ||
    html.match(/property="og:video"[^>]*content="([^"]+)"/i)?.[1] ||
    videoData?.video_versions?.[0]?.url

  const thumbnail =
    html.match(/"thumbnail_src":"([^"]+)"/)?.[1]?.replace(/\\u0026/g, '&')?.replace(/\\/g, '') ||
    html.match(/property="og:image"[^>]*content="([^"]+)"/i)?.[1] ||
    user?.profile_pic_url

  if (gating && !directMp4) {
    throw `Video ini terkena pembatasan usia (${gating.title || '18+'}). Owner: @${user?.username || 'unknown'}. Masukkan cookie sessionid agar bot bisa mengunduh konten 18+.`
  }

  if (!directMp4) {
    throw 'Gagal mengekstrak video Instagram. Pastikan akun tidak privat.'
  }

  return {
    shortcode,
    mediaId,
    owner: user?.username || null,
    ownerId: user?.pk || null,
    thumbnail,
    videoUrl: directMp4
  }
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} https://www.instagram.com/reel/Ddu-AzmOA80/`

  const result = await scraper(text)

  const caption = `*Instagram Reel Downloader*
*ID:* ${result.shortcode}
*Owner:* @${result.owner || '-'}
*Media ID:* ${result.mediaId}`

  await conn.sendFile(
    m.chat,
    result.videoUrl,
    `${result.shortcode}.mp4`,
    caption,
    m
  )
}

handler.help = ['ig2']
handler.tags = ['downloader']
handler.command = /^(ig2)$/i
handler.limit = 10

export default handler