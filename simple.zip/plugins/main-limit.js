import { createCanvas } from '@napi-rs/canvas'

const roundedRect = (ctx, x, y, w, h, r) => {
  const radius = Math.min(r, w / 2, h / 2)
  ctx.beginPath()
  ctx.moveTo(x + radius, y)
  ctx.arcTo(x + w, y, x + w, y + h, radius)
  ctx.arcTo(x + w, y + h, x, y + h, radius)
  ctx.arcTo(x, y + h, x, y, radius)
  ctx.arcTo(x, y, x + w, y, radius)
  ctx.closePath()
}

const fitText = (ctx, text, maxWidth, startSize, weight = '800') => {
  let size = startSize
  while (size > 20) {
    ctx.font = `${weight} ${size}px Sans`
    if (ctx.measureText(text).width <= maxWidth) return size
    size -= 2
  }
  return size
}

let handler = async (m, { conn, isOwner, isPrems }) => {
  let who

  if (m.isGroup) {
    who = m.mentionedJid?.[0] || m.sender
  } else {
    who = m.sender
  }

  const user = global.db.data.users[who]

  if (!user) {
    return m.reply('Pengguna tidak ditemukan di database.')
  }

  const name = user.registered
    ? user.name
    : await conn.getName(who)

  const limitNow = Number(user.limit || 0)
  const unlimited = Boolean(isPrems)
  const status = isOwner
    ? 'OWNER ACCOUNT'
    : isPrems
      ? 'PREMIUM ACCOUNT'
      : user.level > 999
        ? 'ELITE ACCOUNT'
        : 'FREE ACCOUNT'

  const limitText = unlimited
    ? 'UNLIMITED'
    : new Intl.NumberFormat('id-ID').format(limitNow)

  const safeName = name.length > 22 ? `${name.slice(0, 21)}…` : name
  const userTag = `@${who.split('@')[0]}`
  const width = 1200
  const height = 720
  const canvas = createCanvas(width, height)
  const ctx = canvas.getContext('2d')

  // Background.
  const background = ctx.createLinearGradient(0, 0, width, height)
  background.addColorStop(0, '#080f21')
  background.addColorStop(0.5, '#10234a')
  background.addColorStop(1, '#24174d')
  ctx.fillStyle = background
  ctx.fillRect(0, 0, width, height)

  const glow = (x, y, radius, color) => {
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius)
    gradient.addColorStop(0, color)
    gradient.addColorStop(1, 'rgba(0,0,0,0)')
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)
  }

  glow(1050, 70, 430, 'rgba(111, 93, 255, 0.27)')
  glow(75, 690, 420, 'rgba(40, 204, 255, 0.18)')
  glow(720, 360, 380, 'rgba(191, 72, 255, 0.10)')

  // Decorative diagonal lines.
  ctx.strokeStyle = 'rgba(255,255,255,0.06)'
  ctx.lineWidth = 2
  for (let i = -height; i < width; i += 90) {
    ctx.beginPath()
    ctx.moveTo(i, 0)
    ctx.lineTo(i + height, height)
    ctx.stroke()
  }

  // Main card.
  const cardX = 70
  const cardY = 70
  const cardW = 1060
  const cardH = 580

  ctx.save()
  ctx.shadowColor = 'rgba(0,0,0,0.48)'
  ctx.shadowBlur = 40
  ctx.shadowOffsetY = 18
  roundedRect(ctx, cardX, cardY, cardW, cardH, 40)
  const cardGradient = ctx.createLinearGradient(cardX, cardY, cardX + cardW, cardY + cardH)
  cardGradient.addColorStop(0, '#202e62')
  cardGradient.addColorStop(0.48, '#3a2772')
  cardGradient.addColorStop(1, '#74357e')
  ctx.fillStyle = cardGradient
  ctx.fill()
  ctx.restore()

  // Glass highlight and decoration.
  ctx.save()
  roundedRect(ctx, cardX, cardY, cardW, cardH, 40)
  ctx.clip()

  const shine = ctx.createLinearGradient(100, 70, 930, 650)
  shine.addColorStop(0, 'rgba(255,255,255,0.16)')
  shine.addColorStop(0.32, 'rgba(255,255,255,0.025)')
  shine.addColorStop(1, 'rgba(255,255,255,0)')
  ctx.fillStyle = shine
  ctx.fillRect(cardX, cardY, cardW, cardH)

  ctx.fillStyle = 'rgba(255,255,255,0.08)'
  ctx.beginPath()
  ctx.arc(1070, 155, 210, 0, Math.PI * 2)
  ctx.fill()
  ctx.beginPath()
  ctx.arc(1090, 555, 230, 0, Math.PI * 2)
  ctx.fill()
  ctx.restore()

  // Header.
  ctx.fillStyle = '#eeeaff'
  ctx.font = '800 27px Sans'
  ctx.fillText('LIMIT WALLET', 125, 145)
  ctx.fillStyle = 'rgba(238,234,255,0.68)'
  ctx.font = '500 19px Sans'
  ctx.fillText('DIGITAL ACCESS CARD', 125, 178)

  // Ikon petir / limit.
  ctx.save()
  ctx.shadowColor = 'rgba(121, 239, 255, 0.6)'
  ctx.shadowBlur = 18
  ctx.fillStyle = '#90f5ff'
  ctx.beginPath()
  ctx.moveTo(1046, 108)
  ctx.lineTo(1007, 153)
  ctx.lineTo(1037, 153)
  ctx.lineTo(1019, 188)
  ctx.lineTo(1071, 133)
  ctx.lineTo(1041, 133)
  ctx.closePath()
  ctx.fill()
  ctx.restore()

  // Label dan nilai limit.
  ctx.fillStyle = 'rgba(244,242,255,0.72)'
  ctx.font = '500 24px Sans'
  ctx.fillText('LIMIT TERSEDIA', 125, 270)

  const limitSize = fitText(ctx, limitText, 890, unlimited ? 78 : 92)
  ctx.font = `800 ${limitSize}px Sans`
  ctx.fillStyle = '#ffffff'
  ctx.fillText(limitText, 120, 365)

  if (!unlimited) {
    ctx.fillStyle = 'rgba(244,242,255,0.58)'
    ctx.font = '500 21px Sans'
    ctx.fillText('request tersisa untuk digunakan', 125, 397)
  } else {
    ctx.fillStyle = '#a2faff'
    ctx.font = '700 21px Sans'
    ctx.fillText('akses tanpa batas untuk pengguna premium', 125, 397)
  }

  // Divider.
  ctx.strokeStyle = 'rgba(255,255,255,0.2)'
  ctx.lineWidth = 2
  ctx.beginPath()
  ctx.moveTo(125, 435)
  ctx.lineTo(1075, 435)
  ctx.stroke()

  // User details.
  ctx.fillStyle = 'rgba(244,242,255,0.62)'
  ctx.font = '500 19px Sans'
  ctx.fillText('PEMILIK AKUN', 125, 486)
  ctx.fillStyle = '#ffffff'
  ctx.font = '700 28px Sans'
  ctx.fillText(safeName, 125, 525)

  ctx.fillStyle = 'rgba(244,242,255,0.62)'
  ctx.font = '500 19px Sans'
  ctx.fillText('ACCOUNT STATUS', 760, 486)
  ctx.fillStyle = '#a2faff'
  ctx.font = '800 21px Sans'
  ctx.fillText(status, 760, 525)

  // Footer.
  ctx.fillStyle = 'rgba(255,255,255,0.6)'
  ctx.font = '500 18px Sans'
  ctx.fillText(userTag, 125, 590)
  ctx.fillStyle = '#d9c7ff'
  ctx.font = '800 19px Sans'
  ctx.fillText('MRZKYZDNI • LIMIT SERVICE', 835, 590)

  const buffer = canvas.toBuffer('image/png')

  return conn.sendMessage(m.chat, {
    image: buffer,
    caption: `Limit ${name}: ${unlimited ? 'Unlimited' : limitText}`,
    mentions: [who]
  }, {
    quoted: m
  })
}

handler.help = ['limit']
handler.tags = ['xp']
handler.command = /^(limit)$/i
handler.register = false

export default handler