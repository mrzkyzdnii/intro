import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import axios from 'axios'

const W = 1080
const H = 721

try {
  GlobalFonts.registerFromPath('./data/src/font/Roboto-Medium.ttf', 'Roboto')
} catch {}

const makeFakeInstagram = async ({
  name = 'M Rizky Zadani', username = 'mrzkyzdnii', posts = '0',
  followers = '57', following = '61', bio = 'why', avatarInput = null,
} = {}) => {
  const canvas = createCanvas(W, H)
  const ctx = canvas.getContext('2d')
  const bg = '#0c0f13', white = '#f5f6f7', muted = '#aeb3bd', panel = '#2b3038', outline = '#313640'
  const text = (v, x, y, size, color = white, weight = 500, align = 'left') => {
    ctx.font = `${weight} ${size}px "Roboto", Arial, sans-serif`
    ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'alphabetic'
    ctx.fillText(String(v ?? ''), x, y)
  }
  const stroke = (color = white, width = 4) => { ctx.strokeStyle = color; ctx.lineWidth = width; ctx.lineCap = 'round'; ctx.lineJoin = 'round' }
  const rr = (x, y, w, h, r, fill = null, border = null, width = 1) => {
    ctx.beginPath(); ctx.roundRect(x, y, w, h, r)
    if (fill) { ctx.fillStyle = fill; ctx.fill() }
    if (border) { ctx.strokeStyle = border; ctx.lineWidth = width; ctx.stroke() }
  }

  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H)

  // Header icons.
  stroke(white, 5); ctx.beginPath(); ctx.moveTo(33, 57); ctx.lineTo(77, 57); ctx.moveTo(55, 35); ctx.lineTo(55, 80); ctx.stroke()
  rr(397, 51, 21, 24, 3, null, white, 4); ctx.beginPath(); ctx.arc(407.5, 49, 9, Math.PI, 0); ctx.stroke()
  const cleanUsername = String(username || '').replace(/^@/, '')
  const usernameSize = 43, usernameX = 437, usernameY = 73, maxUsernameWidth = 245
  ctx.font = `500 ${usernameSize}px "Roboto", Arial, sans-serif`
  let displayUsername = cleanUsername || 'mrzkyzdnii'
  while (ctx.measureText(displayUsername).width > maxUsernameWidth && displayUsername.length > 1) displayUsername = `${displayUsername.slice(0, -2)}…`
  const usernameWidth = ctx.measureText(displayUsername).width
  text(displayUsername, usernameX, usernameY, usernameSize, white, 500)
  const chevronX = usernameX + usernameWidth + 25
  stroke(white, 4); ctx.beginPath(); ctx.moveTo(chevronX - 10, 52); ctx.lineTo(chevronX, 62); ctx.lineTo(chevronX + 10, 52); ctx.stroke()
  // Threads-like mark.
  stroke(white, 4); ctx.beginPath(); ctx.arc(893, 58, 23, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(892, 58, 9, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.moveTo(895, 58); ctx.bezierCurveTo(914, 58, 917, 69, 911, 77); ctx.bezierCurveTo(904, 87, 884, 86, 878, 75); ctx.stroke()
  for (const y of [39, 57, 76]) { ctx.beginPath(); ctx.moveTo(983, y); ctx.lineTo(1027, y); ctx.stroke() }

  // Avatar.
  let avatar = null
  if (avatarInput) {
    try {
      if (Buffer.isBuffer(avatarInput)) avatar = await loadImage(avatarInput)
      else if (/^https?:\/\//i.test(String(avatarInput))) {
        const r = await axios.get(String(avatarInput), { responseType: 'arraybuffer', timeout: 15000 })
        avatar = await loadImage(Buffer.from(r.data))
      }
    } catch (e) { console.log('Avatar gagal dimuat:', e.message) }
  }
  const cx = 129, cy = 309, size = 148
  ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, 74, 0, Math.PI * 2); ctx.clip()
  if (avatar) {
    const a = avatar.width / avatar.height, dw = a > 1 ? size * a : size, dh = a > 1 ? size : size / a
    ctx.drawImage(avatar, cx - dw / 2, cy - dh / 2, dw, dh)
  } else { ctx.fillStyle = '#3d4248'; ctx.fillRect(cx - 74, cy - 74, size, size); text(String(name || 'U').trim()[0].toUpperCase(), cx, cy + 28, 76, white, 500, 'center') }
  ctx.restore()
  ctx.fillStyle = white; ctx.beginPath(); ctx.arc(200, 348, 22, 0, Math.PI * 2); ctx.fill(); text('+', 200, 356, 35, '#121519', 500, 'center')

  // Avatar hint bubble.
  rr(57, 133, 168, 114, 34, '#2d333b'); text('Make this', 141, 173, 21, muted, 500, 'center'); text('space', 141, 198, 21, muted, 500, 'center'); text('yours...', 141, 223, 21, muted, 500, 'center')
  ctx.fillStyle = '#2d333b'; ctx.beginPath(); ctx.moveTo(91, 238); ctx.lineTo(116, 253); ctx.lineTo(105, 232); ctx.closePath(); ctx.fill()

  // Profile data.
  text(String(name || 'M Rizky Zadani').slice(0, 25), 282, 219, 28, white, 500)
  text(posts, 282, 276, 29, white, 500); text('posts', 282, 314, 28, white, 500)
  text(followers, 513, 276, 29, white, 500); text('followers', 513, 314, 28, white, 500)
  text(following, 792, 276, 29, white, 500); text('following', 792, 314, 28, white, 500)
  text(String(bio || '').slice(0, 70), 38, 419, 27, white, 500)

  // Buttons.
  rr(38, 454, 229, 55, 28, null, outline, 1); stroke(muted, 3); ctx.beginPath(); ctx.moveTo(61, 481); ctx.lineTo(81, 481); ctx.moveTo(71, 471); ctx.lineTo(71, 491); ctx.stroke(); text('Add banners', 94, 490, 23, muted, 500)
  rr(28, 538, 460, 75, 19, panel); rr(502, 538, 460, 75, 19, panel); rr(976, 538, 73, 75, 19, panel)
  text('Edit profile', 258, 586, 28, white, 500, 'center'); text('Share profile', 732, 586, 28, white, 500, 'center')
  stroke(white, 3); ctx.beginPath(); ctx.arc(1020, 567, 7, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(1020, 588, 12, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke(); ctx.beginPath(); ctx.moveTo(991, 577); ctx.lineTo(1007, 577); ctx.moveTo(999, 569); ctx.lineTo(999, 585); ctx.stroke()

  // Bottom navigation icons.
  for (let row = 0; row < 3; row++) for (let col = 0; col < 3; col++) rr(113 + col * 16, 645 + row * 16, 11, 11, 2, white)
  stroke(muted, 4); rr(381, 646, 47, 48, 12, null, muted, 4); ctx.beginPath(); ctx.moveTo(400, 658); ctx.lineTo(414, 670); ctx.lineTo(400, 682); ctx.closePath(); ctx.stroke()
  stroke(muted, 4); ctx.beginPath(); ctx.moveTo(656, 660); ctx.lineTo(674, 645); ctx.lineTo(686, 656); ctx.moveTo(674, 645); ctx.lineTo(674, 679); ctx.quadraticCurveTo(674, 690, 686, 690); ctx.lineTo(700, 690); ctx.moveTo(699, 690); ctx.lineTo(691, 681); ctx.moveTo(699, 690); ctx.lineTo(691, 699); ctx.stroke()
  rr(920, 646, 47, 47, 12, null, muted, 4); stroke(muted, 4); ctx.beginPath(); ctx.arc(944, 663, 7, 0, Math.PI * 2); ctx.stroke(); ctx.beginPath(); ctx.arc(944, 681, 13, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke()

  return canvas.toBuffer('image/png')
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    const q = m.quoted || m, mime = (q.msg || q).mimetype || ''
    if (!text) return m.reply(`*Format:*
${usedPrefix + command} name | username | posts | followers | following | bio | url_avatar

*Contoh:*
${usedPrefix + command} M Rizky Zadani | mrzkyzdnii | 0 | 57 | 61 | why`)
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })
    const args = text.includes('|') ? text.split('|').map(v => v.trim()) : text.split(/\s+/).map(v => v.trim())
    const [name, username, posts, followers, following, bio, url] = args
    if (!name || !username || !posts || !followers || !following) throw `🍂 *Format tidak valid!*

Gunakan pemisah | seperti contoh:
${usedPrefix + command} M Rizky Zadani | mrzkyzdnii | 0 | 57 | 61 | why`
    let avatarInput = url && /^https?:\/\//i.test(url) ? url : null
    if (!avatarInput && mime.startsWith('image/')) avatarInput = await q.download()
    const image = await makeFakeInstagram({ name, username, posts, followers, following, bio: bio || 'why', avatarInput })
    await conn.sendMessage(m.chat, { image, caption: `*Instagram Profile Created*

• *Name:* ${name}
• *Username:* @${username.replace(/^@/, '')}
• *Posts:* ${posts}
• *Followers:* ${followers}
• *Following:* ${following}` }, { quoted: m })
  } catch (e) { console.error('FAKEIG ERROR:', e); await m.reply(typeof e === 'string' ? e : '🍂 *Terjadi kesalahan saat membuat fake Instagram profile.*') }
  finally { try { await conn.sendMessage(m.chat, { react: { text: '', key: m.key } }) } catch {} }
}

handler.help = ['fakeig']; handler.tags = ['maker']; handler.command = /^(fakeig|fakeinstagram|fig)$/i; handler.limit = 10; handler.register = false
export default handler