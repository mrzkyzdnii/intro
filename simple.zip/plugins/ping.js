import { exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)

const handler = async (m, { conn }) => {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        const { stdout } = await execAsync('speedtest-cli --simple', {
            timeout: 120000,
            maxBuffer: 1024 * 1024
        })

        const ping = stdout.match(/Ping:\s*([\d.]+)\s*ms/i)?.[1]
        const download = stdout.match(/Download:\s*([\d.]+)\s*Mbit\/s/i)?.[1]
        const upload = stdout.match(/Upload:\s*([\d.]+)\s*Mbit\/s/i)?.[1]

        if (!ping || !download || !upload) {
            throw new Error('Gagal membaca hasil speedtest')
        }

        const formatSpeed = value => {
            const mbps = parseFloat(value)
            if (mbps >= 1000) return `${(mbps / 1000).toFixed(2)} Gbit/s`
            return `${mbps.toFixed(2)} Mbit/s`
        }

        const result = `╭─〔 ⚡ SPEEDTEST 〕
│
│  ◇ Ping
│  └─ ${ping} ms
│
│  ◇ Download
│  └─ ${formatSpeed(download)}
│
│  ◇ Upload
│  └─ ${formatSpeed(upload)}
│
╰─〔 MRZKYZDNII • NETWORK 〕`

        await conn.reply(m.chat, result, m)
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
    } catch (e) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } })
        throw e
    }
}

handler.help = ['ping']
handler.tags = ['tools']
handler.command = /^ping$/i

export default handler