const ITEMS = {
    money: '💰 Money',
    limit: '🌌 Limit',
    bank: '🏦 Bank',
    chip: '🎟️ Chip',

    potion: '🥤 Potion',
    petfood: '🍖 Pet Food',
    umpan: '🪱 Umpan',
    pet: '🎟️ Pet Token',

    trash: '🗑️ Trash',
    wood: '🪵 Wood',
    rock: '🪨 Rock',
    string: '🕸️ String',
    iron: '⛓️ Iron',
    emerald: '💚 Emerald',
    diamond: '💎 Diamond',
    gold: '👑 Gold',

    common: '📦 Common Crate',
    uncommon: '🎁 Uncommon Crate',
    mythic: '🗳️ Mythic Crate',
    legendary: '🗃️ Legendary Crate',

    botol: '🍾 Botol',
    kardus: '📦 Kardus',
    kaleng: '🥫 Kaleng',
    gelas: '🥛 Gelas',
    plastik: '🛍️ Plastik',

    gandum: '🌾 Gandum',
    minyak: '🛢️ Minyak',
    garam: '🧂 Garam',

    apel: '🍎 Apel',
    anggur: '🍇 Anggur',
    jeruk: '🍊 Jeruk',
    mangga: '🥭 Mangga',
    pisang: '🍌 Pisang',

    bibitapel: '🌱 Bibit Apel',
    bibitanggur: '🌱 Bibit Anggur',
    bibitjeruk: '🌱 Bibit Jeruk',
    bibitmangga: '🌱 Bibit Mangga',
    bibitpisang: '🌱 Bibit Pisang',

    makanan: '🍱 Makanan',

    ayam: '🐔 Ayam',
    babi: '🐖 Babi',
    babihutan: '🐗 Babi Hutan',
    banteng: '🐂 Banteng',
    buaya: '🐊 Buaya',
    gajah: '🐘 Gajah',
    harimau: '🐅 Harimau',
    kambing: '🐐 Kambing',
    kerbau: '🐃 Kerbau',
    monyet: '🐒 Monyet',
    panda: '🐼 Panda',
    sapi: '🐄 Sapi',

    paus: '🐋 Paus',
    kepiting: '🦀 Kepiting',
    gurita: '🐙 Gurita',
    cumi: '🦑 Cumi',
    buntal: '🐡 Buntal',
    dory: '🐠 Dory',
    lumba: '🐬 Lumba',
    lobster: '🦞 Lobster',
    hiu: '🦈 Hiu',
    udang: '🦐 Udang',
    orca: '🐋 Orca',

    ikan: '🐟 Ikan',
    lele: '🐟 Lele',
    nila: '🐟 Nila',
    bawal: '🐟 Bawal',

    steak: '🥩 Steak',
    ayam_goreng: '🍗 Ayam Goreng',
    ayamgoreng: '🍗 Ayam Goreng',
    ayambakar: '🍗 Ayam Bakar',
    ribs: '🥩 Ribs',
    roti: '🍞 Roti',
    udang_goreng: '🍤 Udang Goreng',
    udangbakar: '🍤 Udang Bakar',
    bacon: '🥓 Bacon',

    ikanbakar: '🐟 Ikan Bakar',
    lelebakar: '🐟 Lele Bakar',
    nilabakar: '🐟 Nila Bakar',
    bawalbakar: '🐟 Bawal Bakar',
    kepitingbakar: '🦀 Kepiting Bakar',
    pausbakar: '🐋 Paus Bakar',
    babipanggang: '🐖 Babi Panggang',
    oporayam: '🍗 Opor Ayam',
    rendang: '🥩 Rendang',
    gulai: '🍛 Gulai',

    aqua: '💧 Aqua',
    clay: '🧱 Clay',
    coal: '🪨 Coal',

    ojek: '🛵 Ojek',
    polisi: '🚓 Polisi',
    roket: '🚀 Roket',
    rokets: '🚀 Rokets',
    taxy: '🚕 Taxy',

    horse: '🐴 Horse',
    cat: '🐱 Cat',
    dog: '🐶 Dog',
    fox: '🦊 Fox',
    robo: '🤖 Robo',
    dragon: '🐉 Dragon',
    lion: '🦁 Lion',
    rhinoceros: '🦏 Rhinoceros',
    centaur: '🐎 Centaur',
    kyubi: '🦊 Kyubi',
    griffin: '🦅 Griffin',
    phonix: '🔥 Phonix',
    wolf: '🐺 Wolf'
}

const fmt = (value) => {
    return new Intl.NumberFormat('id-ID').format(
        Number(value) || 0
    )
}

const getUser = (jid) => {
    return global.db?.data?.users?.[jid]
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
    /*
     * ============================
     * DATABASE
     * ============================
     */

    const senderData = getUser(m.sender)

    if (!senderData) {
        return m.reply(
            '❌ Data pengguna kamu tidak ditemukan di database.'
        )
    }

    /*
     * ============================
     * HELP
     * ============================
     */

    if (!args[0]) {
        return m.reply(`
╭━━━〔 📦 TRANSFER ITEM 〕━━━╮
┃
┃ Kirim satu item:
┃
┃ ${usedPrefix + command} money 10000 @user
┃ ${usedPrefix + command} diamond 5 @user
┃ ${usedPrefix + command} potion 10 @user
┃ ${usedPrefix + command} apel 50 @user
┃
┃ ✨ Transfer semua:
┃
┃ ${usedPrefix + command} all 100 @user
┃
┃ Artinya semua item akan
┃ dikurangi 100 dan diberikan
┃ ke target.
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

📦 Total item: ${Object.keys(ITEMS).length}
        `.trim())
    }

    /*
     * ============================
     * ITEM
     * ============================
     */

    const item = String(args[0]).toLowerCase()

    /*
     * ============================
     * AMOUNT
     * ============================
     */

    const amount = Number(args[1])

    if (!Number.isInteger(amount) || amount < 1) {
        return m.reply(
            '❌ Jumlah harus berupa angka bulat dan minimal 1.'
        )
    }

    /*
     * ============================
     * TARGET
     * ============================
     */

    const who =
        m.mentionedJid?.[0] ||
        m.quoted?.sender

    if (!who) {
        return m.reply(
            `❌ Tag atau reply target.\n\n` +
            `Contoh:\n` +
            `${usedPrefix + command} money 10000 @user\n\n` +
            `Atau:\n` +
            `${usedPrefix + command} all 100 @user`
        )
    }

    /*
     * ============================
     * SELF TRANSFER
     * ============================
     */

    if (who === m.sender) {
        return m.reply(
            '❌ Tidak bisa transfer ke diri sendiri.'
        )
    }

    /*
     * ============================
     * RECEIVER DATABASE
     * ============================
     */

    const receiverData = getUser(who)

    if (!receiverData) {
        return m.reply(
            '❌ User penerima tidak ditemukan di database.'
        )
    }

    /*
     * ============================
     * TRANSFER ALL
     * ============================
     */

    if (item === 'all') {
        const availableItems = []
        const insufficientItems = []

        /*
         * Cek SEMUA item terlebih dahulu.
         *
         * Ini penting supaya tidak terjadi
         * transfer setengah jalan.
         */
        for (const key of Object.keys(ITEMS)) {
            const stock = Number(senderData[key]) || 0

            if (stock >= amount) {
                availableItems.push({
                    key,
                    before: stock
                })
            } else {
                insufficientItems.push({
                    key,
                    stock
                })
            }
        }

        /*
         * Kalau tidak ada satu pun item
         * yang memenuhi jumlah.
         */
        if (!availableItems.length) {
            return m.reply(
                `❌ Tidak ada item yang memiliki stok minimal *${fmt(amount)}*.\n\n` +
                `💡 Coba gunakan jumlah yang lebih kecil.`
            )
        }

        /*
         * Transfer semua item yang stoknya cukup.
         */
        for (const itemData of availableItems) {
            const key = itemData.key

            senderData[key] =
                (Number(senderData[key]) || 0) - amount

            receiverData[key] =
                (Number(receiverData[key]) || 0) + amount
        }

        /*
         * Daftar item yang berhasil.
         */
        const transferredList = availableItems
            .map(itemData => {
                const key = itemData.key

                return `│ ${ITEMS[key]} ×${fmt(amount)}`
            })
            .join('\n')

        return conn.reply(
            m.chat,
`╭━━━〔 ✅ TRANSFER ALL 〕━━━╮
┃
┃ 📤 Pengirim
┃ @${m.sender.split('@')[0]}
┃
┃ 📥 Penerima
┃ @${who.split('@')[0]}
┃
┃ 📦 Jumlah / Item
┃ ×${fmt(amount)}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯

*ITEM YANG DITRANSFER*
${transferredList}

╭━━━━━━━━━━━━━━━━━━━━━━╮
│ ✅ Berhasil : ${availableItems.length}
│ ⚠️ Kurang   : ${insufficientItems.length}
╰━━━━━━━━━━━━━━━━━━━━━━╯

> Item yang stoknya kurang dari ${fmt(amount)} otomatis dilewati.`,
            m,
            {
                mentions: [m.sender, who]
            }
        )
    }

    /*
     * ============================
     * SINGLE ITEM
     * ============================
     */

    if (!ITEMS[item]) {
        return m.reply(
`❌ Item *${item}* tidak valid.

Gunakan:
${usedPrefix + command} all ${amount} @user

Atau salah satu item:

${Object.entries(ITEMS)
    .map(([key, value]) => `• ${key} → ${value}`)
    .join('\n')}`
        )
    }

    /*
     * ============================
     * CHECK STOCK
     * ============================
     */

    const stock = Number(senderData[item]) || 0

    if (stock < amount) {
        return m.reply(
`⚠️ *${ITEMS[item]}* kamu tidak cukup.

📦 Stok       : ${fmt(stock)}
📤 Transfer   : ${fmt(amount)}
❌ Kekurangan : ${fmt(amount - stock)}`
        )
    }

    /*
     * ============================
     * EXECUTE TRANSFER
     * ============================
     */

    senderData[item] = stock - amount

    receiverData[item] =
        (Number(receiverData[item]) || 0) + amount

    /*
     * ============================
     * SUCCESS
     * ============================
     */

    return conn.reply(
        m.chat,
`╭━━━〔 ✅ TRANSFER BERHASIL 〕━━━╮
┃
┃ 📦 Item
┃ ${ITEMS[item]}
┃
┃ 📤 Jumlah
┃ ${fmt(amount)}
┃
┃ 👤 Pengirim
┃ @${m.sender.split('@')[0]}
┃
┃ 👥 Penerima
┃ @${who.split('@')[0]}
┃
┃ 📊 Sisa Kamu
┃ ${fmt(senderData[item])}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
        m,
        {
            mentions: [m.sender, who]
        }
    )
}

handler.help = [
    'tf <item> <jumlah> @user',
    'transfer <item> <jumlah> @user'
]

handler.tags = ['rpg']

handler.command = /^(tf|transfer)$/i

handler.rpg = true

export default handler