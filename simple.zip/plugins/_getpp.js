import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
    let who

    try {
        // Tag
        if (m.mentionedJid?.length) {
            who = m.mentionedJid[0]

        // Reply
        } else if (m.quoted?.sender) {
            who = m.quoted.sender

        // Input nomor
        } else if (text) {
            let number = text
                .replace(/[^\d]/g, '') // Sisakan angka saja

            // 08xxxx -> 62xxxx
            if (number.startsWith('0'))
                number = '62' + number.slice(1)

            // 898xxx -> 62898xxx
            if (!number.startsWith('62'))
                number = '62' + number

            let check = await conn.onWhatsApp(number)

            if (!check || !check.length)
                throw '❌ Nomor tidak terdaftar di WhatsApp.'

            who = check[0].jid

        // Private chat
        } else if (!m.isGroup) {
            who = m.sender

        } else {
            throw `Penggunaan:
• .getpp @tag
• Reply pesan lalu .getpp
• .getpp 628**
• .getpp +628**
• .getpp +62 898-**`
        }

        let pp = await conn.profilePictureUrl(who, 'image')
            .catch(() => 'https://telegra.ph/file/24fa902ead26340f3df2c.png')

        await conn.sendFile(
            m.chat,
            pp,
            'pp.jpg',
            'Selesai....',
            m,
            {
                jpegThumbnail: await (await fetch(pp)).buffer()
            }
        )

    } catch (e) {
        m.reply(typeof e === 'string' ? e : e.message)
    }
}

handler.help = ['getpp [@tag|reply|nomor]']
handler.tags = ['tools']
handler.command = /^getpp$/i

handler.limit = 10
export default handler