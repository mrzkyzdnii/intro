// fitur : img2prompt

import axios from 'axios'

const API_URL = 'https://imageprompt.org/api/ai/prompts/image'
const MAX_SIZE = 4 * 1024 * 1024

const MODEL_MAP = {
  general: 'general',
  structured: 'structured',
  graphic: 'graphic-design',
  json: 'json',
  flux: 'flux',
  midjourney: 'midjourney',
  sd: 'stable-diffusion',
  'stable-diffusion': 'stable-diffusion'
}

const generatePrompt = async (buffer, mime, model = 'general', language = 'en') => {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('Buffer gambar kosong')
  if (buffer.length > MAX_SIZE) throw new Error('Ukuran gambar maksimal 4 MB')

  const base64Url = `data:${mime};base64,${buffer.toString('base64')}`

  const { data } = await axios.post(
    API_URL,
    {
      base64Url,
      imageModelId: model,
      language
    },
    {
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      },
      timeout: 120000,
      validateStatus: () => true
    }
  )

  if (data?.prompt) return data.prompt.trim()

  if (data?.error) throw new Error(data.error)
  throw new Error('Gagal mendapatkan prompt dari server')
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''

  if (!mime.startsWith('image/')) {
    return m.reply(
      `✨ Reply/kirim gambar yang mau dibuat prompt.\n\n` +
      `Contoh:\n${usedPrefix + command}\n` +
      `${usedPrefix + command} structured`
    )
  }

  const input = (text || '').trim().toLowerCase().split(/\s+/)[0]
  const model = MODEL_MAP[input] || 'general'

  try {
    await m.react('✨')

    const buffer = await q.download()
    if (!buffer) throw new Error('Gagal download gambar')

    const prompt = await generatePrompt(buffer, mime, model, 'en')

    await conn.sendMessage(
      m.chat,
      {
        text: `${prompt}`,
        ...global.fakestatus
      },
      { quoted: m }
    )

    await m.react('✅')
  } catch (e) {
    console.error('[img2prompt]', e?.response?.data || e)
    await m.react('❌').catch(() => {})
    m.reply(`✨ Gagal membuat prompt: ${e.message || 'server error'}`)
  }
}

handler.help = ['img2prompt [model]']
handler.tags = ['tools']
handler.command = /^(img2prompt|i2p)$/i
handler.limit = 10
handler.register = true

export default handler