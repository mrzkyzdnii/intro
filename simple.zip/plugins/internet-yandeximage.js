import axios from 'axios'
import * as cheerio from 'cheerio'

const scraper = async (query) => {
    try {
        const searchUrl = `https://yandex.com/images/touch/search?lr=112653&text=${encodeURIComponent(query)}`
        const { data: html } = await axios.get(searchUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.9',
            }
        })

        const urls = new Set()

        // 1. Extract dari &quot;img_href&quot;:&quot;(url)&quot;
        const regexImgHref = /&quot;img_href&quot;:&quot;([^&quot;]+)&quot;/g
        let m
        while ((m = regexImgHref.exec(html)) !== null) {
            if (m[1].startsWith('http')) urls.add(m[1])
        }

        // 2. Extract dari &quot;url&quot;:&quot;(url)&quot; (ext: jpg, png, webp, gif)
        const regexUrl = /&quot;url&quot;:&quot;(https?:\\?\/\\?[^&quot;]+\.(?:jpg|jpeg|png|webp|gif)[^&quot;]*)&quot;/gi
        while ((m = regexUrl.exec(html)) !== null) {
            const cleanUrl = m[1].replace(/\\/g, '')
            if (!cleanUrl.includes('yastatic') && !cleanUrl.includes('avatars.mds.yandex.net')) {
                urls.add(cleanUrl)
            }
        }

        // 3. Extract parameter img_url= ter-encode di detail_url
        const regexImgParam = /img_url=([^&;]+)/g
        while ((m = regexImgParam.exec(html)) !== null) {
            try {
                const decoded = decodeURIComponent(m[1])
                if (decoded.startsWith('http') && !decoded.includes('yastatic')) {
                    urls.add(decoded)
                }
            } catch (e) {}
        }

        const list = Array.from(urls)
        if (!list.length) throw 'Gambar gak ditemukan, coba kata kunci lain.'

        // Pilih 1 URL secara acak
        const randomImage = list[Math.floor(Math.random() * list.length)]
        return randomImage
    } catch (err) {
        throw err.message || err
    }
}

// helper buat download ke buffer
const getBuffer = async (url) => {
    const res = await axios.get(url, { 
        responseType: 'arraybuffer',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 15000
    })
    return res.data
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Example:\n${usedPrefix + command} meme`

    await conn.reply(m.chat, '_Mencari gambar di Yandex..._', m)

    try {
        const result = await scraper(text)
        const buffer = await getBuffer(result) // download dulu

        // kirim sebagai image biar pasti gambar bukan dokumen
        await conn.sendMessage(m.chat, { 
            image: buffer, 
            caption: `*Hasil pencarian Yandex untuk:* ${text}` 
        }, { quoted: m })

    } catch (e) {
        await conn.reply(m.chat, `❌ Error: ${e}`, m)
    }
}

handler.help = ['yandeximage']
handler.tags = ['internet']
handler.command = /^(yandeximage)$/i

handler.limit = 10
export default handler