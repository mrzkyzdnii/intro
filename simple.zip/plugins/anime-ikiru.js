import * as cheerio from 'cheerio'

const BASE_URL = 'https://07.ikiru.wtf'
const AJAX_URL = `${BASE_URL}/wp-admin/admin-ajax.php`
const SEARCH_PAGE_URL = `${BASE_URL}/advanced-search/`
const MAX_RESULTS = 5

const requestHtml = async (url, options = {}) => {
  const response = await fetch(url, {
    ...options,
    headers: {
      'user-agent': 'Mozilla/5.0 (compatible; IkiruBot/1.0)',
      accept: 'text/html,application/xhtml+xml',
      ...(options.headers || {})
    },
    redirect: 'follow'
  })

  if (!response.ok) {
    throw new Error(`Ikiru mengembalikan HTTP ${response.status}`)
  }

  return response.text()
}

const cleanText = (value = '') => {
  return value.replace(/\s+/g, ' ').trim()
}

const absoluteUrl = (value) => {
  if (!value) return null

  try {
    const url = new URL(value, BASE_URL)

    if (url.protocol === 'http:') {
      url.protocol = 'https:'
    }

    return url.href
  } catch {
    return null
  }
}

const getImageUrl = ($, root) => {
  const image = $(root)
    .find('img[src], img[data-src], img[data-lazy-src]')
    .first()

  return absoluteUrl(
    image.attr('data-src') ||
    image.attr('data-lazy-src') ||
    image.attr('src')
  )
}

const parseSearchResults = (html) => {
  const $ = cheerio.load(html)
  const results = []
  const seen = new Set()

  $('a[href*="/manga/"]').each((_, element) => {
    const href = absoluteUrl($(element).attr('href'))

    if (
      !href ||
      /\/chapter[-/]/i.test(href) ||
      seen.has(href)
    ) {
      return
    }

    const title = cleanText(
      $(element).find(
        'h1, h2, h3, h4, [itemprop="name"]'
      ).first().text() ||
      $(element).attr('title') ||
      $(element).find('img[alt]').first().attr('alt') ||
      $(element).text()
    )

    const image = getImageUrl($, element)

    if (!title || title.length < 2) {
      return
    }

    seen.add(href)

    results.push({
      title,
      url: href,
      image
    })
  })

  return results.slice(0, MAX_RESULTS)
}

const parseDetail = (html, fallback) => {
  const $ = cheerio.load(html)

  const title =
    cleanText(
      $('[itemprop="name"]').first().text()
    ) ||
    fallback.title

  const description = cleanText(
    $('[itemprop="description"]').last().text() ||
    $('meta[name="description"]').attr('content') ||
    $('meta[property="og:description"]').attr('content') ||
    'Deskripsi tidak tersedia.'
  )

  const image = absoluteUrl(
    $('meta[property="og:image"]').attr('content') ||
    $('meta[property="og:image:url"]').attr('content') ||
    $('meta[property="og:image:secure_url"]').attr('content') ||
    $('img.wp-post-image').first().attr('src') ||
    $('img.wp-post-image').first().attr('data-src') ||
    fallback.image
  )

  const genres = [
    ...new Set(
      $('[itemprop="genre"]')
        .map((_, el) => cleanText($(el).text()))
        .get()
        .filter(Boolean)
    )
  ]

  const status =
    cleanText(
      $('[itemprop="status"]').first().text()
    ) ||
    cleanText(
      $('body')
        .text()
        .match(/\b(Ongoing|Completed|On Hiatus)\b/i)?.[0] || ''
    )

  return {
    title,
    description: description || 'Deskripsi tidak tersedia.',
    image,
    genres,
    status,
    url: fallback.url
  }
}

/**
 * Download gambar sebagai Buffer
 * supaya WhatsApp mengirimnya sebagai image,
 * bukan document.
 */
const getImageBuffer = async (url) => {
  if (!url) {
    throw new Error('URL gambar tidak tersedia')
  }

  const response = await fetch(url, {
    headers: {
      'user-agent': 'Mozilla/5.0 (compatible; IkiruBot/1.0)',
      accept: 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
      referer: BASE_URL
    },
    redirect: 'follow'
  })

  if (!response.ok) {
    throw new Error(`Gagal mengambil gambar: HTTP ${response.status}`)
  }

  const contentType = (
    response.headers.get('content-type') || ''
  ).toLowerCase()

  const buffer = Buffer.from(await response.arrayBuffer())

  if (!buffer.length) {
    throw new Error('Buffer gambar kosong')
  }

  let mimetype = contentType.split(';')[0].trim()

  /**
   * Beberapa server Ikiru kadang memberikan
   * application/octet-stream.
   *
   * Coba deteksi format gambar dari magic bytes.
   */
  if (
    !mimetype.startsWith('image/')
  ) {
    if (
      buffer[0] === 0xFF &&
      buffer[1] === 0xD8 &&
      buffer[2] === 0xFF
    ) {
      mimetype = 'image/jpeg'
    } else if (
      buffer[0] === 0x89 &&
      buffer[1] === 0x50 &&
      buffer[2] === 0x4E &&
      buffer[3] === 0x47
    ) {
      mimetype = 'image/png'
    } else if (
      buffer[0] === 0x47 &&
      buffer[1] === 0x49 &&
      buffer[2] === 0x46
    ) {
      mimetype = 'image/gif'
    } else if (
      buffer[0] === 0x52 &&
      buffer[1] === 0x49 &&
      buffer[2] === 0x46 &&
      buffer[3] === 0x46 &&
      buffer[8] === 0x57 &&
      buffer[9] === 0x45 &&
      buffer[10] === 0x42 &&
      buffer[11] === 0x50
    ) {
      mimetype = 'image/webp'
    } else {
      /**
       * Kalau server tetap tidak memberikan MIME
       * dan format tidak terdeteksi, gunakan JPEG.
       */
      mimetype = 'image/jpeg'
    }
  }

  return {
    buffer,
    mimetype
  }
}

const getSearchNonce = async () => {
  const html = await requestHtml(
    `${AJAX_URL}?type=search_form&action=get_nonce`,
    {
      headers: {
        referer: SEARCH_PAGE_URL
      }
    }
  )

  const nonce = html.match(
    /name=['"]search_nonce['"][^>]*value=['"]([^'"]+)['"]/i
  )?.[1]

  if (!nonce) {
    throw new Error('Nonce pencarian Ikiru tidak ditemukan')
  }

  return nonce
}

const scrapeIkiru = async (keyword) => {
  const nonce = await getSearchNonce()
  const form = new FormData()

  form.set('nonce', nonce)
  form.set('query', keyword)
  form.set('page', '1')
  form.set('genre', '[]')
  form.set('genre_exclude', '[]')
  form.set('author', '[]')
  form.set('artist', '[]')
  form.set('project', '0')
  form.set('type', '[]')
  form.set('status', '[]')
  form.set('order', 'desc')
  form.set('orderby', 'popular')
  form.set('inclusion', 'OR')
  form.set('exclusion', 'OR')

  const searchHtml = await requestHtml(
    `${AJAX_URL}?action=advanced_search`,
    {
      method: 'POST',
      headers: {
        'hx-request': 'true',
        referer: SEARCH_PAGE_URL
      },
      body: form
    }
  )

  const candidates = parseSearchResults(searchHtml)

  if (!candidates.length) {
    return []
  }

  return Promise.all(
    candidates.map(async (candidate) => {
      try {
        const detailHtml = await requestHtml(candidate.url)

        return parseDetail(
          detailHtml,
          candidate
        )
      } catch {
        return {
          ...candidate,
          description:
            'Detail gagal diambil dari halaman Ikiru.',
          genres: [],
          status: ''
        }
      }
    })
  )
}

const formatResult = (items, keyword) => {
  const header =
    `╭─「 *IKIRU SEARCH* 」\n` +
    `│ 🔎 Query: *${keyword}*\n` +
    `│ 📚 Hasil: *${items.length}*\n` +
    `╰──────────────\n`

  const body = items
    .map((item, index) => {
      const genres = item.genres.length
        ? item.genres.join(', ')
        : '-'

      const status = item.status || '-'

      return [
        `\n┌─「 *${index + 1}. ${item.title}* 」`,
        `│ 📌 Status: ${status}`,
        `│ 🎭 Genre: ${genres}`,
        `│ 📝 ${item.description}`,
        `│ 🔗 ${item.url}`,
        `└──────────────`
      ].join('\n')
    })
    .join('\n')

  return header + body
}

const handler = async (
  m,
  {
    conn,
    text,
    usedPrefix,
    command
  }
) => {
  const keyword = cleanText(text)

  if (!keyword) {
    throw `Contoh:\n${usedPrefix + command} villain`
  }

  await conn.reply(
    m.chat,
    '🔎 Sedang mencari di Ikiru...',
    m
  )

  try {
    const results = await scrapeIkiru(keyword)

    if (!results.length) {
      return conn.reply(
        m.chat,
        `❌ Manga dengan keyword “${keyword}” tidak ditemukan.`,
        m
      )
    }

    const caption = formatResult(
      results,
      keyword
    )

    const firstResult = results.find(
      (item) => item.image
    )

    /**
     * Kirim sebagai IMAGE BUFFER.
     * Bukan sendFile(url), karena URL tertentu
     * dari Ikiru terbaca sebagai document.
     */
    if (firstResult?.image) {
      try {
        const {
          buffer,
          mimetype
        } = await getImageBuffer(
          firstResult.image
        )

        return await conn.sendMessage(
          m.chat,
          {
            image: buffer,
            mimetype,
            caption
          },
          {
            quoted: m
          }
        )
      } catch (imageError) {
        console.error(
          '[IKIRU IMAGE ERROR]',
          imageError
        )
      }
    }

    /**
     * Kalau gambar gagal diambil,
     * tetap kirim hasil pencarian sebagai text.
     */
    return conn.reply(
      m.chat,
      caption,
      m
    )
  } catch (error) {
    console.error(
      '[IKIRU ERROR]',
      error
    )

    return conn.reply(
      m.chat,
      `❌ Terjadi kesalahan saat mengambil data Ikiru.\n\n${error.message}`,
      m
    )
  }
}

handler.help = ['ikiru']
handler.tags = ['search']
handler.command = /^ikiru$/i
handler.limit = 10

export default handler