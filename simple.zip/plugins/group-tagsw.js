import * as baileys from "@mrzkyzdnii/baileys";
import crypto from "node:crypto";
import { PassThrough } from "stream";
import ffmpeg from "fluent-ffmpeg";

const warnaMap = {
    biru: "#34B7F1",
    hijau: "#25D366",
    kuning: "#FFD700",
    jingga: "#FF8C00",
    merah: "#FF3B30",
    ungu: "#9C27B0",
    abu: "#9E9E9E",
    hitam: "#000000",
    putih: "#FFFFFF",
    cyan: "#00BCD4",
    pink: "#FF69B4",
    orange: "#FF8C00"
};

const swgcSessions = new Map();
const SESSION_EXPIRE = 5 * 60 * 1000;

function createToken() {
    return crypto.randomBytes(8).toString("hex");
}

function cleanupSessions() {
    const now = Date.now();

    for (const [token, session] of swgcSessions) {
        if (
            !session ||
            now - session.createdAt > SESSION_EXPIRE
        ) {
            swgcSessions.delete(token);
        }
    }
}

setInterval(cleanupSessions, 60 * 1000).unref();

function getColor(name) {
    if (!name) return null;

    return warnaMap[
        String(name)
            .trim()
            .toLowerCase()
    ] || null;
}

function parseInput(text) {
    const raw = String(text || "").trim();

    if (!raw) {
        return {
            caption: "",
            warna: null
        };
    }

    const parts = raw
        .split("|")
        .map(v => v.trim())
        .filter(Boolean);

    let warna = null;
    const captionParts = [];

    for (const part of parts) {
        const lower = part.toLowerCase();

        if (
            !warna &&
            warnaMap[lower] &&
            parts.length > 1
        ) {
            warna = lower;
            continue;
        }

        captionParts.push(part);
    }

    return {
        caption: captionParts.join(" | ").trim(),
        warna
    };
}

function getMime(quoted) {
    return (
        quoted?.mimetype ||
        quoted?.msg?.mimetype ||
        quoted?.message?.imageMessage?.mimetype ||
        quoted?.message?.videoMessage?.mimetype ||
        quoted?.message?.audioMessage?.mimetype ||
        ""
    );
}

function getQuotedCaption(quoted) {
    return (
        quoted?.caption ||
        quoted?.msg?.caption ||
        quoted?.message?.imageMessage?.caption ||
        quoted?.message?.videoMessage?.caption ||
        ""
    );
}

async function toVN(buffer) {
    return new Promise((resolve, reject) => {
        const input = new PassThrough();
        const output = new PassThrough();
        const chunks = [];

        input.end(buffer);

        output.on("data", chunk => {
            chunks.push(chunk);
        });

        output.on("error", reject);

        ffmpeg(input)
            .noVideo()
            .audioCodec("libopus")
            .format("ogg")
            .on("error", reject)
            .on("end", () => {
                resolve(Buffer.concat(chunks));
            })
            .pipe(output);
    });
}

async function groupStatus(conn, jid, content) {
    const backgroundColor = content.backgroundColor;

    const messageContent = {
        ...content
    };

    delete messageContent.backgroundColor;

    const inside = await baileys.generateWAMessageContent(
        messageContent,
        {
            upload: conn.waUploadToServer,
            backgroundColor
        }
    );

    const secret = crypto.randomBytes(32);

    const msg = baileys.generateWAMessageFromContent(
        jid,
        {
            messageContextInfo: {
                messageSecret: secret
            },

            groupStatusMessageV2: {
                message: {
                    ...inside,

                    messageContextInfo: {
                        messageSecret: secret
                    }
                }
            }
        },
        {}
    );

    await conn.relayMessage(
        jid,
        msg.message,
        {
            messageId: msg.key.id
        }
    );

    return msg;
}

async function getGroups(conn) {
    const result =
        await conn.groupFetchAllParticipating();

    return Object.values(result || {})
        .filter(
            g =>
                g?.id &&
                /@g\.us$/i.test(g.id)
        )
        .sort((a, b) =>
            String(a.subject || "")
                .localeCompare(
                    String(b.subject || ""),
                    "id",
                    {
                        sensitivity: "base"
                    }
                )
        );
}

function createGroupRows(groups, token) {
    return groups.map((g, index) => {
        const subject =
            String(g.subject || "Tanpa Nama")
                .replace(/\n/g, " ")
                .trim();

        const members =
            g.participants?.length || 0;

        return {
            title:
                `${String(index + 1).padStart(2, "0")} • ${subject}`
                    .slice(0, 72),

            description:
                `👥 ${members} anggota • Kirim SW ke group ini`,

            id:
                `swgc_select:${token}:${g.id}`
        };
    });
}

async function sendGroupSelector(
    conn,
    m,
    groups,
    session,
    token
) {
    const rows =
        createGroupRows(
            groups,
            token
        );

    const mediaInfo = session.media
        ? session.mime.startsWith("image/")
            ? "🖼️ Gambar"
            : session.mime.startsWith("video/")
                ? "🎬 Video"
                : session.mime.startsWith("audio/")
                    ? "🎵 Audio"
                    : "📦 Media"
        : "📝 Teks";

    const colorInfo = session.warna
        ? `🎨 ${session.warna}`
        : "🎨 Default";

    const preview =
        session.caption
            ? session.caption.length > 120
                ? session.caption.slice(0, 117) + "..."
                : session.caption
            : "Tanpa caption";

    await conn.sendMessage(
        m.chat,
        {
            text:
`╭─〔 ✨ SW GROUP 〕
│
│ ${mediaInfo}
│ ${colorInfo}
│
├─〔 📝 PESAN 〕
│
│ ${preview}
│
├─〔 🎯 PILIH GROUP 〕
│
│ Tersedia ${groups.length} group.
│ Pilih salah satu group
│ untuk langsung mengirim SW.
│
╰────────────────────`,

            footer:
                "⚡ SWGC • Pilih tujuan pengiriman",

            optionText:
                "Pilih Group",

            optionTitle:
                "🎯 Daftar Group",

            nativeFlow: [
                {
                    text: "Pilih Group",

                    sections: [
                        {
                            title:
                                `📋 ${groups.length} Group Tersedia`,

                            rows
                        }
                    ]
                }
            ]
        },
        {
            quoted: m
        }
    );
}

function deepFindResponse(value, depth = 0) {
    if (!value || depth > 8) {
        return null;
    }

    if (
        typeof value === "string"
    ) {
        if (
            value.startsWith(
                "swgc_select:"
            )
        ) {
            return value;
        }

        try {
            const parsed =
                JSON.parse(value);

            return deepFindResponse(
                parsed,
                depth + 1
            );
        } catch {
            return null;
        }
    }

    if (
        typeof value !== "object"
    ) {
        return null;
    }

    const directKeys = [
        "selectedId",
        "selectedRowId",
        "rowId",
        "id"
    ];

    for (const key of directKeys) {
        const val = value?.[key];

        if (
            typeof val === "string" &&
            val.startsWith(
                "swgc_select:"
            )
        ) {
            return val;
        }
    }

    if (
        typeof value.paramsJson === "string"
    ) {
        const result =
            deepFindResponse(
                value.paramsJson,
                depth + 1
            );

        if (result) {
            return result;
        }
    }

    for (const [key, val] of Object.entries(value)) {
        if (
            key === "messageContextInfo" ||
            key === "contextInfo"
        ) {
            continue;
        }

        const result =
            deepFindResponse(
                val,
                depth + 1
            );

        if (result) {
            return result;
        }
    }

    return null;
}

function extractNativeFlowId(m) {
    const sources = [
        m?.message,
        m?.msg,
        m?.message?.interactiveResponseMessage,
        m?.msg?.interactiveResponseMessage,
        m?.message?.interactiveMessage,
        m?.msg?.interactiveMessage
    ];

    for (const source of sources) {
        const result =
            deepFindResponse(source);

        if (result) {
            return result;
        }
    }

    return null;
}

async function prepareMedia(quoted) {
    const mime =
        getMime(quoted);

    if (!mime) {
        return {
            media: null,
            mime: ""
        };
    }

    if (
        !/image|video|audio/i.test(mime)
    ) {
        return {
            media: null,
            mime
        };
    }

    const buffer =
        await quoted
            .download()
            .catch(() => null);

    if (!buffer) {
        throw new Error(
            "MEDIA_DOWNLOAD_FAILED"
        );
    }

    return {
        media: buffer,
        mime
    };
}

async function sendSessionToGroup(
    conn,
    jid,
    session
) {
    const bgColor =
        session.warna
            ? getColor(session.warna)
            : null;

    if (!session.media) {
        const content = {
            text: session.caption
        };

        if (bgColor) {
            content.backgroundColor =
                bgColor;
        }

        return groupStatus(
            conn,
            jid,
            content
        );
    }

    if (
        /^image\//i.test(
            session.mime
        )
    ) {
        const content = {
            image: session.media,
            caption:
                session.caption || ""
        };

        if (bgColor) {
            content.backgroundColor =
                bgColor;
        }

        return groupStatus(
            conn,
            jid,
            content
        );
    }

    if (
        /^video\//i.test(
            session.mime
        )
    ) {
        const content = {
            video: session.media,
            caption:
                session.caption || ""
        };

        if (bgColor) {
            content.backgroundColor =
                bgColor;
        }

        return groupStatus(
            conn,
            jid,
            content
        );
    }

    if (
        /^audio\//i.test(
            session.mime
        )
    ) {
        const vn =
            await toVN(
                session.media
            );

        return groupStatus(
            conn,
            jid,
            {
                audio: vn,
                mimetype:
                    "audio/ogg; codecs=opus",
                ptt: true
            }
        );
    }

    throw new Error(
        "MEDIA_NOT_SUPPORTED"
    );
}

function parseSelectionId(id) {
    if (
        typeof id !== "string"
    ) {
        return null;
    }

    if (
        !id.startsWith(
            "swgc_select:"
        )
    ) {
        return null;
    }

    const parts =
        id.split(":");

    if (
        parts.length < 3
    ) {
        return null;
    }

    return {
        token: parts[1],
        jid: parts
            .slice(2)
            .join(":")
    };
}

let handler = async (
    m,
    {
        conn,
        text,
        usedPrefix,
        command
    }
) => {
    const input =
        String(text || "").trim();

    if (
        !input &&
        !m.quoted
    ) {
        return m.reply(
`╭─〔 ✨ SW GROUP 〕
│
│ Kirim pesan ke status group
│ dengan memilih tujuan dari
│ daftar group yang tersedia.
│
├─〔 📝 TEKS 〕
│
│ ${usedPrefix + command} Halo semuanya
│
├─〔 🎨 WARNA 〕
│
│ ${usedPrefix + command} Halo|merah
│
├─〔 🖼️ MEDIA 〕
│
│ Reply gambar / video / audio
│ lalu:
│ ${usedPrefix + command}
│
╰────────────────────`
        );
    }

    try {
        const parsed =
            parseInput(input);

        let caption =
            parsed.caption;

        const warna =
            parsed.warna;

        const quoted =
            m.quoted || null;

        const mime =
            getMime(quoted);

        const quotedCaption =
            getQuotedCaption(
                quoted
            );

        if (
            !caption &&
            quotedCaption
        ) {
            caption =
                quotedCaption;
        }

        const hasMedia =
            !!mime &&
            /image|video|audio/i.test(
                mime
            );

        if (
            !caption &&
            !hasMedia
        ) {
            return m.reply(
`╭─〔 ❌ PESAN KOSONG 〕
│
│ Masukkan teks atau reply
│ gambar / video / audio.
│
│ Contoh:
│ ${usedPrefix + command} Halo
│ ${usedPrefix + command} Halo|merah
│
╰────────────────────`
            );
        }

        let media = null;
        let mediaMime = "";

        if (hasMedia) {
            const prepared =
                await prepareMedia(
                    quoted
                );

            media =
                prepared.media;

            mediaMime =
                prepared.mime;
        }

        const groups =
            await getGroups(
                conn
            );

        if (
            !groups.length
        ) {
            return m.reply(
`╭─〔 ❌ GROUP KOSONG 〕
│
│ Bot belum tergabung
│ ke group manapun.
│
╰────────────────────`
            );
        }

        const token =
            createToken();

        const session = {
            sender:
                m.sender,

            chat:
                m.chat,

            caption,

            warna,

            media,

            mime:
                mediaMime,

            createdAt:
                Date.now(),

            processing:
                false
        };

        swgcSessions.set(
            token,
            session
        );

        await sendGroupSelector(
            conn,
            m,
            groups,
            session,
            token
        );
    } catch (error) {
        console.error(
            "[SWGC PREPARE ERROR]",
            error
        );

        if (
            error.message ===
            "MEDIA_DOWNLOAD_FAILED"
        ) {
            return m.reply(
`╭─〔 ❌ MEDIA ERROR 〕
│
│ Media tidak dapat diambil.
│
│ Coba reply media tersebut
│ kemudian jalankan command lagi.
│
╰────────────────────`
            );
        }

        return m.reply(
`╭─〔 ❌ SWGC ERROR 〕
│
│ Gagal menyiapkan SW Group.
│
│ ${error.message ||
    "Unknown error"}
│
╰────────────────────`
        );
    }
};

handler.before = async (
    m,
    {
        conn
    }
) => {
    try {
        const selectedId =
            extractNativeFlowId(m);

        if (!selectedId) {
            return;
        }

        const selection =
            parseSelectionId(
                selectedId
            );

        if (!selection) {
            return;
        }

        const {
            token,
            jid: targetId
        } = selection;

        const session =
            swgcSessions.get(
                token
            );

        if (!session) {
            await conn.reply(
                m.chat,
`╭─〔 ⚠️ SESI EXPIRED 〕
│
│ Menu SWGC sudah kadaluarsa.
│
│ Silakan jalankan .swgc
│ kembali untuk membuat
│ menu baru.
│
╰────────────────────`,
                m
            );

            return true;
        }

        if (
            session.sender !==
            m.sender
        ) {
            return true;
        }

        if (
            session.chat !==
            m.chat
        ) {
            return true;
        }

        if (
            Date.now() -
                session.createdAt >
            SESSION_EXPIRE
        ) {
            swgcSessions.delete(
                token
            );

            await conn.reply(
                m.chat,
`╭─〔 ⚠️ SESI EXPIRED 〕
│
│ Menu SWGC sudah kadaluarsa.
│
│ Silakan jalankan .swgc
│ kembali untuk membuat
│ menu baru.
│
╰────────────────────`,
                m
            );

            return true;
        }

        if (
            !/@g\.us$/i.test(
                targetId
            )
        ) {
            return true;
        }

        if (
            session.processing
        ) {
            return true;
        }

        session.processing =
            true;

        await conn.sendMessage(
            m.chat,
            {
                react: {
                    text: "⏳",
                    key: m.key
                }
            }
        ).catch(() => {});

        let groups;

        try {
            groups =
                await getGroups(
                    conn
                );
        } catch {
            session.processing =
                false;

            await conn.sendMessage(
                m.chat,
                {
                    react: {
                        text: "❌",
                        key: m.key
                    }
                }
            ).catch(() => {});

            return true;
        }

        const group =
            groups.find(
                g =>
                    g.id ===
                    targetId
            );

        if (!group) {
            session.processing =
                false;

            await conn.sendMessage(
                m.chat,
                {
                    react: {
                        text: "❌",
                        key: m.key
                    }
                }
            ).catch(() => {});

            await conn.reply(
                m.chat,
`╭─〔 ❌ GROUP TIDAK DITEMUKAN 〕
│
│ Group tersebut sudah tidak
│ tersedia di daftar bot.
│
╰────────────────────`,
                m
            );

            return true;
        }

        try {
            await sendSessionToGroup(
                conn,
                targetId,
                session
            );

            swgcSessions.delete(
                token
            );

            await conn.sendMessage(
                m.chat,
                {
                    react: {
                        text: "✅",
                        key: m.key
                    }
                }
            ).catch(() => {});

            const groupName =
                group.subject ||
                "Tanpa Nama";

            const mediaType =
                session.media
                    ? /^image\//i.test(
                        session.mime
                    )
                        ? "🖼️ Gambar"
                        : /^video\//i.test(
                            session.mime
                        )
                            ? "🎬 Video"
                            : /^audio\//i.test(
                                session.mime
                            )
                                ? "🎵 Audio / VN"
                                : "📦 Media"
                    : "📝 Teks";

            await conn.reply(
                m.chat,
`╭─〔 ✅ SW GROUP TERKIRIM 〕
│
│ Status berhasil dikirim.
│
├─〔 🎯 TARGET 〕
│ ${groupName}
│
├─〔 🆔 GROUP ID 〕
│ ${targetId}
│
├─〔 📦 TYPE 〕
│ ${mediaType}
│
${session.warna
    ? `├─〔 🎨 WARNA 〕
│ ${session.warna}
│
`
    : ""}╰────────────────────`,
                m
            );

            return true;
        } catch (error) {
            console.error(
                "[SWGC SEND ERROR]",
                error
            );

            session.processing =
                false;

            await conn.sendMessage(
                m.chat,
                {
                    react: {
                        text: "❌",
                        key: m.key
                    }
                }
            ).catch(() => {});

            await conn.reply(
                m.chat,
`╭─〔 ❌ SW GROUP GAGAL 〕
│
│ Status gagal dikirim.
│
├─〔 🎯 TARGET 〕
│ ${group.subject || "Tanpa Nama"}
│
├─〔 🆔 ID 〕
│ ${targetId}
│
├─〔 ⚠️ ERROR 〕
│ ${error?.message || "Unknown error"}
│
╰────────────────────`,
                m
            );

            return true;
        }
    } catch (error) {
        console.error(
            "[SWGC BUTTON ERROR]",
            error
        );

        return true;
    }
};

handler.help = [
    "swgc",
    "upswgc"
];

handler.tags = [
    "group"
];

handler.command =
    /^(swgc|upswgc)$/i;

handler.owner = true;
handler.limit = 10;

export default handler;