import { io } from 'socket.io-client'
import axios from 'axios'

// 1. Scraper HeyBro AI (Socket.IO)
const heybro = async (prompt, options = {}) => {
  return new Promise((resolve, reject) => {
    const socket = io('https://backend.heybro.ai/v2/query', {
      transports: ['websocket', 'polling'],
      timeout: 30000
    })

    const userId =
      'temp-user-' +
      Date.now() +
      Math.random().toString(36).substring(2, 7)

    const instruction = `
Kamu adalah AI bernama HeyBro.
Jawab pengguna menggunakan bahasa Indonesia yang ramah, jelas, dan akurat.
Pertanyaan pengguna:
${prompt}
`.trim()

    const payload = {
      prompt: instruction,
      history: [],
      model: 'gpt-4o-mini',
      sourceType: 'web',
      userId
    }

    if (options.buffer) {
      // Socket.io binary transfer
      payload.file = options.buffer
    }

    socket.on('connect', () => {
      socket.emit('/query', {
        body: payload
      })
    })

    let fullText = ''
    let finished = false

    socket.on('response', (data) => {
      if (data && data.type === 'message') {
        fullText += data.value || ''
      }
    })

    socket.on('end', () => {
      if (finished) return
      finished = true
      socket.disconnect()

      if (!fullText.trim()) {
        reject(new Error('Tidak ada respon dari HeyBro AI.'))
      } else {
        resolve(fullText.trim())
      }
    })

    socket.on('connect_error', (err) => {
      if (finished) return
      finished = true
      socket.disconnect()
      reject(new Error('Koneksi socket gagal: ' + err.message))
    })

    socket.on('error', (err) => {
      if (finished) return
      finished = true
      socket.disconnect()
      reject(new Error('Server error: ' + (typeof err === 'object' ? JSON.stringify(err) : err)))
    })

    setTimeout(() => {
      if (finished) return
      finished = true
      socket.disconnect()

      if (fullText.trim()) {
        resolve(fullText.trim())
      } else {
        reject(new Error('Request timeout dari HeyBro AI.'))
      }
    }, 35000)
  })
}

// 2. Fallback AI Vision Scraper (Aktif otomatis jika backend HeyBro menolak melihat gambar)
const analyzeImageFallback = async (buffer, prompt) => {
  const base64 = buffer.toString('base64')
  const dataUrl = `data:image/jpeg;base64,${base64}`

  const response = await axios.post(
    'https://text.pollinations.ai/',
    {
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt || 'Jelaskan gambar ini secara detail menggunakan bahasa Indonesia.' },
            { type: 'image_url', image_url: { url: dataUrl } }
          ]
        }
      ],
      model: 'openai'
    },
    {
      headers: { 'Content-Type': 'application/json' },
      timeout: 45000
    }
  )

  if (typeof response.data === 'string') return response.data.trim()
  if (response.data?.choices?.[0]?.message?.content) {
    return response.data.choices[0].message.content.trim()
  }
  throw new Error('Gagal menganalisis gambar.')
}

// 3. Bot Handler
const handler = async (m, { conn, text, usedPrefix, command }) => {
  // Ambil target pesan (reply atau pesan utama)
  const q = m.quoted ? m.quoted : m

  // Deteksi mimetype gambar dari berbagai struktur Baileys
  const mime =
    q.mimetype ||
    (q.msg && q.msg.mimetype) ||
    (q.message && q.message.imageMessage && q.message.imageMessage.mimetype) ||
    q.mediaType ||
    ''

  const isImage =
    /image\/(jpe?g|png|webp)/i.test(mime) ||
    q.mtype === 'imageMessage' ||
    q.mtype === 'viewOnceMessageV2' ||
    Boolean(q.message?.imageMessage)

  if (!text && !isImage) {
    throw `Contoh Penggunaan:

1. Nanya Biasa:
${usedPrefix + command} resep nasi goreng sederhana

2. Analisis Gambar:
Kirim gambar dengan caption atau reply gambar dengan:
${usedPrefix + command} ini gambar apa?`
  }

  await conn.reply(m.chat, '🔍 _Sedang memproses permintaan..._', m)

  let imgBuffer = null
  if (isImage) {
    try {
      if (typeof q.download === 'function') {
        imgBuffer = await q.download()
      } else if (conn.downloadMediaMessage) {
        imgBuffer = await conn.downloadMediaMessage(q)
      }
    } catch (e) {
      console.error('Gagal download gambar:', e)
    }
  }

  try {
    const prompt = text || 'Jelaskan gambar ini secara detail.'
    let result = ''

    if (imgBuffer) {
      // Coba lewat HeyBro terlebih dahulu
      const res = await heybro(prompt, { buffer: imgBuffer }).catch(() => null)

      // Cek apakah HeyBro merespon dengan penolakan vision (karena limitasi gpt-4o-mini di backend mereka)
      const isRefused =
        !res ||
        /tidak bisa melihat gambar|cannot see image|не могу видеть/i.test(res)

      if (isRefused) {
        // Otomatis lempar ke fallback vision engine agar gambar tetap terbaca 100%
        result = await analyzeImageFallback(imgBuffer, prompt)
      } else {
        result = res
      }
    } else {
      // Pertanyaan teks biasa
      result = await heybro(prompt)
    }

    await conn.reply(m.chat, result, m)
  } catch (err) {
    await conn.reply(m.chat, `❌ *Error:* ${err.message}`, m)
  }
}

handler.help = ['heybro']
handler.tags = ['ai']
handler.command = /^(heybro|bro)$/i
handler.limit = 10

export default handler