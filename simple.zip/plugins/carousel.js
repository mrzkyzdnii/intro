import { MB } from '@mrzkyzdnii/baileys'

const handler = async (m, { conn }) => {
  try {
    const card1 = await new MB.Button(conn)
      .setImage('https://placehold.co/600x400.jpg?text=CARD+1')
      .setBody('Kartu pertama')
      .addReply('Pilih', 'card_1')
      .toCard()

    const card2 = await new MB.Button(conn)
      .setImage('https://placehold.co/600x400.jpg?text=CARD+2')
      .setBody('Kartu kedua')
      .addReply('Pilih', 'card_2')
      .toCard()

    const carousel = new MB.Carousel(conn)
      .setBody('🎠 Contoh Carousel')
      .setFooter('MRZKYZDNII')
      .addCard([card1, card2])

    await carousel.send(m.chat)
  } catch (e) {
    console.error(e)
    m.reply('❌ ' + e.message)
  }
}

handler.help = ['carousel']
handler.tags = ['main']
handler.command = /^carousel$/i

export default handler