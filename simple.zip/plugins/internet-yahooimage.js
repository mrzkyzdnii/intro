import axios from 'axios'
import * as cheerio from 'cheerio'

const scraper = async (query) => {
    if (!query) throw new Error('Query tidak boleh kosong')

    try {
        const url = `https://search.yahoo.com/yhs/search?p=${encodeURIComponent(query)}&hsimp=yhs-001`
        const res = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            },
            timeout: 10000
        })

        const $ = cheerio.load(res.data)
        const results = []

        $('img').each((_, el) => {
            const src = $(el).attr('src') || $(el).attr('data-src')
            const title = $(el).attr('alt') || query
            // skip icon dan placeholder yahoo
            if (src && src.startsWith('http') && !src.includes('yimg.com/rsa') && !src.includes('data:image')) {
                results.push({
                    title,
                    url: src,
                    source: 'Yahoo Search'
                })
            }
        })

        if (results.length > 0) return results
    } catch (err) {
        console.log('Yahoo error:', err.message)
    }

    // Fallback engine jika Yahoo gagal
    const bingUrl = `https://www.bing.com/images/search?q=${encodeURIComponent(query)}`
    const res = await axios.get(bingUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9',
        },
        timeout: 10000
    })

    const results = []
    const regex = /murl&quot;:&quot;(https?:\/\/[^&]+)&quot;/g
    let match
    while ((match = regex.exec(res.data)) !== null) {
        const imgUrl = match[1].replace(/\\u0026/g, '&')
        results.push({
            title: query,
            url: imgUrl,
            source: 'Bing Engine'
        })
    }

    if (results.length === 0) {
        throw new Error(`Gambar tidak ditemukan untuk query: "${query}"`)
    }

    return results
}

// helper download buffer dengan header
const getBuffer = async (url) => {
    const res = await axios.get(url, { 
        responseType: 'arraybuffer',
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
            'Referer': 'https://search.yahoo.com/',
            'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8'
        },
        timeout: 15000
    })
    return res.data
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Example:\n${usedPrefix + command} meme lucu`

    await conn.reply(m.chat, `🔍 *Mencari gambar Yahoo:* _"${text}"_...`, m)

    try {
        const results = await scraper(text)
        
        // coba 3x kalau url pertama mati
        let buffer = null
        for(let i = 0; i < Math.min(3, results.length); i++){
            const randomImage = results[Math.floor(Math.random() * results.length)]
            try {
                buffer = await getBuffer(randomImage.url)
                if(buffer) {
                    var caption = `🖼️ *YAHOO IMAGE SEARCH*\n\n` +
                        `📌 *Query:* ${text}\n` +
                        `🌐 *Source:* ${randomImage.source}`
                    break
                }
            } catch(e) {
                console.log('Gagal download:', randomImage.url)
            }
        }
        
        if(!buffer) throw 'Semua URL gambar gagal di download'

        // Kirim sebagai image buffer biar pasti jadi gambar
        await conn.sendMessage(m.chat, { 
            image: buffer, 
            caption: caption 
        }, { quoted: m })

    } catch (err) {
        const errorMsg = typeof err === 'string' ? err : err.message || 'Terjadi kesalahan saat mencari gambar.'
        await conn.reply(m.chat, `❌ *Error:* ${errorMsg}`, m)
    }
}

handler.help = ['yahooimage']
handler.tags = ['internet']
handler.command = /^(yahooimage)$/i

handler.limit = 10
export default handler