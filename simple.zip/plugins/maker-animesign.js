import axios from 'axios'
import { createCanvas, loadImage, GlobalFonts } from '@napi-rs/canvas'
import fs from 'fs'

const TEMPLATE_URL = 'https://i.ibb.co.com/4nZyfZMN/a39d094d730079cec4f91224ca59937f.jpg'
const FONT_URL = 'https://cdn.jsdelivr.net/fontsource/fonts/caveat@latest/latin-700-normal.ttf'

let fontLoaded = false

// Download & register font aesthetic
const loadFont = async () => {
  if (fontLoaded) return
  try {
    const fontPath = './AestheticFont.ttf'
    if (!fs.existsSync(fontPath)) {
      const res = await axios.get(FONT_URL, { responseType: 'arraybuffer', timeout: 10000 })
      fs.writeFileSync(fontPath, Buffer.from(res.data))
    }
    GlobalFonts.registerFromPath(fontPath, 'AestheticFont')
    fontLoaded = true
  } catch (_) {
    // Jika ganti font gagal, fallback ke sans-serif
  }
}

const scraper = async (query) => {
  if (!query) throw new Error('Teks tidak boleh kosong!')

  await loadFont()

  // Fetch background template
  const res = await axios.get(TEMPLATE_URL, { responseType: 'arraybuffer', timeout: 10000 })
  const bgImage = await loadImage(Buffer.from(res.data))

  const canvas = createCanvas(bgImage.width, bgImage.height)
  const ctx = canvas.getContext('2d')

  // Draw template background
  ctx.drawImage(bgImage, 0, 0)

  // Koordinat & Batas Papan Sign Anime
  const boxWidth = 240   // Batas lebar maksimum teks
  const boxHeight = 340  // Batas tinggi maksimum teks
  const centerX = 560    // Titik tengah X papan
  const centerY = 340    // Titik tengah Y papan

  const fontName = fontLoaded ? 'AestheticFont' : 'sans-serif'

  // Algoritma dynamic font scaling agar teks tidak meluap keluar papan
  let fontSize = 58
  let lines = []
  let lineHeight = 0

  while (fontSize > 12) {
    ctx.font = `bold ${fontSize}px "${fontName}"`
    lineHeight = fontSize * 1.15

    const words = query.trim().split(/\s+/)
    lines = []
    let currentLine = ''

    for (const word of words) {
      const testLine = currentLine ? `${currentLine} ${word}` : word
      const metrics = ctx.measureText(testLine)

      if (metrics.width > boxWidth && currentLine) {
        lines.push(currentLine)
        currentLine = word
      } else {
        currentLine = testLine;
      }
    }
    if (currentLine) {
      lines.push(currentLine)
    }

    const totalHeight = lines.length * lineHeight
    const maxLineWidth = Math.max(...lines.map((l) => ctx.measureText(l).width))

    // Cek apakah teks pas di dalam kotak
    if (maxLineWidth <= boxWidth && totalHeight <= boxHeight) {
      break
    }

    fontSize -= 2
  }

  // Miringkan teks sedikit (-2 derajat) mengikuti perspektif papan
  ctx.save()
  ctx.translate(centerX, centerY)
  ctx.rotate((-2 * Math.PI) / 180)

  // Style Teks Ink Aesthetic
  ctx.fillStyle = '#222222'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.font = `bold ${fontSize}px "${fontName}"`

  const totalHeight = lines.length * lineHeight
  const startY = -totalHeight / 2 + lineHeight / 2

  lines.forEach((line, index) => {
    ctx.fillText(line, 0, startY + index * lineHeight)
  })

  ctx.restore()

  return canvas.toBuffer('image/jpeg')
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} Halo Semuanya!`

  try {
    const buffer = await scraper(text)

    await conn.sendFile(
      m.chat,
      buffer,
      'animesign.jpg',
      `✨ *Anime Sign Result*\n📝 *Text:* ${text}`,
      m
    )
  } catch (err) {
    await conn.reply(m.chat, `❌ Error: ${err.message || err}`, m)
  }
}

handler.help = ['animesign']
handler.tags = ['maker']
handler.command = /^(animesign|animesignboard|animesigntext)$/i

handler.limit = 10
export default handler