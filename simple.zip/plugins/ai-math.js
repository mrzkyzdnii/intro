import axios from 'axios'
import crypto from 'crypto'

/**
 * Scraper MathGPT AI Chat Completions
 * @param {string} query - Pesan / pertanyaan dari user
 * @returns {Promise<string>} - Jawaban teks dari MathGPT
 */
const scraper = async (query) => {
    if (!query) throw new Error('Query tidak boleh kosong')

    const randomConversationId = crypto.randomUUID()

    const response = await axios.post(
        'https://math-gpt.org/api/v3/chat/completions',
        {
            messages: [
                {
                    role: 'user',
                    content: [{ type: 'text', text: query }]
                }
            ],
            conversationId: randomConversationId
        },
        {
            headers: {
                'User-Agent':
                    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Mobile Safari/537.36',
                'Content-Type': 'application/json',
                'Accept': '*/*',
                'Origin': 'https://math-gpt.org',
                'Referer': 'https://math-gpt.org/',
                'x-topic': 'math'
            },
            responseType: 'text',
            timeout: 30000
        }
    )

    let fullResponse = ''
    const lines = response.data.split('\n')

    for (const line of lines) {
        if (line.startsWith('data: ')) {
            const jsonStr = line.slice(6).trim()
            try {
                const parsed = JSON.parse(jsonStr)
                if (parsed.event === 'message_delta' && parsed.delta?.content) {
                    fullResponse += parsed.delta.content
                }
            } catch (e) {
                // Abaikan jika chunk bukan JSON valid
            }
        }
    }

    const result = fullResponse.trim()
    if (!result) {
        throw new Error('Tidak ada respon yang diterima dari MathGPT')
    }

    return result
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Example:\n${usedPrefix + command} aku nih lagi sedih`

    await conn.reply(m.chat, '⏳ _Sedang memikirkan jawaban..._', m)

    try {
        const result = await scraper(text)
        await conn.reply(m.chat, result, m)
    } catch (err) {
        const errorMsg = typeof err === 'string' ? err : err.message || 'Terjadi kesalahan saat memproses request.'
        await conn.reply(m.chat, `❌ *Error:* ${errorMsg}`, m)
    }
}

handler.help = ['mathai']
handler.tags = ['ai', 'tools']
handler.command = /^(mathai)$/i

handler.limit = 10
export default handler