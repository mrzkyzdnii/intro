import cloudscraper from 'cloudscraper'
const BASE_URL = 'https://www.meigen.ai'
const getRandomPrompt = async (query, limit = 20) => {
  const params = new URLSearchParams({
    q: query,
    type: 'posts',
    limit: String(Math.min(Math.max(limit, 1), 20)),
    offset: '0'
  })
  const response = await cloudscraper.get({
    uri: `${BASE_URL}/api/search?${params}`,
    resolveWithFullResponse: true,
    json: true,
    gzip: true,
    headers: {
      accept: 'application/json',
      'accept-language': 'id-ID,id;q=0.9,en;q=0.8',
      'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36',
      referer: `${BASE_URL}/search?q=${encodeURIComponent(query)}`
    }
  })
  if (response.statusCode !== 200) {
    throw new Error(`${response.statusCode}`)
  }
  const results = Array.isArray(response.body?.data) ? response.body.data : []
  if (!response.body?.success || results.length === 0) {
    throw new Error(`${query}`)
  }
  const item = results[Math.floor(Math.random() * results.length)]
  return {
    prompt: item.text?.trim() || '',
    image: item.thumbnail_url || item.media_urls?.[0] || null,
    id: item.id || null,
    author: item.author_display_name || item.author_username || null,
    model: item.model || null
  }
}
const handler = async (m, { conn, text, usedPrefix, command }) => {
  const query = text?.trim()
  if (!query) throw `Contoh: ${usedPrefix + command} cyberpunk city`

  try {
    const result = await getRandomPrompt(query)
    const output = [      
      result.prompt,
      result.image ? `\nPreview: ${result.image}` : '',
      result.author ? `Author: ${result.author}` : '',
      result.model ? `Model: ${result.model}` : ''
    ].filter(Boolean).join('\n')

    await conn.reply(m.chat, output, m)
  } catch (error) {
    throw `${error.message}`
  }
}
handler.help = ['meigen']
handler.tags = ['tools']
handler.command = /^meigen$/i
handler.limit = 10

export default handler