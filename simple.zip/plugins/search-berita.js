import axios from 'axios'
import * as cheerio from 'cheerio'

const scraper = async (query) => {
  const { data } = await axios.get('https://www.detik.com/search/searchall', {
    params: {
      query,
      siteid: 3,
      source_kanal: 'true'
    },
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
    },
    timeout: 10000
  })

  let $ = cheerio.load(data)
  let list = []

  $('article').each((_, el) => {
    const title = $(el).find('.media__title a').text().trim()
    const link = $(el).find('.media__title a').attr('href')
    const category = $(el).find('.media__subtitle').text().trim()
    const desc = $(el).find('.media__desc').text().trim()
    const date = $(el).find('.media__date span').attr('title') || $(el).find('.media__date').text().trim()

    if (title && link) {
      list.push({ title, category, desc, date, link })
    }
  })

  if (!list.length) {
    const res = await axios.get('https://www.detik.com/search/searchall', {
      params: { query },
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
      },
      timeout: 10000
    })
    $ = cheerio.load(res.data)
    $('article').each((_, el) => {
      const title = $(el).find('.media__title a').text().trim()
      const link = $(el).find('.media__title a').attr('href')
      const category = $(el).find('.media__subtitle').text().trim()
      const desc = $(el).find('.media__desc').text().trim()
      const date = $(el).find('.media__date span').attr('title') || $(el).find('.media__date').text().trim()

      if (title && link) {
        list.push({ title, category, desc, date, link })
      }
    })
  }

  if (!list.length) return `Berita dengan kata kunci "${query}" tidak ditemukan.`

  const result = list.slice(0, 10).map((item, index) => {
    return `*${index + 1}. ${item.title}*\n` +
      `📅 ${item.date || '-'}\n` +
      `🏷️ ${item.category || 'Detik'}\n` +
      `📝 ${item.desc || '-'}\n` +
      `🔗 ${item.link}`
  }).join('\n\n────────────────\n\n')

  return `*DETIK NEWS - PENCARIAN*\nKata Kunci: ${query}\n\n` + result
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} demo`

  const result = await scraper(text)

  await conn.reply(m.chat, result, m)
}

handler.help = ['berita']
handler.tags = ['search']
handler.command = /^berita$/i
handler.limit = 10

export default handler