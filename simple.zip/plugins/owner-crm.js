import crypto from 'crypto'
import { proto } from '@mrzkyzdnii/baileys'

const handler = async (m, { conn, text, command }) => {
	const args = String(text || '').trim().split(/\s+/).filter(Boolean)

	if (!m.quoted) {
		const usage = `📌 *.${command}* butuh pesan yang di-reply.

*Command:*
• .crm → Generate file relay siap pakai dari pesan
• .crm2 → Kirim raw + relay code via tombol interaktif
• .adn → Ambil AdditionalNodes dari pesan
• .insp → Ambil raw payload (JSON) pesan
• .relay → Langsung relay ulang pesan

*Flag opsional:*
• -raw → Export raw JSON pesan
• -message → Export bagian message saja
• -relay → Export kode relay
• -file → Kirim hasil export sebagai dokumen
• -snip → Tampilkan hasil sebagai code snippet
• -nofilter → Jangan filter AdditionalNodes
• -nochild → Matikan child
• -noproto → Skip protocol processing

Contoh:
.crm
.crm -snip
.insp -noproto -raw -file
.relay
.adn`

		return m.reply(usage)
	}

	const chatId = m.quoted.chat || m.chat
	const targetId = m.quoted.id

	const sources = [
		{
			type: 'quotedObj',
			data: await m.getQuotedObj?.(),
		},
		{
			type: 'fakeObj',
			data: m.quoted?.fakeObj,
		},
		{
			type: 'quoted',
			data: m.quoted,
		},
	]

	const source = sources.find(v => v.data?.message || v.data?.key)

	if (!source?.data) {
		return m.reply('Message quoted tidak bisa dibaca.')
	}

	const msgSource = source.type
	let msg = normalizeMessage(source.data)

	if (!msg?.message) {
		return m.reply(`⛓️‍💥 Message tidak valid (${typeof msg?.message})`)
	}

	const messageId = msg.key?.id || targetId
	const rawNode = null
	const nodeAttrs = {}
	const nodeContent = []
	const type = Object.keys(msg.message).find(v => !['messageContextInfo', 'senderKeyDistributionMessage'].includes(v)) || 'unknown'
	const additionalNodes = filterAdditionalNodes(nodeContent)
	const relayOptions = {}
	const parentSender = getSenderIdentity(msg.key)
	const noChild = text.includes('-nochild')
	const noProto = text.includes('-noproto')

	const stats = {
		fails: 0,
	}

	const childTree = []

	if (!noChild && !noProto) {
		stats.fails = 0
	}

	if (command === 'relay') {
		const newParentId = await conn.relayMessage(m.chat, structuredClone(msg.message), relayOptions)
		return m.reply(newParentId)
	}

	const rawPayload = {
		message: msg,
		node: rawNode,
		additionalAttributes: nodeAttrs,
		additionalNodes,
	}

	const raw = stringify(rawPayload)
	const message = stringify(msg.message)
	const key = stringify(msg.key)
	const options = stringifySnippet(relayOptions)

	const participant = msg.key?.remoteJid || msg.key?.participant || msg.key?.participantAlt || '-'
	const msgId = msg.key?.id || targetId || '-'
	const snippetMessage = stringifySnippet(msg.message)
	const relayCode = buildRelayScript(snippetMessage, stringifySnippet(relayOptions), childTree)

	const files = {
		raw,
		message,
		relay: relayCode,
	}

	const exportType = ['raw', 'message', 'relay'].find(v => text.includes(`-${v}`))

	if (exportType) {
		if (text.includes('-file')) {
			return conn.sendMessage(
				m.chat,
				{
					document: Buffer.from(files[exportType]),
					fileName: exportType === 'relay' ? `${type}.js` : `${exportType}.json`,
					mimetype: exportType === 'relay' ? 'application/javascript' : 'application/json',
				},
				{ quoted: m }
			)
		}

		return m.reply(files[exportType])
	}

	const isSnip = text.includes('-snip')

	const formatChat = chat => {
		if (!chat) return '-'
		return isSnip ? `${chat.slice(0, 7)}.....${chat.split('@')[1] || ''}` : chat
	}

	const formatId = id => {
		if (!id) return '-'
		return isSnip ? `${id.slice(0, 7)}.....` : id
	}

	const childrenCount = countTree(childTree)
	const childrenLine = stats.fails ? `${childrenCount} (${stats.fails} fail)` : `${childrenCount}`
	const sender = msg.key?.participant || msg.key?.participantAlt || msg.key?.remoteJid || m.quoted?.sender || '-'

	const metadata = `• Type     : ${type}
• Source   : ${msgSource || '-'}
• Chat     : ${formatChat(chatId)}
• ID       : ${formatId(messageId)}
• Sender   : ${sender.split('@')[0]}
• Children : ${childrenLine}`

	if (command === 'insp') {
		const inspPayload = attachChildren(rawPayload, childTree)

		if (isSnip) {
			const imsg = stringify(inspPayload)

			if (imsg.length > 20000) {
				await m.react('❌')
				return m.reply('Payload terlalu besar untuk snip.')
			}

			return new AIRich(conn)
				.addText('# 📥️ Raw Snippet')
				.addMetadata(metadata)
				.addSuggest([type, chatId, messageId])
				.addCode('javascript', imsg)
				.send(m.chat, {
					quoted: m,
					includesSubmessages: false,
				})
		}

		return conn.sendMessage(
			m.chat,
			{
				document: Buffer.from(stringify(inspPayload)),
				fileName: `${type}.json`,
				mimetype: 'application/json',
				caption: metadata,
			},
			{ quoted: m }
		)
	}

	const adn = text.includes('-nofilter') ? additionalNodes : filterAdditionalNodes(additionalNodes)

	if (command === 'adn' && !adn.length) {
		return m.reply('No AdditionalNodes captured 📷')
	}

	if (command === 'crm') {
		if (isSnip) {
			if (relayCode.length > 20000) {
				await m.react('❌')
				return m.reply('Payload terlalu besar untuk snip.')
			}

			return new AIRich(conn)
				.addText('# ⚡ Relay Snippet')
				.addMetadata(metadata)
				.addSuggest([type, chatId, messageId])
				.addCode('javascript', relayCode)
				.send(m.chat, {
					quoted: m,
					includesSubmessages: false,
				})
		}

		return conn.sendMessage(
			m.chat,
			{
				document: Buffer.from(relayCode),
				fileName: `${type}.js`,
				mimetype: 'application/javascript',
				caption: metadata,
			},
			{ quoted: m }
		)
	}

	if (command === 'adn') {
		if (isSnip) {
			return new AIRich(conn)
				.addText('# 📸 AdditionalNode Captured')
				.addMetadata(metadata)
				.addSuggest([type, chatId, messageId])
				.addCode('javascript', stringifySnippet(adn))
				.send(m.chat, {
					quoted: m,
				})
		}

		return conn.sendMessage(
			m.chat,
			{
				document: Buffer.from(stringify(adn)),
				fileName: 'additionalNodes.json',
				mimetype: 'application/json',
			},
			{ quoted: m }
		)
	}

	if (command === 'crm2') {
		return new Button(conn)
			.setTitle(capitalize(type))
			.setBody(metadata + '\n\n' + raw)
			.setMedia({
				document: Buffer.from(relayCode),
				mimetype: 'application/javascript',
				fileName: `${type}.js`,
			})
			.setParams({
				limited_time_offer: {
					text: 'Create Relay Message',
					url: 'https://wa.me/6282139672290',
					copy_code: namebot,
					expiration_time: Date.now() + 60000,
				},
				bottom_sheet: {
					in_thread_buttons_limit: 3,
					divider_indices: [1, 2, 3, 4, 5, 6],
					list_title: 'Payload Options',
					button_title: 'Other',
				},
			})
			.addCopy('Copy Full Raw', raw)
			.addCopy('Copy Relay Code', relayCode)
			.addCopy('Copy Payload', message)
			.addCopy('Copy Key', key)
			.addCopy('Copy Sender', participant)
			.addCopy('Copy Message ID', msgId)
			.addCopy('Copy Options', options)
			.send(m.chat, {
				quoted: m,
			})
	}
}

handler.command = ['crm', 'crm2', 'insp', 'adn', 'relay']
handler.tags = 'owner'
handler.owner = true

export default handler

const ignoredTags = new Set([
	'device-identity',
	'quality_control',
	'enc',
	'hsm',
	'verified_name',
	'multicast',
	'reporting',
	'unavailable',
	'rcat',
])

const ignoredAttributes = new Set([
	'id',
	'from',
	'to',
	'participant',
	'recipient',
	'type',
	'sts',
	'verified_level',
	'notify',
	'addressing_mode',
	'verified_name',
	'participant_pn',
	't',
	'count',
])

const SECRET_CONTEXT = {
	EVENT_EDIT: 'Event Edit',
	MESSAGE_EDIT: 'Message Edit',
	POLL_EDIT: 'Poll Edit',
	POLL_ADD_OPTION: 'Poll Edit',
}

function normalizeMessage(rmsg) {
	try {
		return proto.WebMessageInfo.toObject(
			proto.WebMessageInfo.fromObject(rmsg),
			{
				enums: Number,
				longs: Number,
				bytes: String,
				defaults: false,
			}
		)
	} catch {
		return rmsg
	}
}

function getSenderIdentity(key) {
	if (!key) {
		return {
			me: false,
			jids: new Set(),
		}
	}

	if (key.fromMe) {
		return {
			me: true,
			jids: new Set(),
		}
	}

	const jids = new Set([key.participant, key.participantAlt].filter(Boolean))

	if (!jids.size && key.remoteJid) {
		jids.add(key.remoteJid)
	}

	return {
		me: false,
		jids,
	}
}

function sameSender(a, b) {
	if (!a || !b) return false

	if (a.me || b.me) {
		return a.me && b.me
	}

	for (const jid of a.jids) {
		if (b.jids.has(jid)) return true
	}

	return false
}

function getSenderId(key) {
	const identity = getSenderIdentity(key)

	if (identity.me) {
		return 'me'
	}

	return identity.jids.values().next().value || null
}

function collectDeepKeys(node, depth = 0, maxDepth = 12, out = []) {
	if (!node || typeof node !== 'object' || depth > maxDepth) {
		return out
	}

	if (node.protocolMessage?.key) {
		out.push(node.protocolMessage.key)
	}

	if (node.secretEncryptedMessage?.targetMessageKey) {
		out.push(node.secretEncryptedMessage.targetMessageKey)
	}

	for (const value of Object.values(node)) {
		if (value && typeof value === 'object') {
			collectDeepKeys(value, depth + 1, maxDepth, out)
		}
	}

	return out
}

function collectSecretMessages(node, depth = 0, maxDepth = 12, out = []) {
	if (!node || typeof node !== 'object' || depth > maxDepth) {
		return out
	}

	if (node.secretEncryptedMessage) {
		out.push(node.secretEncryptedMessage)
	}

	for (const value of Object.values(node)) {
		if (value && typeof value === 'object') {
			collectSecretMessages(value, depth + 1, maxDepth, out)
		}
	}

	return out
}

function findMessageSecret(node, depth = 0, maxDepth = 12) {
	if (!node || typeof node !== 'object' || depth > maxDepth) {
		return null
	}

	if (node.messageContextInfo?.messageSecret) {
		return node.messageContextInfo.messageSecret
	}

	for (const value of Object.values(node)) {
		if (value && typeof value === 'object') {
			const found = findMessageSecret(value, depth + 1, maxDepth)

			if (found) return found
		}
	}

	return null
}

function secretEncTypeName(value) {
	if (typeof value === 'string') return value

	try {
		return proto.Message.SecretEncryptedMessage.SecretEncType[value] ?? value
	} catch {
		return value
	}
}

function getSecretContext(type) {
	return SECRET_CONTEXT[type] || null
}

function decryptSecretMessage(secretMsg, target, type) {
	try {
		const targetId = secretMsg?.targetMessageKey?.id

		if (!targetId || !secretMsg?.encPayload || !secretMsg?.encIv || !target?.messageSecret) {
			return null
		}

		const context = getSecretContext(type)

		if (!context) return null

		const messageSecret = target.messageSecret

		if (messageSecret.length !== 32) return null

		const senderJid = target.senderJid

		const info = Buffer.concat([
			Buffer.from(targetId, 'utf8'),
			Buffer.from(senderJid, 'utf8'),
			Buffer.from(senderJid, 'utf8'),
			Buffer.from(context, 'utf8'),
		])

		const key = crypto.hkdfSync(
			'sha256',
			messageSecret,
			Buffer.alloc(0),
			info,
			32
		)

		const encPayload = Buffer.from(secretMsg.encPayload, 'base64')
		const encIv = Buffer.from(secretMsg.encIv, 'base64')

		if (encIv.length !== 12 || encPayload.length < 16) {
			return null
		}

		const authTag = encPayload.subarray(-16)
		const ciphertext = encPayload.subarray(0, -16)

		const decipher = crypto.createDecipheriv(
			'aes-256-gcm',
			Buffer.from(key),
			encIv
		)

		decipher.setAuthTag(authTag)

		const plaintext = Buffer.concat([
			decipher.update(ciphertext),
			decipher.final(),
		])

		const decoded = proto.Message.decode(plaintext)

		return proto.Message.toObject(decoded, {
			enums: Number,
			longs: Number,
			bytes: String,
			defaults: false,
		})
	} catch {
		return null
	}
}

function replaceSecretEnvelope(node, targetSecret, decrypted) {
	if (!node || typeof node !== 'object') {
		return node
	}

	if (node.secretEncryptedMessage === targetSecret) {
		return decrypted
	}

	if (
		node.secretEncryptedMessage &&
		sameSecretEnvelope(node.secretEncryptedMessage, targetSecret)
	) {
		return decrypted
	}

	if (Array.isArray(node)) {
		return node.map(value =>
			replaceSecretEnvelope(value, targetSecret, decrypted)
		)
	}

	const out = { ...node }

	for (const [key, value] of Object.entries(out)) {
		if (value && typeof value === 'object') {
			out[key] = replaceSecretEnvelope(value, targetSecret, decrypted)
		}
	}

	return out
}

function sameSecretEnvelope(a, b) {
	return (
		a?.targetMessageKey?.id === b?.targetMessageKey?.id &&
		a?.encPayload === b?.encPayload &&
		a?.encIv === b?.encIv &&
		a?.secretEncType === b?.secretEncType
	)
}

function getParentKey(key, chat) {
	if (!key?.id) return null

	return {
		id: key.id,
		remoteJid: key.remoteJid || chat,
		fromMe: !!key.fromMe,
		participant: key.participant,
		participantAlt: key.participantAlt,
	}
}

function matchesParentKey(keyObj, parentKey, chat) {
	if (!keyObj || !parentKey) return false

	if (!keyObj.id || keyObj.id !== parentKey.id) {
		return false
	}

	const keyRemoteJid = keyObj.remoteJid || keyObj.remoteJidAlt
	const parentRemoteJid = parentKey.remoteJid || chat

	if (
		keyRemoteJid &&
		parentRemoteJid &&
		keyRemoteJid !== parentRemoteJid
	) {
		return false
	}

	return true
}

function collectProtocolKeys(node, depth = 0, maxDepth = 12, out = []) {
	if (!node || typeof node !== 'object' || depth > maxDepth) {
		return out
	}

	if (node.protocolMessage?.key) {
		out.push(node.protocolMessage.key)
	}

	for (const value of Object.values(node)) {
		if (value && typeof value === 'object') {
			collectProtocolKeys(value, depth + 1, maxDepth, out)
		}
	}

	return out
}

function filterAdditionalNodes(nodes) {
	return (nodes || []).filter(v => !ignoredTags.has(v?.tag))
}

function countTree(nodes) {
	return nodes.reduce(
		(sum, node) => sum + 1 + countTree(node.children || []),
		0
	)
}

function attachChildren(base, tree) {
	if (!tree.length) {
		return base
	}

	return {
		...base,
		__children: tree.map(node => {
			const child = attachChildren(node.raw, node.children)

			if (node.node) {
				return {
					...child,
					__node: node.node,
				}
			}

			return child
		}),
	}
}

function unwrapAssociatedChild(msg) {
	const contextInfo = msg?.message?.messageContextInfo
	const inner = msg?.message?.associatedChildMessage?.message

	if (!inner) {
		return msg
	}

	return {
		...msg,
		message: {
			...inner,
			messageContextInfo: contextInfo,
		},
	}
}

function findBlockEnd(str, openIndex) {
	let depth = 0

	for (let i = openIndex; i < str.length; i++) {
		if (str[i] === '{') {
			depth++
		}

		if (str[i] === '}') {
			depth--

			if (depth === 0) {
				return i
			}
		}
	}

	return -1
}

function injectKeyBlock(snippet, marker, parentIdExpr) {
	const start = snippet.indexOf(marker)

	if (start === -1) {
		return snippet
	}

	const braceIndex = start + marker.length - 1
	const end = findBlockEnd(snippet, braceIndex)

	if (end === -1) {
		return snippet
	}

	const indentMatch = snippet.slice(0, start).match(/([ \t]*)$/)
	const indent = indentMatch ? indentMatch[1] : ''

	const replacement = `${marker.slice(0, -1)}{
${indent}  remoteJid: m.chat,
${indent}  fromMe: true,
${indent}  id: ${parentIdExpr}
${indent}}`

	return snippet.slice(0, start) + replacement + snippet.slice(end + 1)
}

function injectParentKey(childSnippet, parentIdExpr = 'newParentId') {
	return injectKeyBlock(childSnippet, 'parentMessageKey: {', parentIdExpr)
}

function injectTargetKey(childSnippet, parentIdExpr = 'newParentId') {
	return injectKeyBlock(childSnippet, 'targetMessageKey: {', parentIdExpr)
}

function injectProtocolKey(childSnippet, parentIdExpr = 'newParentId') {
	const marker = 'protocolMessage: {'
	const start = childSnippet.indexOf(marker)

	if (start === -1) {
		return childSnippet
	}

	const braceIndex = start + marker.length - 1
	const blockEnd = findBlockEnd(childSnippet, braceIndex)

	if (blockEnd === -1) {
		return childSnippet
	}

	const before = childSnippet.slice(0, start)
	const block = childSnippet.slice(start, blockEnd + 1)
	const after = childSnippet.slice(blockEnd + 1)
	const patchedBlock = injectKeyBlock(block, 'key: {', parentIdExpr)

	return before + patchedBlock + after
}

function buildChildScript(nodes, parentVar, path = []) {
	const blocks = []

	nodes.forEach((node, i) => {
		const varName = `id_${[...path, i].join('_')}`
		const rawChildSnippet = stringifySnippet(node.msg.message)

		let childSnippet = injectParentKey(
			rawChildSnippet,
			parentVar
		)

		childSnippet = injectProtocolKey(
			childSnippet,
			parentVar
		)

		childSnippet = injectTargetKey(
			childSnippet,
			parentVar
		)

		const childOptions = stringifySnippet(node.relayOptions)

		blocks.push(
			`const ${varName} = await conn.relayMessage(
  m.chat,
  ${indentBlock(childSnippet)},
  ${indentBlock(childOptions)}
);`
		)

		if (node.children.length) {
			blocks.push(
				...buildChildScript(
					node.children,
					varName,
					[...path, i]
				)
			)
		}
	})

	return blocks
}

function buildRelayScript(snippetMessage, options, childTree) {
	if (!childTree.length) {
		return `=> conn.relayMessage(
  m.chat,
  ${indentBlock(snippetMessage)},
  ${indentBlock(options)}
)`
	}

	const parentBlock = `const newParentId = await conn.relayMessage(
  m.chat,
  ${indentBlock(snippetMessage)},
  ${indentBlock(options)}
);`

	const childBlocks = buildChildScript(
		childTree,
		'newParentId'
	)

	return '> ' + [
		parentBlock,
		...childBlocks,
		'return newParentId;',
	].join('\n\n')
}

function stringify(obj) {
	return JSON.stringify(
		obj,
		(key, value) => {
			if (Buffer.isBuffer(value)) {
				return value.toString('base64')
			}

			if (
				value?.type === 'Buffer' &&
				Array.isArray(value.data)
			) {
				return Buffer.from(value.data).toString('base64')
			}

			return value
		},
		2
	)
}

function indentBlock(str, level = 1) {
	const pad = '  '.repeat(level)

	return str
		.split('\n')
		.map((line, i) => i === 0 ? line : pad + line)
		.join('\n')
}

function stringifySnippet(obj) {
	const raws = []

	const json = JSON.stringify(
		obj,
		(key, value) => {
			if (
				key === 'unifiedResponse' &&
				value &&
				typeof value === 'object' &&
				typeof value.data === 'string'
			) {
				try {
					const decoded = Buffer
						.from(value.data, 'base64')
						.toString('utf8')

					const parsed = JSON.parse(decoded)
					const id = raws.length

					raws.push(
						`Buffer.from(JSON.stringify(${JSON.stringify(parsed, null, 2)})).toString('base64')`
					)

					return {
						data: `__RAW_${id}__`,
					}
				} catch {}
			}

			if (
				key === 'buttonParamsJson' &&
				typeof value === 'string'
			) {
				try {
					const parsed = JSON.parse(value)
					const id = raws.length

					raws.push(
						`JSON.stringify(${JSON.stringify(parsed, null, 2)})`
					)

					return `__RAW_${id}__`
				} catch {}
			}

			if (Buffer.isBuffer(value)) {
				return value.toString('base64')
			}

			if (
				value?.type === 'Buffer' &&
				Array.isArray(value.data)
			) {
				return Buffer.from(value.data).toString('base64')
			}

			return value
		},
		2
	)

	let code = json.replace(
		/^(\s*)"([^"]+)":/gm,
		(_, indent, key) => `${indent}${key}:`
	)

	code = code
		.split('\n')
		.map(line => {
			const match = line.match(/^(\s*).*"__RAW_(\d+)__"/)

			if (!match) {
				return line
			}

			const [, indent, id] = match

			const block = raws[Number(id)]
				.split('\n')
				.map((l, i) => i === 0 ? l : indent + l)
				.join('\n')

			return line.replace(
				`"__RAW_${id}__"`,
				block
			)
		})
		.join('\n')

	return code
}

function capitalize(str) {
	return str.charAt(0).toUpperCase() + str.slice(1)
}