const handler = async (m, { conn, command }) => {
conn.relayMessage(
m.chat,
{
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
botMetadata: {
messageDisclaimerText: "",
botResponseId: "b2e40280-433c-45d8-9c1a-270bec558860",
verificationMetadata: {
proofs: [
{
version: 1,
useCase: 1,
signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
certificateChain: [
"TklYRUwuTWVzc2FnZUJ1bGRlc..." 
]
}
]
}
}
},
botForwardedMessage: {
message: {
richResponseMessage: {
messageType: 1,
submessages: [
{
messageType: 2,
messageText: "🎯 PANAH TEPAT"
}
],
unifiedResponse: {
data: Buffer.from(JSON.stringify({
"response_id": "4db57b2c-8393-484d-8b9a-8e6d1a14b349",
"sections": [
{
"view_model": {
"primitive": {
"__typename": "GenAIaeacdsnwHtmlPrimitive",
"payload": `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none}
body{margin:0;background:transparent;font-family:Arial,sans-serif;color:#eee;touch-action:manipulation}
.wrap{width:100%;max-width:620px;margin:auto;padding:14px}
.card{background:linear-gradient(145deg,rgba(255,255,255,.09),rgba(255,255,255,.035));border:1px solid rgba(255,255,255,.14);border-radius:22px;overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4);backdrop-filter:blur(18px)}
.head{padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.1);display:flex;justify-content:space-between;align-items:center}
.logo{font-size:10px;letter-spacing:2px;color:#888;text-transform:uppercase}
.title{font-size:23px;font-weight:800;margin-top:3px;background:linear-gradient(135deg,#ff6b6b,#feca57);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.status{font-size:13px;font-weight:bold;text-align:right;color:#ffd93d}
.gameArea{padding:20px}
.canvasWrap{position:relative;background:rgba(0,0,0,.3);border-radius:18px;overflow:hidden;border:2px solid rgba(255,255,255,.1)}
canvas{width:100%;height:auto;display:block;touch-action:none}
.controls{display:flex;gap:10px;margin-top:15px;flex-wrap:wrap}
.ctrlBtn{flex:1;min-width:60px;padding:12px;border:0;border-radius:12px;background:rgba(255,255,255,.08);color:#fff;font-size:16px;font-weight:bold;border:1px solid rgba(255,255,255,.1);transition:all .2s}
.ctrlBtn:active{transform:scale(.95);background:rgba(255,255,255,.15)}
.shootBtn{background:linear-gradient(135deg,#ff6b6b,#ee5a24);flex:2}
.shootBtn:active{transform:scale(.95)}
.info{display:flex;justify-content:space-between;padding:12px 0;color:#888;font-size:14px}
.score{color:#ffd700;font-weight:bold;font-size:18px}
.arrowInfo{color:#ff6b6b;font-weight:bold}
.resetBtn{width:100%;border:0;border-radius:14px;padding:14px;background:linear-gradient(135deg,#6c5ce7,#4834d4);color:#fff;font-size:16px;font-weight:bold;margin-top:10px}
.resetBtn:active{transform:scale(.97)}
.powerBar{width:100%;height:8px;background:rgba(255,255,255,.1);border-radius:4px;overflow:hidden;margin-top:10px}
.powerFill{height:100%;background:linear-gradient(90deg,#2ed573,#ffd93d,#ff6b6b);width:50%;transition:width .05s;border-radius:4px}
</style>

<body>
<div class="wrap">
<div class="card">
<div class="head">
<div>
<div class="logo">🎯 ARCHERY</div>
<div class="title">Panah Tepat</div>
</div>
<div class="status">
<div>🏹 <span id="arrowCount">10</span></div>
</div>
</div>

<div class="gameArea">
<div class="canvasWrap">
<canvas id="gameCanvas" width="600" height="500"></canvas>
</div>

<div class="controls">
<button class="ctrlBtn" id="leftBtn">◀ KIRI</button>
<button class="ctrlBtn" id="rightBtn">KANAN ▶</button>
<button class="ctrlBtn" id="upBtn">▲ ATAS</button>
<button class="ctrlBtn" id="downBtn">BAWAH ▼</button>
</div>

<div class="powerBar">
<div class="powerFill" id="powerFill"></div>
</div>

<button class="shootBtn" id="shootBtn">🎯 LEPAS PANAH!</button>

<div class="info">
<span class="score">⭐ Skor: <span id="score">0</span></span>
<span class="arrowInfo">🏹 Sisa: <span id="arrowsLeft">10</span></span>
<span>🎯 Target: <span id="targetDisplay">0</span>%</span>
</div>

<button class="resetBtn" id="resetBtn">🔄 MULAI LAGI</button>
</div>
</div>
</div>

<script>
const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreDisplay = document.getElementById('score');
const arrowsLeftDisplay = document.getElementById('arrowsLeft');
const arrowCountDisplay = document.getElementById('arrowCount');
const targetDisplay = document.getElementById('targetDisplay');
const powerFill = document.getElementById('powerFill');
const shootBtn = document.getElementById('shootBtn');
const resetBtn = document.getElementById('resetBtn');

// Game state
let arrow = { x: 300, y: 250 };
let target = { x: 300, y: 250 };
let score = 0;
let arrowsLeft = 10;
let maxArrows = 10;
let isShooting = false;
let animationId = null;
let power = 50;
let powerDirection = 1;

// Target ring colors and scores
const rings = [
  { radius: 20, color: '#ff4757', score: 100, label: 'BULLSEYE!' },
  { radius: 45, color: '#ff6b81', score: 75, label: 'Luar Biasa!' },
  { radius: 75, color: '#ffd93d', score: 50, label: 'Bagus!' },
  { radius: 110, color: '#2ed573', score: 25, label: 'Cukup' },
  { radius: 150, color: '#1e90ff', score: 10, label: 'Lumayan' }
];

// Function to draw target
function drawTarget() {
  // Outer glow
  const gradient = ctx.createRadialGradient(target.x, target.y, 0, target.x, target.y, 180);
  gradient.addColorStop(0, 'rgba(255,255,255,0.1)');
  gradient.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = gradient;
  ctx.beginPath();
  ctx.arc(target.x, target.y, 180, 0, Math.PI * 2);
  ctx.fill();

  // Draw rings from outside in
  rings.slice().reverse().forEach((ring, index) => {
    ctx.beginPath();
    ctx.arc(target.x, target.y, ring.radius, 0, Math.PI * 2);
    ctx.fillStyle = ring.color;
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.3)';
    ctx.lineWidth = 1;
    ctx.stroke();
  });

  // Center dot
  ctx.beginPath();
  ctx.arc(target.x, target.y, 5, 0, Math.PI * 2);
  ctx.fillStyle = '#fff';
  ctx.fill();

  // Crosshair
  ctx.strokeStyle = 'rgba(255,255,255,0.2)';
  ctx.lineWidth = 1;
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.moveTo(target.x - 200, target.y);
  ctx.lineTo(target.x + 200, target.y);
  ctx.moveTo(target.x, target.y - 200);
  ctx.lineTo(target.x, target.y + 200);
  ctx.stroke();
  ctx.setLineDash([]);

  // Score labels
  ctx.fillStyle = 'rgba(255,255,255,0.4)';
  ctx.font = '10px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  const ringScores = [100, 75, 50, 25, 10];
  ringScores.forEach((s, i) => {
    const radius = i === 0 ? 12 : (i === 1 ? 33 : (i === 2 ? 60 : (i === 3 ? 93 : 130)));
    ctx.fillText(s, target.x + radius + 15, target.y - 10);
  });
}

// Function to draw arrow
function drawArrow() {
  const angle = Math.atan2(arrow.y - target.y, arrow.x - target.x);
  const dist = Math.sqrt((arrow.x - target.x)**2 + (arrow.y - target.y)**2);
  
  // Arrow body
  ctx.save();
  ctx.translate(arrow.x, arrow.y);
  ctx.rotate(angle);
  
  // Arrow shaft
  ctx.fillStyle = '#f5f5f5';
  ctx.shadowColor = 'rgba(255,255,255,0.3)';
  ctx.shadowBlur = 10;
  ctx.fillRect(-30, -2, 60, 4);
  ctx.shadowBlur = 0;
  
  // Arrowhead
  ctx.fillStyle = '#ffd93d';
  ctx.beginPath();
  ctx.moveTo(-35, 0);
  ctx.lineTo(-20, -8);
  ctx.lineTo(-20, 8);
  ctx.closePath();
  ctx.fill();
  
  // Arrow tip
  ctx.fillStyle = '#ff6b6b';
  ctx.beginPath();
  ctx.moveTo(-40, 0);
  ctx.lineTo(-32, -4);
  ctx.lineTo(-32, 4);
  ctx.closePath();
  ctx.fill();
  
  // Fletching (feathers)
  ctx.fillStyle = '#ffd93d';
  ctx.fillRect(25, -8, 5, 16);
  ctx.fillStyle = '#ff6b6b';
  ctx.fillRect(28, -8, 4, 16);
  
  // Arrow glow effect
  ctx.shadowColor = 'rgba(255,215,0,0.5)';
  ctx.shadowBlur = 20;
  ctx.fillStyle = 'rgba(255,215,0,0.1)';
  ctx.beginPath();
  ctx.arc(0, 0, 10, 0, Math.PI * 2);
  ctx.fill();
  ctx.shadowBlur = 0;
  
  ctx.restore();
  
  // Distance guide line
  if (dist > 10 && !isShooting) {
    ctx.strokeStyle = 'rgba(255,255,255,0.1)';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 5]);
    ctx.beginPath();
    ctx.moveTo(arrow.x, arrow.y);
    ctx.lineTo(target.x, target.y);
    ctx.stroke();
    ctx.setLineDash([]);
  }
}

// Function to draw game
function drawGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  
  // Background gradient
  const bgGrad = ctx.createRadialGradient(300, 250, 50, 300, 250, 400);
  bgGrad.addColorStop(0, 'rgba(255,255,255,0.05)');
  bgGrad.addColorStop(1, 'rgba(0,0,0,0.3)');
  ctx.fillStyle = bgGrad;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  // Grid
  ctx.strokeStyle = 'rgba(255,255,255,0.03)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= canvas.width; i += 30) {
    ctx.beginPath();
    ctx.moveTo(i, 0);
    ctx.lineTo(i, canvas.height);
    ctx.stroke();
  }
  for (let i = 0; i <= canvas.height; i += 30) {
    ctx.beginPath();
    ctx.moveTo(0, i);
    ctx.lineTo(canvas.width, i);
    ctx.stroke();
  }
  
  drawTarget();
  drawArrow();
  
  // Arrow count display
  ctx.fillStyle = 'rgba(255,255,255,0.1)';
  ctx.font = '12px Arial';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'top';
  ctx.fillText('🏹 ' + arrowsLeft + '/' + maxArrows, canvas.width - 10, 10);
}

// Function to calculate score based on distance
function calculateScore() {
  const dx = arrow.x - target.x;
  const dy = arrow.y - target.y;
  const dist = Math.sqrt(dx*dx + dy*dy);
  
  let earnedScore = 0;
  let label = '';
  
  for (const ring of rings) {
    if (dist <= ring.radius) {
      earnedScore = ring.score;
      label = ring.label;
      break;
    }
  }
  
  if (dist > rings[rings.length-1].radius) {
    earnedScore = 0;
    label = 'Meleset 😅';
  }
  
  return { score: earnedScore, label, distance: Math.round(dist) };
}

// Function to shoot arrow
function shootArrow() {
  if (isShooting || arrowsLeft <= 0) return;
  
  isShooting = true;
  arrowsLeft--;
  arrowCountDisplay.textContent = arrowsLeft;
  arrowsLeftDisplay.textContent = arrowsLeft;
  
  // Animate arrow to target
  const startX = arrow.x;
  const startY = arrow.y;
  const targetX = target.x;
  const targetY = target.y;
  const duration = 300;
  const startTime = Date.now();
  
  const powerMultiplier = power / 100;
  const maxDeviation = 80 * (1 - powerMultiplier * 0.7);
  const deviationX = (Math.random() - 0.5) * maxDeviation * 2;
  const deviationY = (Math.random() - 0.5) * maxDeviation * 2;
  
  const endX = targetX + deviationX;
  const endY = targetY + deviationY;
  
  function animateShoot() {
    const elapsed = Date.now() - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    
    arrow.x = startX + (endX - startX) * eased;
    arrow.y = startY + (endY - startY) * eased;
    
    drawGame();
    
    if (progress < 1) {
      requestAnimationFrame(animateShoot);
    } else {
      // Arrow landed
      const result = calculateScore();
      score += result.score;
      scoreDisplay.textContent = score;
      
      // Show result
      ctx.fillStyle = 'rgba(0,0,0,0.7)';
      ctx.fillRect(0, canvas.height/2 - 30, canvas.width, 60);
      ctx.fillStyle = result.score > 0 ? '#ffd93d' : '#ff6b6b';
      ctx.font = 'bold 24px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(result.label + ' (+' + result.score + ')', canvas.width/2, canvas.height/2);
      
      // Show accuracy
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.font = '14px Arial';
      ctx.fillText('Jarak: ' + result.distance + 'px', canvas.width/2, canvas.height/2 + 35);
      
      // Update power display
      targetDisplay.textContent = result.score;
      
      setTimeout(() => {
        isShooting = false;
        arrow.x = 300 + (Math.random() - 0.5) * 50;
        arrow.y = 250 + (Math.random() - 0.5) * 50;
        
        // Randomize target position
        target.x = 100 + Math.random() * 400;
        target.y = 80 + Math.random() * 340;
        
        drawGame();
        
        if (arrowsLeft <= 0) {
          endGame();
        }
      }, 1000);
    }
  }
  
  animateShoot();
}

// Function to end game
function endGame() {
  ctx.fillStyle = 'rgba(0,0,0,0.85)';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  
  ctx.fillStyle = '#ffd93d';
  ctx.font = 'bold 36px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('🏹 GAME OVER', canvas.width/2, canvas.height/2 - 50);
  
  ctx.fillStyle = '#fff';
  ctx.font = '24px Arial';
  ctx.fillText('⭐ Skor Akhir: ' + score, canvas.width/2, canvas.height/2 + 15);
  
  const accuracy = Math.round((score / (maxArrows * 100)) * 100);
  ctx.fillStyle = '#888';
  ctx.font = '18px Arial';
  ctx.fillText('Akurasi: ' + accuracy + '%', canvas.width/2, canvas.height/2 + 55);
  
  ctx.fillStyle = '#aaa';
  ctx.font = '14px Arial';
  ctx.fillText('Tekan "MULAI LAGI" untuk bermain ulang', canvas.width/2, canvas.height/2 + 100);
}

// Arrow movement controls
function moveArrow(dx, dy) {
  if (isShooting) return;
  const step = 8;
  arrow.x = Math.max(0, Math.min(canvas.width, arrow.x + dx * step));
  arrow.y = Math.max(0, Math.min(canvas.height, arrow.y + dy * step));
  drawGame();
}

// Power meter animation
let powerInterval = null;

function startPowerMeter() {
  if (powerInterval) clearInterval(powerInterval);
  powerInterval = setInterval(() => {
    if (!isShooting) {
      power += powerDirection * 0.8;
      if (power >= 100) { power = 100; powerDirection = -1; }
      if (power <= 0) { power = 0; powerDirection = 1; }
      powerFill.style.width = power + '%';
    }
  }, 50);
}

// Event listeners
document.getElementById('leftBtn').addEventListener('click', () => moveArrow(-1, 0));
document.getElementById('rightBtn').addEventListener('click', () => moveArrow(1, 0));
document.getElementById('upBtn').addEventListener('click', () => moveArrow(0, -1));
document.getElementById('downBtn').addEventListener('click', () => moveArrow(0, 1));

shootBtn.addEventListener('click', shootArrow);

// Keyboard support
document.addEventListener('keydown', (e) => {
  switch(e.key) {
    case 'ArrowLeft': moveArrow(-1, 0); e.preventDefault(); break;
    case 'ArrowRight': moveArrow(1, 0); e.preventDefault(); break;
    case 'ArrowUp': moveArrow(0, -1); e.preventDefault(); break;
    case 'ArrowDown': moveArrow(0, 1); e.preventDefault(); break;
    case ' ': shootArrow(); e.preventDefault(); break;
  }
});

// Touch controls for mobile
let touchStartX = 0;
let touchStartY = 0;
canvas.addEventListener('touchstart', (e) => {
  const touch = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  touchStartX = (touch.clientX - rect.left) / rect.width * canvas.width;
  touchStartY = (touch.clientY - rect.top) / rect.height * canvas.height;
});

canvas.addEventListener('touchmove', (e) => {
  e.preventDefault();
  const touch = e.touches[0];
  const rect = canvas.getBoundingClientRect();
  const x = (touch.clientX - rect.left) / rect.width * canvas.width;
  const y = (touch.clientY - rect.top) / rect.height * canvas.height;
  const dx = x - touchStartX;
  const dy = y - touchStartY;
  if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
    moveArrow(Math.sign(dx), Math.sign(dy));
    touchStartX = x;
    touchStartY = y;
  }
});

// Reset function
function resetGame() {
  score = 0;
  arrowsLeft = maxArrows;
  arrowCountDisplay.textContent = arrowsLeft;
  arrowsLeftDisplay.textContent = arrowsLeft;
  scoreDisplay.textContent = score;
  targetDisplay.textContent = '0';
  isShooting = false;
  arrow.x = 300;
  arrow.y = 250;
  target.x = 300;
  target.y = 250;
  power = 50;
  powerFill.style.width = '50%';
  drawGame();
}

resetBtn.addEventListener('click', resetGame);

// Initialize
startPowerMeter();
drawGame();
</script>`,
"trusted_sources":[
"adam.dev"
]
},
"__typename":"GenAISingleLayoutViewModel"
}
}
]
})).toString('base64')
},
contextInfo:{
forwardingScore:1,
isForwarded:true,
forwardedAiBotMessageInfo:{
botJid:"867051314767696@bot"
},
forwardOrigin:4
}
}
}
}
},
{}
)
}

handler.help=['bow']
handler.tags=['game']
handler.command=/^(bow)$/i

export default handler