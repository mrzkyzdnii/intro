const genUuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
  const r = Math.random() * 16 | 0
  const v = c === 'x' ? r : (r & 0x3 | 0x8)
  return v.toString(16)
})

const handler = async (m, { conn }) => {
  const responseId = genUuid()
  const botResponseId = genUuid()

  const gameNeonDuel = `
<style>
#nd{position:relative;width:100%;height:620px;overflow:hidden;background:radial-gradient(circle at 50% 35%,#21153b 0,#0b0915 45%,#030409 100%);font-family:Arial,sans-serif;color:#fff;touch-action:none}
#nd *{box-sizing:border-box}
#nd canvas{position:absolute;inset:0;width:100%;height:100%}
#nd .ndhud{position:absolute;top:14px;left:12px;right:12px;display:flex;gap:7px;z-index:4}
#nd .ndcard{flex:1;padding:8px 9px;border:1px solid #ffffff16;background:#ffffff09;border-radius:12px;backdrop-filter:blur(10px)}
#nd .ndlabel{font-size:8px;color:#969ab2;letter-spacing:1.8px}
#nd .ndval{font-size:17px;font-weight:900;margin-top:2px}
#nd .ndbars{position:absolute;top:69px;left:12px;right:12px;z-index:4}
#nd .ndbar{height:7px;background:#ffffff0d;border-radius:20px;margin:5px 0;overflow:hidden}
#nd #ndp{height:100%;width:100%;background:linear-gradient(90deg,#00e5ff,#526dff);transition:.2s}
#nd #nde{height:100%;width:100%;background:linear-gradient(90deg,#ff326d,#ff8b35);transition:.2s}
#nd .ndstatus{position:absolute;top:103px;left:50%;transform:translateX(-50%);font-size:9px;letter-spacing:3px;color:#aeb2ca;z-index:4;white-space:nowrap}
#nd .ndcontrols{position:absolute;bottom:14px;left:12px;right:12px;display:flex;gap:8px;z-index:6}
#nd button{height:52px;flex:1;border:1px solid #ffffff18;border-radius:14px;background:#ffffff0b;color:#fff;font-weight:900;font-size:11px;letter-spacing:1px}
#nd button:active{transform:scale(.95);background:#ffffff20}
#nd #nda{border-color:#00e5ff55}
#nd #ndg{border-color:#9c6cff55}
#nd #ndd{border-color:#ff4f9a55}
#nd .ndoverlay{position:absolute;inset:0;z-index:10;background:#02030bcc;backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center}
#nd .ndbox{width:calc(100% - 46px);max-width:350px;padding:28px 20px;text-align:center;border:1px solid #ffffff18;border-radius:23px;background:#0a0a12ee;box-shadow:0 20px 80px #000}
#nd .ndtitle{font-size:27px;font-weight:900;letter-spacing:4px;background:linear-gradient(90deg,#00e5ff,#8066ff,#ff4f9a);-webkit-background-clip:text;color:transparent}
#nd .nddesc{font-size:11px;line-height:1.7;color:#8f93aa;margin:10px 0 20px}
#nd .ndstart{width:100%;background:linear-gradient(90deg,#007dff,#7748ff);border:0}
#nd .ndhide{display:none}
</style>
<div id="nd">
<canvas id="ndc"></canvas>
<div class="ndhud">
<div class="ndcard"><div class="ndlabel">SCORE</div><div class="ndval" id="nds">0</div></div>
<div class="ndcard"><div class="ndlabel">COMBO</div><div class="ndval" id="ndco">x0</div></div>
<div class="ndcard"><div class="ndlabel">ROUND</div><div class="ndval" id="ndr">1</div></div>
</div>
<div class="ndbars">
<div class="ndbar"><div id="ndp"></div></div>
<div class="ndbar"><div id="nde"></div></div>
</div>
<div class="ndstatus" id="ndst">READY</div>
<div class="ndcontrols">
<button id="nda">⚔ ATTACK</button>
<button id="ndg">◈ GUARD</button>
<button id="ndd">✦ DASH</button>
</div>
<div class="ndoverlay" id="ndmenu">
<div class="ndbox">
<div class="ndtitle" id="ndtitle">NEON DUEL</div>
<div class="nddesc" id="nddesc">Strike the enemy, guard incoming attacks and use dash to evade lethal hits.</div>
<button class="ndstart" id="ndstart">ENTER ARENA</button>
</div>
</div>
</div>
<script>
(()=>{const c=document.getElementById('ndc'),x=c.getContext('2d'),s=document.getElementById('nds'),co=document.getElementById('ndco'),r=document.getElementById('ndr'),pb=document.getElementById('ndp'),eb=document.getElementById('nde'),st=document.getElementById('ndst'),menu=document.getElementById('ndmenu'),title=document.getElementById('ndtitle'),desc=document.getElementById('nddesc'),start=document.getElementById('ndstart'),at=document.getElementById('nda'),gd=document.getElementById('ndg'),ds=document.getElementById('ndd');let w=0,h=0,dpr=1,run=false,last=0,score=0,combo=0,round=1,php=100,ehp=100,guard=0,dash=0,attack=0,tele=0,enemy=1.3,parts=[],shake=0;
function size(){dpr=Math.min(devicePixelRatio||1,2);w=c.clientWidth;h=c.clientHeight;c.width=w*dpr;c.height=h*dpr;x.setTransform(dpr,0,0,dpr,0,0)}size();addEventListener('resize',size);
function sound(f,d=.06,t='sine'){try{const a=new AudioContext(),o=a.createOscillator(),g=a.createGain();o.type=t;o.frequency.value=f;g.gain.value=.025;o.connect(g);g.connect(a.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,a.currentTime+d);o.stop(a.currentTime+d)}catch{}}
function burst(px,py,col,n=15){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,q=50+Math.random()*180;parts.push({x:px,y:py,vx:Math.cos(a)*q,vy:Math.sin(a)*q,l:1,c:col})}}
function reset(){score=0;combo=0;round=1;php=100;ehp=100;guard=0;dash=0;attack=0;tele=0;enemy=1.2;parts=[];run=true;menu.classList.add('ndhide');title.textContent='NEON DUEL';desc.textContent='Strike the enemy, guard incoming attacks and use dash to evade lethal hits.';start.textContent='ENTER ARENA';last=performance.now();requestAnimationFrame(loop)}
function hitEnemy(n){ehp=Math.max(0,ehp-n);combo++;score+=n*10+combo*5;burst(w*.73,h*.53,'#ff397d',18);shake=.12;sound(120+n*8,.07,'square');if(ehp<=0){score+=250+round*100;round++;ehp=Math.min(100,82+round*9);php=Math.min(100,php+20);enemy=1;st.textContent='ROUND '+round;sound(760,.14,'triangle')}}
function hitPlayer(n){if(dash>0){score+=35;st.textContent='EVADED';sound(620,.05);return}if(guard>0){php=Math.max(0,php-Math.ceil(n*.15));combo++;score+=60;st.textContent='PARRY';burst(w*.27,h*.53,'#00e5ff',22);sound(920,.08,'square')}else{php=Math.max(0,php-n);combo=0;st.textContent='HIT';burst(w*.27,h*.53,'#ff315e',20);sound(80,.11,'sawtooth')}shake=.15}
function doAttack(){if(!run||attack>0)return;attack=.22;if(tele>0){hitEnemy(22+round*2);st.textContent='COUNTER'}else hitEnemy(11+Math.min(combo,8))}
function doGuard(){if(!run)return;guard=.58;st.textContent='GUARD';sound(420,.04)}
function doDash(){if(!run||dash>0)return;dash=.38;st.textContent='DASH';sound(700,.05)}
at.onclick=doAttack;gd.onclick=doGuard;ds.onclick=doDash;start.onclick=reset;
function fighter(px,col,flip,active,cy){x.save();x.translate(px,cy);x.scale(flip?-1:1,1);x.shadowBlur=28;x.shadowColor=col;x.fillStyle=col;x.beginPath();x.arc(0,-48,17,0,Math.PI*2);x.fill();x.fillStyle='#070811';x.beginPath();x.arc(0,-48,9,0,Math.PI*2);x.fill();x.strokeStyle=col;x.lineWidth=7;x.beginPath();x.moveTo(0,-25);x.lineTo(0,38);x.moveTo(0,-10);x.lineTo(active?53:35,-2);x.moveTo(0,38);x.lineTo(-23,70);x.moveTo(0,38);x.lineTo(23,70);x.stroke();x.lineWidth=3;x.beginPath();x.moveTo(active?48:30,-4);x.lineTo(active?80:42,-4);x.stroke();x.restore()}
function draw(){x.clearRect(0,0,w,h);const g=x.createRadialGradient(w*.5,h*.48,10,w*.5,h*.48,Math.max(w,h)*.7);g.addColorStop(0,'#17132c');g.addColorStop(1,'#030408');x.fillStyle=g;x.fillRect(0,0,w,h);x.strokeStyle='#ffffff08';for(let i=0;i<17;i++){let yy=130+i*30;x.beginPath();x.moveTo(0,yy);x.lineTo(w,yy);x.stroke()}const cy=h*.54;for(let i=0;i<4;i++){x.strokeStyle='#00e5ff10';x.beginPath();x.arc(w*.27,cy,55+i*18,0,Math.PI*2);x.stroke();x.strokeStyle='#ff397d10';x.beginPath();x.arc(w*.73,cy,55+i*18,0,Math.PI*2);x.stroke()}fighter(w*.27,'#00e5ff',false,attack>0,cy);fighter(w*.73,'#ff397d',true,tele>0,cy);if(guard>0){x.strokeStyle='#9368ff';x.lineWidth=5;x.shadowBlur=25;x.shadowColor='#9368ff';x.beginPath();x.arc(w*.27,cy,62,0,Math.PI*2);x.stroke()}parts.forEach(p=>{x.globalAlpha=p.l;x.fillStyle=p.c;x.shadowBlur=12;x.shadowColor=p.c;x.fillRect(p.x,p.y,3,3);x.globalAlpha=1})}
function loop(now){if(!run)return;const dt=Math.min(.033,(now-last)/1000);last=now;guard=Math.max(0,guard-dt);dash=Math.max(0,dash-dt);attack=Math.max(0,attack-dt);if(tele>0){tele-=dt;if(tele<=0)hitPlayer(9+round*2)}else{enemy-=dt;if(enemy<=0){tele=.7;enemy=Math.max(.8,1.8-round*.07);st.textContent='INCOMING'}}parts.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=90*dt;p.l-=dt*2});parts=parts.filter(p=>p.l>0);s.textContent=Math.floor(score);co.textContent='x'+combo;r.textContent=round;pb.style.width=Math.max(0,php)+'%';eb.style.width=Math.max(0,ehp)+'%';if(php<=0){run=false;menu.classList.remove('ndhide');title.textContent='DEFEATED';desc.textContent='Final score: '+Math.floor(score)+' • Round '+round;start.textContent='RETRY';st.textContent='GAME OVER'}draw();requestAnimationFrame(loop)}
})();
</script>`

  const gameVault = `
<style>
#vb{position:relative;width:100%;height:620px;overflow:hidden;background:radial-gradient(circle at 50% 30%,#261b09,#090806 50%,#020202 100%);font-family:Arial,sans-serif;color:#fff;touch-action:none}
#vb *{box-sizing:border-box}
#vb canvas{position:absolute;inset:0;width:100%;height:100%}
#vb .vbhud{position:absolute;top:14px;left:10px;right:10px;display:flex;gap:6px;z-index:4}
#vb .vbcard{flex:1;padding:8px 7px;border:1px solid #d6a63a20;background:#ffffff08;border-radius:11px}
#vb .vblabel{font-size:7px;color:#a99a78;letter-spacing:1.4px}
#vb .vbval{font-size:16px;font-weight:900;margin-top:2px}
#vb .vbmsg{position:absolute;top:84px;left:50%;transform:translateX(-50%);font-size:9px;letter-spacing:2.5px;color:#dfb75e;white-space:nowrap;z-index:4}
#vb .vboverlay{position:absolute;inset:0;z-index:10;background:#020202c9;backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center}
#vb .vbbox{width:calc(100% - 46px);max-width:350px;padding:28px 20px;text-align:center;border:1px solid #d8a83c2d;border-radius:23px;background:#100e0aee;box-shadow:0 20px 80px #000}
#vb .vbtitle{font-size:27px;font-weight:900;letter-spacing:4px;color:#e6ba5c}
#vb .vbdesc{font-size:11px;line-height:1.7;color:#a09780;margin:10px 0 20px}
#vb .vbstart{width:100%;height:52px;border:0;border-radius:14px;background:linear-gradient(90deg,#9d6b17,#e7be63);color:#090704;font-weight:900}
#vb .vbhide{display:none}
</style>
<div id="vb">
<canvas id="vbc"></canvas>
<div class="vbhud">
<div class="vbcard"><div class="vblabel">CREDITS</div><div class="vbval" id="vbs">0</div></div>
<div class="vbcard"><div class="vblabel">LEVEL</div><div class="vbval" id="vbl">1</div></div>
<div class="vbcard"><div class="vblabel">COMBO</div><div class="vbval" id="vbcmb">x0</div></div>
<div class="vbcard"><div class="vblabel">TIME</div><div class="vbval" id="vbt">8.0</div></div>
</div>
<div class="vbmsg" id="vbmsg">MEMORIZE THE SEQUENCE</div>
<div class="vboverlay" id="vbmenu">
<div class="vbbox">
<div class="vbtitle" id="vbtitle">VAULT BREAKER</div>
<div class="vbdesc" id="vbdesc">Memorize the glowing nodes, then unlock the vault in the exact order.</div>
<button class="vbstart" id="vbstart">BREACH VAULT</button>
</div>
</div>
</div>
<script>
(()=>{const c=document.getElementById('vbc'),x=c.getContext('2d'),sc=document.getElementById('vbs'),lv=document.getElementById('vbl'),cm=document.getElementById('vbcmb'),tm=document.getElementById('vbt'),msg=document.getElementById('vbmsg'),menu=document.getElementById('vbmenu'),title=document.getElementById('vbtitle'),desc=document.getElementById('vbdesc'),start=document.getElementById('vbstart');let w=0,h=0,dpr=1,run=false,last=0,score=0,level=1,combo=0,time=8,seq=[],step=0,reveal=0,flash=-1,parts=[];
function size(){dpr=Math.min(devicePixelRatio||1,2);w=c.clientWidth;h=c.clientHeight;c.width=w*dpr;c.height=h*dpr;x.setTransform(dpr,0,0,dpr,0,0)}size();addEventListener('resize',size);
function sound(f,d=.06,t='sine'){try{const a=new AudioContext(),o=a.createOscillator(),g=a.createGain();o.type=t;o.frequency.value=f;g.gain.value=.025;o.connect(g);g.connect(a.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,a.currentTime+d);o.stop(a.currentTime+d)}catch{}}
function burst(px,py,col,n=15){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,q=40+Math.random()*150;parts.push({x:px,y:py,vx:Math.cos(a)*q,vy:Math.sin(a)*q,l:1,c:col})}}
function round(){const count=Math.min(10,3+Math.floor((level-1)/2));let pool=[];for(let i=0;i<16;i++)pool.push(i);for(let i=pool.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[pool[i],pool[j]]=[pool[j],pool[i]]}seq=pool.slice(0,count);step=0;reveal=1.2+count*.12;time=8+Math.min(level,8)*.35;flash=-1;msg.textContent='MEMORIZE THE SEQUENCE';sound(520,.06)}
function reset(){score=0;level=1;combo=0;run=true;menu.classList.add('vbhide');title.textContent='VAULT BREAKER';desc.textContent='Memorize the glowing nodes, then unlock the vault in the exact order.';start.textContent='BREACH VAULT';round();last=performance.now();requestAnimationFrame(loop)}
start.onclick=reset;
function metrics(){const size=Math.max(240,Math.min(w-32,(h-135)*.75,390)),gap=8,s=(size-gap*3)/4,left=(w-size)/2,top=(h-size)/2+20;return{size,gap,s,left,top}}
function cell(px,py){const m=metrics();const col=Math.floor((px-m.left)/(m.s+m.gap)),row=Math.floor((py-m.top)/(m.s+m.gap));if(col<0||col>3||row<0||row>3)return-1;const rx=m.left+col*(m.s+m.gap),ry=m.top+row*(m.s+m.gap);if(px>rx+m.s||py>ry+m.s)return-1;return row*4+col}
c.addEventListener('pointerdown',e=>{if(!run||reveal>0)return;const q=c.getBoundingClientRect(),id=cell(e.clientX-q.left,e.clientY-q.top);if(id<0)return;if(id===seq[step]){const m=metrics(),row=Math.floor(id/4),col=id%4;burst(m.left+col*(m.s+m.gap)+m.s/2,m.top+row*(m.s+m.gap)+m.s/2,'#e8bd62',16);flash=id;score+=100+level*25+combo*20;combo++;step++;sound(700+step*45,.05);if(step>=seq.length){score+=500+level*100;level++;combo++;msg.textContent='VAULT BREACHED';sound(980,.15,'triangle');setTimeout(()=>{if(run)round()},350)}}else{combo=0;time-=2;flash=id;msg.textContent='INVALID NODE';sound(90,.1,'sawtooth');setTimeout(()=>flash=-1,180)}});
function draw(){x.clearRect(0,0,w,h);const g=x.createRadialGradient(w*.5,h*.45,10,w*.5,h*.45,Math.max(w,h)*.7);g.addColorStop(0,'#241b0d');g.addColorStop(1,'#030303');x.fillStyle=g;x.fillRect(0,0,w,h);const m=metrics();for(let i=0;i<16;i++){const row=Math.floor(i/4),col=i%4,rx=m.left+col*(m.s+m.gap),ry=m.top+row*(m.s+m.gap),active=reveal>0&&seq.includes(i);let gg=x.createLinearGradient(rx,ry,rx+m.s,ry+m.s);gg.addColorStop(0,active?'#d8aa4c':'#19140b');gg.addColorStop(1,active?'#72521b':'#0c0a07');x.fillStyle=gg;x.shadowBlur=active?22:0;x.shadowColor='#d9a943';x.beginPath();x.moveTo(rx+12,ry);x.lineTo(rx+m.s-12,ry);x.quadraticCurveTo(rx+m.s,ry,rx+m.s,ry+12);x.lineTo(rx+m.s,ry+m.s-12);x.quadraticCurveTo(rx+m.s,ry+m.s,rx+m.s-12,ry+m.s);x.lineTo(rx+12,ry+m.s);x.quadraticCurveTo(rx,ry+m.s,rx,ry+m.s-12);x.lineTo(rx,ry+12);x.quadraticCurveTo(rx,ry,rx+12,ry);x.fill();x.shadowBlur=0;x.strokeStyle=flash===i?'#fff':'#d4a94325';x.lineWidth=flash===i?3:1;x.stroke();if(active){x.fillStyle='#fff';x.beginPath();x.arc(rx+m.s/2,ry+m.s/2,6,0,Math.PI*2);x.fill()}}parts.forEach(p=>{x.globalAlpha=p.l;x.fillStyle=p.c;x.shadowBlur=12;x.shadowColor=p.c;x.fillRect(p.x,p.y,3,3);x.globalAlpha=1})}
function loop(now){if(!run)return;const dt=Math.min(.033,(now-last)/1000);last=now;if(reveal>0){reveal-=dt;if(reveal<=0){msg.textContent='UNLOCK THE NODES IN ORDER';sound(320,.06)}}else time-=dt;if(time<=0){time=0;run=false;menu.classList.remove('vbhide');title.textContent='VAULT SEALED';desc.textContent='Credits secured: '+Math.floor(score)+' • Level '+level;start.textContent='RETRY'}parts.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=70*dt;p.l-=dt*2});parts=parts.filter(p=>p.l>0);sc.textContent=Math.floor(score);lv.textContent=level;cm.textContent='x'+combo;tm.textContent=time.toFixed(1);draw();requestAnimationFrame(loop)}
})();
</script>`

  const gameStarfall = `
<style>
#sf{position:relative;width:100%;height:620px;overflow:hidden;background:#02030a;font-family:Arial,sans-serif;color:#fff;touch-action:none}
#sf *{box-sizing:border-box}
#sf canvas{position:absolute;inset:0;width:100%;height:100%}
#sf .sfhud{position:absolute;top:14px;left:10px;right:10px;display:flex;gap:6px;z-index:4}
#sf .sfcard{flex:1;padding:8px 7px;border:1px solid #ffffff14;background:#ffffff08;border-radius:11px;backdrop-filter:blur(10px)}
#sf .sflabel{font-size:7px;color:#7e85a3;letter-spacing:1.4px}
#sf .sfval{font-size:16px;font-weight:900;margin-top:2px}
#sf .sfcontrols{position:absolute;bottom:14px;left:10px;right:10px;display:flex;gap:8px;z-index:6}
#sf button{height:53px;border:1px solid #ffffff16;background:#ffffff09;color:#fff;border-radius:14px;font-weight:900}
#sf .sfmove{width:72px;font-size:17px}
#sf .sfburst{flex:1;background:linear-gradient(90deg,#24265c,#743eff);border-color:#8b6cff55}
#sf button:active{transform:scale(.94)}
#sf .sfoverlay{position:absolute;inset:0;z-index:10;background:#02030acb;backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center}
#sf .sfbox{width:calc(100% - 46px);max-width:360px;padding:28px 20px;text-align:center;border:1px solid #716bff30;border-radius:23px;background:#080916ee;box-shadow:0 20px 80px #000}
#sf .sftitle{font-size:28px;font-weight:900;letter-spacing:4px;background:linear-gradient(90deg,#65f5ff,#786dff,#ee69ff);-webkit-background-clip:text;color:transparent}
#sf .sfdesc{font-size:11px;line-height:1.7;color:#858ba9;margin:10px 0 20px}
#sf .sfstart{width:100%;height:52px;border:0;border-radius:14px;background:linear-gradient(90deg,#3868ff,#9b4dff)}
#sf .sfhide{display:none}
</style>
<div id="sf">
<canvas id="sfc"></canvas>
<div class="sfhud">
<div class="sfcard"><div class="sflabel">SCORE</div><div class="sfval" id="sfs">0</div></div>
<div class="sfcard"><div class="sflabel">WAVE</div><div class="sfval" id="sfw">1</div></div>
<div class="sfcard"><div class="sflabel">HP</div><div class="sfval" id="sfh">100</div></div>
<div class="sfcard"><div class="sflabel">COMBO</div><div class="sfval" id="sfcmb">x0</div></div>
</div>
<div class="sfcontrols">
<button class="sfmove" id="sfl">◀</button>
<button class="sfburst" id="sfb">✦ STAR BURST</button>
<button class="sfmove" id="sfr">▶</button>
</div>
<div class="sfoverlay" id="sfmenu">
<div class="sfbox">
<div class="sftitle" id="sftitle">STARFALL</div>
<div class="sfdesc" id="sfdesc">Survive the cosmic storm, destroy the fleet and defeat the boss waves.</div>
<button class="sfstart" id="sfstart">LAUNCH SHIP</button>
</div>
</div>
</div>
<script>
(()=>{const c=document.getElementById('sfc'),x=c.getContext('2d'),sc=document.getElementById('sfs'),wv=document.getElementById('sfw'),hpEl=document.getElementById('sfh'),cm=document.getElementById('sfcmb'),left=document.getElementById('sfl'),right=document.getElementById('sfr'),burstBtn=document.getElementById('sfb'),menu=document.getElementById('sfmenu'),title=document.getElementById('sftitle'),desc=document.getElementById('sfdesc'),start=document.getElementById('sfstart');let w=0,h=0,dpr=1,run=false,last=0,score=0,wave=1,hp=100,combo=0,px=0,fire=0,spawn=0,boost=0,shield=0,burst=0,stars=[],bullets=[],enemies=[],drops=[],enemyBullets=[],parts=[],boss=null,mL=false,mR=false;
function size(){dpr=Math.min(devicePixelRatio||1,2);w=c.clientWidth;h=c.clientHeight;c.width=w*dpr;c.height=h*dpr;x.setTransform(dpr,0,0,dpr,0,0);if(!px)px=w/2}size();addEventListener('resize',size);
for(let i=0;i<90;i++)stars.push({x:Math.random(),y:Math.random(),s:20+Math.random()*100,a:.2+Math.random()*.6});
function sound(f,d=.05,t='sine'){try{const a=new AudioContext(),o=a.createOscillator(),g=a.createGain();o.type=t;o.frequency.value=f;g.gain.value=.02;o.connect(g);g.connect(a.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,a.currentTime+d);o.stop(a.currentTime+d)}catch{}}
function burstP(px,py,col,n=14){for(let i=0;i<n;i++){const a=Math.random()*Math.PI*2,q=40+Math.random()*180;parts.push({x:px,y:py,vx:Math.cos(a)*q,vy:Math.sin(a)*q,l:1,c:col})}}
function reset(){score=0;wave=1;hp=100;combo=0;fire=0;spawn=.2;boost=0;shield=0;burst=0;bullets=[];enemies=[];drops=[];enemyBullets=[];parts=[];boss=null;px=w/2;run=true;menu.classList.add('sfhide');title.textContent='STARFALL';desc.textContent='Survive the cosmic storm, destroy the fleet and defeat the boss waves.';start.textContent='LAUNCH SHIP';last=performance.now();requestAnimationFrame(loop)}
start.onclick=reset;
function move(el,type){el.addEventListener('pointerdown',e=>{e.preventDefault();if(type==='l')mL=true;else mR=true});['pointerup','pointercancel','pointerleave'].forEach(v=>el.addEventListener(v,()=>{if(type==='l')mL=false;else mR=false}))}
move(left,'l');move(right,'r');
burstBtn.addEventListener('pointerdown',()=>{if(run&&burst<=0){burst=3;score+=50;sound(850,.1,'triangle')}})
c.addEventListener('pointermove',e=>{if(e.buttons){const q=c.getBoundingClientRect();px=Math.max(24,Math.min(w-24,e.clientX-q.left))}})
function shoot(){const count=burst>0?3:1;for(let i=0;i<count;i++){const off=(i-(count-1)/2)*9;bullets.push({x:px+off,y:h-88,vx:off*1.7,vy:-560})}sound(620,.02)}
function spawnEnemy(){const r=12+Math.random()*17,type=Math.random()<.17?'fast':'rock';enemies.push({x:24+Math.random()*(w-48),y:-30-r,r,vy:type==='fast'?155+wave*5:90+wave*4,hp:type==='fast'?1:2+Math.floor(wave/4),type,rot:0})}
function makeBoss(){const max=80+wave*18;boss={x:w/2,y:88,r:45,hp:max,max,vx:125,fire:.8};sound(90,.3,'sawtooth')}
function damage(n){if(shield>0){score+=15;return}hp=Math.max(0,hp-n);combo=0;burstP(px,h-70,'#ff426e',18);sound(70,.1,'sawtooth')}
function draw(){x.clearRect(0,0,w,h);const g=x.createLinearGradient(0,0,0,h);g.addColorStop(0,'#020515');g.addColorStop(.5,'#08051b');g.addColorStop(1,'#02030a');x.fillStyle=g;x.fillRect(0,0,w,h);stars.forEach(s=>{s.y+=s.s/9000;if(s.y>1)s.y=0;x.fillStyle='rgba(150,190,255,'+s.a+')';x.fillRect(s.x*w,s.y*h,1+s.a*1.5,1+s.a*2)});bullets.forEach(b=>{x.strokeStyle='#6cf8ff';x.lineWidth=4;x.shadowBlur=15;x.shadowColor='#6cf8ff';x.beginPath();x.moveTo(b.x,b.y);x.lineTo(b.x-b.vx*.015,b.y+18);x.stroke();x.shadowBlur=0});enemies.forEach(e=>{const col=e.type==='fast'?'#ff4d9a':'#9b83ff';x.save();x.translate(e.x,e.y);x.rotate(e.rot);x.shadowBlur=20;x.shadowColor=col;x.fillStyle=col;x.beginPath();for(let i=0;i<8;i++){const a=i*Math.PI/4,q=i%2?e.r*.6:e.r;x.lineTo(Math.cos(a)*q,Math.sin(a)*q)}x.closePath();x.fill();x.fillStyle='#080913';x.beginPath();x.arc(0,0,e.r*.33,0,Math.PI*2);x.fill();x.restore()});if(boss){x.save();x.translate(boss.x,boss.y);x.shadowBlur=30;x.shadowColor='#bd5cff';x.strokeStyle='#d36cff';x.lineWidth=5;x.beginPath();x.arc(0,0,boss.r,0,Math.PI*2);x.stroke();x.fillStyle='#251040';x.beginPath();x.arc(0,0,boss.r-7,0,Math.PI*2);x.fill();x.fillStyle='#fff';x.beginPath();x.arc(-14,-3,5,0,Math.PI*2);x.arc(14,-3,5,0,Math.PI*2);x.fill();x.restore()}enemyBullets.forEach(b=>{x.fillStyle='#ff557e';x.shadowBlur=13;x.shadowColor='#ff557e';x.beginPath();x.arc(b.x,b.y,4,0,Math.PI*2);x.fill();x.shadowBlur=0});drops.forEach(p=>{const col=p.type==='shield'?'#59eaff':'#ffda68';x.strokeStyle=col;x.lineWidth=3;x.shadowBlur=18;x.shadowColor=col;x.beginPath();x.arc(p.x,p.y,12+Math.sin(Date.now()/120)*3,0,Math.PI*2);x.stroke();x.shadowBlur=0});x.save();x.translate(px,h-72);x.shadowBlur=28;x.shadowColor='#5cecff';x.fillStyle='#67eaff';x.beginPath();x.moveTo(0,-30);x.lineTo(24,25);x.lineTo(0,17);x.lineTo(-24,25);x.closePath();x.fill();x.fillStyle='#08152c';x.beginPath();x.moveTo(0,-17);x.lineTo(10,12);x.lineTo(0,8);x.lineTo(-10,12);x.closePath();x.fill();if(shield>0){x.strokeStyle='#62eaff';x.lineWidth=3;x.beginPath();x.arc(0,0,35,0,Math.PI*2);x.stroke()}x.restore();parts.forEach(p=>{x.globalAlpha=p.l;x.fillStyle=p.c;x.shadowBlur=10;x.shadowColor=p.c;x.fillRect(p.x,p.y,3,3);x.globalAlpha=1})}
function loop(now){if(!run)return;const dt=Math.min(.033,(now-last)/1000);last=now;if(mL)px-=330*dt;if(mR)px+=330*dt;px=Math.max(24,Math.min(w-24,px));if(burst>0)burst-=dt;if(boost>0)boost-=dt;if(shield>0)shield-=dt;fire-=dt;if(fire<=0){shoot();fire=boost>0?.09:.22}spawn-=dt;if(!boss&&spawn<=0){spawn=Math.max(.24,.9-wave*.035);spawnEnemy()}if(wave%5===0&&!boss&&enemies.length===0)makeBoss();if(wave%5!==0&&Math.floor(score/900)>=wave){wave++;sound(900,.1)}bullets.forEach(b=>{b.x+=b.vx*dt;b.y+=b.vy*dt});bullets=bullets.filter(b=>b.y>-30);enemies.forEach(e=>{e.y+=e.vy*dt;e.rot+=dt*1.5});enemyBullets.forEach(b=>b.y+=b.vy*dt);enemyBullets=enemyBullets.filter(b=>b.y<h+30);
for(let i=bullets.length-1;i>=0;i--){const b=bullets[i];let hit=false;for(let j=enemies.length-1;j>=0;j--){const e=enemies[j];if(Math.hypot(b.x-e.x,b.y-e.y)<e.r+5){e.hp--;bullets.splice(i,1);hit=true;if(e.hp<=0){score+=e.type==='fast'?35:20;combo++;burstP(e.x,e.y,e.type==='fast'?'#ff4d9a':'#9c7cff',20);if(Math.random()<.09)drops.push({x:e.x,y:e.y,type:Math.random()<.5?'shield':'boost'})}break}}if(hit)continue;if(boss&&Math.hypot(b.x-boss.x,b.y-boss.y)<boss.r+5){boss.hp--;bullets.splice(i,1);if(boss.hp<=0){score+=1000;combo+=5;burstP(boss.x,boss.y,'#fff',70);boss=null;wave++;sound(1100,.25,'triangle')}}}
enemies=enemies.filter(e=>{if(e.y>h+35){damage(8);return false}return e.hp>0});
if(boss){boss.x+=boss.vx*dt;if(boss.x> w-boss.r||boss.x<boss.r)boss.vx*=-1;boss.fire-=dt;if(boss.fire<=0){boss.fire=.7;enemyBullets.push({x:boss.x,y:boss.y+boss.r,vy:190+wave*4})}}
for(let i=enemyBullets.length-1;i>=0;i--){const b=enemyBullets[i];if(Math.abs(b.x-px)<23&&b.y>h-110){damage(12);enemyBullets.splice(i,1)}}
for(let i=drops.length-1;i>=0;i--){const p=drops[i];p.y+=100*dt;if(Math.hypot(p.x-px,p.y-(h-72))<38){if(p.type==='shield')shield=5;else boost=5;score+=50;sound(850,.1);drops.splice(i,1)}else if(p.y>h+20)drops.splice(i,1)}
parts.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=60*dt;p.l-=dt*2});parts=parts.filter(p=>p.l>0);
if(hp<=0){run=false;menu.classList.remove('sfhide');title.textContent='STARFALL LOST';desc.textContent='Final score: '+Math.floor(score)+' • Wave '+wave;start.textContent='RELAUNCH'}sc.textContent=Math.floor(score);wv.textContent=wave;hpEl.textContent=Math.ceil(hp);cm.textContent='x'+combo;draw();requestAnimationFrame(loop)}
})();
</script>`

  const payloadData = {
    response_id: responseId,
    sections: [{
      view_model: {
        primitive: {
          text: '🎮 Arcade Mini Games',
          __typename: 'GenAIMarkdownTextUXPrimitive'
        },
        __typename: 'GenAISingleLayoutViewModel'
      }
    }],
    embedded_screens: [{
      title: 'Arcade Mini Games',
      content: [{
        __typename: 'FOAIDNixelButtonSheets',
        tabs: [
          {
            id: 'tab_0',
            tab_header: '⚔️ NEON DUEL',
            sections: [{
              __typename: 'GenAIUnifiedResponseSection',
              view_model: {
                __typename: 'GenAISingleLayoutViewModel',
                primitive: {
                  __typename: 'GenAIaeacdsnwHtmlPrimitive',
                  payload: gameNeonDuel,
                  trusted_sources: []
                }
              }
            }],
            step_entries: []
          },
          {
            id: 'tab_1',
            tab_header: '💎 VAULT BREAKER',
            sections: [{
              __typename: 'GenAIUnifiedResponseSection',
              view_model: {
                __typename: 'GenAISingleLayoutViewModel',
                primitive: {
                  __typename: 'GenAIaeacdsnwHtmlPrimitive',
                  payload: gameVault,
                  trusted_sources: []
                }
              }
            }],
            step_entries: []
          },
          {
            id: 'tab_2',
            tab_header: '🚀 STARFALL',
            sections: [{
              __typename: 'GenAIUnifiedResponseSection',
              view_model: {
                __typename: 'GenAISingleLayoutViewModel',
                primitive: {
                  __typename: 'GenAIaeacdsnwHtmlPrimitive',
                  payload: gameStarfall,
                  trusted_sources: []
                }
              }
            }],
            step_entries: []
          }
        ]
      }]
    }]
  }

  await conn.relayMessage(m.chat, {
    messageContextInfo: {
      deviceListMetadata: {},
      deviceListMetadataVersion: 2,
      botMetadata: {
        messageDisclaimerText: '',
        botResponseId,
        verificationMetadata: {
          proofs: [{
            verificationKey: 'mrzkyzdnii',
            verificationValue: 'mrzkyzdnii'
          }]
        }
      }
    },
    botForwardedMessage: {
      message: {
        richResponseMessage: {
          messageType: 1,
          submessages: [{
            messageType: 2,
            messageText: '🎮 Arcade Mini Games'
          }],
          unifiedResponse: {
            data: Buffer.from(JSON.stringify(payloadData)).toString('base64')
          },
          contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedAiBotMessageInfo: {
              botJid: '867051314767696@bot'
            },
            forwardOrigin: 4
          }
        }
      }
    }
  }, {
    additionalNodes: [{
      tag: 'biz',
      attrs: {},
      content: [{
        tag: 'interactive',
        attrs: {
          type: 'native_flow',
          v: '1'
        },
        content: [{
          tag: 'native_flow',
          attrs: {
            v: '9',
            name: 'mixed'
          }
        }]
      }]
    }]
  })
}

handler.help = ['arcade']
handler.tags = ['game']
handler.command = /^(arcade|game)$/i

export default handler