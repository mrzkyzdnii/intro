import axios from 'axios'
import * as cheerio from 'cheerio'

/**
 * Scraper Google Images Resolusi Penuh (HD Asli)
 * @param {string} query
 * @returns {Promise<Array<{title: string, url: string, width: number, height: number, source: string}>>}
 */
const scraper = async (query) => {
  if (!query) throw new Error('Masukkan kata kunci pencarian!')

  const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch&hl=id&gl=id`
  
  const { data: html } = await axios.get(searchUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
      'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
    },
    timeout: 15000
  })

  const results = []

  // Ekstraksi data AF_initDataCallback (Berisi URL Full HD Asli dari Google Image Client Data)
  const scriptRegex = /AF_initDataCallback\({key:\s*'ds:1',.*?data:\s*(\[.+?\])\s*,\s*sideChannel/s
  const match = html.match(scriptRegex)

  if (match && match[1]) {
    try {
      const data = JSON.parse(match[1])
      const items = data?.[56]?.[1]?.[0]?.[0]?.[1]?.[0] || []
      
      for (const item of items) {
        const itemData = item?.[0]?.[0]
        if (!itemData) continue

        // URL Full HD asli
        const originalUrl = itemData?.[1]?.[3]?.[0]
        const width = itemData?.[1]?.[3]?.[2] || 0
        const height = itemData?.[1]?.[3]?.[1] || 0
        const title = itemData?.[1]?.[9]?.[2003]?.[3] || query
        const source = itemData?.[1]?.[9]?.[2003]?.[2] || ''

        if (originalUrl && originalUrl.startsWith('http')) {
          results.push({
            title: title.replace(/<[^>]*>?/gm, '').trim(),
            url: originalUrl,
            width,
            height,
            source
          })
        }
      }
    } catch {
      // Fallback regex jika JSON schema sedikit bergeser
    }
  }

  // Fallback pattern matching jika format dinamis
  if (results.length === 0) {
    const regex = /\["(https?:\/\/[^"]+)",\s*(\d+),\s*(\d+)\]/g
    let m
    while ((m = regex.exec(html)) !== null) {
      const imgUrl = m[1]
      const h = parseInt(m[2], 10)
      const w = parseInt(m[3], 10)

      if (
        w > 300 && h > 300 && 
        !imgUrl.includes('gstatic.com') && 
        !imgUrl.includes('google.com') &&
        (imgUrl.endsWith('.jpg') || imgUrl.endsWith('.jpeg') || imgUrl.endsWith('.png') || imgUrl.endsWith('.webp') || imgUrl.includes('format='))
      ) {
        results.push({
          title: query,
          url: imgUrl,
          width: w,
          height: h,
          source: imgUrl
        })
      }
    }
  }

  if (results.length === 0) {
    throw new Error(`Tidak dapat menemukan gambar HD untuk query: "${query}"`)
  }

  return results
}

// Handler Bot WhatsApp
const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*Format Penggunaan:*\n${usedPrefix + command} <nama gambar>\n\n*Contoh:*\n${usedPrefix + command} Gojo Satoru Wallpaper HD`

  await conn.reply(m.chat, `🔎 Sedang mencari gambar HD untuk *${text}*...`, m)

  try {
    const images = await scraper(text)
    
    // Pilih 1 gambar acak dari hasil scraping HD
    const selected = images[Math.floor(Math.random() * images.length)]

    const caption = `*GOOGLE IMAGE SEARCH (HD)*\n\n` +
      `📌 *Judul:* ${selected.title}\n` +
      (selected.width && selected.height ? `📐 *Resolusi:* ${selected.width} x ${selected.height} px\n` : '') +
      (selected.source ? `🌐 *Sumber:* ${selected.source}\n` : '') +
      `🖼️ *URL Gambar:* ${selected.url}`

    // Kirim gambar Full HD langsung ke chat
    await conn.sendFile(m.chat, selected.url, 'google_hd.jpg', caption, m)
  } catch (err) {
    await conn.reply(m.chat, `❌ *Terjadi Kesalahan:*\n${err.message}`, m)
  }
}

handler.help = ['gimage', 'googleimage', 'image', 'gimg']
handler.tags = ['internet']
handler.command = /^(gimage|googleimage|image|gimg)$/i

export default handler