let handler = async (m, { conn, usedPrefix, command, text }) => {
    const user = global.db?.data?.users?.[m.sender]

    if (!user) {
        throw '❌ Data user belum tersedia.'
    }

    // ==========================================
    // DEFAULT
    // ==========================================
    if (typeof user.money !== 'number' || !Number.isFinite(user.money)) {
        user.money = 0
    }

    if (typeof user.bank !== 'number' || !Number.isFinite(user.bank)) {
        user.bank = 0
    }

    // ==========================================
    // FORMAT ANGKA
    // ==========================================
    const format = number => {
        return Number(number).toLocaleString('id-ID')
    }

    // ==========================================
    // BANK
    // ==========================================
    if (command.toLowerCase() === 'bank') {
        const total = user.money + user.bank

        const teks = `╭━━〔 🏦 BANK 〕━━╮
┃
┃  👤 Nasabah : *${m.name || 'User'}*
┃
┃  💰 Money   : *Rp${format(user.money)}*
┃  🏦 Bank    : *Rp${format(user.bank)}*
┃
┃  💎 Total   : *Rp${format(total)}*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┃  📥 *DEPOSIT*
┃  ${usedPrefix}deposit 100000
┃
┃  📤 *WITHDRAW*
┃  ${usedPrefix}wd 100000
┃
┃  💸 Tax Deposit : *1%*
┃
╰━━━━━━━━━━━━━━━━━━━━╯`

        return conn.reply(m.chat, teks, m)
    }

    // ==========================================
    // AMBIL JUMLAH
    // ==========================================
    const amount = Number(
        String(text || '')
            .replace(/[.,]/g, '')
            .trim()
    )

    if (!text || !Number.isFinite(amount)) {
        if (command.toLowerCase() === 'deposit') {
            throw `❌ Masukkan jumlah money yang ingin disetor.

Contoh:
${usedPrefix}deposit 100000`
        }

        if (command.toLowerCase() === 'wd') {
            throw `❌ Masukkan jumlah money yang ingin ditarik.

Contoh:
${usedPrefix}wd 100000`
        }
    }

    if (amount <= 0) {
        throw '❌ Jumlah harus lebih dari *0*.'
    }

    if (!Number.isSafeInteger(amount)) {
        throw '❌ Jumlah terlalu besar atau tidak valid.'
    }

    // ==========================================
    // DEPOSIT
    // ==========================================
    if (command.toLowerCase() === 'deposit') {
        if (user.money < amount) {
            throw `❌ Money kamu tidak cukup.

💰 Money kamu : *Rp${format(user.money)}*
📥 Deposit    : *Rp${format(amount)}*
📉 Kekurangan : *Rp${format(amount - user.money)}*`
        }

        // Tax 1%
        const tax = Math.floor(amount * 0.01)
        const received = amount - tax

        if (received <= 0) {
            throw '❌ Jumlah terlalu kecil setelah terkena tax.'
        }

        user.money -= amount
        user.bank += received

        const teks = `╭━━〔 📥 DEPOSIT BERHASIL 〕━━╮
┃
┃  💰 Deposit  : *Rp${format(amount)}*
┃  💸 Tax 1%   : *Rp${format(tax)}*
┃  🏦 Masuk Bank : *Rp${format(received)}*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┃  💰 Money    : *Rp${format(user.money)}*
┃  🏦 Bank     : *Rp${format(user.bank)}*
┃
╰━━━━━━━━━━━━━━━━━━━━╯`

        return conn.reply(m.chat, teks, m)
    }

    // ==========================================
    // WITHDRAW / WD
    // ==========================================
    if (command.toLowerCase() === 'wd') {
        if (user.bank < amount) {
            throw `❌ Saldo bank tidak cukup.

🏦 Saldo Bank : *Rp${format(user.bank)}*
📤 Withdraw   : *Rp${format(amount)}*
📉 Kekurangan : *Rp${format(amount - user.bank)}*`
        }

        user.bank -= amount
        user.money += amount

        const teks = `╭━━〔 📤 WITHDRAW BERHASIL 〕━━╮
┃
┃  🏦 Dari Bank : *Rp${format(amount)}*
┃  💰 Masuk Money : *Rp${format(amount)}*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃
┃  💰 Money : *Rp${format(user.money)}*
┃  🏦 Bank  : *Rp${format(user.bank)}*
┃
╰━━━━━━━━━━━━━━━━━━━━╯`

        return conn.reply(m.chat, teks, m)
    }

    // ==========================================
    // COMMAND TIDAK DIKENAL
    // ==========================================
    throw `❌ Command bank tidak valid.

Contoh:
${usedPrefix}bank
${usedPrefix}deposit 100000
${usedPrefix}wd 100000`
}

handler.help = [
    'bank',
    'deposit',
    'wd'
]

handler.tags = ['rpg']

handler.command = /^(bank|deposit|wd)$/i

export default handler