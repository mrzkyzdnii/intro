const handler = async (m, { conn, command }) => {
conn.relayMessage(
m.chat,
{
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
botMetadata: {
messageDisclaimerText: "",
botResponseId: "xox-game-2026",
verificationMetadata: {
proofs: [
{
version: 1,
useCase: 1,
signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
certificateChain: ["TklYRUwuTWVzc2FnZUJ1bGRlc..."]
}
]
}
}
},
botForwardedMessage: {
message: {
richResponseMessage: {
messageType: 1,
submessages: [
{
messageType: 2,
messageText: "🎮 XOX GAME"
}
],
unifiedResponse: {
data: Buffer.from(JSON.stringify({
"response_id": "xox-game-2026",
"sections": [
{
"view_model": {
"primitive": {
"__typename": "GenAIaeacdsnwHtmlPrimitive",
"payload": `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;user-select:none}
body{margin:0;background:transparent;font-family:'Segoe UI',Arial,sans-serif;color:#eee;touch-action:manipulation}
.wrap{width:100%;max-width:520px;margin:auto;padding:14px}
.card{background:linear-gradient(145deg,rgba(255,255,255,.08),rgba(255,255,255,.03));border:1px solid rgba(255,255,255,.12);border-radius:24px;padding:20px;backdrop-filter:blur(16px);box-shadow:0 16px 48px rgba(0,0,0,.5)}
.header{text-align:center;margin-bottom:16px}
.header h1{font-size:28px;font-weight:800;margin:0;background:linear-gradient(135deg,#f7971e,#ffd200);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.header p{font-size:13px;color:#999;margin:4px 0 0}
.status{text-align:center;font-size:20px;font-weight:700;padding:12px;border-radius:12px;background:rgba(255,255,255,.06);margin-bottom:16px;border:1px solid rgba(255,255,255,.08)}
.board{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;max-width:400px;margin:0 auto 16px}
.cell{aspect-ratio:1;background:rgba(255,255,255,.06);border:2px solid rgba(255,255,255,.12);border-radius:16px;font-size:56px;font-weight:700;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;color:#fff;text-shadow:0 4px 12px rgba(0,0,0,.3)}
.cell:active{transform:scale(.94);background:rgba(255,255,255,.14)}
.cell.x{color:#ff6b6b;text-shadow:0 4px 20px rgba(255,107,107,.4)}
.cell.o{color:#4ecdc4;text-shadow:0 4px 20px rgba(78,205,196,.4)}
.cell.win{background:rgba(46,213,115,.25)!important;border-color:#2ed573!important;animation:pulse .6s ease infinite alternate}
@keyframes pulse{0%{transform:scale(1)}100%{transform:scale(1.05)}}
.levels{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px}
.level-btn{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:10px 4px;color:#aaa;font-size:11px;font-weight:600;cursor:pointer;transition:all .2s;text-align:center}
.level-btn:active{transform:scale(.95)}
.level-btn.active{background:linear-gradient(135deg,#f7971e,#ffd200);color:#000;border-color:#ffd200;font-weight:700}
.level-btn .icon{font-size:18px;display:block;margin-bottom:2px}
.controls{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.btn{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:12px;color:#fff;font-size:14px;font-weight:700;cursor:pointer;transition:all .2s}
.btn:active{transform:scale(.95)}
.btn.reset{background:linear-gradient(135deg,#667eea,#764ba2)}
.btn.auto{background:linear-gradient(135deg,#f093fb,#f5576c)}
.score{display:flex;justify-content:space-around;padding:12px;background:rgba(255,255,255,.05);border-radius:12px;margin-bottom:16px;font-size:14px;font-weight:600}
.score span{display:flex;align-items:center;gap:6px}
.score .x-score{color:#ff6b6b}
.score .o-score{color:#4ecdc4}
.score .draw-score{color:#ffd93d}
.footer{text-align:center;color:#666;font-size:11px;margin-top:12px}
</style>

<body>
<div class="wrap">
<div class="card">

<div class="header">
<h1>🎮 XOX GAME</h1>
<p>Pilih level & mulai main!</p>
</div>

<div class="score">
<span class="x-score">❌ <span id="xScore">0</span></span>
<span class="draw-score">⚖️ <span id="drawScore">0</span></span>
<span class="o-score">⭕ <span id="oScore">0</span></span>
</div>

<div id="status" class="status">🎯 Pilih level dulu!</div>

<div class="levels">
<div class="level-btn" data-level="easy">😊<br>Mudah</div>
<div class="level-btn" data-level="medium">🤔<br>Sedang</div>
<div class="level-btn" data-level="hard">😈<br>Sulit</div>
<div class="level-btn" data-level="impossible">🤖<br>Impossible</div>
</div>

<div class="board" id="board">
<div class="cell" data-index="0"></div>
<div class="cell" data-index="1"></div>
<div class="cell" data-index="2"></div>
<div class="cell" data-index="3"></div>
<div class="cell" data-index="4"></div>
<div class="cell" data-index="5"></div>
<div class="cell" data-index="6"></div>
<div class="cell" data-index="7"></div>
<div class="cell" data-index="8"></div>
</div>

<div class="controls">
<button class="btn reset" id="reset">🔄 Reset</button>
<button class="btn auto" id="autoPlay">🤖 Auto Play</button>
</div>

<div class="footer">Kamu ❌ • Bot ⭕ • Tap kotak untuk main</div>

</div>
</div>

<script>
const boardEl = document.getElementById('board');
const cells = document.querySelectorAll('.cell');
const statusEl = document.getElementById('status');
const resetBtn = document.getElementById('reset');
const autoBtn = document.getElementById('autoPlay');
const levelBtns = document.querySelectorAll('.level-btn');
const xScoreEl = document.getElementById('xScore');
const oScoreEl = document.getElementById('oScore');
const drawScoreEl = document.getElementById('drawScore');

let board = Array(9).fill('');
let currentPlayer = 'X';
let gameActive = true;
let level = 'easy';
let scores = { X: 0, O: 0, draw: 0 };
let gameCount = 0;
let isBotTurn = false;
let autoPlayInterval = null;

const winPatterns = [
[0,1,2],[3,4,5],[6,7,8],
[0,3,6],[1,4,7],[2,5,8],
[0,4,8],[2,4,6]
];

// ===== LEVEL CONFIG =====
const levelConfig = {
easy: { label: '😊 Mudah', botDelay: 800, mistakeChance: 0.4 },
medium: { label: '🤔 Sedang', botDelay: 600, mistakeChance: 0.2 },
hard: { label: '😈 Sulit', botDelay: 400, mistakeChance: 0.05 },
impossible: { label: '🤖 Impossible', botDelay: 300, mistakeChance: 0 }
};

function updateLevelUI() {
levelBtns.forEach(btn => {
btn.classList.toggle('active', btn.dataset.level === level);
});
statusEl.textContent = \`🎯 Level: \${levelConfig[level].label}\`;
}

function updateScoreUI() {
xScoreEl.textContent = scores.X;
oScoreEl.textContent = scores.O;
drawScoreEl.textContent = scores.draw;
}

function checkWinner(boardState) {
for (let pattern of winPatterns) {
const [a,b,c] = pattern;
if (boardState[a] && boardState[a] === boardState[b] && boardState[a] === boardState[c]) {
return { winner: boardState[a], pattern };
}
}
return boardState.includes('') ? null : { winner: 'draw' };
}

function getEmptyCells(boardState) {
return boardState.map((v,i) => v === '' ? i : null).filter(v => v !== null);
}

// ===== AI LOGIC =====
function minimax(boardState, depth, isMaximizing, alpha = -Infinity, beta = Infinity) {
const result = checkWinner(boardState);
if (result) {
if (result.winner === 'O') return 10 - depth;
if (result.winner === 'X') return depth - 10;
return 0;
}

const empty = getEmptyCells(boardState);
if (empty.length === 0) return 0;

if (isMaximizing) {
let maxEval = -Infinity;
for (let idx of empty) {
boardState[idx] = 'O';
const eval = minimax(boardState, depth + 1, false, alpha, beta);
boardState[idx] = '';
maxEval = Math.max(maxEval, eval);
alpha = Math.max(alpha, eval);
if (beta <= alpha) break;
}
return maxEval;
} else {
let minEval = Infinity;
for (let idx of empty) {
boardState[idx] = 'X';
const eval = minimax(boardState, depth + 1, true, alpha, beta);
boardState[idx] = '';
minEval = Math.min(minEval, eval);
beta = Math.min(beta, eval);
if (beta <= alpha) break;
}
return minEval;
}
}

function getBotMove(boardState, level) {
const empty = getEmptyCells(boardState);
if (empty.length === 0) return null;

const config = levelConfig[level];

// Easy: mostly random
if (level === 'easy') {
return empty[Math.floor(Math.random() * empty.length)];
}

// Medium: 20% random
if (level === 'medium' && Math.random() < 0.2) {
return empty[Math.floor(Math.random() * empty.length)];
}

// Hard: 5% random
if (level === 'hard' && Math.random() < 0.05) {
return empty[Math.floor(Math.random() * empty.length)];
}

// Impossible: always perfect
let bestScore = -Infinity;
let bestMoves = [];

for (let idx of empty) {
const boardCopy = [...boardState];
boardCopy[idx] = 'O';
const score = minimax(boardCopy, 0, false);
if (score > bestScore) {
bestScore = score;
bestMoves = [idx];
} else if (score === bestScore) {
bestMoves.push(idx);
}
}

return bestMoves[Math.floor(Math.random() * bestMoves.length)];
}

// ===== GAME LOGIC =====
function makeMove(index) {
if (!gameActive || isBotTurn || board[index] !== '' || currentPlayer !== 'X') return;

board[index] = 'X';
renderBoard();
const result = checkWinner(board);
if (result) {
endGame(result);
return;
}

currentPlayer = 'O';
statusEl.textContent = '⏳ Bot berpikir...';
isBotTurn = true;

const delay = levelConfig[level].botDelay;
setTimeout(() => {
if (!gameActive) return;
const botIndex = getBotMove(board, level);
if (botIndex === null) {
const result = checkWinner(board);
if (result) endGame(result);
return;
}
board[botIndex] = 'O';
renderBoard();
const result2 = checkWinner(board);
if (result2) {
endGame(result2);
return;
}
currentPlayer = 'X';
isBotTurn = false;
statusEl.textContent = '🧑 Giliran kamu (❌)';
}, delay);
}

function endGame(result) {
gameActive = false;
isBotTurn = false;

if (result.winner === 'X') {
scores.X++;
statusEl.textContent = '🎉 Kamu Menang! ❌';
result.pattern.forEach(i => cells[i].classList.add('win'));
} else if (result.winner === 'O') {
scores.O++;
statusEl.textContent = '😵 Bot Menang! ⭕';
result.pattern.forEach(i => cells[i].classList.add('win'));
} else {
scores.draw++;
statusEl.textContent = '🤝 Seri!';
}

updateScoreUI();
}

function renderBoard() {
cells.forEach((cell, i) => {
cell.textContent = board[i];
cell.className = 'cell';
if (board[i] === 'X') cell.classList.add('x');
if (board[i] === 'O') cell.classList.add('o');
});
}

function resetGame() {
if (autoPlayInterval) {
clearInterval(autoPlayInterval);
autoPlayInterval = null;
autoBtn.textContent = '🤖 Auto Play';
}
board = Array(9).fill('');
currentPlayer = 'X';
gameActive = true;
isBotTurn = false;
renderBoard();
statusEl.textContent = '🧑 Giliran kamu (❌)';
}

function startAutoPlay() {
if (autoPlayInterval) {
clearInterval(autoPlayInterval);
autoPlayInterval = null;
autoBtn.textContent = '🤖 Auto Play';
return;
}

if (!gameActive) resetGame();
autoBtn.textContent = '⏹ Stop';
autoPlayInterval = setInterval(() => {
if (!gameActive) {
clearInterval(autoPlayInterval);
autoPlayInterval = null;
autoBtn.textContent = '🤖 Auto Play';
return;
}
const empty = getEmptyCells(board);
if (empty.length === 0) return;
const randomIdx = empty[Math.floor(Math.random() * empty.length)];
makeMove(randomIdx);
}, 600);
}

// ===== EVENT LISTENERS =====
cells.forEach(cell => {
cell.addEventListener('click', () => {
const idx = parseInt(cell.dataset.index);
makeMove(idx);
});
});

resetBtn.addEventListener('click', resetGame);

autoBtn.addEventListener('click', startAutoPlay);

levelBtns.forEach(btn => {
btn.addEventListener('click', () => {
level = btn.dataset.level;
updateLevelUI();
resetGame();
});
});

// ===== INIT =====
updateLevelUI();
resetGame();
updateScoreUI();

// Simpan state untuk persistensi (via WA)
window.__xoxState = {
getState: () => ({ board, currentPlayer, gameActive, level, scores, gameCount }),
setState: (s) => { board = s.board; currentPlayer = s.currentPlayer; gameActive = s.gameActive; level = s.level; scores = s.scores; gameCount = s.gameCount; renderBoard(); updateLevelUI(); updateScoreUI(); }
};

</script>
</body>`,
"trusted_sources": ["adam.dev"]
},
"__typename": "GenAISingleLayoutViewModel"
}
}
]
})).toString('base64')
},
contextInfo: {
forwardingScore: 1,
isForwarded: true,
forwardedAiBotMessageInfo: {
botJid: "867051314767696@bot"
},
forwardOrigin: 4
}
}
}
}
},
{}
)
}

handler.help = ['xox']
handler.tags = ['game']
handler.command = /^(xox)$/i

export default handler