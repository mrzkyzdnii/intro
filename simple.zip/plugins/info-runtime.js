import os from 'os'

let handler = async (m, { conn }) => {
    try {
        let uptime = process.uptime()
        let hours = Math.floor(uptime / 3600)
        let minutes = Math.floor((uptime % 3600) / 60)
        let seconds = Math.floor(uptime % 60)

        let text = `◈ Runtime : ${hours}h ${minutes}m ${seconds}s
◈ System  : ${os.platform()}
◈ Arch    : ${os.arch()}`

        await conn.reply(m.chat, text, m)
    } catch {
        await conn.reply(m.chat, '✗ Gagal mengambil data runtime.', m)
    }
}

handler.help = ['runtime']
handler.tags = ['info']
handler.command = ['runtime']

handler.limit = 10
export default handler