import { xpRange } from '../lib/levelling.js'

let handler = async (m, { conn, isOwner, isPrems }) => {
  let who = m.mentionedJid?.[0] || m.quoted?.sender || m.sender
  let user = global.db.data.users[who]

  if (!user) throw 'User tidak ditemukan.'

  let {
    level = 0,
    exp = 0,
    money = 0,
    limit = 0,
    role = 'Newbie',
    registered = false,
    name = '',
    age = '-',
    pasangan = '',
    jadian = false,
    jadianTime = 0
  } = user

  let { min, xp } = xpRange(level, global.multiplier || 1)

  let username = registered ? name : await conn.getName(who)

  let bio = 'Tidak ada bio'
  try {
    bio = (await conn.fetchStatus(who))?.status || 'Tidak ada bio'
  } catch {}

  let status = isOwner
    ? 'Owner'
    : isPrems
      ? 'Premium'
      : 'Free User'

  let limitText = isPrems ? 'Unlimited' : limit

  let pasanganText = 'Tidak Ada'
  let lamaJadian = '-'
  let tanggalJadian = '-'

  if (jadian && pasangan) {
    let diff = Date.now() - jadianTime
    let hari = Math.floor(diff / 86400000)
    let jam = Math.floor(diff / 3600000) % 24

    pasanganText = `@${pasangan.split('@')[0]}`
    lamaJadian = `${hari} Hari ${jam} Jam`

    tanggalJadian = new Date(jadianTime).toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
  }

  let total = Math.max(1, xp - min)
  let current = Math.max(0, exp - min)
  let percent = Math.min(100, Math.floor(current / total * 100))

  let filled = Math.floor(percent / 10)
  let bar = '█'.repeat(filled) + '░'.repeat(10 - filled)

  let text = `
╭━━〔 ◈ PROFILE 〕━━╮
┃
┃  👤 Nama : ${username}
┃  🎂 Umur : ${registered ? age : '-'} Tahun
┃  🏷️ Role : ${role}
┃  ✨ Status : ${status}
┃
┣━━〔 ◇ BIO 〕━━
┃
┃  ${bio}
┃
┣━━〔 ◇ EXPERIENCE 〕━━
┃
┃  ▸ Level : ${level}
┃  ▸ XP : ${current.toLocaleString('id-ID')} / ${total.toLocaleString('id-ID')}
┃  ▸ Progress : ${bar} ${percent}%
┃
┣━━〔 ◇ ECONOMY 〕━━
┃
┃  💰 Money : Rp${money.toLocaleString('id-ID')}
┃  ⚡ Limit : ${limitText}
┃
┣━━〔 ◇ RELATIONSHIP 〕━━
┃
┃  ❤️ Status : ${jadian ? 'Berpacaran' : 'Jomblo'}
┃  💕 Pasangan : ${pasanganText}
┃  📅 Sejak : ${tanggalJadian}
┃  ⏱️ Bersama : ${lamaJadian}
┃
╰━━━━━━━━━━━━━━━━━━╯
`.trim()

  await conn.reply(m.chat, text, m, {
    mentions: [
      who,
      ...(jadian && pasangan ? [pasangan] : [])
    ]
  })
}

handler.help = ['profile']
handler.tags = ['xp']
handler.command = /^(profile|profil|me)$/i
handler.limit = false

export default handler