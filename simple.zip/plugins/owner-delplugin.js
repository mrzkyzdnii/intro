import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
  if (!isOwner) return m.reply('❌ Khusus owner.')

  let input = text ? text.trim() : ''

  if (!input) {
    return m.reply(
      `📦 *Cara pakai:*\n\n` +
      `• ${usedPrefix + command} namaplugin.js\n` +
      `• ${usedPrefix + command} menu | sticker | runtime\n\n` +
      `Contoh:\n` +
      `• ${usedPrefix}def menu\n` +
      `• ${usedPrefix}delplugin sticker\n` +
      `• ${usedPrefix}delplugin roboguru | hn | hhw`
    )
  }

  let targets = input.split('|').map(v => v.trim()).filter(v => v)

  let success = []
  let failed = []

  for (let t of targets) {
    let target = t.endsWith('.js') ? t : t + '.js'
    const pluginsDir = './plugins'
    const filePath = path.join(pluginsDir, target)

    if (fs.existsSync(filePath)) {
      try {
        fs.unlinkSync(filePath)
        success.push(target)
      } catch (e) {
        failed.push(target)
      }
      continue
    }

    const found = findFileRecursive(pluginsDir, target)
    if (found) {
      try {
        fs.unlinkSync(found)
        success.push(target)
      } catch (e) {
        failed.push(target)
      }
    } else {
      failed.push(target)
    }
  }

  let msg = ''
  if (success.length) msg += `✅ *Berhasil dihapus (${success.length}):*\n${success.map(v => `• ${v}`).join('\n')}\n\n`
  if (failed.length) msg += `❌ *Tidak ditemukan (${failed.length}):*\n${failed.map(v => `• ${v}`).join('\n')}`

  await m.reply(msg.trim())
}

function findFileRecursive(dir, filename) {
  try {
    const items = fs.readdirSync(dir, { withFileTypes: true })
    for (const item of items) {
      const fullPath = path.join(dir, item.name)
      if (item.isDirectory()) {
        const result = findFileRecursive(fullPath, filename)
        if (result) return result
      } else if (item.name === filename) {
        return fullPath
      }
    }
  } catch (e) {
    return null
  }
  return null
}

handler.help = [
  'deleteplugin <namafile>',
  'delplugin <namafile>',
  'def <namafile>'
]
handler.tags = ['owner']
handler.command = /^(deleteplugin|delplugin|def|removeplugin|rmplugin)$/i
handler.owner = true
handler.limit = 10

export default handler