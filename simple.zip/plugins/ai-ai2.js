const handler = async (m, { conn, usedPrefix, command }) => {
    await conn.relayMessage(m.chat, {
        interactiveMessage: {
            header: {
                title: 'AI2',
                subtitle: 'mrzkyzdnii',
                hasMediaAttachment: false
            },
            body: {
                text: `🤖 *AI2*

> AI chat interaktif langsung dari browser.

Gunakan AI2 untuk ngobrol, bertanya, mencari ide, dan berbagai kebutuhan lainnya.

⚡ *Mode:* AI Chat
🌐 *Bahasa:* Indonesia
🚀 *Platform:* AI2

Tekan tombol di bawah untuk mulai menggunakan AI2.`
            },
            footer: {
                text: 'mrzkyzdnii • AI2'
            },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: '🤖 Buka AI2',
                            icon: 'Promotion',
                            url: 'https://99ekjse9z4ytl57g9ibsgx0vgu6gqltd.pastehtml.dev/',
                            webview_interaction: true
                        })
                    }
                ],
                messageParamsJson: '{}',
                messageVersion: 1
            },
            contextInfo: {
                participant: m.sender,
                stanzaId: m.key?.id || '',
                quotedMessage: {
                    extendedTextMessage: {
                        text: `${usedPrefix + command}`,
                        previewType: 0,
                        inviteLinkGroupTypeV2: 0
                    }
                }
            }
        }
    }, {
        additionalNodes: [
            {
                tag: 'biz',
                attrs: {},
                content: [
                    {
                        tag: 'interactive',
                        attrs: {
                            type: 'native_flow',
                            v: '1'
                        },
                        content: [
                            {
                                tag: 'native_flow',
                                attrs: {
                                    v: '9',
                                    name: 'mixed'
                                }
                            }
                        ]
                    }
                ]
            }
        ]
    })
}

handler.help = ['ai2']
handler.tags = ['ai']
handler.command = /^ai2$/i

export default handler