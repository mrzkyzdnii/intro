import sharp from 'sharp'
import axios from 'axios'

/**
 * Generator Gambar TikTok Comment Card
 * Menghasilkan Buffer PNG resolusi tinggi secara instan
 */
const generateTokComment = async (name, text, avatarInput, options = {}) => {
  const isDark = options.isDark !== false
  const likes = options.likes || `${(Math.random() * 9 + 1).toFixed(1)}K`
  const time = options.time || '1h ago'

  // Fetch avatar image dan ubah ke Base64 Data URI
  let avatarBase64 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='
  if (avatarInput) {
    try {
      if (Buffer.isBuffer(avatarInput)) {
        avatarBase64 = `data:image/png;base64,${avatarInput.toString('base64')}`
      } else if (typeof avatarInput === 'string' && avatarInput.startsWith('http')) {
        const res = await axios.get(avatarInput, { responseType: 'arraybuffer' })
        const mime = res.headers['content-type'] || 'image/png'
        avatarBase64 = `data:${mime};base64,${Buffer.from(res.data).toString('base64')}`
      }
    } catch (e) {
      console.error('Failed to load avatar:', e.message)
    }
  }

  // Warna Palette TikTok Dark / Light Mode
  const bgColor = isDark ? '#121212' : '#ffffff'
  const nameColor = isDark ? '#a1a1a6' : '#616161'
  const commentColor = isDark ? '#ffffff' : '#121212'
  const subColor = isDark ? '#757578' : '#8a8a8e'
  const heartColor = isDark ? '#8a8a8e' : '#8a8a8e'

  // Algoritma auto word-wrap teks komentar
  const maxCharsPerLine = 38
  const words = text.split(' ')
  const lines = []
  let currentLine = ''

  for (const word of words) {
    if ((currentLine + ' ' + word).trim().length <= maxCharsPerLine) {
      currentLine = (currentLine + ' ' + word).trim()
    } else {
      if (currentLine) lines.push(currentLine)
      currentLine = word
    }
  }
  if (currentLine) lines.push(currentLine)
  if (lines.length === 0) lines.push('')

  const lineHeight = 22
  const textBlockHeight = lines.length * lineHeight

  // Dimensi gambar dinamis menyesuaikan panjang teks
  const width = 540
  const height = Math.max(120, 60 + textBlockHeight + 35)

  const escapeXml = (str) =>
    String(str).replace(/[<>&'"]/g, (c) => ({
      '<': '&lt;',
      '>': '&gt;',
      '&': '&amp;',
      "'": '&apos;',
      '"': '&quot;'
    }[c]))

  const tspanLines = lines
    .map(
      (line, idx) =>
        `<tspan x="72" dy="${idx === 0 ? 0 : lineHeight}">${escapeXml(line)}</tspan>`
    )
    .join('')

  // SVG Template Layout TikTok Comment
  const svg = `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
    <style>
      .bg { fill: ${bgColor}; }
      .username { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 13px; font-weight: 600; fill: ${nameColor}; }
      .comment-text { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 15px; font-weight: 400; fill: ${commentColor}; }
      .meta-text { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 13px; font-weight: 500; fill: ${subColor}; }
      .likes-text { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; font-size: 12px; font-weight: 500; fill: ${subColor}; text-anchor: middle; }
    </style>
    
    <rect width="${width}" height="${height}" rx="16" class="bg" />
    
    <!-- Clip Avatar Bulat -->
    <defs>
      <clipPath id="avatarClip">
        <circle cx="42" cy="40" r="20" />
      </clipPath>
    </defs>
    
    <!-- Avatar Image -->
    <image href="${avatarBase64}" x="22" y="20" width="40" height="40" clip-path="url(#avatarClip)" preserveAspectRatio="xMidYMid slice" />
    
    <!-- Nama User -->
    <text x="72" y="34" class="username">${escapeXml(name)}</text>
    
    <!-- Teks Komentar -->
    <text x="72" y="58" class="comment-text">
      ${tspanLines}
    </text>
    
    <!-- Meta (Timestamp & Reply) -->
    <text x="72" y="${58 + textBlockHeight + 14}" class="meta-text">${escapeXml(time)}<tspan dx="16" font-weight="600" fill="${subColor}">Reply</tspan></text>
    
    <!-- Icon Heart TikTok & Counter Likes -->
    <g transform="translate(${width - 42}, 30)">
      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" fill="none" stroke="${heartColor}" stroke-width="1.8" transform="scale(0.85) translate(-2, -2)" />
      <text x="8" y="28" class="likes-text">${escapeXml(likes)}</text>
    </g>
  </svg>`

  // Render SVG ke Buffer PNG
  return await sharp(Buffer.from(svg)).png().toBuffer()
}

/**
 * Main Handler Bot WhatsApp
 */
const handler = async (m, { conn, text, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m
  let mime = (q.msg || q).mimetype || ''

  let name = ''
  let commentText = ''
  let avatarInput = null

  // Parameter parsing logic
  if (text.includes('|')) {
    const parts = text.split('|').map((v) => v.trim())
    if (parts.length >= 3) {
      name = parts[0]
      commentText = parts[1]
      avatarInput = parts[2]
    } else if (parts.length === 2) {
      name = parts[0]
      commentText = parts[1]
    }
  } else {
    commentText = text.trim()
  }

  // Jika avatar belum diisi dari URL, cek dari media (photo quoted / sent)
  if (!avatarInput && /image/.test(mime)) {
    avatarInput = await q.download()
  }

  // Jika avatar masih kosong, ambil foto profil sender dari WhatsApp
  if (!avatarInput) {
    try {
      avatarInput = await conn.profilePictureUrl(m.sender, 'image')
    } catch {
      avatarInput = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_1280.png'
    }
  }

  // Default nama jika tidak diisi
  if (!name) {
    name = m.pushName || m.sender.split('@')[0]
  }

  // Validasi input minimal
  if (!commentText) {
    throw `✨ *Cara Penggunaan:*\n\n` +
      `1. \`${usedPrefix + command} Name | Text | Url Image\`\n` +
      `2. \`${usedPrefix + command} Name | Text\` *(sambil reply foto)*\n` +
      `3. \`${usedPrefix + command} Text\` *(sambil reply foto)*\n\n` +
      `Contoh:\n\`${usedPrefix + command} Saber | Halo coy, ini komentar TikTok! | https://example.com/avatar.png\``
  }

  try {
    if (m.react) await m.react('🎨')

    // Generate gambar komentar
    const imageBuffer = await generateTokComment(name, commentText, avatarInput)

    // Kirim gambar ke chat
    await conn.sendFile(
      m.chat,
      imageBuffer,
      'tokcomment.png',
      `✨ *TikTok Comment Generator*`,
      m
    )
  } catch (e) {
    console.error(e)
    m.reply('✨ Gagal membuat gambar komentar TikTok, coba lagi nanti.')
  }
}

handler.help = ['tokcomment']
handler.tags = ['maker']
handler.command = /^tokcomment$/i
handler.limit = 10
handler.register = true

export default handler