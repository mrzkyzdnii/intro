let handler = async (m, { text }) => {
  if (!text) {
    return m.reply(`Cara penggunaan:

.logo-maker code | text1 | text2
.logo-maker code | text1

> Code hanya ada 1-20000`)
  }

  const code = text.split(" | ")[0]?.trim() || "-"
  const company = text.split(" | ")[1]?.trim() || "-"
  const slogan = text.split(" | ")[2]?.trim() || ""

  if (isNaN(code) || code < 1 || code > 20000) {
    return m.reply("Code harus berupa angka antara 1 dan 20000.")
  }

  const url = `https://www.designmantic.com/create_thumb?id=${encodeURIComponent(code)}&company=${encodeURIComponent(company)}&slogan=${encodeURIComponent(slogan)}`

  await conn.sendMessage(
    m.chat,
    {
      image: { url },
      caption: `Thanks ${m.pushName || "User"} for using my bot (⁠づ⁠｡⁠◕⁠‿⁠◕⁠｡⁠)⁠づ`
    },
    { quoted: m }
  )
}

handler.help = ["logo-maker <code> | <text1> | [text2]"]
handler.tags = ["maker"]
handler.command = /^logo-maker$/i
handler.limit = 10
handler.register = true

export default handler