let handler = async (m, { conn }) => {
    let list = Object.entries(global.db.data.users)

    list.map(([user, data]) => (data.limit = 500))

    conn.reply(m.chat, `*Berhasil direset 500 limit / user*`, m)
}

handler.help = ['limit'].map(v => 'reset' + v)
handler.tags = ['owner']
handler.command = /^(resetlimit)$/i

handler.owner = true
handler.limit = 10

export default handler