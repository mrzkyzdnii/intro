const formatMoney = value => Number(value || 0).toLocaleString('id-ID')
const roll = () => Math.floor(Math.random() * 20) + 1

const getMessageId = message => (
  message?.key?.id ||
  message?.id ||
  message?.stanzaId ||
  null
)

const getQuotedId = quoted => (
  quoted?.key?.id ||
  quoted?.id ||
  quoted?.stanzaId ||
  null
)

const sendMention = (conn, chat, text, mentions, quoted) => {
  return conn.sendMessage(chat, { text, mentions }, { quoted })
}

const finishChallenge = (conn, chat, target, pending) => {
  if (conn.casinoDuel?.[target] === pending) {
    delete conn.casinoDuel[target]
  }
  if (pending.timer) clearTimeout(pending.timer)
}

let handler = async (m, { conn, args, usedPrefix }) => {
  conn.casinoDuel = conn.casinoDuel || {}

  const target = m.mentionedJid?.[0]
  const amount = Number(args?.[0])

  if (!target || !Number.isInteger(amount) || amount < 1) {
    return m.reply(`Cara pakai:\n${usedPrefix}casino 1000 @user\n\nContoh: ${usedPrefix}casino 1000 @628xxxx`)
  }

  if (target === m.sender) {
    return m.reply('Kamu tidak dapat menantang diri sendiri. (￣▽￣)')
  }

  if (conn.casinoDuel[target]) {
    return m.reply('Pengguna tersebut masih memiliki tantangan casino yang belum selesai.')
  }

  const challengerUser = global.db.data.users[m.sender]
  const targetUser = global.db.data.users[target]

  if (!challengerUser || !targetUser) {
    return m.reply('Data salah satu pengguna tidak ditemukan di database.')
  }

  const challengerMoney = Number(challengerUser.money || 0)
  const targetMoney = Number(targetUser.money || 0)

  if (challengerMoney < amount) {
    return m.reply(`Saldo kamu tidak mencukupi. Saldo saat ini: Rp${formatMoney(challengerMoney)}.`)
  }

  if (targetMoney < amount) {
    return sendMention(
      conn,
      m.chat,
      `Saldo @${target.split('@')[0]} tidak mencukupi untuk taruhan Rp${formatMoney(amount)}.`,
      [target],
      m
    )
  }

  const challengeText = `╭─〔 ♠ TANTANGAN CASINO 〕\n│ @${m.sender.split('@')[0]} menantang\n│ @${target.split('@')[0]} bermain casino.\n│\n│ Taruhan : Rp${formatMoney(amount)} / pemain\n│ Sistem   : angka acak 1–20\n│\n│ @${target.split('@')[0]}, apakah kamu setuju?\n│\n│ Balas pesan ini dengan angka:\n│ 1 untuk menerima\n│ 2 untuk menolak\n│\n│ Batas waktu: 20 detik\n╰────────────`

  // Simpan challenge setelah pesan tantangan berhasil dikirim.
  const challengeMessage = await sendMention(
    conn,
    m.chat,
    challengeText,
    [m.sender, target],
    m
  )

  const pending = {
    chat: m.chat,
    challenger: m.sender,
    target,
    amount,
    messageId: getMessageId(challengeMessage),
    createdAt: Date.now(),
    timer: null
  }

  conn.casinoDuel[target] = pending

  // Jika tidak ada balasan dalam 20 detik, challenge dibatalkan.
  pending.timer = setTimeout(async () => {
    if (conn.casinoDuel?.[target] !== pending) return

    delete conn.casinoDuel[target]

    await sendMention(
      conn,
      pending.chat,
      `╭─〔 CASINO EXPIRED 〕\n│ Tantangan dari @${pending.challenger.split('@')[0]} dibatalkan.\n│ @${pending.target.split('@')[0]} tidak merespons dalam 20 detik.\n│\n│ Tidak ada money yang dipotong.\n╰────────────`,
      [pending.challenger, pending.target],
      m
    )
  }, 20000)
}

// Diproses sebelum handler utama, mengikuti pola handler pilihan angka.
handler.before = async (m, { conn }) => {
  conn.casinoDuel = conn.casinoDuel || {}

  const answer = String(m.text || '').trim()
  if (!/^(1|2)$/.test(answer)) return

  // State disimpan berdasarkan JID target, jadi balasan target langsung ditemukan.
  const pending = conn.casinoDuel[m.sender]
  if (!pending) return

  // Wajib reply pesan challenge yang benar.
  if (!m.quoted) return
  if (getQuotedId(m.quoted) !== pending.messageId) return

  finishChallenge(conn, m.chat, m.sender, pending)

  if (answer === '2') {
    return sendMention(
      conn,
      m.chat,
      `╭─〔 CASINO DITOLAK 〕\n│ @${pending.target.split('@')[0]} menolak tantangan.\n│ Taruhan Rp${formatMoney(pending.amount)} tidak jadi diproses.\n╰────────────`,
      [pending.challenger, pending.target],
      m
    )
  }

  const challengerUser = global.db.data.users[pending.challenger]
  const targetUser = global.db.data.users[pending.target]

  if (!challengerUser || !targetUser) {
    return m.reply('Data salah satu pemain tidak ditemukan di database.')
  }

  const challengerMoney = Number(challengerUser.money || 0)
  const targetMoney = Number(targetUser.money || 0)

  // Cek ulang saldo ketika diterima untuk mencegah saldo negatif atau race condition.
  if (challengerMoney < pending.amount) {
    return m.reply(`Tantangan dibatalkan karena saldo penantang tidak lagi mencukupi. Saldo: Rp${formatMoney(challengerMoney)}`)
  }

  if (targetMoney < pending.amount) {
    return sendMention(
      conn,
      m.chat,
      `Tantangan dibatalkan karena saldo @${pending.target.split('@')[0]} tidak lagi mencukupi.`,
      [pending.target],
      m
    )
  }

  challengerUser.money = challengerMoney - pending.amount
  targetUser.money = targetMoney - pending.amount

  const challengerRoll = roll()
  const targetRoll = roll()
  const pot = pending.amount * 2
  let winner = null
  let resultText

  if (challengerRoll > targetRoll) {
    challengerUser.money += pot
    winner = pending.challenger
    resultText = `@${pending.challenger.split('@')[0]} memenangkan pot Rp${formatMoney(pot)}.`
  } else if (targetRoll > challengerRoll) {
    targetUser.money += pot
    winner = pending.target
    resultText = `@${pending.target.split('@')[0]} memenangkan pot Rp${formatMoney(pot)}.`
  } else {
    challengerUser.money += pending.amount
    targetUser.money += pending.amount
    resultText = `Hasil seri. Taruhan dikembalikan Rp${formatMoney(pending.amount)} kepada masing-masing pemain.`
  }

  return sendMention(
    conn,
    m.chat,
    `╭─〔 ✦ HASIL CASINO DUEL 〕\n│ Taruhan : Rp${formatMoney(pending.amount)} / pemain\n│ Total pot: Rp${formatMoney(pot)}\n│\n│ @${pending.challenger.split('@')[0]}  ::  ${challengerRoll}\n│ @${pending.target.split('@')[0]}  ::  ${targetRoll}\n│\n│ Pemenang : ${winner ? `@${winner.split('@')[0]}` : 'SERI'}\n│ ${resultText}\n╰────────────`,
    [pending.challenger, pending.target, ...(winner ? [winner] : [])],
    m
  )
}

handler.help = ['casino']
handler.tags = ['rpg']
handler.command = /^(casino)$/i
handler.register = true
handler.group = true
handler.rpg = true

export default handler