import axios from 'axios'
import fs from 'fs'
import path from 'path'

class SessionManager {
    constructor() {
        this.sessionDir = path.resolve('lib')
        this.sessionFile = path.join(this.sessionDir, 'pizzasession.json')
        this.timeout = 5 * 60 * 1000
        this.maxMessages = 20
        this.startCleanup()
    }

    startCleanup() {
        const interval = setInterval(() => {
            try {
                const sessions = this.load()
                this.cleanExpired(sessions)
            } catch {}
        }, 30 * 1000)

        interval.unref?.()
    }

    load() {
        try {
            if (!fs.existsSync(this.sessionDir)) {
                fs.mkdirSync(this.sessionDir, { recursive: true })
            }

            if (!fs.existsSync(this.sessionFile)) {
                fs.writeFileSync(this.sessionFile, JSON.stringify({}, null, 2))
                return {}
            }

            const data = fs.readFileSync(this.sessionFile, 'utf8')
            if (!data.trim()) return {}

            const parsed = JSON.parse(data)
            return parsed && typeof parsed === 'object' ? parsed : {}
        } catch {
            return {}
        }
    }

    save(sessions) {
        try {
            if (!fs.existsSync(this.sessionDir)) {
                fs.mkdirSync(this.sessionDir, { recursive: true })
            }

            fs.writeFileSync(
                this.sessionFile,
                JSON.stringify(sessions, null, 2),
                'utf8'
            )
        } catch {}
    }

    cleanExpired(sessions) {
        const now = Date.now()
        let changed = false

        for (const userId of Object.keys(sessions)) {
            const session = sessions[userId]
            if (!session || !session.lastUpdate || now - session.lastUpdate >= this.timeout) {
                delete sessions[userId]
                changed = true
            }
        }

        if (changed) this.save(sessions)
    }

    getSession(userId) {
        const sessions = this.load()
        this.cleanExpired(sessions)

        let session = sessions[userId]

        if (!session || typeof session !== 'object' || !Array.isArray(session.messages)) {
            session = {
                messages: [],
                lastUpdate: Date.now()
            }
        }

        if (session.lastUpdate && Date.now() - session.lastUpdate >= this.timeout) {
            session = {
                messages: [],
                lastUpdate: Date.now()
            }
            delete sessions[userId]
        }

        return { sessions, session }
    }

    updateSession(userId, session, sessions) {
        session.lastUpdate = Date.now()
        sessions[userId] = session
        this.save(sessions)
    }

    clearSession(userId) {
        const sessions = this.load()
        if (sessions[userId]) {
            delete sessions[userId]
            this.save(sessions)
            return true
        }
        return false
    }
}

class PizzaGPT {
    constructor() {
        this.baseURL = 'https://pizzagpt.it'
        this.userAgent =
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' +
            'AppleWebKit/537.36 (KHTML, like Gecko) ' +
            'Chrome/124.0.0.0 Safari/537.36'
        
        this.INITIAL_GREETING = {
            text: 'Ciao, come posso aiutarti oggi?',
            sender: 'assistant'
        }
    }

    async getSessionCredentials() {
        const homeRes = await axios.get(`${this.baseURL}/`, {
            headers: {
                'User-Agent': this.userAgent,
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
            },
            timeout: 15000
        })

        const homeCookies = (homeRes.headers['set-cookie'] || [])
            .map(c => c.split(';')[0])
            .join('; ')

        const csrfRes = await axios.get(`${this.baseURL}/api/csrf-token`, {
            headers: {
                'User-Agent': this.userAgent,
                'Accept': 'application/json',
                'Referer': `${this.baseURL}/`,
                ...(homeCookies ? { 'Cookie': homeCookies } : {})
            },
            timeout: 15000
        })

        const token = csrfRes.data?.token
        if (!token) {
            throw new Error('Gagal mendapatkan CSRF Token PizzaGPT.')
        }

        const csrfCookies = (csrfRes.headers['set-cookie'] || [])
            .map(c => c.split(';')[0])
            .join('; ')

        const allCookies = [homeCookies, csrfCookies]
            .filter(Boolean)
            .join('; ')

        return {
            token,
            cookie: allCookies || `csrf-token=${token}`
        }
    }

    buildChatArray(history, currentQuestion) {
        const validHistory = (Array.isArray(history) ? history : [])
            .filter(v => v && typeof v === 'object' && v.text)
            .map(v => ({
                text: String(v.text).trim(),
                sender: v.sender === 'assistant' ? 'assistant' : 'user',
                studyMode: false
            }))
            .slice(-18)

        return [
            this.INITIAL_GREETING,
            ...validHistory,
            {
                text: String(currentQuestion).trim(),
                sender: 'user',
                studyMode: false
            }
        ]
    }

    async chat(query, history = []) {
        const text = String(query || '').trim()
        if (!text) {
            throw new Error('Pertanyaan tidak boleh kosong.')
        }

        const { token, cookie } = await this.getSessionCredentials()
        const chatPayload = this.buildChatArray(history, text)

        const response = await axios.post(
            `${this.baseURL}/api/chat`,
            {
                question: text,
                searchEnabled: false,
                studyMode: false,
                chat: chatPayload
            },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'User-Agent': this.userAgent,
                    'Origin': this.baseURL,
                    'Referer': `${this.baseURL}/`,
                    'X-CSRF-Token': token,
                    'Cookie': cookie
                },
                timeout: 60000
            }
        )

        const result = response.data?.content
        if (!result) {
            throw new Error('Tidak ada respon konten dari PizzaGPT.')
        }

        return String(result).trim()
    }
}

const sessionManager = new SessionManager()
const pizzaGPT = new PizzaGPT()

const handler = async (m, { conn, text, usedPrefix, command }) => {
    const input = (text || '').trim()
    if (!input) {
        throw `*Contoh Penggunaan:*
${usedPrefix + command} Halo, nama gw Jenno

*Untuk reset ingatan/sesi:*
${usedPrefix + command} reset`
    }

    const userId = m.sender

    if (/^(reset|clear|hapus)$/i.test(input)) {
        sessionManager.clearSession(userId)
        return conn.reply(m.chat, '✅ Sesi percakapan berhasil direset.', m)
    }

    const { sessions, session } = sessionManager.getSession(userId)

    try {
        const history = Array.isArray(session.messages) ? session.messages : []
        const result = await pizzaGPT.chat(input, history)

        session.messages.push({
            text: input,
            sender: 'user',
            studyMode: false,
            timestamp: Date.now()
        })

        session.messages.push({
            text: result,
            sender: 'assistant',
            studyMode: false,
            timestamp: Date.now()
        })

        if (session.messages.length > sessionManager.maxMessages) {
            session.messages = session.messages.slice(-sessionManager.maxMessages)
        }

        sessionManager.updateSession(userId, session, sessions)

        await conn.reply(m.chat, result, m)
    } catch (error) {
        console.error('PizzaGPT Error:', error.response?.data || error.message)

        const statusCode = error.response?.status
        let message = error.response?.data?.message || error.message || 'Terjadi kesalahan.'

        if (statusCode === 429) {
            message = 'Terlalu banyak permintaan dalam waktu singkat. Tunggu beberapa detik lalu coba lagi.'
        }

        await conn.reply(m.chat, `❌ Error: ${message}`, m)
    }
}

handler.help = ['pizzagpt <teks>', 'pizza <teks>']
handler.tags = ['ai']
handler.command = /^(pizzagpt|pizza)$/i

export default handler