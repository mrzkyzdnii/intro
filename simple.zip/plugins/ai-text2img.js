import axios from 'axios'

const API_KEYS = [
    'sk-Hic1FPLlsSgYwbV3pMh9wxhUCf6AYrlyCSENUibfy6Gyphlh',
    'sk-5sLsHWn2ohvQNh2FmiN0NpstFCSSylybwUKLrKvDHtSixKuW',
    'sk-RMDctEw9oGJuButr2gwSkES1vvD5sgMZeDpQK3EsfZyEwGO'
]

const API_URL = 'https://apihub.agnes-ai.com/v1/images/generations'

const shuffle = array => {
    const result = [...array]
    for (let i = result.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1))
        ;[result[i], result[j]] = [result[j], result[i]]
    }
    return result
}

const generateImage = async (ratio, prompt) => {
    const keys = shuffle(API_KEYS)
    let lastError

    for (const apiKey of keys) {
        try {
            const { data } = await axios.post(
                API_URL,
                {
                    model: 'agnes-image-2.5-flash',
                    prompt,
                    size: '2K',
                    ratio,
                    extra_body: {
                        response_format: 'url'
                    }
                },
                {
                    headers: {
                        Authorization: `Bearer ${apiKey}`,
                        'Content-Type': 'application/json'
                    },
                    timeout: 120000
                }
            )

            const url = data?.data?.[0]?.url

            if (url) return url

            lastError = new Error('URL gambar tidak ditemukan')
        } catch (e) {
            lastError = e

            const message = e?.response?.data?.error?.message || e?.response?.data?.message || e.message || ''

            if (/invalid token|unauthorized|invalid api key|authentication/i.test(message)) {
                continue
            }

            throw e
        }
    }

    throw lastError || new Error('Semua API key gagal digunakan')
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Contoh:\n${usedPrefix + command} 16:9 | cinematic futuristic city`

    const parts = text.split('|')
    const ratio = parts.shift()?.trim()
    const prompt = parts.join('|').trim()

    const ratios = [
        '1:1',
        '16:9',
        '9:16',
        '4:3',
        '3:4',
        '3:2',
        '2:3',
        '21:9'
    ]

    if (!ratios.includes(ratio)) {
        throw `Ratio tidak valid.\n\nRatio tersedia:\n${ratios.join(', ')}\n\nContoh:\n${usedPrefix + command} 16:9 | cinematic futuristic city`
    }

    if (!prompt) {
        throw `Prompt tidak boleh kosong.\n\nContoh:\n${usedPrefix + command} 16:9 | cinematic futuristic city`
    }

    await m.react('⏳')

    try {
        const url = await generateImage(ratio, prompt)

        await conn.sendFile(
            m.chat,
            url,
            `text2img-${ratio.replace(':', 'x')}.png`,
            `🎨 *Text to Image*\n\nRatio: ${ratio}\nPrompt: ${prompt}`,
            m
        )

        await m.react('✅')
    } catch (e) {
        await m.react('❌')

        const error = e?.response?.data?.error?.message ||
            e?.response?.data?.message ||
            e.message ||
            'Unknown error'

        throw `Gagal membuat gambar:\n${error}`
    }
}

handler.help = ['text2img']
handler.tags = ['ai']
handler.command = /^text2img$/i

export default handler