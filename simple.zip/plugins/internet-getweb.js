import axios from 'axios'
import * as cheerio from 'cheerio'
import archiver from 'archiver'
import { URL } from 'url'
import path from 'path'
import { PassThrough } from 'stream'

const MAX_FILES = 200
const MAX_TOTAL = 50 * 1024 * 1024
const MAX_FILE = 5 * 1024 * 1024
const CONCURRENCY = 8
const TIMEOUT = 15000

const BROWSER_HEADERS = {
  'User-Agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
    '(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
  'Accept': '*/*',
  'Accept-Language': 'en-US,en;q=0.9',
  'sec-ch-ua': '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"',
}

// ---- URL helpers ----

function normalizeUrl(input) {
  let u = input.trim()
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u
  try {
    const parsed = new URL(u)
    // strip common tracking params
    const dropParams = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid', 'ref', 'ref_src']
    dropParams.forEach((p) => parsed.searchParams.delete(p))
    return parsed
  } catch {
    return null
  }
}

function sameOrigin(a, b) {
  try {
    return new URL(a).origin === new URL(b).origin
  } catch {
    return false
  }
}

function urlToRelPath(absUrl, baseUrl) {
  try {
    const u = new URL(absUrl)
    const base = new URL(baseUrl)
    if (u.origin !== base.origin) {
      // external — group under _external/<host>/<path>
      return path.posix.join('_external', u.host, u.pathname.replace(/^\/+/, '')) + (u.search || '')
    }
    // same origin: mirror path
    let p = u.pathname.replace(/^\/+/, '')
    if (!p || p.endsWith('/')) p = (p || 'index') + '.html'
    return p + (u.search || '') + (u.hash || '')
  } catch {
    return null
  }
}

// ---- Proxy fetch chain ----

async function fetchThrough(target, as = 'document') {
  const headers = { ...BROWSER_HEADERS }
  if (as === 'document') {
    headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    headers['sec-fetch-dest'] = 'document'
    headers['sec-fetch-mode'] = 'navigate'
    headers['sec-fetch-site'] = 'none'
  } else {
    headers['sec-fetch-dest'] = 'empty'
    headers['sec-fetch-mode'] = 'cors'
    headers['sec-fetch-site'] = 'same-origin'
  }

  const attempts = [
    // 1. direct
    async () => {
      const r = await axios.get(target, {
        timeout: TIMEOUT,
        headers,
        responseType: as === 'document' ? 'text' : 'arraybuffer',
        maxRedirects: 5,
        validateStatus: (s) => s >= 200 && s < 400,
      })
      const body = r.data
      // detect Cloudflare challenge
      if (typeof body === 'string' && body.includes('Just a moment...')) {
        throw new Error('Cloudflare challenge')
      }
      return { data: body, contentType: r.headers['content-type'] || '', finalUrl: r.request?.res?.responseUrl || target }
    },
    // 2. cors.sh (for non-blocked hosts)
    async () => {
      const r = await axios.get('https://proxy.cors.sh/' + target, {
        timeout: TIMEOUT,
        headers: { ...headers, 'x-cors-api-key': process.env.CORS_SH_KEY || '' },
        responseType: as === 'document' ? 'text' : 'arraybuffer',
      })
      const body = r.data
      if (typeof body === 'string' && body.includes('Just a moment...')) {
        throw new Error('CF via cors.sh')
      }
      return { data: body, contentType: r.headers['content-type'] || '', finalUrl: target }
    },
    // 3. wayback (works for documents and assets; for assets use if_ raw prefix)
    async () => {
      const api = 'https://archive.org/wayback/available?url=' + encodeURIComponent(target)
      const a = await axios.get(api, { timeout: 8000 })
      const snap = a.data?.archived_snapshots?.closest?.url
      if (!snap) throw new Error('no wayback snapshot')
      // for assets, swap /web/TIMESTAMP/ to /web/TIMESTAMPif_/ for raw bytes
      let fetchUrl = snap
      if (as === 'asset') {
        fetchUrl = snap.replace('/web/', '/web/').replace(/(\d{14})(im_|\/)/, '$1if_/')
      }
      const r = await axios.get(fetchUrl, {
        timeout: TIMEOUT,
        headers,
        responseType: as === 'document' ? 'text' : 'arraybuffer',
      })
      return { data: r.data, contentType: r.headers['content-type'] || '', finalUrl: target, wayback: true }
    },
  ]

  let lastErr
  for (const fn of attempts) {
    try {
      return await fn()
    } catch (e) {
      lastErr = e
    }
  }
  throw lastErr || new Error('All proxies failed')
}

// ---- HTML asset extraction ----

function extractAssets($, pageUrl) {
  const urls = new Set()

  const resolve = (u) => {
    if (!u) return null
    u = u.trim()
    if (u.startsWith('data:') || u.startsWith('blob:') || u.startsWith('javascript:') || u.startsWith('mailto:') || u.startsWith('#')) {
      return null
    }
    // strip wayback prefix and return the embedded real URL
    // patterns: https://web.archive.org/web/TIMESTAMP/https://real.com/path
    //           https://web.archive.org/web/TIMESTAMPim_/https://real.com/path
    //           /web/TIMESTAMPim_/https://real.com/path
    const wbMatch = u.match(/^(?:https?:\/\/[^/]+)?\/web\/\d+(?:im_|if_|cs_)?\/(.+)$/)
    if (wbMatch) {
      u = wbMatch[1]
      if (!/^https?:\/\//.test(u)) {
        // relative path within wayback — assume same origin as pageUrl
        try { u = new URL(u, pageUrl).href } catch { return null }
      }
    }
    try {
      return new URL(u, pageUrl).href
    } catch {
      return null
    }
  }

  // <img src> + srcset
  $('img').each((_, el) => {
    const src = $(el).attr('src')
    if (src) {
      const r = resolve(src)
      if (r) urls.add(r)
    }
    const srcset = $(el).attr('srcset')
    if (srcset) {
      srcset.split(',').forEach((part) => {
        const u = part.trim().split(/\s+/)[0]
        const r = resolve(u)
        if (r) urls.add(r)
      })
    }
  })

  // <script src>
  $('script[src]').each((_, el) => {
    const r = resolve($(el).attr('src'))
    if (r) urls.add(r)
  })

  // <link href> (stylesheet, icon, manifest, etc)
  $('link[href]').each((_, el) => {
    const r = resolve($(el).attr('href'))
    if (r) urls.add(r)
  })

  // <source src> in <video>/<audio>/<picture>
  $('source[src]').each((_, el) => {
    const r = resolve($(el).attr('src'))
    if (r) urls.add(r)
  })

  // <video>/<audio> poster + src
  $('video, audio').each((_, el) => {
    const s = $(el).attr('src')
    const p = $(el).attr('poster')
    if (s) { const r = resolve(s); if (r) urls.add(r) }
    if (p) { const r = resolve(p); if (r) urls.add(r) }
  })

  // inline style background-image: url(...)
  $('[style]').each((_, el) => {
    const style = $(el).attr('style') || ''
    const re = /url\((['"]?)([^'")]+)\1\)/g
    let m
    while ((m = re.exec(style))) {
      const r = resolve(m[2])
      if (r) urls.add(r)
    }
  })

  // <style> blocks: @import + url(...)
  $('style').each((_, el) => {
    const css = $(el).html() || ''
    const reImport = /@import\s+(?:url\()?['"]?([^'")]+)['"]?\)?/g
    let m
    while ((m = reImport.exec(css))) {
      const r = resolve(m[1])
      if (r) urls.add(r)
    }
    const reUrl = /url\((['"]?)([^'")]+)\1\)/g
    while ((m = reUrl.exec(css))) {
      const r = resolve(m[2])
      if (r) urls.add(r)
    }
  })

  // filter: keep only http(s) and within reasonable length
  return [...urls].filter((u) => /^https?:\/\//i.test(u) && u.length < 2048)
}

// ---- Asset download with concurrency cap ----

async function pMap(items, mapper, concurrency) {
  const results = new Array(items.length)
  let i = 0
  const workers = Array.from({ length: concurrency }, async () => {
    while (true) {
      const idx = i++
      if (idx >= items.length) return
      try {
        results[idx] = await mapper(items[idx], idx)
      } catch (e) {
        results[idx] = { error: e }
      }
    }
  })
  await Promise.all(workers)
  return results
}

// ---- Main: get a website as a zip buffer ----

async function getWebAsZip(inputUrl) {
  const pageUrl = normalizeUrl(inputUrl)
  if (!pageUrl) throw 'URL tidak valid. Contoh: .getweb https://example.com'

  // 1. fetch document
  const doc = await fetchThrough(pageUrl.href, 'document')
  const html = doc.data
  if (typeof html !== 'string' || html.length < 50) {
    throw 'Response kosong atau bukan HTML'
  }

  const $ = cheerio.load(html)
  const finalUrl = doc.finalUrl || pageUrl.href

  // 2. extract asset URLs
  const assetUrls = extractAssets($, finalUrl)
  // only download same-origin (external assets often blocked, slow, big)
  const sameOriginUrls = assetUrls.filter((u) => sameOrigin(u, finalUrl))

  // 3. dedupe + cap
  const todo = sameOriginUrls.slice(0, MAX_FILES)

  // 4. parallel download
  const downloaded = await pMap(todo, async (url) => {
    try {
      const r = await fetchThrough(url, 'asset')
      const buf = Buffer.isBuffer(r.data) ? r.data : Buffer.from(r.data)
      if (buf.length > MAX_FILE) {
        return { url, skipped: 'too_big', size: buf.length }
      }
      return { url, buf, contentType: r.contentType, size: buf.length }
    } catch (e) {
      return { url, error: e.message }
    }
  }, CONCURRENCY)

  // 5. build manifest and rewrite HTML
  const urlToPath = new Map()
  let totalSize = 0
  const skipped = []
  const failed = []

  for (const item of downloaded) {
    if (item?.skipped === 'too_big') {
      skipped.push(item.url)
      continue
    }
    if (item?.error) {
      failed.push({ url: item.url, err: item.error })
      continue
    }
    if (!item?.buf) continue
    const relPath = urlToRelPath(item.url, finalUrl)
    if (!relPath) continue
    if (totalSize + item.size > MAX_TOTAL) {
      skipped.push(item.url)
      continue
    }
    urlToPath.set(item.url, relPath)
    totalSize += item.size
  }

  // rewrite HTML so local asset paths are reachable
  const rewriteAttr = (val) => {
    if (!val) return val
    const abs = (() => {
      try { return new URL(val, finalUrl).href } catch { return null }
    })()
    if (abs && urlToPath.has(abs)) return urlToPath.get(abs)
    return val
  }
  $('img').each((_, el) => {
    const s = $(el).attr('src')
    if (s) $(el).attr('src', rewriteAttr(s))
    const ss = $(el).attr('srcset')
    if (ss) {
      $(el).attr('srcset', ss.split(',').map((p) => {
        const [u, ...rest] = p.trim().split(/\s+/)
        return rewriteAttr(u) + (rest.length ? ' ' + rest.join(' ') : '')
      }).join(', '))
    }
  })
  $('script[src]').each((_, el) => {
    const s = $(el).attr('src')
    if (s) $(el).attr('src', rewriteAttr(s))
  })
  $('link[href]').each((_, el) => {
    const s = $(el).attr('href')
    if (s) $(el).attr('href', rewriteAttr(s))
  })
  $('source[src]').each((_, el) => {
    const s = $(el).attr('src')
    if (s) $(el).attr('src', rewriteAttr(s))
  })
  $('[style]').each((_, el) => {
    const st = $(el).attr('style') || ''
    $(el).attr('style', st.replace(/url\((['"]?)([^'")]+)\1\)/g, (m, q, u) => {
      return 'url(' + q + rewriteAttr(u) + q + ')'
    }))
  })
  $('style').each((_, el) => {
    const css = $(el).html() || ''
    const out = css
      .replace(/@import\s+(?:url\()?['"]?([^'")]+)['"]?\)?/g, (m, u) => '@import "' + rewriteAttr(u) + '"')
      .replace(/url\((['"]?)([^'")]+)\1\)/g, (m, q, u) => 'url(' + q + rewriteAttr(u) + q + ')')
    $(el).text(out)
  })

  // add a small banner so user knows this is a clone
  const banner = `\n<!-- Cloned by .getweb from ${finalUrl} on ${new Date().toISOString()} -->\n`
  const outHtml = banner + $.html()

  // 6. stream into zip
  const archive = archiver('zip', { zlib: { level: 6 } })
  const passthrough = new PassThrough()
  const chunks = []
  passthrough.on('data', (c) => chunks.push(c))
  const done = new Promise((resolve, reject) => {
    passthrough.on('end', resolve)
    passthrough.on('error', reject)
    archive.on('error', reject)
  })
  archive.pipe(passthrough)

  // index.html at root
  archive.append(outHtml, { name: 'index.html' })

  // manifest
  const manifest = {
    source: finalUrl,
    clonedAt: new Date().toISOString(),
    totalAssets: urlToPath.size,
    totalBytes: totalSize,
    htmlBytes: Buffer.byteLength(outHtml, 'utf8'),
    skipped: skipped.slice(0, 50),
    failed: failed.slice(0, 50),
    notes: skipped.length || failed.length
      ? 'Some assets could not be downloaded. Open the page locally with internet; relative paths still work for downloaded ones.'
      : 'All assets downloaded successfully.',
  }
  archive.append(JSON.stringify(manifest, null, 2), { name: '_manifest.json' })

  // assets
  for (const [url, relPath] of urlToPath) {
    const item = downloaded.find((d) => d && d.url === url)
    if (item?.buf) archive.append(item.buf, { name: relPath })
  }

  await archive.finalize()
  await done

  const zipBuf = Buffer.concat(chunks)
  return {
    buffer: zipBuf,
    size: zipBuf.length,
    manifest,
    domain: pageUrl.hostname,
  }
}

// ---- Handler ----

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} https://example.com`

  await m.reply('🕷️ *Cloning website...*\n_Sedang mengunduh HTML + assets, mohon tunggu._')

  try {
    const result = await getWebAsZip(text)

    const cap = `✅ *Website berhasil di-clone*\n\n` +
      `🌐 Source: ${result.manifest.source}\n` +
      `📦 Files: ${result.manifest.totalAssets} asset(s) + index.html\n` +
      `💾 Size: ${(result.size / 1024).toFixed(1)} KB\n` +
      `🗓️ Cloned: ${result.manifest.clonedAt}\n` +
      `📋 Detail lengkap: lihat _manifest.json di dalam zip`

    const filename = `${result.domain.replace(/[^a-z0-9.-]/gi, '_')}.zip`
    await conn.sendFile(m.chat, result.buffer, filename, cap, m)
  } catch (e) {
    const msg = typeof e === 'string' ? e : (e?.message || 'Unknown error')
    await m.reply(
      `❌ Gagal clone website.\n\n*Alasan:* ${msg}\n\n` +
        `_Tips:_\n` +
        `• Pastikan URL bisa dibuka di browser\n` +
        `• Coba URL yang lebih statis (blog, docs, landing page)\n` +
        `• Hindari situs yang full Cloudflare-protected (SPA, login page)\n` +
        `• Maks 200 asset / 50 MB per clone`,
    )
  }
}

handler.help = ['getweb']
handler.tags = ['internet']
handler.command = /^(getweb|cloneweb|webclone)$/i
handler.limit = 10

export default handler