const handler = async (m, { conn, command }) => {
conn.relayMessage(
m.chat,
{
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
botMetadata: {
messageDisclaimerText: "",
botResponseId: "connect4-fixed",
verificationMetadata: {
proofs: [
{
version: 1,
useCase: 1,
signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
certificateChain: ["TklYRUwuTWVzc2FnZUJ1bGRlc..."]
}
]
}
}
},
botForwardedMessage: {
message: {
richResponseMessage: {
messageType: 1,
submessages: [
{
messageType: 2,
messageText: "🎯 CONNECT FOUR (FIXED)"
}
],
unifiedResponse: {
data: Buffer.from(JSON.stringify({
"response_id": "connect4-fixed",
"sections": [
{
"view_model": {
"primitive": {
"__typename": "GenAIaeacdsnwHtmlPrimitive",
"payload": `<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;user-select:none}
body{margin:0;background:transparent;font-family:'Segoe UI',Arial,sans-serif;color:#eee;touch-action:manipulation}
.wrap{width:100%;max-width:560px;margin:auto;padding:12px}
.card{background:linear-gradient(145deg,rgba(255,255,255,.08),rgba(255,255,255,.03));border:1px solid rgba(255,255,255,.12);border-radius:24px;padding:18px;backdrop-filter:blur(16px);box-shadow:0 16px 48px rgba(0,0,0,.5)}
.header{text-align:center;margin-bottom:12px}
.header h1{font-size:26px;font-weight:800;margin:0;background:linear-gradient(135deg,#f7971e,#ffd200);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.header p{font-size:12px;color:#999;margin:2px 0 0}
.status{text-align:center;font-size:17px;font-weight:700;padding:10px;border-radius:12px;background:rgba(255,255,255,.06);margin-bottom:12px;border:1px solid rgba(255,255,255,.08)}
.board-wrap{display:flex;justify-content:center;margin:8px 0}
.board{display:grid;grid-template-columns:repeat(7,1fr);gap:6px;max-width:420px;width:100%;aspect-ratio:7/6;background:linear-gradient(180deg,#1a1a2e,#16213e);border-radius:16px;padding:10px;border:2px solid rgba(255,255,255,.1)}
.cell{aspect-ratio:1;background:rgba(255,255,255,.05);border-radius:50%;border:2px solid rgba(255,255,255,.08);cursor:pointer;transition:all .2s;position:relative;display:flex;align-items:center;justify-content:center}
.cell:active{transform:scale(.92)}
.cell.has-piece{transform:scale(.95)}
.cell .piece{width:85%;height:85%;border-radius:50%;box-shadow:inset -3px -3px 8px rgba(0,0,0,.5),inset 3px 3px 8px rgba(255,255,255,.2);transition:all .3s cubic-bezier(.34,1.56,.64,1)}
.cell .piece.red{background:radial-gradient(circle at 35% 35%,#ff6b6b,#c0392b);box-shadow:0 4px 20px rgba(255,107,107,.3)}
.cell .piece.yellow{background:radial-gradient(circle at 35% 35%,#ffd93d,#f39c12);box-shadow:0 4px 20px rgba(255,217,61,.3)}
.cell.win .piece{animation:winPulse .5s ease infinite alternate;border:3px solid #2ed573}
@keyframes winPulse{0%{transform:scale(.9)}100%{transform:scale(1.1)}}
.cell.hover{background:rgba(255,255,255,.12)}
.controls{display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-top:12px}
.btn{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);border-radius:12px;padding:10px;color:#fff;font-size:13px;font-weight:600;cursor:pointer;transition:all .2s}
.btn:active{transform:scale(.95)}
.btn.reset{background:linear-gradient(135deg,#667eea,#764ba2)}
.btn.auto{background:linear-gradient(135deg,#f093fb,#f5576c)}
.btn.difficulty{background:linear-gradient(135deg,#4facfe,#00f2fe)}
.levels{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:8px 0}
.level-btn{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);border-radius:10px;padding:8px 4px;color:#aaa;font-size:11px;font-weight:600;cursor:pointer;transition:all .2s;text-align:center}
.level-btn:active{transform:scale(.95)}
.level-btn.active{background:linear-gradient(135deg,#f7971e,#ffd200);color:#000;border-color:#ffd200}
.level-btn .icon{font-size:20px;display:block}
.score{display:flex;justify-content:space-around;padding:10px;background:rgba(255,255,255,.05);border-radius:12px;margin:8px 0;font-size:13px;font-weight:600}
.score span{display:flex;align-items:center;gap:5px}
.score .red-score{color:#ff6b6b}
.score .yellow-score{color:#ffd93d}
.score .draw-score{color:#a29bfe}
.footer{text-align:center;color:#666;font-size:11px;margin-top:10px}
</style>

<body>
<div class="wrap">
<div class="card">

<div class="header">
<h1>🎯 CONNECT FOUR</h1>
<p>Susun 4 biji berurutan!</p>
</div>

<div class="score">
<span class="red-score">🔴 <span id="redScore">0</span></span>
<span class="draw-score">⚖️ <span id="drawScore">0</span></span>
<span class="yellow-score">🟡 <span id="yellowScore">0</span></span>
</div>

<div id="status" class="status">🔴 Giliran kamu!</div>

<div class="levels">
<div class="level-btn active" data-level="easy">😊<br>Mudah</div>
<div class="level-btn" data-level="hard">😈<br>Sulit</div>
<div class="level-btn" data-level="impossible">🤖<br>Impossible</div>
</div>

<div class="board-wrap">
<div class="board" id="board"></div>
</div>

<div class="controls">
<button class="btn reset" id="reset">🔄 Reset</button>
<button class="btn auto" id="autoPlay">🤖 Auto Play</button>
<button class="btn difficulty" id="suggest">💡 Hint</button>
</div>

<div class="footer">Kamu 🔴 • Bot 🟡 • Tap kolom untuk main</div>

</div>
</div>

<script>
const ROWS = 6;
const COLS = 7;
let board = [];
let currentPlayer = 'red';
let gameActive = true;
let level = 'easy';
let scores = { red: 0, yellow: 0, draw: 0 };
let isBotThinking = false;
let botTimeout = null;
let autoPlayInterval = null;

const boardEl = document.getElementById('board');
const statusEl = document.getElementById('status');
const resetBtn = document.getElementById('reset');
const autoBtn = document.getElementById('autoPlay');
const suggestBtn = document.getElementById('suggest');
const levelBtns = document.querySelectorAll('.level-btn');
const redScoreEl = document.getElementById('redScore');
const yellowScoreEl = document.getElementById('yellowScore');
const drawScoreEl = document.getElementById('drawScore');

const levelConfig = {
easy: { label: 'Mudah', depth: 2, randomChance: 0.4 },
hard: { label: 'Sulit', depth: 4, randomChance: 0.05 },
impossible: { label: 'Impossible', depth: 6, randomChance: 0 }
};

function initBoard() {
board = Array.from({length: ROWS}, () => Array(COLS).fill(null));
currentPlayer = 'red';
gameActive = true;
isBotThinking = false;
if (botTimeout) {
clearTimeout(botTimeout);
botTimeout = null;
}
renderBoard();
updateStatus();
}

function renderBoard() {
boardEl.innerHTML = '';
for (let r = 0; r < ROWS; r++) {
for (let c = 0; c < COLS; c++) {
const cell = document.createElement('div');
cell.className = 'cell';
cell.dataset.row = r;
cell.dataset.col = c;
if (board[r][c]) {
cell.classList.add('has-piece');
const piece = document.createElement('div');
piece.className = \`piece \${board[r][c]}\`;
cell.appendChild(piece);
}
cell.addEventListener('click', () => handleCellClick(c));
boardEl.appendChild(cell);
}
}
}

function updateStatus() {
if (!gameActive) return;
if (currentPlayer === 'red') {
statusEl.textContent = '🔴 Giliran kamu!';
} else {
statusEl.textContent = '🟡 Bot berpikir...';
}
}

function getValidColumns() {
return board[0].map((v, i) => v === null ? i : null).filter(v => v !== null);
}

function getNextRow(col) {
for (let r = ROWS - 1; r >= 0; r--) {
if (board[r][col] === null) return r;
}
return -1;
}

function checkWinner(boardState, row, col, player) {
if (row === undefined) {
for (let r = 0; r < ROWS; r++) {
for (let c = 0; c < COLS; c++) {
if (boardState[r][c]) {
const result = checkWinner(boardState, r, c, boardState[r][c]);
if (result) return result;
}
}
}
return null;
}

const directions = [[0,1],[1,0],[1,1],[1,-1]];
for (let [dr, dc] of directions) {
let count = 1;
let cells = [{r: row, c: col}];
for (let dir of [1, -1]) {
for (let step = 1; step < 4; step++) {
const nr = row + dr * step * dir;
const nc = col + dc * step * dir;
if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS || boardState[nr][nc] !== player) break;
count++;
cells.push({r: nr, c: nc});
}
}
if (count >= 4) return { player, cells };
}
return null;
}

function isBoardFull() {
return board.every(row => row.every(cell => cell !== null));
}

// ===== MAIN GAME FUNCTION =====
function makeMove(col, player) {
if (!gameActive) return false;
if (isBotThinking) return false;
if (board[0][col] !== null) return false;

const row = getNextRow(col);
board[row][col] = player;

const win = checkWinner(board, row, col, player);
if (win) {
gameActive = false;
scores[player]++;
updateScoreUI();
statusEl.textContent = \`\${player === 'red' ? '🎉 Kamu' : '😵 Bot'} Menang!\`;
win.cells.forEach(({r, c}) => {
const idx = r * COLS + c;
boardEl.children[idx].classList.add('win');
});
renderBoard();
return true;
}

if (isBoardFull()) {
gameActive = false;
scores.draw++;
updateScoreUI();
statusEl.textContent = '🤝 Seri!';
renderBoard();
return true;
}

// Switch player
currentPlayer = (currentPlayer === 'red' ? 'yellow' : 'red');
renderBoard();
updateStatus();

// Trigger bot if needed
if (gameActive && currentPlayer === 'yellow') {
triggerBot();
}

return true;
}

// ===== BOT TRIGGER =====
function triggerBot() {
if (!gameActive) return;
if (currentPlayer !== 'yellow') return;
if (isBotThinking) return;

isBotThinking = true;
statusEl.textContent = '🟡 Bot berpikir...';

if (botTimeout) clearTimeout(botTimeout);

const delay = level === 'easy' ? 600 : level === 'hard' ? 400 : 300;
botTimeout = setTimeout(() => {
if (!gameActive || currentPlayer !== 'yellow') {
isBotThinking = false;
return;
}
doBotMove();
}, delay);
}

// ===== BOT MOVE =====
function doBotMove() {
if (!gameActive || currentPlayer !== 'yellow') {
isBotThinking = false;
return;
}

const validCols = getValidColumns();
if (validCols.length === 0) {
isBotThinking = false;
return;
}

const config = levelConfig[level];
let bestCol = validCols[0];
let bestScore = -Infinity;

// Random move for easy
if (level === 'easy' && Math.random() < config.randomChance) {
bestCol = validCols[Math.floor(Math.random() * validCols.length)];
} else {
const boardCopy = board.map(row => [...row]);
for (let col of validCols) {
const row = getNextRowState(boardCopy, col);
boardCopy[row][col] = 'yellow';
const score = minimax(boardCopy, config.depth - 1, false, -Infinity, Infinity);
boardCopy[row][col] = null;
if (score > bestScore) {
bestScore = score;
bestCol = col;
}
}

// Random chance for hard
if (level === 'hard' && Math.random() < config.randomChance) {
bestCol = validCols[Math.floor(Math.random() * validCols.length)];
}
}

isBotThinking = false;
if (botTimeout) {
clearTimeout(botTimeout);
botTimeout = null;
}
makeMove(bestCol, 'yellow');
}

// ===== AI HELPER FUNCTIONS =====
function getValidColumnsState(boardState) {
return boardState[0].map((v, i) => v === null ? i : null).filter(v => v !== null);
}

function getNextRowState(boardState, col) {
for (let r = ROWS - 1; r >= 0; r--) {
if (boardState[r][col] === null) return r;
}
return -1;
}

function isBoardFullState(boardState) {
return boardState.every(row => row.every(cell => cell !== null));
}

function evaluateBoard(boardState, player) {
let score = 0;
const opponent = player === 'red' ? 'yellow' : 'red';

for (let r = 0; r < ROWS; r++) {
for (let c = 0; c < COLS; c++) {
const directions = [[0,1],[1,0],[1,1],[1,-1]];
for (let [dr, dc] of directions) {
let count = 0, empty = 0, oppCount = 0;
for (let step = 0; step < 4; step++) {
const nr = r + dr * step;
const nc = c + dc * step;
if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) break;
if (boardState[nr][nc] === player) count++;
else if (boardState[nr][nc] === null) empty++;
else oppCount++;
}
if (count + empty === 4) {
if (count === 4) score += 1000;
else if (count === 3 && empty === 1) score += 100;
else if (count === 2 && empty === 2) score += 10;
}
if (oppCount + empty === 4 && oppCount >= 3) {
score -= 80;
}
}
}
}
return score;
}

function minimax(boardState, depth, isMaximizing, alpha, beta) {
const player = isMaximizing ? 'yellow' : 'red';

for (let r = 0; r < ROWS; r++) {
for (let c = 0; c < COLS; c++) {
if (boardState[r][c]) {
const win = checkWinner(boardState, r, c, boardState[r][c]);
if (win) {
if (win.player === 'yellow') return 10000 - depth;
if (win.player === 'red') return -10000 + depth;
}
}
}
}

if (depth === 0 || isBoardFullState(boardState)) {
return evaluateBoard(boardState, 'yellow') - evaluateBoard(boardState, 'red');
}

const validCols = getValidColumnsState(boardState);
if (isMaximizing) {
let maxEval = -Infinity;
for (let col of validCols) {
const row = getNextRowState(boardState, col);
boardState[row][col] = 'yellow';
const eval = minimax(boardState, depth - 1, false, alpha, beta);
boardState[row][col] = null;
maxEval = Math.max(maxEval, eval);
alpha = Math.max(alpha, eval);
if (beta <= alpha) break;
}
return maxEval;
} else {
let minEval = Infinity;
for (let col of validCols) {
const row = getNextRowState(boardState, col);
boardState[row][col] = 'red';
const eval = minimax(boardState, depth - 1, true, alpha, beta);
boardState[row][col] = null;
minEval = Math.min(minEval, eval);
beta = Math.min(beta, eval);
if (beta <= alpha) break;
}
return minEval;
}
}

// ===== HANDLE CLICK =====
function handleCellClick(col) {
if (!gameActive) return;
if (currentPlayer !== 'red') return;
if (isBotThinking) {
statusEl.textContent = '⏳ Tunggu bot selesai...';
return;
}
makeMove(col, 'red');
}

// ===== SUGGEST =====
function suggestMove() {
if (!gameActive || isBotThinking || currentPlayer !== 'red') return;

const validCols = getValidColumns();
if (validCols.length === 0) return;

let bestCol = validCols[0];
let bestScore = -Infinity;
const boardCopy = board.map(row => [...row]);

for (let col of validCols) {
const row = getNextRowState(boardCopy, col);
boardCopy[row][col] = 'red';
const score = minimax(boardCopy, 4, true, -Infinity, Infinity);
boardCopy[row][col] = null;
if (score > bestScore) {
bestScore = score;
bestCol = col;
}
}

const cells = boardEl.children;
for (let r = 0; r < ROWS; r++) {
const idx = r * COLS + bestCol;
if (cells[idx] && !board[r][bestCol]) {
cells[idx].style.background = 'rgba(46,213,115,.3)';
cells[idx].style.borderColor = '#2ed573';
setTimeout(() => {
cells[idx].style.background = '';
cells[idx].style.borderColor = '';
}, 2000);
}
}
statusEl.textContent = \`💡 Coba kolom \${bestCol + 1}\`;
}

// ===== UI =====
function updateScoreUI() {
redScoreEl.textContent = scores.red;
yellowScoreEl.textContent = scores.yellow;
drawScoreEl.textContent = scores.draw;
}

function updateLevelUI() {
levelBtns.forEach(btn => {
btn.classList.toggle('active', btn.dataset.level === level);
});
}

function resetGame() {
if (botTimeout) {
clearTimeout(botTimeout);
botTimeout = null;
}
if (autoPlayInterval) {
clearInterval(autoPlayInterval);
autoPlayInterval = null;
autoBtn.textContent = '🤖 Auto Play';
}
isBotThinking = false;
initBoard();
updateScoreUI();
}

function startAutoPlay() {
if (autoPlayInterval) {
clearInterval(autoPlayInterval);
autoPlayInterval = null;
autoBtn.textContent = '🤖 Auto Play';
return;
}

if (!gameActive) resetGame();
autoBtn.textContent = '⏹ Stop';

autoPlayInterval = setInterval(() => {
if (!gameActive || isBotThinking) return;
const validCols = getValidColumns();
if (validCols.length === 0) return;
const randomCol = validCols[Math.floor(Math.random() * validCols.length)];
if (currentPlayer === 'red') {
makeMove(randomCol, 'red');
} else {
// Trigger bot if it's bot's turn
if (!isBotThinking) {
triggerBot();
}
}
}, 500);
}

// ===== EVENTS =====
resetBtn.addEventListener('click', resetGame);
autoBtn.addEventListener('click', startAutoPlay);
suggestBtn.addEventListener('click', suggestMove);

levelBtns.forEach(btn => {
btn.addEventListener('click', () => {
level = btn.dataset.level;
updateLevelUI();
resetGame();
statusEl.textContent = \`🔴 Giliran kamu! (Level: \${levelConfig[level].label})\`;
});
});

// ===== INIT =====
initBoard();
updateScoreUI();
updateLevelUI();
</script>
</body>`,
"trusted_sources": ["adam.dev"]
},
"__typename": "GenAISingleLayoutViewModel"
}
}
]
})).toString('base64')
},
contextInfo: {
forwardingScore: 1,
isForwarded: true,
forwardedAiBotMessageInfo: {
botJid: "867051314767696@bot"
},
forwardOrigin: 4
}
}
}
}
},
{}
)
}

handler.help = ['c4']
handler.tags = ['game']
handler.command = /^(c4)$/i

export default handler