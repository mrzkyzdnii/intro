import { createCanvas } from '@napi-rs/canvas'

// ============================================================
// TEMPLATE DATA — 5 SERTIFIKAT
// ============================================================
const TEMPLATES = {
  sertifikatlemot: {
    title: 'SERTIFIKAT KELEMBAMAN INTERNASIONAL',
    subtitle: '~ Worldwide Sloth Response Authority ~',
    award: '[*]',
    intro: 'Dengan penuh kebanggaan, sertifikat ini dianugerahkan kepada:',
    bodyTitle: 'Sebagai pengakuan resmi atas jasanya dalam:',
    issuer: 'Komite Anti Slow Respon Dunia',
    sealText: ['OFFICIAL', 'LEMOT', '2026'],
    palette: {
      gold: '#c9a45c', darkGold: '#8a6d2c', cream: '#fdf6e3',
      paper: '#fbf3df', ink: '#3a2e1f', seal: '#8b1a1a',
      quote: '#8b1a1a', ribbonInk: '#3a2e1f'
    },
    reasons: [
      'membalas chat 2 hari sekali',
      'loading mulu padahal sinyal 5G',
      'buka WA kayak nunggu sinetron tayang ulang',
      'suka bales "iya" 3 minggu kemudian',
      'kecepatan responnya ngalahin kura-kura pensiun'
    ],
    caption: (nama, alasan) =>
      'Sertifikat Kelembaman Internasional\n\nUntuk: ' + nama + '\nAlasan: ' + alasan + '\n\nDengan resmi diakui sebagai salah satu responden paling legendis.',
    prefix: 'LMT'
  },

  sertifikatbucin: {
    title: 'SERTIFIKAT KEBUCINAN NASIONAL',
    subtitle: '~ Indonesian Romantic Disorder Center ~',
    award: '[<3]',
    intro: 'Dengan penuh haru biru, sertifikat ini dianugerahkan kepada:',
    bodyTitle: 'Atas diagnosa klinis sebagai:',
    issuer: 'Komite Pemerhati Jomblo Akut',
    sealText: ['CERTIFIED', 'BUCIN', '2026'],
    palette: {
      gold: '#e8a3b8', darkGold: '#b24e6d', cream: '#fff0f5',
      paper: '#fff5f8', ink: '#5a2a3a', seal: '#c2185b',
      quote: '#c2185b', ribbonInk: '#5a2a3a'
    },
    reasons: [
      'stalking IG mantan tiap jam 3 pagi',
      'save semua chat gebetan sampai screenshot stories',
      'bikin playlist 200 lagu khusus buat dia',
      'kirim good morning text tiap hari meskipun dibales 4 hari kemudian',
      'tau jadwal dia lebih detail dari jadwal sendiri'
    ],
    caption: (nama, alasan) =>
      'Sertifikat Kebucinan Nasional\n\nUntuk: ' + nama + '\nDiagnosa: ' + alasan + '\n\nSaatnya move on? Enggak ah.',
    prefix: 'BCN'
  },

  sertifikattolol: {
    title: 'SERTIFIKAT KETOLOLAN RESMI',
    subtitle: '~ United Brain Cell Deficiency Bureau ~',
    award: '[o.O]',
    intro: 'Dengan penuh tanggung jawab, sertifikat ini dianugerahkan kepada:',
    bodyTitle: 'Atas kontribusinya dalam kategori:',
    issuer: 'Dewan Pembina Kuota Otak Nasional',
    sealText: ['VERIFIED', 'TOLOL', '2026'],
    palette: {
      gold: '#f0b54a', darkGold: '#a06a1a', cream: '#fff8e1',
      paper: '#fff4d6', ink: '#4a2c10', seal: '#b8860b',
      quote: '#b8860b', ribbonInk: '#4a2c10'
    },
    reasons: [
      'kunci motor masih nyangkut tapi udah jalan 2 km',
      'cari kacamata padahal lagi dipake',
      'beli pulsa 2 kali karena lupa yang pertama udah masuk',
      'chat "iya" tapi yang dikirim screenshot mabar',
      'password sendiri 3x salah padahal baru diganti tadi pagi'
    ],
    caption: (nama, alasan) =>
      'Sertifikat Ketololan Resmi\n\nUntuk: ' + nama + '\nKategori: ' + alasan + '\n\nMerahasiakan identitas? Enggak lah, biar semua tau.',
    prefix: 'TOL'
  },

  sertifikatjomblo: {
    title: 'SERTIFIKAT JOMBLO KRONIS',
    subtitle: '~ National Single Forever Association ~',
    award: '[^_^]',
    intro: 'Dengan penuh simpati, sertifikat ini dianugerahkan kepada:',
    bodyTitle: 'Atas kelanggengan luar biasa dalam kategori:',
    issuer: 'Paguyuban Pensiun PDKT',
    sealText: ['OFFICIAL', 'JOMBLO', '2026'],
    palette: {
      gold: '#8b9dc3', darkGold: '#3b4f7a', cream: '#e8edf5',
      paper: '#dde4f0', ink: '#1a2440', seal: '#2c3e6e',
      quote: '#2c3e6e', ribbonInk: '#1a2440'
    },
    reasons: [
      'nonton drama Korea sendirian sambil nangis',
      'refresh Twitter nungguin gebetan like story',
      'beli dessert porsi besar buat satu orang',
      'pernah nembak dan jawabannya "kita temenan aja"',
      'sudah 5 tahun Valentine cuma dapat ucapan dari grup kantor'
    ],
    caption: (nama, alasan) =>
      'Sertifikat Jomblo Kronis\n\nUntuk: ' + nama + '\nPrestasi: ' + alasan + '\n\nStatus: Setia menunggu yang tak pasti.',
    prefix: 'JMB'
  },

  sertifikatkentang: {
    title: 'SERTIFIKAT KENTANG NASIONAL',
    subtitle: '~ Republik Pengangguran Kreatif Nusantara ~',
    award: '[zzz]',
    intro: 'Dengan penuh apresiasi, sertifikat ini dianugerahkan kepada:',
    bodyTitle: 'Atas dedikasi tingginya dalam hal:',
    issuer: 'Kementerian Rebahan & Scrolling Berlebihan',
    sealText: ['CERTIFIED', 'KENTANG', '2026'],
    palette: {
      gold: '#a8956b', darkGold: '#6b5a2e', cream: '#f4ecd8',
      paper: '#ebe0c0', ink: '#3d2f1a', seal: '#7a5c2a',
      quote: '#7a5c2a', ribbonInk: '#3d2f1a'
    },
    reasons: [
      'rebah 16 jam sehari dan tetap capek',
      'scroll TikTok 4 jam tapi ngerasa udah produktif',
      'niat mau olahraga tapi malah tiduran dulu 2 jam',
      'alarm bunyi 5 kali baru bangun, itu pun snooze',
      'quote of the day: "ntar aja deh" (niat-nya minggu lalu)'
    ],
    caption: (nama, alasan) =>
      'Sertifikat Kentang Nasional\n\nUntuk: ' + nama + '\nSpesialisasi: ' + alasan + '\n\nTerus aja rebahan, yang penting happy.',
    prefix: 'KTG'
  }
}

// ============================================================
// DRAWING ENGINE
// ============================================================
function drawCertificate(ctx, tpl, nama, alasan, nomor) {
  const W = 1000, H = 700
  const p = tpl.palette

  ctx.fillStyle = p.paper
  ctx.fillRect(0, 0, W, H)

  ctx.save()
  ctx.globalAlpha = 0.05
  ctx.strokeStyle = p.darkGold
  ctx.lineWidth = 1
  for (let i = -H; i < W; i += 14) {
    ctx.beginPath()
    ctx.moveTo(i, 0)
    ctx.lineTo(i + H, H)
    ctx.stroke()
  }
  ctx.restore()

  ctx.strokeStyle = p.darkGold
  ctx.lineWidth = 6
  ctx.strokeRect(20, 20, W - 40, H - 40)
  ctx.strokeStyle = p.gold
  ctx.lineWidth = 2
  ctx.strokeRect(38, 38, W - 76, H - 76)
  ctx.strokeStyle = p.darkGold
  ctx.lineWidth = 1
  ctx.strokeRect(50, 50, W - 100, H - 100)

  const cornerOrnament = (x, y, fx, fy) => {
    ctx.save()
    ctx.translate(x, y)
    ctx.scale(fx, fy)
    ctx.strokeStyle = p.darkGold
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(0, 30); ctx.lineTo(0, 0); ctx.lineTo(30, 0)
    ctx.stroke()
    ctx.beginPath()
    ctx.arc(10, 10, 6, 0, Math.PI * 2)
    ctx.stroke()
    ctx.fillStyle = p.darkGold
    ctx.beginPath()
    ctx.arc(10, 10, 2, 0, Math.PI * 2)
    ctx.fill()
    ctx.restore()
  }
  cornerOrnament(60, 60, 1, 1)
  cornerOrnament(W - 60, 60, -1, 1)
  cornerOrnament(60, H - 60, 1, -1)
  cornerOrnament(W - 60, H - 60, -1, -1)

  const ribbonY = 90
  ctx.fillStyle = p.darkGold
  ctx.fillRect(120, ribbonY, W - 240, 70)
  ctx.fillStyle = p.gold
  ctx.fillRect(128, ribbonY + 6, W - 256, 58)
  ctx.fillStyle = p.cream
  ctx.fillRect(132, ribbonY + 10, W - 264, 50)

  ctx.fillStyle = p.ribbonInk
  ctx.font = 'bold 30px Georgia, "Times New Roman", serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(tpl.award + '  ' + tpl.title + '  ' + tpl.award, W / 2, ribbonY + 35)

  ctx.fillStyle = p.darkGold
  ctx.font = 'italic 18px Georgia, serif'
  ctx.fillText(tpl.subtitle, W / 2, 195)

  ctx.fillStyle = p.ink
  ctx.font = '20px Georgia, serif'
  ctx.fillText(tpl.intro, W / 2, 245)

  ctx.fillStyle = p.darkGold
  ctx.font = 'bold 52px "Times New Roman", Georgia, serif'
  ctx.textBaseline = 'alphabetic'
  let displayName = nama
  if (ctx.measureText(displayName).width > W - 200) {
    while (ctx.measureText(displayName + '...').width > W - 200 && displayName.length > 0) {
      displayName = displayName.slice(0, -1)
    }
    displayName += '...'
  }
  ctx.fillText(displayName, W / 2, 320)

  const nameWidth = ctx.measureText(displayName).width
  ctx.strokeStyle = p.darkGold
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.moveTo(W / 2 - nameWidth / 2 - 20, 335)
  ctx.lineTo(W / 2 + nameWidth / 2 + 20, 335)
  ctx.stroke()

  ctx.fillStyle = p.ink
  ctx.font = '20px Georgia, serif'
  ctx.fillText(tpl.bodyTitle, W / 2, 380)

  ctx.fillStyle = p.quote
  ctx.font = 'bold italic 24px Georgia, serif'
  const maxWidth = W - 200
  const reason = '"' + alasan + '"'
  if (ctx.measureText(reason).width > maxWidth) {
    const words = reason.split(' ')
    let line1 = '', line2 = ''
    for (const w of words) {
      if (ctx.measureText(line1 + w + ' ').width < maxWidth) line1 += w + ' '
      else line2 += w + ' '
    }
    ctx.fillText(line1.trim(), W / 2, 425)
    ctx.fillText(line2.trim(), W / 2, 458)
  } else {
    ctx.fillText(reason, W / 2, 425)
  }

  ctx.strokeStyle = p.gold
  ctx.lineWidth = 1
  ctx.beginPath()
  ctx.moveTo(W / 2 - 150, 500)
  ctx.lineTo(W / 2 + 150, 500)
  ctx.stroke()
  ctx.fillStyle = p.darkGold
  ctx.beginPath()
  ctx.arc(W / 2, 500, 4, 0, Math.PI * 2)
  ctx.fill()

  ctx.textAlign = 'left'
  ctx.fillStyle = p.ink
  ctx.font = '15px Georgia, serif'
  ctx.fillText('Dikeluarkan oleh:', 100, 540)
  ctx.font = 'bold 16px Georgia, serif'
  ctx.fillText(tpl.issuer, 100, 562)
  ctx.font = '13px Georgia, serif'
  ctx.fillStyle = p.darkGold
  ctx.fillText('Tanggal: ' + new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }), 100, 585)
  ctx.fillText('No: ' + nomor, 100, 605)

  ctx.textAlign = 'center'
  ctx.strokeStyle = p.ink
  ctx.lineWidth = 1.5
  ctx.beginPath()
  ctx.moveTo(W - 280, 600)
  ctx.lineTo(W - 100, 600)
  ctx.stroke()
  ctx.fillStyle = p.ink
  ctx.font = 'italic 16px Georgia, serif'
  ctx.fillText('Ketua ' + tpl.title.split(' ').slice(-1)[0] + ' RI', W - 190, 595)
  ctx.font = '13px Georgia, serif'
  ctx.fillStyle = p.darkGold
  ctx.fillText('(ttd. Tangan Terhormat)', W - 190, 620)

  const sealX = 130, sealY = 600, sealR = 32
  ctx.save()
  ctx.translate(sealX, sealY)
  ctx.strokeStyle = p.seal
  ctx.lineWidth = 3
  ctx.beginPath(); ctx.arc(0, 0, sealR, 0, Math.PI * 2); ctx.stroke()
  ctx.lineWidth = 1
  ctx.beginPath(); ctx.arc(0, 0, sealR - 6, 0, Math.PI * 2); ctx.stroke()
  ctx.font = 'bold 12px Georgia, serif'
  ctx.fillStyle = p.seal
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillText(tpl.sealText[0], 0, -8)
  ctx.fillText(tpl.sealText[1], 0, 5)
  ctx.fillText(tpl.sealText[2], 0, 17)
  ctx.restore()

  ctx.save()
  ctx.globalAlpha = 0.08
  ctx.fillStyle = p.darkGold
  ctx.font = 'bold 140px Georgia, serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.translate(W / 2, H / 2)
  ctx.rotate(-0.4)
  ctx.fillText(tpl.sealText[1], 0, 0)
  ctx.restore()
}

function pick(arr) {
  return arr[Math.floor(Math.random() * arr.length)]
}

// ============================================================
// SINGLE HANDLER — switch case, kayak format lo sebelumnya
// ============================================================
let handler = async (m, { text, conn, command }) => {
  const type = command.toLowerCase()
  const tpl = TEMPLATES[type]
  if (!tpl) return m.reply('Sertifikat tidak ditemukan.')

  const nama = (text || m.pushName || 'Anonim').toUpperCase()
  const alasan = pick(tpl.reasons)
  const nomor = tpl.prefix + '-' + Date.now().toString().slice(-8)

  try {
    const canvas = createCanvas(1000, 700)
    const ctx = canvas.getContext('2d')
    drawCertificate(ctx, tpl, nama, alasan, nomor)

    const buffer = canvas.toBuffer('image/jpeg', { quality: 0.92 })
    await conn.sendFile(m.chat, buffer, type + '.jpg', tpl.caption(nama, alasan), m)
  } catch (e) {
    console.error(e)
    m.reply('Gagal membuat sertifikat.\n' + e.message)
  }
}

handler.help = [
  'sertifikatlemot <nama>',
  'sertifikatbucin <nama>',
  'sertifikattolol <nama>',
  'sertifikatjomblo <nama>',
  'sertifikatkentang <nama>'
]
handler.tags = ['fun', 'maker']
handler.command = /^(sertifikatlemot|sertifikatbucin|sertifikattolol|sertifikatjomblo|sertifikatkentang)$/i
handler.limit = 10
handler.premium = false

export default handler