const items = {
    buy: {
        limit: { money: 9999 },
        chip: { money: 1000000 },
        exp: { money: 1000 },
        potion: { money: 1250 },

        trash: { money: 40 },
        wood: { money: 700 },
        rock: { money: 850 },
        string: { money: 400 },
        iron: { money: 3000 },

        diamond: { money: 500000 },
        emerald: { money: 100000 },
        gold: { money: 100000 },

        common: { money: 2000 },
        uncommon: { money: 20000 },
        mythic: { money: 75000 },
        legendary: { money: 200000 },

        petfood: { money: 750000000 },
        pet: { money: 120000 },

        anggur: { money: 2000 },
        apel: { money: 2000 },
        jeruk: { money: 2000 },
        mangga: { money: 2000 },
        pisang: { money: 2000 },

        bibitanggur: { money: 2000 },
        bibitapel: { money: 2000 },
        bibitjeruk: { money: 2000 },
        bibitmangga: { money: 2000 },
        bibitpisang: { money: 2000 },

        umpan: { money: 5000 }
    },

    sell: {
        /*
         * PENTING:
         * Harga jual TIDAK BOLEH >= harga beli.
         *
         * Target maksimal sekitar 50% dari harga beli.
         */

        limit: { money: 5000 },
        exp: { money: 1 },
        chip: { money: 500000 },

        potion: { money: 625 },

        trash: { money: 20 },
        wood: { money: 350 },
        rock: { money: 425 },
        string: { money: 200 },
        iron: { money: 1500 },

        diamond: { money: 250000 },
        emerald: { money: 50000 },
        gold: { money: 50000 },

        common: { money: 1000 },
        uncommon: { money: 10000 },
        mythic: { money: 37500 },
        legendary: { money: 100000 },

        petfood: { money: 1750 },
        pet: { money: 60000 },

        anggur: { money: 1000 },
        apel: { money: 1000 },
        jeruk: { money: 1000 },
        mangga: { money: 1000 },
        pisang: { money: 1000 },

        bibitanggur: { money: 1000 },
        bibitapel: { money: 1000 },
        bibitjeruk: { money: 1000 },
        bibitmangga: { money: 1000 },
        bibitpisang: { money: 1000 },

        umpan: { money: 2500 },

        // Hewan dan hasil tangkapan
        ayam: { money: 50000 },
        babi: { money: 55000 },
        babihutan: { money: 65000 },
        banteng: { money: 70000 },
        buaya: { money: 75000 },
        gajah: { money: 95000 },
        harimau: { money: 100000 },
        kambing: { money: 55000 },
        kerbau: { money: 70000 },
        monyet: { money: 60000 },
        panda: { money: 95000 },
        sapi: { money: 65000 },

        paus: { money: 100000 },
        kepiting: { money: 60000 },
        gurita: { money: 65000 },
        cumi: { money: 55000 },
        buntal: { money: 70000 },
        dory: { money: 50000 },
        lumba: { money: 85000 },
        lobster: { money: 90000 },
        hiu: { money: 85000 },
        udang: { money: 50000 },
        orca: { money: 100000 },

        ikan: { money: 50000 },
        lele: { money: 50000 },
        nila: { money: 55000 },
        bawal: { money: 60000 },

        /*
         * Item yang tidak punya market BUY
         * tetap boleh dijual.
         */

        botol: { money: 2500 },
        kardus: { money: 5000 },
        kaleng: { money: 7500 },
        clay: { money: 1000 },
        coal: { money: 2000 },
        gelas: { money: 3750 },
        plastik: { money: 6250 }
    }
}

const namaItem = {
    limit: '💎 Limit',
    chip: '🎰 Chip',
    exp: '✨ Exp',
    potion: '🧪 Potion',

    botol: '🧴 Botol',
    kardus: '📦 Kardus',
    kaleng: '🥫 Kaleng',
    gelas: '🥛 Gelas',
    plastik: '🛍️ Plastik',

    trash: '🗑️ Trash',
    wood: '🪵 Wood',
    rock: '🪨 Rock',
    string: '🧵 String',
    iron: '⛓️ Iron',

    diamond: '💎 Diamond',
    emerald: '🟢 Emerald',
    gold: '🪙 Gold',

    common: '📦 Common',
    uncommon: '🎁 Uncommon',
    mythic: '🔮 Mythic',
    legendary: '👑 Legendary',

    petfood: '🍖 Petfood',
    pet: '🐾 Pet',

    anggur: '🍇 Anggur',
    apel: '🍎 Apel',
    jeruk: '🍊 Jeruk',
    mangga: '🥭 Mangga',
    pisang: '🍌 Pisang',

    bibitanggur: '🌱 Bibit Anggur',
    bibitapel: '🌱 Bibit Apel',
    bibitjeruk: '🌱 Bibit Jeruk',
    bibitmangga: '🌱 Bibit Mangga',
    bibitpisang: '🌱 Bibit Pisang',

    umpan: '🪱 Umpan',

    ayam: '🍗 Ayam',
    babi: '🐖 Babi',
    babihutan: '🐗 Babi Hutan',
    banteng: '🐂 Banteng',
    buaya: '🐊 Buaya',
    gajah: '🐘 Gajah',
    harimau: '🐅 Harimau',
    kambing: '🐐 Kambing',
    kerbau: '🐃 Kerbau',
    monyet: '🐒 Monyet',
    panda: '🐼 Panda',
    sapi: '🐄 Sapi',

    paus: '🐋 Paus',
    kepiting: '🦀 Kepiting',
    gurita: '🐙 Gurita',
    cumi: '🦑 Cumi',
    buntal: '🐡 Buntal',
    dory: '🐠 Dory',
    lumba: '🐬 Lumba-lumba',
    lobster: '🦞 Lobster',
    hiu: '🦈 Hiu',
    udang: '🦐 Udang',
    orca: '🐳 Orca',

    ikan: '🐟 Ikan',
    lele: '🐟 Lele',
    nila: '🐟 Nila',
    bawal: '🐟 Bawal'
}

const formatNumber = number => {
    return Number(number || 0).toLocaleString('id-ID')
}

const capitalize = value => {
    return String(value || '')
        .toLowerCase()
        .replace(/\b\w/g, char => char.toUpperCase())
}

const getItemName = item => {
    return namaItem[item] || `📦 ${capitalize(item)}`
}

const safeInteger = number => {
    return Number.isSafeInteger(number)
}

/*
 * ==============================
 * VALIDASI MARKET ANTI ARBITRAGE
 * ==============================
 *
 * Semua item yang mempunyai harga BUY
 * wajib mempunyai harga SELL lebih kecil.
 *
 * Kalau ada developer salah memasukkan
 * harga sell >= harga buy, transaksi
 * akan diblokir.
 */

const validateMarketPrice = (item, buyPrice, sellPrice) => {
    const buy = Number(buyPrice)
    const sell = Number(sellPrice)

    /*
     * Item tidak punya harga buy.
     * Tidak perlu dibandingkan.
     */
    if (!safeInteger(buy) || buy <= 0) {
        return {
            valid: true,
            buy,
            sell
        }
    }

    /*
     * Kalau item punya BUY dan SELL,
     * SELL wajib lebih kecil dari BUY.
     */
    if (
        safeInteger(sell) &&
        sell > 0 &&
        sell >= buy
    ) {
        return {
            valid: false,
            reason: 'Harga jual harus lebih rendah dari harga beli.'
        }
    }

    return {
        valid: true,
        buy,
        sell
    }
}

/*
 * ==============================
 * CEK RPG
 * ==============================
 */

let handler = async (m, { conn, command, usedPrefix, args }) => {
    const rawCommand = String(command || '').toLowerCase()

    /*
     * buy  → buy
     * beli → buy
     * sell → sell
     * jual → sell
     */

    const cmd =
        rawCommand === 'beli'
            ? 'buy'
            : rawCommand === 'jual'
                ? 'sell'
                : rawCommand === 'price'
                ? 'price'
                : rawCommand

    /*
     * ==============================
     * ITEM
     * ==============================
     */

    const item = String(args[0] || '')
        .toLowerCase()
        .trim()

    /*
     * ==============================
     * RPG CHECK
     * ==============================
     */

    if (
        !item.includes('limit') &&
        m.isGroup &&
        global.db?.data?.chats?.[m.chat]?.rpg === false
    ) {
        if (typeof dfail === 'function') {
            return dfail('rpg', m, conn)
        }

        return m.reply(
            '❌ Fitur RPG sedang dinonaktifkan di grup ini.'
        )
    }

    /*
     * ==============================
     * DATABASE
     * ==============================
     */

    const user = global.db?.data?.users?.[m.sender]

    if (!user) {
        return m.reply(
            '❌ Data pengguna belum tersedia. Coba lagi sebentar.'
        )
    }

    /*
     * ==============================
     * NORMALISASI MONEY
     * ==============================
     */

    let money = Number(user.money)

    if (
        !safeInteger(money) ||
        money < 0
    ) {
        user.money = 0
        money = 0
    }

    /*
     * ==============================
     * MARKET
     * ==============================
     */

    const marketItems =
        cmd === 'price'
            ? {
                ...items.buy,
                ...items.sell
            }
            : items[cmd] || {}

    /*
     * ==============================
     * LIST ITEM
     * ==============================
     */

    const listItems = Object.keys(marketItems).filter(key => {
        return Object.prototype.hasOwnProperty.call(
            user,
            key
        )
    })

    /*
     * ==============================
     * GENERATE LIST
     * ==============================
     */

    const listText = listItems.length
        ? listItems.map((key, index) => {
            const price = Number(
                marketItems[key]?.money || 0
            )

            const stock = Number(
                user[key] || 0
            )

            return [
                `│ ${String(index + 1).padStart(2, '0')} ┃ ${getItemName(key)}`,
                `│    💰 Rp${formatNumber(price)} / item`,
                cmd === 'sell'
                    ? `│    📦 Stok: ${formatNumber(Math.max(stock, 0))}`
                    : `│    🛒 Harga: Rp${formatNumber(price)}`
            ].join('\n')
        }).join(
            '\n├────────────────────────\n'
        )
        : '│ ❌ Tidak ada item yang tersedia.'

    /*
     * ==============================
     * TITLE
     * ==============================
     */

    const title =
        cmd === 'buy'
            ? '🛒 MARKET BUY'
            : cmd === 'price'
                ? '🏷️ PRICE CHECK'
                : '💰 MARKET SELL'

    const action =
        cmd === 'buy'
            ? 'BELI BARANG'
            : cmd === 'price'
                ? 'CEK HARGA'
                : 'JUAL BARANG'

    /*
     * ==============================
     * MARKET MENU
     * ==============================
     */

    const menu = `
╭━━━━━━━━━━━━━━━━━━━━━━━━╮
│       🏪 *RPG MARKET*
│       ${title}
╰━━━━━━━━━━━━━━━━━━━━━━━━╯

╭─「 📦 ${action} 」
${listText}
╰────────────────────────

╭─「 💡 CARA PAKAI 」
│
│ ${usedPrefix}${rawCommand} <item> <jumlah>
│
│ Contoh:
│ ➜ ${usedPrefix}${rawCommand} potion 10
│ ➜ ${usedPrefix}${rawCommand} botol 20
│
╰────────────────────────

💰 *Saldo:* Rp${formatNumber(user.money)}

✨ Pilih item dan tentukan jumlahnya!
`.trim()

    /*
     * ==============================
     * TANPA ITEM
     * ==============================
     */

    if (!item) {
        return conn.reply(
            m.chat,
            menu,
            m
        )
    }

    /*
     * ==============================
     * ITEM TIDAK ADA
     * ==============================
     */

    if (
        !Object.prototype.hasOwnProperty.call(
            marketItems,
            item
        )
    ) {
        return m.reply(
`╭─❒ ⚠️ *ITEM TIDAK DITEMUKAN*
│
│ 📦 Item : *${item}*
│
│ Item tersebut tidak tersedia
│ di market ${cmd}.
│
│ 💡 Gunakan:
│ ${usedPrefix}${rawCommand}
│
╰────────────────────`
        )
    }

    /*
     * ==============================
     * PRICE CHECK
     * ==============================
     */

    if (cmd === 'price') {
        const buyPrice = Number(items.buy?.[item]?.money || 0)
        const sellPrice = Number(items.sell?.[item]?.money || 0)
        const hasBuyPrice = safeInteger(buyPrice) && buyPrice > 0
        const hasSellPrice = safeInteger(sellPrice) && sellPrice > 0

        return m.reply(`
╭━━━━━━━━━━━━━━━━━━━━╮
│   🏷️ *HARGA MARKET*
╰━━━━━━━━━━━━━━━━━━━━╯

╭─「 ${getItemName(item)} 」
│
│ 🛒 Harga beli
│   ${hasBuyPrice ? `Rp${formatNumber(buyPrice)}` : 'Tidak tersedia'}
│
│ 💰 Harga jual
│   ${hasSellPrice ? `Rp${formatNumber(sellPrice)}` : 'Tidak tersedia'}
│
╰────────────────────

Gunakan:
➜ ${usedPrefix}buy ${item} 1
➜ ${usedPrefix}sell ${item} 1`.trim())
    }

    /*
     * ==============================
     * PRICE VALIDATION
     * ==============================
     */

    const buyPrice =
        Number(
            items.buy?.[item]?.money || 0
        )

    const sellPrice =
        Number(
            items.sell?.[item]?.money || 0
        )

    const priceValidation =
        validateMarketPrice(
            item,
            buyPrice,
            sellPrice
        )

    /*
     * Kalau terjadi kesalahan konfigurasi
     * harga, transaksi langsung diblokir.
     */

    if (!priceValidation.valid) {
        console.error(
            `[MARKET SECURITY] Arbitrage detected: ${item} | BUY=${buyPrice} | SELL=${sellPrice}`
        )

        return m.reply(
`❌ *TRANSAKSI DIBLOKIR*

Harga market untuk *${getItemName(item)}*
tidak aman.

🛒 Buy  : Rp${formatNumber(buyPrice)}
💰 Sell : Rp${formatNumber(sellPrice)}

Harga jual tidak boleh sama atau lebih
tinggi dari harga beli.

> Hubungi admin untuk memperbaiki market.`
        )
    }

    /*
     * ==============================
     * VALIDASI JUMLAH
     * ==============================
     */

    let total

    if (args[1] === undefined) {
        total = 1
    } else {
        const amount = String(args[1]).trim()

        if (!/^\d+$/.test(amount)) {
            return m.reply(
`❌ *Jumlah tidak valid!*

Gunakan angka bulat positif.

Contoh:
➜ ${usedPrefix}${rawCommand} ${item} 10`
            )
        }

        total = Number(amount)
    }

    /*
     * ==============================
     * VALIDATE TOTAL
     * ==============================
     */

    if (
        !safeInteger(total) ||
        total <= 0
    ) {
        return m.reply(
            '❌ Jumlah harus berupa angka positif yang valid.'
        )
    }

    /*
     * ==============================
     * PRICE
     * ==============================
     */

    const price =
        Number(
            marketItems[item]?.money
        )

    if (
        !safeInteger(price) ||
        price <= 0
    ) {
        return m.reply(
            '❌ Harga item tidak valid.'
        )
    }

    /*
     * ==============================
     * OVERFLOW PROTECTION
     * ==============================
     */

    if (
        total >
        Math.floor(
            Number.MAX_SAFE_INTEGER /
            price
        )
    ) {
        return m.reply(
            '❌ Jumlah terlalu besar untuk diproses.'
        )
    }

    const totalPrice =
        total * price

    if (
        !safeInteger(totalPrice) ||
        totalPrice <= 0
    ) {
        return m.reply(
            '❌ Total transaksi tidak valid.'
        )
    }

    /*
     * ==============================
     * BUY / BELI
     * ==============================
     */

    if (cmd === 'buy') {
        const currentMoney =
            Number(user.money || 0)

        /*
         * SALDO
         */

        if (
            !safeInteger(currentMoney) ||
            currentMoney < totalPrice
        ) {
            const kurang =
                totalPrice -
                Math.max(
                    currentMoney,
                    0
                )

            return m.reply(
`╭━━━━━━━━━━━━━━━━━━━━╮
│   💸 *SALDO TIDAK CUKUP*
╰━━━━━━━━━━━━━━━━━━━━╯

╭─「 🧾 DETAIL 」 
│
│ 📦 Item  : ${getItemName(item)}
│ 🔢 Jumlah: ${formatNumber(total)}
│ 💰 Total : Rp${formatNumber(totalPrice)}
│
│ 💵 Saldo : Rp${formatNumber(currentMoney)}
│ ❗ Kurang: Rp${formatNumber(kurang)}
│
╰────────────────────`
            )
        }

        /*
         * ITEM USER
         */

        let currentItem =
            Number(user[item] || 0)

        if (
            !safeInteger(currentItem) ||
            currentItem < 0
        ) {
            currentItem = 0
            user[item] = 0
        }

        /*
         * ITEM OVERFLOW
         */

        if (
            currentItem >
            Number.MAX_SAFE_INTEGER -
            total
        ) {
            return m.reply(
                '❌ Jumlah item terlalu besar.'
            )
        }

        /*
         * TRANSAKSI
         */

        user.money =
            currentMoney -
            totalPrice

        user[item] =
            currentItem +
            total

        /*
         * SUCCESS
         */

        return conn.reply(
            m.chat,
`
╭━━━━━━━━━━━━━━━━━━━━━━━━╮
│     🛒 *PEMBELIAN SUKSES*
╰━━━━━━━━━━━━━━━━━━━━━━━━╯

╭─「 🧾 TRANSAKSI 」
│
│ 📦 Item
│   ${getItemName(item)}
│
│ 🔢 Jumlah
│   ${formatNumber(total)}
│
│ 💵 Harga / item
│   Rp${formatNumber(price)}
│
│ 💸 Total bayar
│   *Rp${formatNumber(totalPrice)}*
│
╰────────────────────────

╭─「 💳 HASIL 」
│
│ 💰 Sisa money
│   *Rp${formatNumber(user.money)}*
│
│ 📦 Total ${getItemName(item)}
│   *${formatNumber(user[item])}*
│
╰────────────────────────

✅ Pembelian berhasil!
`.trim(),
            m
        )
    }

    /*
     * ==============================
     * SELL / JUAL
     * ==============================
     */

    const owned =
        Number(user[item] || 0)

    /*
     * STOK TIDAK CUKUP
     */

    if (
        !safeInteger(owned) ||
        owned < total
    ) {
        return m.reply(
`╭━━━━━━━━━━━━━━━━━━━━╮
│   📦 *STOK TIDAK CUKUP*
╰━━━━━━━━━━━━━━━━━━━━╯

╭─「 📊 DETAIL 」
│
│ 📦 Item : ${getItemName(item)}
│
│ 📦 Punya: *${formatNumber(Math.max(owned, 0))}*
│ 🛒 Jual : *${formatNumber(total)}*
│
│ ❌ Jumlah item tidak mencukupi.
╰────────────────────`
        )
    }

    /*
     * ==============================
     * MONEY VALIDATION
     * ==============================
     */

    let currentMoney =
        Number(user.money || 0)

    if (
        !safeInteger(currentMoney) ||
        currentMoney < 0
    ) {
        currentMoney = 0
        user.money = 0
    }

    /*
     * ==============================
     * MONEY OVERFLOW
     * ==============================
     */

    if (
        currentMoney >
        Number.MAX_SAFE_INTEGER -
        totalPrice
    ) {
        return m.reply(
            '❌ Saldo akan melebihi batas maksimum.'
        )
    }

    /*
     * ==============================
     * TRANSAKSI SELL
     * ==============================
     */

    user[item] =
        owned - total

    user.money =
        currentMoney +
        totalPrice

    /*
     * ==============================
     * SUCCESS
     * ==============================
     */

    return conn.reply(
        m.chat,
`
╭━━━━━━━━━━━━━━━━━━━━━━━━╮
│      💰 *PENJUALAN SUKSES*
╰━━━━━━━━━━━━━━━━━━━━━━━━╯

╭─「 🧾 TRANSAKSI 」
│
│ 📦 Item
│   ${getItemName(item)}
│
│ 🔢 Jumlah
│   ${formatNumber(total)}
│
│ 💵 Harga / item
│   Rp${formatNumber(price)}
│
│ 💰 Total diterima
│   *Rp${formatNumber(totalPrice)}*
│
╰────────────────────────

╭─「 📊 HASIL 」
│
│ 📦 Sisa ${getItemName(item)}
│   *${formatNumber(user[item])}*
│
│ 💰 Money
│   *Rp${formatNumber(user.money)}*
│
╰────────────────────────

✨ Penjualan berhasil!
`.trim(),
        m
    )
}

handler.help = [
    'buy <item> <count>',
    'beli <item> <count>',
    'sell <item> <count>',
    'jual <item> <count>',
    'price <item>'
]

handler.tags = ['rpg']

handler.command =
    /^(buy|beli|sell|jual|price)$/i

handler.register = true
handler.group = true
handler.disabled = false

export default handler