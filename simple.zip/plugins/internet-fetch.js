import fetch from 'node-fetch'
import * as cheerio from 'cheerio'
import path from 'path'

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36'

class SmartFetcher {
    constructor(url) {
        this.url = url
        this.maxRedirects = 30
        this.visited = new Set()
    }

    normalizeUrl(url, base = this.url) {
        try {
            if (!url) return null

            url = String(url).trim()
            url = url
                .replace(/&amp;/gi, '&')
                .replace(/\\u0026/g, '&')
                .replace(/\\\//g, '/')
                .replace(/^['"`]|['"`]$/g, '')

            if (/^(data|blob|javascript|mailto|tel):/i.test(url)) {
                return null
            }

            if (url.startsWith('//')) {
                return new URL('https:' + url).href
            }

            return new URL(url, base).href
        } catch {
            return null
        }
    }

    filename(url, type = '') {
        try {
            const pathname = new URL(url).pathname
            let name = path.basename(pathname.split('?')[0]) || 'file'

            name = decodeURIComponent(name).replace(
                /[<>:"/\\|?*\x00-\x1F]/g,
                '_'
            )

            if (!path.extname(name) && type) {
                name += this.extMap(type)
            }

            return name || 'file'
        } catch {
            return 'file'
        }
    }

    extMap(mime) {
        return {
            'image/jpeg': '.jpg',
            'image/png': '.png',
            'image/gif': '.gif',
            'image/webp': '.webp',
            'image/avif': '.avif',
            'image/bmp': '.bmp',
            'image/svg+xml': '.svg',
            'video/mp4': '.mp4',
            'video/webm': '.webm',
            'video/quicktime': '.mov',
            'video/x-msvideo': '.avi',
            'video/x-matroska': '.mkv',
            'audio/mpeg': '.mp3',
            'audio/mp4': '.m4a',
            'audio/aac': '.aac',
            'audio/ogg': '.ogg',
            'audio/wav': '.wav',
            'audio/flac': '.flac',
            'audio/opus': '.opus',
            'application/pdf': '.pdf',
            'application/zip': '.zip',
            'application/vnd.rar': '.rar',
            'application/vnd.android.package-archive': '.apk'
        }[mime] || ''
    }

    async request(url, options = {}) {
        const controller = new AbortController()
        const timer = setTimeout(() => controller.abort(), 30000)

        try {
            return await fetch(url, {
                ...options,
                signal: controller.signal,
                redirect: 'manual',
                headers: {
                    'User-Agent': UA,
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Referer': this.url,
                    ...options.headers
                }
            })
        } finally {
            clearTimeout(timer)
        }
    }

    async resolve(url) {
        let current = url

        for (let i = 0; i < this.maxRedirects; i++) {
            if (this.visited.has(current)) {
                break
            }

            this.visited.add(current)

            const res = await this.request(current)
            const location = res.headers.get('location')

            if (
                [301, 302, 303, 307, 308].includes(res.status) &&
                location
            ) {
                current = this.normalizeUrl(location, current)

                if (!current) {
                    break
                }

                continue
            }

            return {
                url: current,
                response: res
            }
        }

        throw new Error('Too many redirects')
    }

    extractFromJson(data, baseUrl, found = new Set()) {
        const add = value => {
            if (typeof value !== 'string') return

            const url = this.normalizeUrl(value, baseUrl)

            if (url && this.isMediaUrl(url)) {
                found.add(url)
            }
        }

        if (typeof data === 'string') {
            add(data)

            const matches =
                data.match(/https?:\/\/[^"'\\\s<>]+/gi) || []

            for (const item of matches) {
                add(item)
            }

            return [...found]
        }

        if (Array.isArray(data)) {
            for (const item of data) {
                this.extractFromJson(item, baseUrl, found)
            }

            return [...found]
        }

        if (data && typeof data === 'object') {
            for (const [key, value] of Object.entries(data)) {
                if (
                    /url|src|source|image|video|audio|thumbnail|download|media|file|stream/i.test(
                        key
                    )
                ) {
                    if (typeof value === 'string') {
                        add(value)
                    }
                }

                this.extractFromJson(value, baseUrl, found)
            }
        }

        return [...found]
    }

    isMediaUrl(url) {
        if (!url) return false

        return /\.(?:jpg|jpeg|png|gif|webp|avif|bmp|svg|ico|tiff|mp4|m4v|webm|mov|avi|mkv|flv|mp3|m4a|aac|ogg|oga|wav|flac|opus|pdf|zip|rar|apk|exe)(?:[?#].*)?$/i.test(
            url
        )
    }

    async probe(url) {
        try {
            const res = await this.request(url, {
                method: 'HEAD'
            })

            return {
                url,
                status: res.status,
                type: (res.headers.get('content-type') || '')
                    .split(';')[0]
                    .toLowerCase(),
                length: Number(
                    res.headers.get('content-length') || 0
                )
            }
        } catch {
            return {
                url,
                status: 0,
                type: '',
                length: 0
            }
        }
    }

    detectType(url, contentType = '') {
        contentType = contentType.toLowerCase()

        if (
            contentType &&
            contentType !== 'application/octet-stream'
        ) {
            return contentType
        }

        try {
            const ext = path
                .extname(new URL(url).pathname)
                .toLowerCase()

            return {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp',
                '.avif': 'image/avif',
                '.bmp': 'image/bmp',
                '.svg': 'image/svg+xml',
                '.ico': 'image/x-icon',
                '.mp4': 'video/mp4',
                '.m4v': 'video/mp4',
                '.webm': 'video/webm',
                '.mov': 'video/quicktime',
                '.avi': 'video/x-msvideo',
                '.mkv': 'video/x-matroska',
                '.mp3': 'audio/mpeg',
                '.m4a': 'audio/mp4',
                '.aac': 'audio/aac',
                '.ogg': 'audio/ogg',
                '.oga': 'audio/ogg',
                '.wav': 'audio/wav',
                '.flac': 'audio/flac',
                '.opus': 'audio/opus',
                '.pdf': 'application/pdf',
                '.zip': 'application/zip',
                '.rar': 'application/vnd.rar',
                '.apk': 'application/vnd.android.package-archive',
                '.exe': 'application/vnd.microsoft.portable-executable'
            }[ext] || 'application/octet-stream'
        } catch {
            return 'application/octet-stream'
        }
    }

    async run() {
        const { url, response } = await this.resolve(this.url)

        const type = (response.headers.get('content-type') || '')
            .split(';')[0]
            .toLowerCase()

        const length = Number(
            response.headers.get('content-length') || 0
        )

        if (length > 100 * 1024 * 1024 * 1024) {
            response.body?.destroy()
            throw new Error(
                `Content-Length terlalu besar: ${length}`
            )
        }

        if (
            type.startsWith('image/') ||
            type.startsWith('video/') ||
            type.startsWith('audio/') ||
            type === 'application/pdf' ||
            type === 'application/zip' ||
            type === 'application/x-rar-compressed' ||
            type === 'application/vnd.rar' ||
            type === 'application/octet-stream'
        ) {
            return {
                mode: 'direct',
                url,
                type: this.detectType(url, type),
                filename: this.filename(url, type)
            }
        }

        if (type.includes('json')) {
            const data = await response.json()
            const urls = this.extractFromJson(data, url)

            return {
                mode: 'json',
                data,
                urls
            }
        }

        if (
            type.includes('html') ||
            type.startsWith('text/')
        ) {
            const html = await response.text()

            return {
                mode: 'html',
                html,
                url
            }
        }

        const buffer = await response.arrayBuffer()

        return {
            mode: 'buffer',
            buffer: Buffer.from(buffer),
            url,
            type: this.detectType(url, type),
            filename: this.filename(url, type)
        }
    }
}

const handler = async (
    m,
    { text, conn, usedPrefix, command }
) => {
    if (!text) {
        throw `example nya gini : ${usedPrefix + command} https://example.com`
    }

    if (!/^https?:\/\//i.test(text)) {
        text = 'https://' + text
    }

    let target

    try {
        target = new URL(text).href
    } catch {
        throw 'URL tidak valid'
    }

    await m.react('⏳')

    try {
        const result = await new SmartFetcher(target).run()

        if (result.mode === 'direct') {
            await conn.sendFile(
                m.chat,
                result.url,
                result.filename,
                `Nih hasil dari:\n${target}`,
                m
            )

            await m.react('✅')
            return
        }

        if (result.mode === 'json') {
            if (result.urls.length) {
                const media = [...new Set(result.urls)].slice(0, 20)

                for (const url of media) {
                    try {
                        const info = await new SmartFetcher(url).run()

                        if (info.mode === 'direct') {
                            await conn.sendFile(
                                m.chat,
                                info.url,
                                info.filename,
                                null,
                                m
                            )
                        }
                    } catch {}
                }

                await m.react('✅')
                return
            }

            const json = JSON.stringify(
                result.data,
                null,
                2
            )

            await m.reply(json.slice(0, 65536))

            await conn.sendFile(
                m.chat,
                Buffer.from(json),
                'result.json',
                null,
                m
            )

            await m.react('✅')
            return
        }

        if (result.mode === 'html') {
            await conn.sendFile(
                m.chat,
                Buffer.from(result.html),
                'file.html',
                `HTML dari:\n${result.url}`,
                m
            )

            await m.react('✅')
            return
        }

        if (result.mode === 'buffer') {
            await conn.sendFile(
                m.chat,
                result.buffer,
                result.filename,
                `Nih hasil dari:\n${result.url}`,
                m
            )

            await m.react('✅')
            return
        }

        throw new Error('Format response tidak dikenali')
    } catch (e) {
        await m.react('❌')
        throw e?.message || String(e)
    }
}

handler.help = ['fetch', 'get'].map(v => v + ' <url>')
handler.tags = ['internet']
handler.command = /^(fetch|get)$/i
handler.limit = 10

export default handler