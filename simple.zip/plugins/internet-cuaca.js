import { createCanvas } from '@napi-rs/canvas'

// ============================================================
// WEATHER CODE → GLYPH, DESCRIPTION, DARK THEME PALETTE
// Semua gradient pake tone gelap, text putih jelas terbaca
// ============================================================
const WEATHER_CODES = {
  '113': { glyph: 'SUN',   desc: 'Cerah',            gradient: ['#1E3C72', '#2A5298', '#0F2027'] },
  '116': { glyph: 'SUN',   desc: 'Berawan Sebagian', gradient: ['#283048', '#3B4F6E', '#1A2A40'] },
  '119': { glyph: 'CLOUD', desc: 'Berawan',          gradient: ['#232526', '#414345', '#1A1B1D'] },
  '122': { glyph: 'CLOUD', desc: 'Mendung',          gradient: ['#1C1C1C', '#363636', '#101010'] },
  '143': { glyph: 'FOG',   desc: 'Berkabut',         gradient: ['#3E4A5C', '#5C6B7E', '#2C3645'] },
  '176': { glyph: 'RAIN',  desc: 'Hujan Ringan',     gradient: ['#0F2027', '#203A43', '#0A1418'] },
  '179': { glyph: 'SNOW',  desc: 'Salju Ringan',     gradient: ['#3B4F6E', '#5C7AA8', '#2A3A5A'] },
  '182': { glyph: 'SNOW',  desc: 'Hujan Es',         gradient: ['#2A3A4A', '#4A5C7A', '#1A2A3A'] },
  '185': { glyph: 'RAIN',  desc: 'Gerimis Dingin',   gradient: ['#0F2027', '#1A3A5C', '#0A1418'] },
  '200': { glyph: 'STORM', desc: 'Badai Petir',      gradient: ['#000000', '#1A1A2E', '#0A0A1E'] },
  '227': { glyph: 'SNOW',  desc: 'Salju Berhembus',  gradient: ['#3B4F6E', '#5C7AA8', '#2A3A5A'] },
  '230': { glyph: 'SNOW',  desc: 'Badai Salju',      gradient: ['#2A3A5A', '#4A5C7A', '#1A2A3A'] },
  '248': { glyph: 'FOG',   desc: 'Kabut Tebal',      gradient: ['#2C3645', '#4A5C7A', '#1A2435'] },
  '260': { glyph: 'FOG',   desc: 'Kabut Dingin',     gradient: ['#2C3645', '#4A5C7A', '#1A2435'] },
  '263': { glyph: 'RAIN',  desc: 'Gerimis',          gradient: ['#1C2A3A', '#2C3A4A', '#0C1A2A'] },
  '266': { glyph: 'RAIN',  desc: 'Gerimis Ringan',   gradient: ['#1C2A3A', '#2C3A4A', '#0C1A2A'] },
  '269': { glyph: 'RAIN',  desc: 'Gerimis Lebat',    gradient: ['#0F2027', '#1A3A5C', '#0A1418'] },
  '272': { glyph: 'SNOW',  desc: 'Salju Lebat',      gradient: ['#2A3A5A', '#4A5C7A', '#1A2A3A'] },
  '281': { glyph: 'RAIN',  desc: 'Hujan Beku',       gradient: ['#0F2027', '#1A3A5C', '#0A1418'] },
  '284': { glyph: 'RAIN',  desc: 'Hujan Beku Lebat', gradient: ['#0A1418', '#1A2A4A', '#050A18'] },
  '293': { glyph: 'RAIN',  desc: 'Hujan Ringan',     gradient: ['#0F2027', '#203A43', '#0A1418'] },
  '296': { glyph: 'RAIN',  desc: 'Hujan Ringan',     gradient: ['#0F2027', '#203A43', '#0A1418'] },
  '299': { glyph: 'RAIN',  desc: 'Hujan Sedang',     gradient: ['#0A1A2A', '#1A3A5C', '#050A18'] },
  '302': { glyph: 'RAIN',  desc: 'Hujan Sedang',     gradient: ['#0A1A2A', '#1A3A5C', '#050A18'] },
  '305': { glyph: 'RAIN',  desc: 'Hujan Lebat',      gradient: ['#050A18', '#1A2A4A', '#000005'] },
  '308': { glyph: 'RAIN',  desc: 'Hujan Lebat',      gradient: ['#050A18', '#1A2A4A', '#000005'] },
  '311': { glyph: 'RAIN',  desc: 'Hujan Beku',       gradient: ['#0A1A2A', '#1A3A5C', '#050A18'] },
  '314': { glyph: 'RAIN',  desc: 'Hujan Beku Lebat', gradient: ['#050A18', '#1A2A4A', '#000005'] },
  '317': { glyph: 'SNOW',  desc: 'Hujan Es Ringan',  gradient: ['#2A3A5A', '#4A5C7A', '#1A2A3A'] },
  '320': { glyph: 'SNOW',  desc: 'Hujan Es Sedang',  gradient: ['#2A3A5A', '#4A5C7A', '#1A2A3A'] },
  '323': { glyph: 'SNOW',  desc: 'Salju Ringan',     gradient: ['#3B4F6E', '#5C7AA8', '#2A3A5A'] },
  '326': { glyph: 'SNOW',  desc: 'Salju Ringan',     gradient: ['#3B4F6E', '#5C7AA8', '#2A3A5A'] },
  '329': { glyph: 'SNOW',  desc: 'Salju Sedang',     gradient: ['#2A3A5A', '#4A5C7A', '#1A2A3A'] },
  '332': { glyph: 'SNOW',  desc: 'Salju Sedang',     gradient: ['#2A3A5A', '#4A5C7A', '#1A2A3A'] },
  '335': { glyph: 'SNOW',  desc: 'Salju Lebat',      gradient: ['#1A2A3A', '#3A4A6A', '#0A1A2A'] },
  '338': { glyph: 'SNOW',  desc: 'Salju Lebat',      gradient: ['#1A2A3A', '#3A4A6A', '#0A1A2A'] },
  '350': { glyph: 'SNOW',  desc: 'Hujan Es',         gradient: ['#2A3A4A', '#4A5C7A', '#1A2A3A'] },
  '353': { glyph: 'RAIN',  desc: 'Hujan Singkat',    gradient: ['#0F2027', '#203A43', '#0A1418'] },
  '356': { glyph: 'RAIN',  desc: 'Hujan Lebat',      gradient: ['#0A1A2A', '#1A3A5C', '#050A18'] },
  '359': { glyph: 'RAIN',  desc: 'Hujan Deras',      gradient: ['#050A18', '#1A2A4A', '#000005'] },
  '362': { glyph: 'SNOW',  desc: 'Hujan Es Singkat', gradient: ['#2A3A4A', '#4A5C7A', '#1A2A3A'] },
  '365': { glyph: 'SNOW',  desc: 'Hujan Es Lebat',   gradient: ['#1A2A3A', '#3A4A6A', '#0A1A2A'] },
  '368': { glyph: 'SNOW',  desc: 'Salju Singkat',    gradient: ['#3B4F6E', '#5C7AA8', '#2A3A5A'] },
  '371': { glyph: 'SNOW',  desc: 'Salju Lebat',      gradient: ['#1A2A3A', '#3A4A6A', '#0A1A2A'] },
  '374': { glyph: 'SNOW',  desc: 'Hujan Es Ringan',  gradient: ['#2A3A4A', '#4A5C7A', '#1A2A3A'] },
  '377': { glyph: 'SNOW',  desc: 'Hujan Es Lebat',   gradient: ['#1A2A3A', '#3A4A6A', '#0A1A2A'] },
  '386': { glyph: 'STORM', desc: 'Hujan Petir',      gradient: ['#000000', '#1A1A2E', '#0A0A1E'] },
  '389': { glyph: 'STORM', desc: 'Hujan Petir Lebat',gradient: ['#000000', '#0F0F1E', '#050508'] },
  '392': { glyph: 'STORM', desc: 'Salju Petir',      gradient: ['#0A0A1E', '#1A1A3E', '#050510'] },
  '395': { glyph: 'STORM', desc: 'Salju Petir Lebat',gradient: ['#000000', '#0F0F1E', '#050508'] },
  '149': { glyph: 'FOG',   desc: 'Berkabut/Asap',    gradient: ['#3E4A5C', '#5C6B7E', '#2C3645'] }
}

const DEFAULT_CODE = { glyph: 'SUN', desc: 'Cerah', gradient: ['#1E3C72', '#2A5298', '#0F2027'] }

// ============================================================
// DRAW GLYPH (custom shapes, no emoji)
// ============================================================
function drawWeatherGlyph(ctx, type, cx, cy, size) {
  ctx.save()
  ctx.strokeStyle = '#FFD54F'
  ctx.fillStyle = '#FFD54F'
  ctx.lineWidth = Math.max(2, size * 0.08)
  ctx.lineCap = 'round'
  ctx.lineJoin = 'round'

  if (type === 'SUN') {
    const r = size * 0.22
    ctx.beginPath()
    ctx.arc(cx, cy, r, 0, Math.PI * 2)
    ctx.fill()
    for (let i = 0; i < 8; i++) {
      const angle = (i * Math.PI) / 4
      const r1 = size * 0.34
      const r2 = size * 0.48
      ctx.beginPath()
      ctx.moveTo(cx + Math.cos(angle) * r1, cy + Math.sin(angle) * r1)
      ctx.lineTo(cx + Math.cos(angle) * r2, cy + Math.sin(angle) * r2)
      ctx.stroke()
    }
  } else if (type === 'CLOUD') {
    const s = size * 0.5
    ctx.beginPath()
    ctx.arc(cx - s * 0.5, cy, s * 0.5, Math.PI, 0)
    ctx.arc(cx, cy - s * 0.2, s * 0.6, Math.PI, 0)
    ctx.arc(cx + s * 0.5, cy, s * 0.5, Math.PI, 0)
    ctx.lineTo(cx + s, cy + s * 0.2)
    ctx.lineTo(cx - s, cy + s * 0.2)
    ctx.closePath()
    ctx.fill()
  } else if (type === 'RAIN') {
    const s = size * 0.5
    ctx.beginPath()
    ctx.arc(cx - s * 0.5, cy - s * 0.2, s * 0.4, Math.PI, 0)
    ctx.arc(cx, cy - s * 0.4, s * 0.5, Math.PI, 0)
    ctx.arc(cx + s * 0.5, cy - s * 0.2, s * 0.4, Math.PI, 0)
    ctx.lineTo(cx + s, cy)
    ctx.lineTo(cx - s, cy)
    ctx.closePath()
    ctx.fill()
    ctx.strokeStyle = '#4FC3F7'
    ctx.fillStyle = '#4FC3F7'
    ctx.lineWidth = Math.max(2, size * 0.1)
    for (let i = -1; i <= 1; i++) {
      const dx = cx + i * size * 0.25
      const dy = cy + size * 0.2
      ctx.beginPath()
      ctx.moveTo(dx, dy)
      ctx.lineTo(dx, dy + size * 0.3)
      ctx.stroke()
    }
  } else if (type === 'SNOW') {
    const s = size * 0.5
    ctx.beginPath()
    ctx.arc(cx - s * 0.5, cy - s * 0.2, s * 0.4, Math.PI, 0)
    ctx.arc(cx, cy - s * 0.4, s * 0.5, Math.PI, 0)
    ctx.arc(cx + s * 0.5, cy - s * 0.2, s * 0.4, Math.PI, 0)
    ctx.lineTo(cx + s, cy)
    ctx.lineTo(cx - s, cy)
    ctx.closePath()
    ctx.fill()
    ctx.strokeStyle = '#E1F5FE'
    ctx.fillStyle = '#E1F5FE'
    ctx.lineWidth = Math.max(2, size * 0.1)
    for (let i = -1; i <= 1; i++) {
      const dx = cx + i * size * 0.25
      const dy = cy + size * 0.35
      for (let a = 0; a < 3; a++) {
        const ang = (a * Math.PI) / 3
        const r1 = size * 0.1
        const r2 = size * 0.18
        ctx.beginPath()
        ctx.moveTo(dx - Math.cos(ang) * r1, dy - Math.sin(ang) * r1)
        ctx.lineTo(dx + Math.cos(ang) * r2, dy + Math.sin(ang) * r2)
        ctx.moveTo(dx - Math.cos(ang) * r1, dy + Math.sin(ang) * r1)
        ctx.lineTo(dx + Math.cos(ang) * r2, dy - Math.sin(ang) * r2)
        ctx.stroke()
      }
    }
  } else if (type === 'STORM') {
    const s = size * 0.5
    ctx.beginPath()
    ctx.arc(cx - s * 0.5, cy - s * 0.3, s * 0.4, Math.PI, 0)
    ctx.arc(cx, cy - s * 0.5, s * 0.5, Math.PI, 0)
    ctx.arc(cx + s * 0.5, cy - s * 0.3, s * 0.4, Math.PI, 0)
    ctx.lineTo(cx + s, cy - s * 0.1)
    ctx.lineTo(cx - s, cy - s * 0.1)
    ctx.closePath()
    ctx.fill()
    ctx.fillStyle = '#FFD54F'
    ctx.beginPath()
    ctx.moveTo(cx - size * 0.08, cy)
    ctx.lineTo(cx + size * 0.08, cy)
    ctx.lineTo(cx - size * 0.05, cy + size * 0.15)
    ctx.lineTo(cx + size * 0.1, cy + size * 0.15)
    ctx.lineTo(cx - size * 0.1, cy + size * 0.4)
    ctx.lineTo(cx + size * 0.02, cy + size * 0.22)
    ctx.lineTo(cx - size * 0.1, cy + size * 0.22)
    ctx.closePath()
    ctx.fill()
  } else if (type === 'FOG') {
    ctx.strokeStyle = '#B0BEC5'
    ctx.fillStyle = '#B0BEC5'
    ctx.lineWidth = Math.max(3, size * 0.1)
    for (let i = 0; i < 3; i++) {
      const yy = cy - size * 0.25 + i * size * 0.25
      const x1 = cx - size * (0.4 - i * 0.05)
      const x2 = cx + size * (0.4 - i * 0.05)
      ctx.beginPath()
      ctx.moveTo(x1, yy)
      ctx.lineTo(x2, yy)
      ctx.stroke()
    }
  }
  ctx.restore()
}

// ============================================================
// DRAW WEATHER CARD — DARK THEME
// ============================================================
function drawWeatherCard(data) {
  const W = 900, H = 1200
  const canvas = createCanvas(W, H)
  const ctx = canvas.getContext('2d')

  const current = data.current_condition[0]
  const area = data.nearest_area[0]
  const today = data.weather[0]
  const tomorrow = data.weather[1] || today
  const dayAfter = data.weather[2] || today

  const code = WEATHER_CODES[current.weatherCode] || DEFAULT_CODE
  const grad = code.gradient

  // === DARK BACKGROUND ===
  const bg = ctx.createLinearGradient(0, 0, 0, H)
  bg.addColorStop(0, grad[0])
  bg.addColorStop(0.5, grad[1])
  bg.addColorStop(1, grad[2])
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, W, H)

  // === Subtle accent line at top ===
  ctx.fillStyle = '#FFD54F'
  ctx.fillRect(0, 0, W, 4)

  // === HEADER ===
  ctx.fillStyle = '#ffffff'
  ctx.textAlign = 'left'
  ctx.textBaseline = 'top'

  // Location with pin marker (yellow)
  ctx.fillStyle = '#FFD54F'
  ctx.beginPath()
  ctx.arc(70, 75, 6, 0, Math.PI * 2)
  ctx.fill()
  ctx.fillRect(68, 75, 4, 16)
  ctx.beginPath()
  ctx.moveTo(60, 88); ctx.lineTo(80, 88); ctx.lineTo(70, 100); ctx.closePath()
  ctx.fill()

  ctx.fillStyle = '#ffffff'
  ctx.font = 'bold 36px Arial, sans-serif'
  ctx.fillText(area.areaName[0].value || 'Unknown', 90, 55)

  ctx.font = '20px Arial, sans-serif'
  ctx.fillStyle = '#FFD54F'
  ctx.fillText((area.region[0].value || '') + ', ' + (area.country[0].value || ''), 90, 100)

  ctx.font = '14px Arial, sans-serif'
  ctx.fillStyle = '#9E9E9E'
  ctx.fillText('Lat ' + area.latitude + ' / Lon ' + area.longitude, 90, 130)
  ctx.fillText('Obs: ' + (current.observation_time || '-'), 90, 152)

  // Big weather glyph top-right
  drawWeatherGlyph(ctx, code.glyph, W - 110, 110, 160)

  // Big temperature
  ctx.fillStyle = '#ffffff'
  ctx.font = 'bold 110px Arial, sans-serif'
  ctx.fillText(current.temp_C + 'C', 50, 195)

  ctx.font = 'bold 28px Arial, sans-serif'
  ctx.fillStyle = '#FFD54F'
  ctx.fillText(code.desc, 50, 310)

  ctx.font = '16px Arial, sans-serif'
  ctx.fillStyle = '#BDBDBD'
  ctx.fillText('Feels like ' + current.FeelsLikeC + 'C', 50, 348)

  // === STATS GRID (4 columns) ===
  const stats = [
    { label: 'HUMIDITY',   value: current.humidity + '%' },
    { label: 'WIND',       value: current.windspeedKmph + ' km/h ' + current.winddir16Point },
    { label: 'PRESSURE',   value: current.pressure + ' mb' },
    { label: 'VISIBILITY', value: current.visibility + ' km' }
  ]

  const statY = 410
  const statH = 110
  const statW = (W - 60 - 30) / 4
  stats.forEach((s, i) => {
    const sx = 30 + i * (statW + 10)

    // Card background (solid dark, lebih solid dari glass)
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)'
    roundRect(ctx, sx, statY, statW, statH, 12)
    ctx.fill()
    ctx.strokeStyle = 'rgba(255, 215, 79, 0.3)'
    ctx.lineWidth = 1
    ctx.stroke()

    // Accent bar di kiri card
    ctx.fillStyle = '#FFD54F'
    ctx.fillRect(sx, statY, 3, statH)

    // Value
    ctx.fillStyle = '#ffffff'
    ctx.textAlign = 'center'
    ctx.font = 'bold 22px Arial, sans-serif'
    ctx.fillText(s.value, sx + statW / 2, statY + 35)

    // Label
    ctx.font = '11px Arial, sans-serif'
    ctx.fillStyle = '#9E9E9E'
    ctx.fillText(s.label, sx + statW / 2, statY + 75)
  })

  // === 3-DAY FORECAST ===
  ctx.fillStyle = '#ffffff'
  ctx.textAlign = 'left'
  ctx.font = 'bold 20px Arial, sans-serif'
  ctx.fillText('3-DAY FORECAST', 30, 555)

  const days = [
    { name: 'TODAY',     data: today },
    { name: 'TOMORROW',  data: tomorrow },
    { name: 'DAY AFTER', data: dayAfter }
  ]

  const dayY = 590
  const dayH = 170
  const dayW = (W - 60 - 20) / 3
  days.forEach((d, i) => {
    const dx = 30 + i * (dayW + 10)
    const midHour = d.data.hourly[4] || d.data.hourly[Math.floor(d.data.hourly.length / 2)]
    const dayCode = WEATHER_CODES[midHour.weatherCode] || DEFAULT_CODE

    // Card
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)'
    roundRect(ctx, dx, dayY, dayW, dayH, 12)
    ctx.fill()
    ctx.strokeStyle = 'rgba(255, 215, 79, 0.3)'
    ctx.lineWidth = 1
    ctx.stroke()

    // Day name
    ctx.fillStyle = '#FFD54F'
    ctx.textAlign = 'center'
    ctx.font = 'bold 14px Arial, sans-serif'
    ctx.fillText(d.name, dx + dayW / 2, dayY + 15)

    // Weather glyph
    drawWeatherGlyph(ctx, dayCode.glyph, dx + dayW / 2, dayY + 60, 60)

    // Description
    ctx.fillStyle = '#ffffff'
    ctx.font = '12px Arial, sans-serif'
    ctx.fillText(dayCode.desc, dx + dayW / 2, dayY + 100)

    // Temp range
    ctx.font = 'bold 18px Arial, sans-serif'
    ctx.fillText(d.data.mintempC + ' / ' + d.data.maxtempC + ' C', dx + dayW / 2, dayY + 125)

    // Sun info
    ctx.font = '10px Arial, sans-serif'
    ctx.fillStyle = '#9E9E9E'
    ctx.fillText('Sun: ' + d.data.astronomy[0].sunrise + ' - ' + d.data.astronomy[0].sunset, dx + dayW / 2, dayY + 150)
  })

  // === HOURLY FORECAST ===
  ctx.fillStyle = '#ffffff'
  ctx.textAlign = 'left'
  ctx.font = 'bold 20px Arial, sans-serif'
  ctx.fillText('HOURLY FORECAST', 30, 790)

  // Card background
  const hourCardY = 825
  const hourCardH = 320
  ctx.fillStyle = 'rgba(255, 255, 255, 0.08)'
  roundRect(ctx, 30, hourCardY, W - 60, hourCardH, 12)
  ctx.fill()
  ctx.strokeStyle = 'rgba(255, 215, 79, 0.3)'
  ctx.lineWidth = 1
  ctx.stroke()

  // Get 8 hourly entries
  const hourly = today.hourly
  const targetCount = 8
  const step = Math.max(1, Math.floor(hourly.length / targetCount))
  const hourlyData = []
  for (let i = 0; i < hourly.length && hourlyData.length < targetCount; i += step) {
    hourlyData.push(hourly[i])
  }

  const hourW = (W - 100) / 8
  hourlyData.forEach((h, i) => {
    const hx = 50 + i * hourW
    const hCode = WEATHER_CODES[h.weatherCode] || DEFAULT_CODE

    // Time
    ctx.fillStyle = '#FFD54F'
    ctx.textAlign = 'center'
    ctx.font = 'bold 14px Arial, sans-serif'
    ctx.fillText(formatHour(h.time), hx + hourW / 2, hourCardY + 20)

    // Weather glyph
    drawWeatherGlyph(ctx, hCode.glyph, hx + hourW / 2, hourCardY + 70, 50)

    // Temperature
    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 18px Arial, sans-serif'
    ctx.fillText((h.tempC || h.temp_C || '?') + ' C', hx + hourW / 2, hourCardY + 115)

    // Feels like
    ctx.font = '11px Arial, sans-serif'
    ctx.fillStyle = '#9E9E9E'
    ctx.fillText('Feels ' + (h.FeelsLikeC || '?'), hx + hourW / 2, hourCardY + 135)

    // Rain bar
    const rain = parseInt(h.chanceofrain) || 0
    const barX = hx + hourW / 2 - 12
    const barY = hourCardY + 165
    const barW = 24
    const barH = 80
    ctx.fillStyle = 'rgba(255, 255, 255, 0.1)'
    ctx.fillRect(barX, barY, barW, barH)

    if (rain > 0) {
      const rainH = (rain / 100) * barH
      const rainGrad = ctx.createLinearGradient(0, barY + barH - rainH, 0, barY + barH)
      rainGrad.addColorStop(0, '#4FC3F7')
      rainGrad.addColorStop(1, '#0277BD')
      ctx.fillStyle = rainGrad
      ctx.fillRect(barX, barY + barH - rainH, barW, rainH)
    }

    // Rain %
    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 11px Arial, sans-serif'
    ctx.fillText(rain + '%', hx + hourW / 2, hourCardY + 270)
    ctx.font = '9px Arial, sans-serif'
    ctx.fillStyle = '#9E9E9E'
    ctx.fillText('RAIN', hx + hourW / 2, hourCardY + 285)
  })

  // === FOOTER ===
  ctx.fillStyle = '#616161'
  ctx.font = 'italic 12px Arial, sans-serif'
  ctx.textAlign = 'center'
  ctx.fillText('Data: wttr.in / World Weather Online', W / 2, 1170)
  ctx.fillText('Generated: ' + new Date().toLocaleString('id-ID'), W / 2, 1188)

  return canvas.toBuffer('image/jpeg', { quality: 0.92 })
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.lineTo(x + w - r, y)
  ctx.arcTo(x + w, y, x + w, y + r, r)
  ctx.lineTo(x + w, y + h - r)
  ctx.arcTo(x + w, y + h, x + w - r, y + h, r)
  ctx.lineTo(x + r, y + h)
  ctx.arcTo(x, y + h, x, y + h - r, r)
  ctx.lineTo(x, y + r)
  ctx.arcTo(x, y, x + r, y, r)
  ctx.closePath()
}

function formatHour(time) {
  const t = String(time).padStart(4, '0')
  return t.slice(0, 2) + ':' + t.slice(2, 4)
}

// ============================================================
// HANDLER
// ============================================================
let handler = async (m, { conn, args }) => {
  try {
    if (!args[0]) {
      return m.reply('Mau cek cuaca daerah mana?\n\n*Contoh:*\n.cuaca Jakarta\n.cuaca Bandung\n.cuaca "New York"')
    }

    const lokasi = args.join(' ')
    await m.reply('[Cuaca] Lagi ngintip langit buat *' + lokasi + '*...')

    const url = 'https://wttr.in/' + encodeURIComponent(lokasi) + '?format=j1'
    const response = await fetch(url, {
      headers: { 'User-Agent': 'curl/7.88.1' }
    })

    if (!response.ok) {
      throw Error('Lokasi "' + lokasi + '" gak ketemu. Coba nama kota lain?')
    }

    const data = await response.json()

    if (!data.current_condition || !data.nearest_area || !data.weather) {
      throw Error('Response API ngaco. Coba lagi nanti.')
    }

    let buffer
    try {
      buffer = drawWeatherCard(data)
    } catch (canvasErr) {
      console.error('Canvas error:', canvasErr)
      const current = data.current_condition[0]
      const area = data.nearest_area[0]
      return m.reply(
        '*Cuaca ' + (area.areaName[0].value || lokasi) + '*\n\n' +
        (area.region[0].value || '') + ', ' + (area.country[0].value || '') + '\n' +
        'Suhu: *' + current.temp_C + 'C* (terasa ' + current.FeelsLikeC + 'C)\n' +
        (current.weatherDesc[0].value || '-') + '\n' +
        'Lembab: ' + current.humidity + '%\n' +
        'Angin: ' + current.windspeedKmph + ' km/h (' + current.winddir16Point + ')\n' +
        'Visibility: ' + current.visibility + ' km'
      )
    }

    const current = data.current_condition[0]
    const area = data.nearest_area[0]
    const today = data.weather[0]
    const code = WEATHER_CODES[current.weatherCode] || DEFAULT_CODE

    const caption =
      '*Cuaca ' + (area.areaName[0].value || lokasi) + '*\n' +
      (area.region[0].value || '') + ', ' + (area.country[0].value || '') + '\n' +
      'Suhu: ' + current.temp_C + 'C (terasa ' + current.FeelsLikeC + 'C)\n' +
      code.desc + '\n' +
      'Range: ' + today.mintempC + 'C - ' + today.maxtempC + 'C\n' +
      'Sunrise: ' + today.astronomy[0].sunrise + ' | Sunset: ' + today.astronomy[0].sunset

    await conn.sendFile(m.chat, buffer, 'cuaca.jpg', caption, m)
  } catch (e) {
    await m.reply('Error: ' + e.message)
  }
}

handler.help = ['cuaca <kota>']
handler.command = ['cuaca', 'weather']
handler.tags = ['tools']

handler.limit = 10
export default handler