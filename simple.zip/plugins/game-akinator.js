import { gotScraping } from 'got-scraping'

class Akinator {
  constructor({ region = 'id', childMode = true } = {}) {
    this.region = region
    this.childMode = childMode
    this.baseUrl = `https://${region}.akinator.com`
    this.cookies = new Map()
    this.step = 1
    this.progress = 0
    this.question = ''
    this.session = ''
    this.signature = ''
    this.step_last_proposition = ''
    this.sid = '1'
    this.isWin = false
    this.sugestion_name = ''
    this.sugestion_desc = ''
    this.sugestion_photo = ''
  }

  _cleanText(str) {
    if (!str) return ''
    return str
      .replace(/&nbsp;/g, ' ')
      .replace(/&#(\d+);/g, (_, dec) => String.fromCharCode(dec))
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#039;/g, "'")
      .trim()
  }

  _getCookieHeader() {
    return Array.from(this.cookies.entries()).map(([k, v]) => `${k}=${v}`).join('; ')
  }

  _saveCookies(setCookies) {
    if (!setCookies) return
    const list = Array.isArray(setCookies) ? setCookies : [setCookies]
    for (const raw of list) {
      const parts = raw.split(';')[0].split('=')
      const key = parts[0].trim()
      const val = parts.slice(1).join('=').trim()
      if (key) this.cookies.set(key, val)
    }
  }

  async _request(path, data = null) {
    const url = new URL(path, this.baseUrl).toString()
    const cookieHeader = this._getCookieHeader()
    const headers = {
      'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    }
    if (cookieHeader) headers['cookie'] = cookieHeader

    let res
    if (data) {
      headers['content-type'] = 'application/x-www-form-urlencoded'
      headers['x-requested-with'] = 'XMLHttpRequest'
      headers['origin'] = this.baseUrl
      headers['referer'] = `${this.baseUrl}/game`
      res = await gotScraping.post(url, { headers, form: data, throwHttpErrors: false })
    } else {
      res = await gotScraping.get(url, { headers, throwHttpErrors: false })
    }

    this._saveCookies(res.headers['set-cookie'])
    return res
  }

  async start() {
    await this._request('/')
    const res = await this._request('/game', {
      sid: this.sid,
      cm: this.childMode ? 'true' : 'false'
    })

    if (res.statusCode !== 200) {
      throw new Error(`Server Akinator merespon HTTP ${res.statusCode}`)
    }

    const html = res.body
    this.session = html.match(/name="session"[^>]*value="([^"]+)"/i)?.[1]
      || html.match(/id="session"[^>]*value="([^"]+)"/i)?.[1]
      || html.match(/session:\s*['"]([^'"]+)['"]/i)?.[1]
      || html.match(/localStorage\.setItem\('session',\s*'([^']+)'\)/i)?.[1]

    this.signature = html.match(/name="signature"[^>]*value="([^"]+)"/i)?.[1]
      || html.match(/id="signature"[^>]*value="([^"]+)"/i)?.[1]
      || html.match(/signature:\s*['"]([^'"]+)['"]/i)?.[1]
      || ''

    const rawQuestion = html.match(/<p[^>]*class="[^"]*question-text[^"]*"[^>]*>([\s\S]*?)<\/p>/i)?.[1]
      || html.match(/id="question-label"[^>]*>([\s\S]*?)<\/p>/i)?.[1]
      || html.match(/<div class="bubble-body">[\s\S]*?<p[^>]*>([\s\S]*?)<\/p>/i)?.[1]

    this.question = this._cleanText(rawQuestion)
    this.step = parseInt(html.match(/localStorage\.setItem\('step',\s*'([^']+)'\)/)?.[1] || '1')
    this.progress = parseFloat(html.match(/localStorage\.setItem\('progression',\s*'([^']+)'\)/)?.[1] || '0')

    if (!this.session || !this.question) {
      throw new Error('Gagal mengekstrak sesi Akinator dari response')
    }
    return this
  }

  async answer(answerId) {
    const res = await this._request('/answer', {
      step: String(this.step),
      progression: String(this.progress),
      sid: this.sid,
      cm: this.childMode ? 'true' : 'false',
      answer: String(answerId),
      step_last_proposition: this.step_last_proposition,
      session: this.session,
      signature: this.signature
    })

    if (res.statusCode !== 200) {
      throw new Error(`Server Akinator merespon HTTP ${res.statusCode}`)
    }

    const data = JSON.parse(res.body)
    if (data.completion !== 'OK') {
      throw new Error(`Respon Akinator: ${data.completion}`)
    }

    if (data.session) this.session = data.session
    if (data.signature) this.signature = data.signature

    if (data.id_proposition) {
      this.isWin = true
      this.sugestion_name = this._cleanText(data.name_proposition)
      this.sugestion_desc = this._cleanText(data.description_proposition)
      this.sugestion_photo = data.photo
    } else {
      this.step = parseInt(data.step)
      this.progress = parseFloat(data.progression)
      this.question = this._cleanText(data.question)
    }
    return this
  }

  async back() {
    const res = await this._request('/cancel_answer', {
      step: String(this.step),
      progression: String(this.progress),
      sid: this.sid,
      cm: this.childMode ? 'true' : 'false',
      session: this.session,
      signature: this.signature
    })

    if (res.statusCode !== 200) {
      throw new Error(`Server Akinator merespon HTTP ${res.statusCode}`)
    }

    const data = JSON.parse(res.body)
    if (data.session) this.session = data.session
    if (data.signature) this.signature = data.signature
    this.step = parseInt(data.step)
    this.progress = parseFloat(data.progression)
    this.question = this._cleanText(data.question)
    return this
  }
}

if (!global.akinatorSessions) global.akinatorSessions = {}

const ANSWERS = {
  '1': 0, 'ya': 0, 'yes': 0, 'y': 0,
  '2': 1, 'tidak': 1, 'no': 1, 't': 1,
  '3': 2, 'tidak tahu': 2, 'idk': 2,
  '4': 3, 'mungkin': 3,
  '5': 4, 'mungkin tidak': 4,
  '0': 'back', 'kembali': 'back', 'b': 'back'
}

const renderProgressBar = (progress) => {
  const total = 10
  const filled = Math.min(total, Math.max(0, Math.round((progress / 100) * total)))
  return '■'.repeat(filled) + '□'.repeat(total - filled)
}

const buildQuestion = (aki) =>
`╭───〔 *AKINATOR* 〕
│
├ *Pertanyaan #${aki.step}*
│ "${aki.question}"
│
├ *Progres :* [${renderProgressBar(aki.progress)}] ${Math.round(aki.progress)}%
│
├ *Pilihan :*
│ [ 1 ] Ya
│ [ 2 ] Tidak
│ [ 3 ] Tidak Tahu
│ [ 4 ] Mungkin
│ [ 5 ] Mungkin Tidak
│ [ 0 ] Kembali
│
╰────────────────────────
> Ketik *.akistop* untuk menyerah`

let handler = async (m, { conn, command }) => {
  const id = m.chat

  if (/^akistop$/i.test(command)) {
    if (!global.akinatorSessions[id]) return m.reply('Tidak ada sesi game yang sedang aktif.')
    delete global.akinatorSessions[id]
    return m.reply('Sesi permainan telah dihentikan.')
  }

  if (global.akinatorSessions[id]) return m.reply('Sesi Akinator masih berjalan.\nKetik *.akistop* jika ingin berhenti.')

  try {
    await m.reply('Menghubungkan ke Akinator...')
    const aki = new Akinator({ region: 'id', childMode: true })
    await aki.start()
    global.akinatorSessions[id] = { aki, sender: m.sender, loading: false }
    await conn.sendMessage(m.chat, { text: buildQuestion(aki) }, { quoted: m })
  } catch (e) {
    delete global.akinatorSessions[id]
    m.reply(`Gagal memulai: ${e.message}`)
  }
}

handler.before = async function (m, { conn }) {
  const id = m.chat
  const session = global.akinatorSessions?.[id]
  if (!session) return
  if (m.sender !== session.sender) return

  const input = m.text?.toLowerCase().trim()
  const answer = ANSWERS[input]
  if (answer === undefined) return

  if (session.loading) return
  session.loading = true

  const { aki } = session

  try {
    if (answer === 'back') {
      if (aki.step <= 1) {
        m.reply('Sudah berada di pertanyaan pertama.')
        session.loading = false
        return !0
      }
      await aki.back()
    } else {
      await aki.answer(answer)
    }

    if (aki.isWin) {
      delete global.akinatorSessions[id]
      const caption = `╭───〔 *AKINATOR GUESS* 〕\n│\n├ *Nama :* ${aki.sugestion_name}\n├ *Deskripsi :* ${aki.sugestion_desc}\n│\n╰────────────────────────\n_Apakah tebakan ini benar?_`
      if (aki.sugestion_photo) {
        await conn.sendMessage(m.chat, {
          image: { url: aki.sugestion_photo },
          caption
        }, { quoted: m })
      } else {
        await conn.sendMessage(m.chat, { text: caption }, { quoted: m })
      }
      return !0
    }

    await conn.sendMessage(m.chat, { text: buildQuestion(aki) }, { quoted: m })
  } catch (e) {
    delete global.akinatorSessions[id]
    m.reply(`Terjadi kendala: ${e.message}`)
  } finally {
    if (global.akinatorSessions[id]) {
      global.akinatorSessions[id].loading = false
    }
  }

  return !0
}

handler.help = ['akinator', 'aki', 'akistop']
handler.tags = ['game']
handler.command = /^(akinator|aki|akistop)$/i

export default handler