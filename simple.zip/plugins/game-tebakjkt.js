import axios from 'axios'

let timeout = 60000 // 60 detik

let handler = async (m, { conn, command, isAdmin, isOwner }) => {
  global.tebakjkt = global.tebakjkt || {}
  const chat = m.chat
  const room = global.tebakjkt[chat] || {}

  if (command === "tebakjkt" || command === "tjkt") {
    if (room.answer) 
      return conn.reply(chat, "❌ Masih ada soal belum terjawab di chat ini.", m)

    try {
      // Ambil data dari GitHub
      const res = await axios.get(
        "https://raw.githubusercontent.com/siputzx/tebak-jkt/main/tebak.json",
        { timeout: 30000 }
      )

      const list = res.data
      const pick = list[Math.floor(Math.random() * list.length)]

      // Kirim gambar
      await conn.sendMessage(
        chat,
        {
          image: { url: pick.gambar },
          caption: `👤 *TEBAK JKT48*\n\n🖼️ Siapa nama member JKT48 di gambar ini?\n⏳ Waktu: *60 detik*\n💡 Ketik jawaban langsung.\n🔑 Ketik *.whojkt* untuk klu (Admin saja).\n📝 Ketik *.hintjkt* untuk hint (Semua user).`,
        },
        { quoted: m }
      )

      global.tebakjkt[chat] = {
        answer: pick.jawaban.toLowerCase(),
        player: m.sender,
        timer: setTimeout(() => {
          conn.reply(chat, `❌ Waktu habis!\nJawaban: *${pick.jawaban}*`)
          delete global.tebakjkt[chat]
        }, timeout),
      }

    } catch (error) {
      console.error('Error fetching data:', error)
      return conn.reply(chat, "❌ Gagal mengambil data. Coba lagi nanti!", m)
    }
  }

  // Fitur clue (hanya admin/owner) - Full clue
  if (command === "whojkt") {
    if (!room.answer) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    if (!isAdmin && !isOwner)
      return conn.reply(chat, "❌ Klu hanya untuk admin/owner.", m)

    const ans = room.answer
    const words = ans.split(' ')
    let hint = words.map(word => {
      if (word.length <= 2) return word
      return word[0] + "_".repeat(word.length - 2) + word.slice(-1)
    }).join(' ')
    
    return conn.reply(chat, `🧩 *KLU:* ${hint}`, m)
  }

  // Fitur hint (semua user) - Simple hint
  if (command === "hintjkt") {
    if (!room.answer) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    
    const ans = room.answer
    const hint = ans[0] + "_".repeat(Math.max(ans.length - 2, 1)) + ans.slice(-1)
    return conn.reply(chat, `🧩 *HINT:* ${hint}`, m)
  }

  // Fitur cek player
  if (command === "whojktplayer") {
    if (!room.player) 
      return conn.reply(chat, "❌ Tidak ada game aktif.", m)
    return conn.reply(
      chat,
      `👤 Player: @${room.player.split("@")[0]}`,
      m,
      { mentions: [room.player] }
    )
  }

  // Fitur total member (info tambahan)
  if (command === "totaljkt") {
    try {
      const res = await axios.get(
        "https://raw.githubusercontent.com/siputzx/tebak-jkt/main/tebak.json",
        { timeout: 30000 }
      )
      const total = res.data.length
      return conn.reply(chat, `👥 *Total Member JKT48:* ${total} orang`, m)
    } catch (error) {
      return conn.reply(chat, "❌ Gagal mengambil data!", m)
    }
  }
}

handler.all = async function (m) {
  const room = global.tebakjkt?.[m.chat]
  if (!room?.answer) return

  const text = (m.text || "").trim().toLowerCase()
  if (!text) return

  // Cek jawaban (case insensitive)
  if (text === room.answer) {
    clearTimeout(room.timer)
    await this.reply(m.chat, `✅ *Benar!* 🎉\nJawaban: *${room.answer}*`, m)
    delete global.tebakjkt[m.chat]
  }
}

handler.help = ["tebakjkt"]
handler.tags = ["game"]
handler.command = /^(tebakjkt|tjkt|whojkt|hintjkt|whojktplayer|totaljkt)$/i
handler.limit = 10

export default handler