const sessions = new Map()

const MIN_BET = 1000
const MAX_BET = 5000000
const SESSION_TIMEOUT = 5 * 60 * 1000

const LEVELS = [
  { level: 1, multiplier: 1.00, risk: 50 },
  { level: 2, multiplier: 1.30, risk: 50 },
  { level: 3, multiplier: 1.75, risk: 50 },
  { level: 4, multiplier: 2.40, risk: 60 },
  { level: 5, multiplier: 3.30, risk: 60 },
  { level: 6, multiplier: 4.80, risk: 60 },
  { level: 7, multiplier: 7.00, risk: 80 },
  { level: 8, multiplier: 10.00, risk: 83 },
  { level: 9, multiplier: 15.00, risk: 86 },
  { level: 10, multiplier: 25.00, risk: 88 }
]

const formatMoney = value =>
  `Rp${Number(value || 0).toLocaleString('id-ID')}`

const getKey = m => m.sender

const getLevel = level =>
  LEVELS[
    Math.min(
      Math.max(level - 1, 0),
      LEVELS.length - 1
    )
  ]

const deleteSession = m => {
  sessions.delete(getKey(m))
}

const getSession = m => {
  const session = sessions.get(getKey(m))

  if (!session) return null

  if (
    Date.now() - session.updatedAt >
    SESSION_TIMEOUT
  ) {
    sessions.delete(getKey(m))
    return null
  }

  return session
}

const editMessage = async (
  conn,
  chat,
  key,
  text
) => {
  if (!key) {
    return conn.sendMessage(
      chat,
      { text }
    )
  }

  try {
    return await conn.sendMessage(
      chat,
      {
        text,
        edit: key
      }
    )
  } catch {
    return conn.sendMessage(
      chat,
      { text }
    )
  }
}

const createSession = (
  m,
  bet,
  messageKey
) => {
  const level = getLevel(1)

  const session = {
    sender: m.sender,
    chat: m.chat,
    bet,
    level: 1,
    multiplier: level.multiplier,
    reward: Math.floor(
      bet * level.multiplier
    ),
    createdAt: Date.now(),
    updatedAt: Date.now(),
    jackpot: false,
    messageKey
  }

  sessions.set(
    getKey(m),
    session
  )

  return session
}

const progressBar = (
  current,
  total
) => {
  const size = 10

  const filled = Math.round(
    (current / total) * size
  )

  return (
    '▰'.repeat(filled) +
    '▱'.repeat(size - filled)
  )
}

const riskStatus = risk => {
  if (risk <= 40)
    return '🟢 RENDAH'

  if (risk <= 60)
    return '🟡 SEDANG'

  if (risk <= 80)
    return '🟠 TINGGI'

  return '🔴 SANGAT TINGGI'
}

const gameText = (
  session,
  usedPrefix
) => {
  const current =
    getLevel(session.level)

  const next =
    session.level <
    LEVELS.length
      ? getLevel(
          session.level + 1
        )
      : null

  const profit =
    session.reward -
    session.bet

  return `
╭━━━〔 🎲 R I S K 〕━━━╮
┃
┃  💰 Modal
┃  ${formatMoney(session.bet)}
┃
┃  💎 Hadiah Saat Ini
┃  ${formatMoney(session.reward)}
┃
┃  📈 Multiplier
┃  ×${session.multiplier}
┃
╰━━━━━━━━━━━━━━━━━━╯

╭━━━〔 PROGRESS 〕━━━╮
┃
┃  Level ${session.level}/${LEVELS.length}
┃  ${progressBar(
    session.level,
    LEVELS.length
  )}
┃
┃  📊 Profit:
┃  ${profit >= 0
    ? '+' + formatMoney(profit)
    : formatMoney(profit)}
┃
╰━━━━━━━━━━━━━━━━━━╯

╭━━━〔 ⚠️ RISK 〕━━━╮
┃
┃  Risiko: ${current.risk}%
┃  Status: ${riskStatus(current.risk)}
┃
╰━━━━━━━━━━━━━━━━━━╯

${
  session.level === 1
    ? `
╭━━━〔 🔒 LOCKED 〕━━━╮
┃
┃  Cashout masih terkunci.
┃  Lewati Level 1 terlebih dahulu.
┃
┃  🔥 ${usedPrefix}risk lanjut
┃
╰━━━━━━━━━━━━━━━━━━╯
`
    : `
╭━━━〔 ACTION 〕━━━╮
┃
┃  💰 ${usedPrefix}risk ambil
┃  🔥 ${usedPrefix}risk lanjut
┃
╰━━━━━━━━━━━━━━━━━━╯
`
}

${
  next
    ? `
╭━━━〔 NEXT LEVEL 〕━━━╮
┃
┃  🎯 Level ${next.level}
┃  📈 ×${next.multiplier}
┃  💀 Risiko ${next.risk}%
┃
╰━━━━━━━━━━━━━━━━━━╯
`
    : `
╭━━━〔 👑 MAX LEVEL 〕━━━╮
┃
┃  Kamu telah mencapai
┃  level tertinggi!
┃
╰━━━━━━━━━━━━━━━━━━╯
`
}

${
  session.jackpot
    ? '🌟 *LUCKY BONUS AKTIF*\n'
    : ''
}

⏳ Session aktif selama 5 menit.
`
}

const startGame = async (
  m,
  {
    conn,
    text,
    usedPrefix
  }
) => {
  const existing =
    getSession(m)

  if (existing) {
    return editMessage(
      conn,
      m.chat,
      existing.messageKey,
      gameText(
        existing,
        usedPrefix
      )
    )
  }

  const raw =
    String(text || '').trim()

  if (!raw) {
    return m.reply(`
╭━━━〔 🎲 RISK GAME 〕━━━╮
┃
┃  Uji keberanianmu.
┃  Semakin tinggi level,
┃  semakin besar hadiahnya.
┃
╰━━━━━━━━━━━━━━━━━━╯

💡 Cara bermain:

${usedPrefix}risk <jumlah>

Contoh:
${usedPrefix}risk 10000

💰 Minimum
${formatMoney(MIN_BET)}

💰 Maximum
${formatMoney(MAX_BET)}

⚠️ Level 1 wajib dilewati
sebelum cashout tersedia.
`)
  }

  if (!/^\d+$/.test(raw)) {
    return m.reply(
      '❌ Jumlah taruhan harus berupa angka.'
    )
  }

  const bet = Number(raw)

  if (!Number.isSafeInteger(bet)) {
    return m.reply(
      '❌ Jumlah taruhan terlalu besar.'
    )
  }

  if (bet < MIN_BET) {
    return m.reply(
      `❌ Minimum taruhan ${formatMoney(MIN_BET)}.`
    )
  }

  if (bet > MAX_BET) {
    return m.reply(
      `❌ Maximum taruhan ${formatMoney(MAX_BET)}.`
    )
  }

  const user =
    global.db?.data?.users?.[m.sender]

  if (!user) {
    return m.reply(
      '❌ Data pengguna belum tersedia.'
    )
  }

  if (
    !Number.isFinite(
      Number(user.money)
    )
  ) {
    user.money = 0
  }

  user.money =
    Number(user.money)

  if (user.money < bet) {
    return m.reply(`
╭━━━〔 ❌ GAGAL 〕━━━╮
┃
┃  Uang kamu tidak cukup.
┃
┃  💰 Taruhan
┃  ${formatMoney(bet)}
┃
┃  💵 Saldo
┃  ${formatMoney(user.money)}
┃
╰━━━━━━━━━━━━━━━━━━╯
`)
  }

  user.money -= bet

  const sent =
    await conn.sendMessage(
      m.chat,
      {
        text: `
╭━━━〔 🎲 R I S K 〕━━━╮
┃
┃  💰 Modal
┃  ${formatMoney(bet)}
┃
┃  💎 Hadiah
┃  ${formatMoney(bet)}
┃
┃  🎯 Level 1
┃  📈 ×1.00
┃  💀 Risiko 30%
┃
╰━━━━━━━━━━━━━━━━━━╯

🔒 *CASHOUT TERKUNCI*

Kamu harus melewati
Level 1 terlebih dahulu.

🔥 ${usedPrefix}risk lanjut
`
      },
      {
        quoted: m
      }
    )

  createSession(
    m,
    bet,
    sent.key
  )
}

const continueGame = async (
  m,
  {
    conn,
    usedPrefix
  }
) => {
  const session =
    getSession(m)

  if (!session) {
    return m.reply(
      `❌ Tidak ada game aktif.\n\n${usedPrefix}risk 10000`
    )
  }

  session.updatedAt =
    Date.now()

  if (
    session.level >=
    LEVELS.length
  ) {
    return editMessage(
      conn,
      m.chat,
      session.messageKey,
      `
╭━━━〔 👑 MAX LEVEL 〕━━━╮
┃
┃  Kamu telah mencapai
┃  Level ${LEVELS.length}!
┃
┃  💎 Hadiah
┃  ${formatMoney(session.reward)}
┃
┃  📈 Multiplier
┃  ×${session.multiplier}
┃
╰━━━━━━━━━━━━━━━━━━╯

💰 ${usedPrefix}risk ambil
`
    )
  }

  const nextLevel =
    getLevel(
      session.level + 1
    )

  const roll =
    Math.random() * 100

  /*
   * GAGAL
   */
  if (
    roll < nextLevel.risk
  ) {
    const reward =
      session.reward

    const lastLevel =
      session.level

    const key =
      session.messageKey

    deleteSession(m)

    return editMessage(
      conn,
      m.chat,
      key,
      `
╭━━━〔 💀 GAME OVER 〕━━━╮
┃
┃  Kamu gagal melewati
┃  Level ${nextLevel.level}.
┃
╰━━━━━━━━━━━━━━━━━━╯

🎯 Level terakhir
${lastLevel}

💎 Hadiah yang hilang
${formatMoney(reward)}

💸 Semua hadiah hangus.

━━━━━━━━━━━━━━━━━━

😈 *Terlalu serakah.*

🎲 Main lagi:
${usedPrefix}risk 10000
`
    )
  }

  /*
   * BERHASIL
   */
  session.level =
    nextLevel.level

  session.multiplier =
    nextLevel.multiplier

  session.reward =
    Math.floor(
      session.bet *
      nextLevel.multiplier
    )

  session.updatedAt =
    Date.now()

  let lucky = ''

  /*
   * Lucky bonus 1%
   */
  if (
    Math.random() < 0.01
  ) {
    session.jackpot = true

    const bonus =
      Math.floor(
        session.reward * 0.25
      )

    session.reward +=
      bonus

    session.multiplier =
      Number(
        (
          session.reward /
          session.bet
        ).toFixed(2)
      )

    lucky = `
🌟 *LUCKY BONUS*

Bonus:
+${formatMoney(bonus)}
`
  }

  /*
   * MAX LEVEL
   */
  if (
    session.level ===
    LEVELS.length
  ) {
    return editMessage(
      conn,
      m.chat,
      session.messageKey,
      `
╭━━━〔 👑 VICTORY 〕━━━╮
┃
┃  Kamu berhasil mencapai
┃  MAX LEVEL!
┃
╰━━━━━━━━━━━━━━━━━━╯

🎯 Level
${session.level}

📈 Multiplier
×${session.multiplier}

💎 Hadiah
${formatMoney(session.reward)}

${lucky}

🔒 Permainan selesai.

💰 ${usedPrefix}risk ambil
`
    )
  }

  return editMessage(
    conn,
    m.chat,
    session.messageKey,
    `
╭━━━〔 🎉 SUCCESS 〕━━━╮
┃
┃  Kamu berhasil melewati
┃  Level ${session.level}!
┃
╰━━━━━━━━━━━━━━━━━━╯

🎯 Level
${session.level}/${LEVELS.length}

📈 Multiplier
×${session.multiplier}

💎 Hadiah
${formatMoney(session.reward)}

⚠️ Risiko berikutnya
${getLevel(
    session.level + 1
  ).risk}%

${lucky}

╭━━━〔 ACTION 〕━━━╮
┃
┃  💰 ${usedPrefix}risk ambil
┃  🔥 ${usedPrefix}risk lanjut
┃
╰━━━━━━━━━━━━━━━━━━╯
`
  )
}

const takeReward = async (
  m,
  {
    conn,
    usedPrefix
  }
) => {
  const session =
    getSession(m)

  if (!session) {
    return m.reply(
      `❌ Tidak ada game aktif.\n\n${usedPrefix}risk 10000`
    )
  }

  /*
   * Level 1 tidak bisa cashout
   */
  if (
    session.level < 2
  ) {
    return editMessage(
      conn,
      m.chat,
      session.messageKey,
      `
╭━━━〔 🔒 LOCKED 〕━━━╮
┃
┃  Cashout belum tersedia.
┃
┃  🎯 Level saat ini
┃  ${session.level}
┃
┃  💎 Hadiah
┃  ${formatMoney(session.reward)}
┃
╰━━━━━━━━━━━━━━━━━━╯

⚠️ Lewati Level 1 dahulu.

🔥 ${usedPrefix}risk lanjut
`
    )
  }

  const user =
    global.db?.data?.users?.[m.sender]

  if (!user) {
    const key =
      session.messageKey

    deleteSession(m)

    return editMessage(
      conn,
      m.chat,
      key,
      '❌ Data pengguna tidak ditemukan.'
    )
  }

  if (
    !Number.isFinite(
      Number(user.money)
    )
  ) {
    user.money = 0
  }

  user.money =
    Number(user.money)

  const reward =
    Number(session.reward)

  const profit =
    reward -
    session.bet

  const key =
    session.messageKey

  user.money += reward

  deleteSession(m)

  return editMessage(
    conn,
    m.chat,
    key,
    `
╭━━━〔 💰 CASHOUT 〕━━━╮
┃
┃  Hadiah berhasil diamankan!
┃
╰━━━━━━━━━━━━━━━━━━╯

🎯 Level
${session.level}

📈 Multiplier
×${session.multiplier}

💵 Modal
${formatMoney(session.bet)}

💎 Hadiah
${formatMoney(reward)}

📊 Profit
+${formatMoney(profit)}

${
  session.jackpot
    ? '🌟 Lucky Bonus: YES\n'
    : ''
}

━━━━━━━━━━━━━━━━━━

💰 Saldo sekarang
${formatMoney(user.money)}

🎉 Keputusan yang bagus.
Kamu berhasil keluar sebelum
hadiahnya hangus.

🎲 Main lagi:
.risk 10000
`
  )
}

const statusGame = async (
  m,
  {
    conn,
    usedPrefix
  }
) => {
  const session =
    getSession(m)

  if (!session) {
    return m.reply(
      `🎲 Tidak ada game aktif.\n\n${usedPrefix}risk 10000`
    )
  }

  return editMessage(
    conn,
    m.chat,
    session.messageKey,
    gameText(
      session,
      usedPrefix
    )
  )
}

let handler = async (
  m,
  {
    conn,
    text,
    usedPrefix,
    command
  }
) => {
  const args =
    String(text || '')
      .trim()
      .split(/\s+/)
      .filter(Boolean)

  const action =
    String(
      args[0] || ''
    ).toLowerCase()

  /*
   * .risk
   */
  if (!action) {
    return startGame(
      m,
      {
        conn,
        text: '',
        usedPrefix
      }
    )
  }

  /*
   * .risk lanjut
   */
  if (
    action === 'lanjut' ||
    action === 'next' ||
    action === 'continue'
  ) {
    return continueGame(
      m,
      {
        conn,
        usedPrefix
      }
    )
  }

  /*
   * .risk ambil
   */
  if (
    action === 'ambil' ||
    action === 'take' ||
    action === 'cashout'
  ) {
    return takeReward(
      m,
      {
        conn,
        usedPrefix
      }
    )
  }

  /*
   * .risk status
   */
  if (
    action === 'status' ||
    action === 'cek'
  ) {
    return statusGame(
      m,
      {
        conn,
        usedPrefix
      }
    )
  }

  /*
   * .risk <jumlah>
   */
  if (
    /^\d+$/.test(action)
  ) {
    return startGame(
      m,
      {
        conn,
        text: args.join(' '),
        usedPrefix
      }
    )
  }

  return m.reply(`
╭━━━〔 🎲 RISK GAME 〕━━━╮
┃
┃  ${usedPrefix}risk <jumlah>
┃
┃  Contoh:
┃  ${usedPrefix}risk 10000
┃
╰━━━━━━━━━━━━━━━━━━╯

🔥 ${usedPrefix}risk lanjut
💰 ${usedPrefix}risk ambil
📊 ${usedPrefix}risk status

⚠️ Semakin tinggi level,
semakin besar risikonya.
`)
}

handler.help = [
  'risk <jumlah>',
  'risk lanjut',
  'risk ambil',
  'risk status'
]

handler.tags = [
  'rpg',
  'game'
]

handler.command =
  /^risk$/i

handler.register = true

export default handler