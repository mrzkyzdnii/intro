const handler = async (m, { conn, command }) => {
    // Simpan data session per pengguna
    if (!global.slotSessions) global.slotSessions = {};
    const userId = m.sender;
    if (!global.slotSessions[userId]) {
        global.slotSessions[userId] = {
            balance: 1000000,
            bet: 10000,
            history: []
        };
    }
    const session = global.slotSessions[userId];

    const htmlContent = `
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;user-select:none}
body{margin:0;background:transparent;font-family:'Segoe UI',Arial,sans-serif;color:#eee;touch-action:manipulation}
.wrap{width:100%;max-width:480px;margin:auto;padding:12px}
.card{background:linear-gradient(145deg,#1a1a2e,#16213e);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:18px;box-shadow:0 16px 48px rgba(0,0,0,0.7)}
.header{text-align:center;margin-bottom:12px}
.header h1{font-size:28px;font-weight:900;margin:0;background:linear-gradient(135deg,#f7971e,#ffd200);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.header p{font-size:12px;color:#888;margin:2px 0 0}
.balance{background:rgba(255,255,255,0.06);border-radius:14px;padding:12px;text-align:center;margin-bottom:12px;border:1px solid rgba(255,215,0,0.2)}
.balance .amount{font-size:28px;font-weight:800;color:#ffd700}
.balance .label{font-size:13px;color:#999}
.slot-machine{background:#0f0f1a;border-radius:16px;padding:16px;border:2px solid rgba(255,215,0,0.3);margin-bottom:12px}
.reels{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:8px 0}
.reel{background:#1a1a2e;border-radius:12px;padding:12px;aspect-ratio:1;display:flex;align-items:center;justify-content:center;font-size:48px;border:2px solid rgba(255,255,255,0.08);transition:all 0.15s}
.reel.spinning{border-color:#ffd700;box-shadow:0 0 30px rgba(255,215,0,0.3)}
.reel.win{border-color:#2ed573;box-shadow:0 0 30px rgba(46,213,115,0.4)}
.result{text-align:center;font-size:18px;font-weight:700;padding:10px;border-radius:12px;margin:8px 0}
.result.win{color:#2ed573;background:rgba(46,213,115,0.15)}
.result.lose{color:#ff6b6b;background:rgba(255,107,107,0.15)}
.controls{display:grid;grid-template-columns:2fr 1fr 1fr;gap:8px;margin-top:12px}
.btn{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.1);border-radius:12px;padding:12px;color:#fff;font-size:14px;font-weight:700;cursor:pointer;transition:all 0.2s;text-align:center}
.btn:active{transform:scale(0.95)}
.btn.spin{background:linear-gradient(135deg,#f7971e,#ffd200);color:#000;font-size:18px}
.btn.spin:disabled{opacity:0.5;transform:none}
.btn.bet{background:linear-gradient(135deg,#667eea,#764ba2)}
.btn.reset{background:linear-gradient(135deg,#f093fb,#f5576c)}
.bet-controls{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:6px;margin:8px 0}
.bet-btn{background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.08);border-radius:10px;padding:8px 4px;color:#aaa;font-size:12px;font-weight:600;cursor:pointer;transition:all 0.2s;text-align:center}
.bet-btn:active{transform:scale(0.95)}
.bet-btn.active{background:linear-gradient(135deg,#f7971e,#ffd200);color:#000;border-color:#ffd200}
.history{margin-top:10px;max-height:80px;overflow-y:auto;font-size:12px;color:#888;background:rgba(0,0,0,0.3);border-radius:10px;padding:8px}
.history .h-win{color:#2ed573}
.history .h-lose{color:#ff6b6b}
.history .h-big{color:#ffd700;font-weight:700}
.footer{text-align:center;color:#666;font-size:10px;margin-top:10px}
</style>

<body>  
<div class="wrap">  
<div class="card">  
<div class="header"><h1>🎰 SLOT JUDOL</h1><p>VIP CASINO — Spin & Win!</p></div>  
<div class="balance"><div class="label">💰 SALDO</div><div class="amount" id="balance">${session.balance.toLocaleString('id-ID')}</div></div>  
<div class="slot-machine">  
<div class="reels">  
<div class="reel" id="r0">🍒</div>  
<div class="reel" id="r1">🍒</div>  
<div class="reel" id="r2">🍒</div>  
</div>  
<div id="result" class="result">Tekan SPIN untuk mulai!</div>  
</div>  
<div class="bet-controls">  
<div class="bet-btn ${session.bet === 10000 ? 'active' : ''}" data-bet="10000">10K</div>  
<div class="bet-btn ${session.bet === 50000 ? 'active' : ''}" data-bet="50000">50K</div>  
<div class="bet-btn ${session.bet === 100000 ? 'active' : ''}" data-bet="100000">100K</div>  
<div class="bet-btn ${session.bet === 500000 ? 'active' : ''}" data-bet="500000">500K</div>  
</div>  
<div class="controls">  
<button class="btn spin" id="spinBtn">🎰 SPIN</button>  
<button class="btn bet" id="maxBtn">🔥 MAX BET</button>  
<button class="btn reset" id="resetBtn">🔄 Reset</button>  
</div>  
<div class="history" id="history">${session.history.map(h => 
    `<span class="${h.amt > 0 ? 'h-win' : 'h-lose'} ${h.amt > 50000 ? 'h-big' : ''}">${h.res} ${h.amt > 0 ? '+' : ''}${h.amt.toLocaleString('id-ID')}</span>`
).join(' • ')}</div>  
<div class="footer">Fake money 1Juta • Mainkan dengan bijak</div>  
</div>  
</div>  
<script>  
// Data dari server
const sessionData = {
    balance: ${session.balance},
    bet: ${session.bet},
    history: ${JSON.stringify(session.history)}
};

let balance = sessionData.balance;  
let bet = sessionData.bet;  
let spinning = false;  
let history = sessionData.history;  
const sym = ['🍒','🍋','🍊','🍇','💎','7️⃣','⭐','🎰'];  
const val = {'🍒':1.5,'🍋':2,'🍊':2.5,'🍇':3,'💎':5,'7️⃣':8,'⭐':10,'🎰':20};  
const reels = [document.getElementById('r0'),document.getElementById('r1'),document.getElementById('r2')];  
const balanceEl = document.getElementById('balance');  
const resultEl = document.getElementById('result');  
const historyEl = document.getElementById('history');  
const spinBtn = document.getElementById('spinBtn');  
const resetBtn = document.getElementById('resetBtn');  
const maxBtn = document.getElementById('maxBtn');  
const betBtns = document.querySelectorAll('.bet-btn');  

function fmt(n){return n.toLocaleString('id-ID');}
function updBalance(){balanceEl.textContent = fmt(balance);}
function randSym(){return sym[Math.floor(Math.random()*sym.length)];}

function checkWin(r){
    if(r[0]===r[1]&&r[1]===r[2]) return {type:'jackpot', mult:val[r[0]]*2};
    if(r[0]===r[1]||r[1]===r[2]||r[0]===r[2]){
        const m = r[0]===r[1]?r[0]:r[1]===r[2]?r[1]:r[0];
        return {type:'pair', mult:val[m]};
    }
    return {type:'lose', mult:0};
}

function addHistory(res, amt){
    history.unshift({res, amt});
    if(history.length>20) history.pop();
    historyEl.innerHTML = history.map(h => {
        const cls = h.amt > 0 ? 'h-win' : 'h-lose';
        const big = h.amt > 50000 ? 'h-big' : '';
        return \`<span class="\${cls} \${big}">\${h.res} \${h.amt > 0 ? '+' : ''}\${fmt(h.amt)}</span>\`;
    }).join(' • ');
}

function spin(){
    if(spinning) return;
    if(balance < bet){ resultEl.textContent='❌ Saldo tidak cukup!'; resultEl.className='result lose'; return; }
    spinning = true;
    spinBtn.disabled = true;
    resultEl.textContent = '🎰 Spinning...';
    resultEl.className = 'result';
    reels.forEach(r => r.classList.add('spinning'));
    let count=0;
    const iv = setInterval(() => {
        reels.forEach(r => r.textContent = randSym());
        count++;
        if(count>=10){ clearInterval(iv); finish(); }
    }, 80);
}

function finish(){
    reels.forEach(r => r.classList.remove('spinning'));
    const res = reels.map(r => r.textContent);
    const win = checkWin(res);
    let amt = 0, msg = '';
    if(win.type === 'jackpot'){
        amt = bet * win.mult;
        msg = \`🎉 JACKPOT! \${res.join(' ')} — x\${win.mult.toFixed(1)}\`;
        resultEl.className = 'result win';
        reels.forEach(r => r.classList.add('win'));
        setTimeout(() => reels.forEach(r => r.classList.remove('win')), 1500);
    } else if(win.type === 'pair'){
        amt = bet * win.mult;
        msg = \`✅ Pair! \${res.join(' ')} — x\${win.mult.toFixed(1)}\`;
        resultEl.className = 'result win';
    } else {
        amt = -bet;
        msg = \`❌ Kalah! \${res.join(' ')} — -\${fmt(bet)}\`;
        resultEl.className = 'result lose';
    }
    balance += amt;
    updBalance();
    resultEl.textContent = \`\${msg} | \${amt >= 0 ? '+' : ''}\${fmt(amt)}\`;
    addHistory(res.join(' '), amt);
    if(balance <= 0){ resultEl.textContent='💸 BANKRUP! Reset saldo?'; balance=1000000; updBalance(); }
    spinning = false;
    spinBtn.disabled = false;
    
    // Kirim update ke server
    window.parent.postMessage({
        type: 'updateSession',
        balance: balance,
        bet: bet,
        history: history
    }, '*');
}

function resetGame(){
    balance = 1000000;
    history = [];
    updBalance();
    resultEl.textContent = '🔄 Game di-reset!';
    resultEl.className = 'result';
    reels.forEach((r,i) => { r.textContent = ['🍒','🍒','🍒'][i]||'🍒'; r.classList.remove('win','spinning'); });
    historyEl.innerHTML = '';
    window.parent.postMessage({
        type: 'updateSession',
        balance: balance,
        bet: bet,
        history: history
    }, '*');
}

function setBet(amount){ bet = Math.min(amount, balance); betBtns.forEach(b => b.classList.toggle('active', parseInt(b.dataset.bet)===bet)); }
function maxBet(){ const max = Math.min(500000, balance); bet = max; betBtns.forEach(b => b.classList.toggle('active', parseInt(b.dataset.bet)===max)); }

spinBtn.addEventListener('click', spin);
resetBtn.addEventListener('click', resetGame);
maxBtn.addEventListener('click', maxBet);
betBtns.forEach(b => b.addEventListener('click', () => setBet(parseInt(b.dataset.bet))));
updBalance();
</script>
</body>`;

    await conn.relayMessage(
        m.chat, {
            messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
                botMetadata: {
                    messageDisclaimerText: "",
                    botResponseId: "judol-slot-v3",
                    verificationMetadata: {
                        proofs: [{
                            version: 1,
                            useCase: 1,
                            signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                            certificateChain: ["TklYRUwuTWVzc2FnZUJ1bGRlc..."]
                        }]
                    }
                }
            },
            botForwardedMessage: {
                message: {
                    richResponseMessage: {
                        messageType: 1,
                        submessages: [{
                            messageType: 2,
                            messageText: "🎰 SLOT JUDOL — VIP CASINO"
                        }],
                        unifiedResponse: {
                            data: Buffer.from(JSON.stringify({
                                "response_id": "judol-slot-v3",
                                "sections": [{
                                    "view_model": {
                                        "primitive": {
                                            "__typename": "GenAIaeacdsnwHtmlPrimitive",
                                            "payload": htmlContent,
                                            "trusted_sources": ["kyy.dev"]
                                        },
                                        "__typename": "GenAISingleLayoutViewModel"
                                    }
                                }]
                            })).toString('base64')
                        }
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "867051314767696@bot"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }, {}
    );
}

handler.help = ['judol'];
handler.tags = ['game'];
handler.command = /^(judol)$/i;

export default handler;