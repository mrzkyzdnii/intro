import * as cheerio from 'cheerio'

const searchGoogle = async (query, max = 5) => {
  const headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'Referer': 'https://html.duckduckgo.com/'
  }

  const results = []
  let url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`
  let cookies = ''

  while (results.length < max && url) {
    const currentHeaders = { ...headers }
    if (cookies) currentHeaders['Cookie'] = cookies

    const res = await fetch(url, { headers: currentHeaders })
    const setCookie = res.headers.get('set-cookie')
    if (setCookie) cookies = setCookie.split(';')[0]

    if (!res.ok) break

    const html = await res.text()
    const $ = cheerio.load(html)

    $('.result').each((_, el) => {
      const title = $(el).find('.result__title a').text().trim()
      let link = $(el).find('.result__title a').attr('href')
      const snippet = $(el).find('.result__snippet').text().trim()

      if (title && link) {
        if (link.includes('uddg=')) {
          link = decodeURIComponent(link.split('uddg=')[1].split('&')[0])
        }
        if (link.startsWith('http') && !results.some(r => r.link === link)) {
          results.push({ title, link, snippet })
        }
      }
    })

    const form = $('.nav-link form')
    const params = new URLSearchParams()
    form.find('input').each((_, el) => {
      const name = $(el).attr('name')
      const val = $(el).attr('value')
      if (name && val) params.append(name, val)
    })

    const qs = params.toString()
    url = (results.length < max && qs) ? `https://html.duckduckgo.com/html/?${qs}` : null
  }

  return results.slice(0, max)
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Example:\n${usedPrefix + command} resep rendang --5\n${usedPrefix + command} nodejs tutorial --20`

  const match = text.match(/--(\d+)/)
  let count = match ? parseInt(match[1]) : 5
  if (count > 20) count = 20
  if (count < 1) count = 1

  const query = text.replace(/--\d+/g, '').trim()
  if (!query) throw `Masukkan keyword pencarian!\nContoh: ${usedPrefix + command} nodejs tutorial --10`

  await conn.reply(m.chat, `Mencari ${count} hasil untuk: *${query}*...`, m)

  const items = await searchGoogle(query, count)
  if (!items.length) return m.reply(`Tidak ditemukan hasil untuk: *${query}*`)

  const list = items.map((item, i) => {
    return `[ ${i + 1} ] *${item.title}*\n*URL:* ${item.link}\n*Info:* ${item.snippet || 'Tidak ada deskripsi.'}`
  }).join('\n\n────────────────────────\n\n')

  const caption = `╭───〔 *GOOGLE SEARCH* 〕\n│ Query: "${query}"\n│ Total: ${items.length} Hasil\n╰────────────────────────\n\n${list}`

  await conn.reply(m.chat, caption, m)
}

handler.help = ['google', 'googleit', 'gsearch']
handler.tags = ['search']
handler.command = /^(google|googleit|gsearch)$/i
handler.limit = 5

export default handler